import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/unified_design.dart';
import 'package:sajli/records.dart';

void main() {
  testWidgets('real Sajli student selection stays in one new Flutter workspace',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 3000);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final original = File('modules/sajli/assets/demo.json').readAsStringSync();
    final records = Records.decode(original);
    // These cases are read-only. Use the packaged fixture directly instead of
    // creating/awaiting temporary filesystem operations in the FakeAsync zone.
    final file = File('modules/sajli/assets/demo.json');
    final student = records.people.first;
    var legacyLaunches = 0;

    print('SAJLI-STUDENT-TEST: before pumpWidget');
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: UnifiedSectionPage(
      spec: unifiedSections[1], school: 'مدرستي', dayName: 'الأحد',
      lessons: const [], students: [UnifiedStudent(
        id: student['id'].toString(), name: student['name'].toString(),
        group: records.className(student['classId'].toString()),
        registerNumber: student['number']?.toString() ?? '',
        attendance: 'غير مسجّل',
      )], classCount: records.activeClasses.length,
      records: records, recordsFile: file,
      onOpenNative: () => legacyLaunches++,
      onOpenSection: (_) {}, onStudent: (_) {},
      onAttendance: () {}, onStatistics: () {},
      onTransferToBell: () {}, onOpenBooks: () {},
      onChangeDay: () {},
    ))));
    print('SAJLI-STUDENT-TEST: before first pump');
    await tester.pump();
    print('SAJLI-STUDENT-TEST: initial workspace rendered');
    expect(find.byType(UnifiedHero), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('unified-tab-sajli-students')));
    print('SAJLI-STUDENT-TEST: student tab tapped');
    await tester.pump();
    print('SAJLI-STUDENT-TEST: student tab rendered');
    final tile = find.byKey(ValueKey('unified-student-${student['id']}'));
    expect(tile, findsOneWidget);
    // Keep the complete test workspace inside the test viewport. Avoid
    // ensureVisible/scroll animations here: this test verifies navigation,
    // not scroll physics, and the previous CI run stalled while revealing
    // descendants of the nested workspace.
    expect(tile.hitTestable(), findsOneWidget, reason: 'Student tile should already be in the expanded test viewport');
    print('SAJLI-STUDENT-TEST: student tile is hit-testable');
    await tester.tap(tile);
    print('SAJLI-STUDENT-TEST: student tile tapped');
    await tester.pump();
    print('SAJLI-STUDENT-TEST: profile rendered');
    expect(find.text('البيانات الأساسية'), findsOneWidget);
    expect(find.byType(UnifiedHero), findsOneWidget,
      reason: 'The student profile must NOT add a second old/new hero.');
    expect(legacyLaunches, 0);
    expect(tester.takeException(), isNull);
  }, timeout: const Timeout(Duration(seconds: 75)));

  testWidgets('Sajli parent report uses one cohesive new design',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 3000);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final source = File('modules/sajli/assets/demo.json').readAsStringSync();
    final records = Records.decode(source);
    // This case is read-only too; the packaged fixture is sufficient.
    final file = File('modules/sajli/assets/demo.json');
    var oldLaunches = 0;
    print('SAJLI-REPORT-TEST: before pumpWidget');
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: UnifiedSectionPage(
      spec: unifiedSections[1], school: 'مدرستي', dayName: 'الأحد',
      lessons: const [], students: const [], classCount: 0,
      records: records, recordsFile: file,
      initialTab: 'reports', onOpenNative: () => oldLaunches++,
      onOpenSection: (_) {}, onStudent: (_) {},
      onAttendance: () {}, onStatistics: () {},
      onTransferToBell: () {}, onOpenBooks: () {}, onChangeDay: () {},
    ))));
    print('SAJLI-REPORT-TEST: before first pump');
    await tester.pump();
    print('SAJLI-REPORT-TEST: report rendered');
    expect(find.text('تقرير ولي الأمر'), findsOneWidget);
    // The section headings are present inside the new scrollable workspace.
    final second = find.text('ثانيًا • التحصيل الدراسي');
    // The expanded test viewport keeps the report sections visible without
    // invoking Scrollable.ensureVisible (the previous CI hang point).
    expect(second.hitTestable(), findsOneWidget, reason: 'Report block should already be visible in the expanded test viewport');
    print('SAJLI-REPORT-TEST: report section is hit-testable');
    expect(oldLaunches, 0);
    expect(tester.takeException(), isNull);
  }, timeout: const Timeout(Duration(seconds: 75)));
}
