import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'arabic_digit_formatter.dart';

/// Placed above the root Navigator, not inside a route. A dialog or a nested
/// Flutter navigator cannot accidentally cover or bypass the application lock.
class MadrasatiAppLockGate extends StatefulWidget {
  const MadrasatiAppLockGate({
    required this.verifyPin,
    required this.verifyBiometrics,
    required this.authorizeRecovery,
    required this.saveRecoveredPin,
    required this.biometricEnabled,
    super.key,
  });

  final Future<bool> Function(String pin) verifyPin;
  final Future<bool> Function() verifyBiometrics;
  final Future<bool> Function() authorizeRecovery;
  final Future<bool> Function(String pin) saveRecoveredPin;
  final bool biometricEnabled;

  @override
  State<MadrasatiAppLockGate> createState() => _MadrasatiAppLockGateState();
}

class _MadrasatiAppLockGateState extends State<MadrasatiAppLockGate> {
  final _pin = TextEditingController();
  final _confirmation = TextEditingController();
  bool _busy = false;
  bool _recoveryAuthorized = false;
  String? _error;

  @override
  void dispose() {
    _pin.dispose();
    _confirmation.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy) return;
    final pin = _pin.text;
    if (!RegExp(r'^[0-9]{4,8}$').hasMatch(pin)) {
      setState(() => _error = 'أدخل رمزاً من 4 إلى 8 أرقام.');
      return;
    }
    if (_recoveryAuthorized &&
        (pin.length < 6 || pin != _confirmation.text)) {
      setState(() => _error =
          'لاسترداد القفل، أدخل رمزاً جديداً من 6 إلى 8 أرقام وأكده.');
      return;
    }
    setState(() { _busy = true; _error = null; });
    try {
      final okay = _recoveryAuthorized
          ? await widget.saveRecoveredPin(pin)
          : await widget.verifyPin(pin);
      if (!okay && mounted) {
        setState(() => _error = 'لم يُفتح التطبيق. تحقق من الرمز أو طريقة الاسترداد.');
        _pin.clear();
        _confirmation.clear();
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'تعذّر التحقق الآن. لم يُفتح التطبيق.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _biometric() async {
    if (_busy) return;
    setState(() { _busy = true; _error = null; });
    try {
      if (!await widget.verifyBiometrics() && mounted) {
        setState(() => _error = 'تعذّر التعرف على البصمة، استخدم الرمز.');
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'البصمة غير متاحة، استخدم الرمز.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _recover() async {
    if (_busy) return;
    setState(() { _busy = true; _error = null; });
    try {
      final verified = await widget.authorizeRecovery();
      if (!mounted) return;
      if (verified) {
        _pin.clear();
        _confirmation.clear();
        setState(() => _recoveryAuthorized = true);
      } else {
        setState(() => _error =
            'لم يتم إثبات هوية صاحب الجهاز. يبقى التطبيق مقفلاً.');
      }
    } catch (_) {
      if (mounted) setState(() => _error = 'التحقق من هوية الجهاز غير متاح.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      child: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 370),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  padding: const EdgeInsets.all(23),
                  decoration: BoxDecoration(
                    color: scheme.primaryContainer,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.lock_outline_rounded, size: 48,
                      color: scheme.onPrimaryContainer),
                ),
                const SizedBox(height: 16),
                const Text('مدرستي مقفل', style: TextStyle(
                    fontSize: 23, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(_recoveryAuthorized
                    ? 'تم إثبات هوية الجهاز. أنشئ رمزاً جديداً لقفل التطبيق.'
                    : 'أدخل رمز التطبيق، أو استخدم بصمتك المسجلة على الهاتف.',
                    textAlign: TextAlign.center),
                const SizedBox(height: 18),
                TextField(
                  key: const ValueKey('app-lock-pin-input'),
                  controller: _pin,
                  keyboardType: TextInputType.number,
                  textDirection: TextDirection.ltr,
                  obscureText: true,
                  enableSuggestions: false,
                  autocorrect: false,
                  maxLength: 8,
                  inputFormatters: [
          const MadrasatiAsciiDigitFormatter(),
          FilteringTextInputFormatter.digitsOnly,
        ],
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    counterText: '',
                    labelText: _recoveryAuthorized ? 'الرمز الجديد' : 'رمز قفل التطبيق',
                  ),
                  onSubmitted: (_) => _submit(),
                ),
                if (_recoveryAuthorized) ...[
                  const SizedBox(height: 8),
                  TextField(
                    key: const ValueKey('app-lock-confirm-input'),
                    controller: _confirmation,
                    keyboardType: TextInputType.number,
                    textDirection: TextDirection.ltr,
                    obscureText: true,
                    maxLength: 8,
                    inputFormatters: [
          const MadrasatiAsciiDigitFormatter(),
          FilteringTextInputFormatter.digitsOnly,
        ],
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      counterText: '',
                      labelText: 'تأكيد الرمز الجديد',
                    ),
                    onSubmitted: (_) => _submit(),
                  ),
                ],
                if (_error != null) Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text(_error!, textAlign: TextAlign.center,
                      style: TextStyle(color: scheme.error)),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  key: const ValueKey('app-lock-submit'),
                  onPressed: _busy ? null : _submit,
                  icon: const Icon(Icons.lock_open_outlined),
                  label: Text(_recoveryAuthorized ? 'حفظ الرمز وفتح التطبيق' : 'فتح بالرمز'),
                ),
                if (widget.biometricEnabled && !_recoveryAuthorized) ...[
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    key: const ValueKey('app-lock-biometric'),
                    onPressed: _busy ? null : _biometric,
                    icon: const Icon(Icons.fingerprint),
                    label: const Text('فتح بالبصمة'),
                  ),
                ],
                if (!_recoveryAuthorized) TextButton.icon(
                  key: const ValueKey('app-lock-recover'),
                  onPressed: _busy ? null : _recover,
                  icon: const Icon(Icons.phonelink_lock_outlined),
                  label: const Text('استرداد القفل عبر قفل شاشة الهاتف'),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
