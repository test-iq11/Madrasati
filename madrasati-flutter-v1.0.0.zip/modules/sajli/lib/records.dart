import 'dart:convert';

typedef Json = Map<String, dynamic>;

Json object(Object? value) =>
    value is Map ? Map<String, dynamic>.from(value) : {};

String asciiDigits(String value) => value
    .replaceAllMapped(RegExp('[٠-٩۰-۹]'), (m) {
      final code = m[0]!.codeUnitAt(0);
      return (code - (code >= 0x06f0 ? 0x06f0 : 0x0660)).toString();
    })
    .replaceAll('٫', '.');

String numText(num n) =>
    n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(1);
String dayKey(DateTime d) => d.toIso8601String().substring(0, 10);
const monthNames = [
  'كانون الثاني',
  'شباط',
  'آذار',
  'نيسان',
  'أيار',
  'حزيران',
  'تموز',
  'آب',
  'أيلول',
  'تشرين الأول',
  'تشرين الثاني',
  'كانون الأول',
];
const attendanceLabels = {
  'present': 'حاضر',
  'absent': 'غائب',
  'excused': 'بعذر',
  'late': 'متأخر',
};
const gradeLabels = {'score': 'درجة', 'absent': 'غائب', 'exempt': 'معفى'};
const groups = ['الفصل الأول', 'نصف السنة', 'الفصل الثاني', 'الامتحان النهائي'];

class RemovedStudent {
  const RemovedStudent(this._student, this._index, this._direct, this._daily);
  final Json _student;
  final int _index;
  final Json _direct;
  final Map<String, Json> _daily;
}

class Records {
  Records(this.data);

  factory Records.decode(String text) {
    final data = object(jsonDecode(text));
    if (data['classes'] is! List ||
        data['students'] is! List ||
        data['grades'] is! Map ||
        data['attendance'] is! Map) {
      throw const FormatException('بنية النسخة الاحتياطية غير صالحة');
    }
    final records = Records(data);
    final classIds = <String>{};
    for (final row in records.classes) {
      if (row['id'] == null ||
          row['name'] is! String ||
          !classIds.add(row['id'].toString())) {
        throw const FormatException('صف غير صالح أو مكرر');
      }
    }
    final studentIds = <String>{};
    for (final row in records.people) {
      if (row['id'] == null ||
          row['name'] is! String ||
          !classIds.contains(row['classId'].toString()) ||
          !studentIds.add(row['id'].toString())) {
        throw const FormatException('بيانات التلاميذ غير صالحة');
      }
    }
    if (records.activeClasses.isEmpty ||
        records.courses.isEmpty ||
        records.periods.isEmpty) {
      throw const FormatException('النسخة تحتاج إلى صف ومواد وفترات تقييم');
    }
    for (final row in records.activeClasses) {
      if (records.subjects(row['id'].toString()).isEmpty) {
        throw const FormatException('أحد الصفوف لا يحتوي على مواد');
      }
    }
    return records;
  }

  final Json data;
  List<Json> list(String key) =>
      (data[key] as List? ?? []).map(object).toList();
  List<Json> get classes => list('classes');
  List<Json> get activeClasses =>
      classes.where((r) => r['archived'] != true).toList();
  List<Json> get people => list('students');
  List<Json> get periods => list('periods');
  List<String> get courses =>
      (data['subjects'] as List? ?? []).map((e) => e.toString()).toList();
  List<String> subjects(String classId) =>
      (object(data['classSubjects'])[classId] as List?)
          ?.map((e) => e.toString())
          .toList() ??
      courses;
  List<Json> students(String classId) => people
      .where((r) => r['classId'].toString() == classId && r['archived'] != true)
      .toList();
  RemovedStudent? deleteStudent(String id) {
    final students = people;
    final index = students.indexWhere(
      (student) => student['id'].toString() == id,
    );
    if (index == -1) return null;
    final student = students.removeAt(index);
    final direct = <String, dynamic>{};
    for (final key in ['grades', 'gradeStates']) {
      final root = object(data[key]);
      if (root.containsKey(id)) {
        direct[key] = root.remove(id);
        data[key] = root;
      }
    }
    final daily = <String, Json>{};
    for (final key in ['attendance', 'attNotes']) {
      final root = object(data[key]);
      final removed = <String, dynamic>{};
      for (final day in root.keys.toList()) {
        final row = object(root[day]);
        if (row.containsKey(id)) {
          removed[day] = row.remove(id);
          root[day] = row;
        }
      }
      if (removed.isNotEmpty) {
        daily[key] = removed;
        data[key] = root;
      }
    }
    data['students'] = students;
    return RemovedStudent(student, index, direct, daily);
  }

  bool restoreStudent(RemovedStudent removal) {
    final id = removal._student['id'].toString();
    final students = people;
    if (students.any((student) => student['id'].toString() == id)) return false;
    final index = removal._index > students.length
        ? students.length
        : removal._index;
    students.insert(index, removal._student);
    data['students'] = students;
    for (final entry in removal._direct.entries) {
      data[entry.key] = {...object(data[entry.key]), id: entry.value};
    }
    for (final entry in removal._daily.entries) {
      final root = object(data[entry.key]);
      for (final day in entry.value.entries) {
        root[day.key] = {...object(root[day.key]), id: day.value};
      }
      data[entry.key] = root;
    }
    return true;
  }

  String className(String id) =>
      classes
          .where((r) => r['id'].toString() == id)
          .firstOrNull?['name']
          ?.toString() ??
      '';
  String get school => data['school']?.toString() ?? '';
  String get teacher => data['teacher']?.toString() ?? '';
  String get year => data['year']?.toString() ?? '';
  num maximum(String subject) {
    final value = object(data['gradeMax'])[subject];
    return value is num && value.isFinite && value > 0 ? value : 100;
  }

  Object? _lookup(String key, String id, String subject, String period) =>
      object(object(object(data[key])[id])[subject])[period];

  String gradeStatus(String id, String subject, String period) {
    final status = _lookup('gradeStates', id, subject, period)?.toString();
    return gradeLabels.containsKey(status) ? status! : 'score';
  }

  num? score(String id, String subject, String period) {
    if (gradeStatus(id, subject, period) != 'score') return null;
    final value = num.tryParse(
      _lookup('grades', id, subject, period).toString(),
    );
    return value != null &&
            value.isFinite &&
            value >= 0 &&
            value <= maximum(subject)
        ? value
        : null;
  }

  String gradeText(String id, String subject, String period) {
    final status = gradeStatus(id, subject, period);
    final value = score(id, subject, period);
    return status != 'score'
        ? gradeLabels[status]!
        : value == null
        ? '—'
        : numText(value);
  }

  void _put(
    String key,
    String id,
    String subject,
    String period,
    Object? value,
  ) {
    final root = object(data[key]);
    final person = object(root[id]);
    final course = object(person[subject]);
    course[period] = value;
    person[subject] = course;
    root[id] = person;
    data[key] = root;
  }

  void setScore(String id, String subject, String period, num? value) {
    if (value != null &&
        (!value.isFinite || value < 0 || value > maximum(subject))) {
      throw const FormatException('الدرجة خارج النطاق');
    }
    _put('grades', id, subject, period, value);
  }

  void setGradeStatus(
    String id,
    String subject,
    String period,
    String status,
  ) => _put('gradeStates', id, subject, period, status);

  Json attendance(String day) => object(object(data['attendance'])[day]);
  void setAttendance(String day, String id, String status) {
    final root = object(data['attendance']);
    final row = attendance(day);
    if (status.isEmpty) {
      row.remove(id);
    } else {
      row[id] = status;
    }
    root[day] = row;
    data['attendance'] = root;
  }

  Map<String, int> attendanceSummary(String id, String month) {
    final result = <String, int>{for (final k in attendanceLabels.keys) k: 0};
    for (final entry in object(data['attendance']).entries) {
      if (!entry.key.startsWith('$month-')) continue;
      final status = object(entry.value)[id]?.toString();
      if (result.containsKey(status)) result[status!] = result[status]! + 1;
    }
    return result;
  }

  num rounded(num n) => switch (data['rounding']) {
    'floor' => n.floor(),
    'decimal' => (n * 10).round() / 10,
    _ => n.round(),
  };

  num? weighted(List<num?> values, List<num> weights) {
    var sum = 0.0;
    var total = 0.0;
    for (var i = 0; i < values.length; i++) {
      final weight = weights[i];
      if (weight <= 0) continue;
      final value = values[i];
      if (value == null) return null;
      sum += (value * weight).toDouble();
      total += weight.toDouble();
    }
    return total == 0 ? null : rounded(sum / total);
  }

  ({num? first, num? mid, num? second, num? effort, num? exam, num? finalGrade})
  annual(String id, String subject) {
    List<num?> group(String label) => periods
        .where((p) => p['section'] == label)
        .map((p) => score(id, subject, p['key'].toString()))
        .toList();
    num? mean(String label) {
      final values = group(label);
      return weighted(values, List<num>.filled(values.length, 1));
    }

    final first = mean(groups[0]);
    final mid = group(groups[1]).firstOrNull;
    final second = mean(groups[2]);
    final exam = group(groups[3]).firstOrNull;
    final calc = object(data['calc']);
    num weight(String k) => calc[k] is num ? calc[k] as num : 1;
    final effort = weighted(
      [first, mid, second],
      [weight('f1'), weight('mid'), weight('f2')],
    );
    return (
      first: first,
      mid: mid,
      second: second,
      effort: effort,
      exam: exam,
      finalGrade: weighted([effort, exam], [weight('sai'), weight('exam')]),
    );
  }

  List<({String period, double? percent, int count})> trend(
    String id,
    String classId,
  ) {
    return periods.where((p) => p['section'] != groups.last).map((p) {
      final period = p['key'].toString();
      final values = subjects(classId)
          .map((s) {
            final value = score(id, s, period);
            return value == null ? null : value / maximum(s) * 100;
          })
          .whereType<double>()
          .toList();
      return (
        period: period,
        percent: values.isEmpty
            ? null
            : values.reduce((a, b) => a + b) / values.length,
        count: values.length,
      );
    }).toList();
  }
}
