package com.sajli.school;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.flutter.embedding.android.FlutterFragmentActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

public class SajliActivity extends FlutterFragmentActivity {
    private static final int SAVE = 7001;
    private static final int OPEN = 7002;
    private static final int MAX_BACKUP = 24 * 1024 * 1024;
    private final ExecutorService files = Executors.newSingleThreadExecutor();
    private MethodChannel.Result pending;
    private byte[] pendingBytes;

    @Override
    public void configureFlutterEngine(FlutterEngine engine) {
        super.configureFlutterEngine(engine);
        new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), "sajli/files")
            .setMethodCallHandler(this::handle);
    }

    private void handle(MethodCall call, MethodChannel.Result result) {
        switch (call.method) {
            case "dataDirectory":
                result.success(getFilesDir().getAbsolutePath());
                break;
            case "saveFile": {
                byte[] bytes = call.argument("bytes");
                String name = call.argument("name");
                String mime = call.argument("mime");
                if (bytes == null || name == null || mime == null) {
                    result.error("data", "Invalid export", null);
                    return;
                }
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(mime)
                    .putExtra(Intent.EXTRA_TITLE, name);
                launchPicker(intent, SAVE, bytes, result);
                break;
            }
            case "openJson": {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                launchPicker(intent, OPEN, null, result);
                break;
            }
            case "printPdf":
                print(call, result);
                break;
            default:
                result.notImplemented();
        }
    }

    private void launchPicker(Intent intent, int request, byte[] bytes, MethodChannel.Result result) {
        if (pending != null) {
            result.error("busy", "File picker is already open", null);
            return;
        }
        pending = result;
        pendingBytes = bytes;
        try {
            startActivityForResult(intent, request);
        } catch (RuntimeException e) {
            pending = null;
            pendingBytes = null;
            result.error("picker", "Could not open file picker", null);
        }
    }

    @Override
    protected void onActivityResult(int request, int code, Intent data) {
        super.onActivityResult(request, code, data);
        if ((request != SAVE && request != OPEN) || pending == null) return;
        MethodChannel.Result result = pending;
        byte[] bytes = pendingBytes;
        pending = null;
        pendingBytes = null;
        if (code != Activity.RESULT_OK || data == null || data.getData() == null) {
            result.success(null);
            return;
        }
        final android.net.Uri uri = data.getData();
        files.execute(() -> {
            try {
                if (request == SAVE) {
                    try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                        if (out == null) throw new IllegalStateException("Cannot write");
                        out.write(bytes);
                    }
                    runOnUiThread(() -> result.success(true));
                } else {
                    try (InputStream in = getContentResolver().openInputStream(uri);
                         ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                        if (in == null) throw new IllegalStateException("Cannot read");
                        byte[] block = new byte[8192];
                        int count;
                        while ((count = in.read(block)) != -1) {
                            if (out.size() + count > MAX_BACKUP) throw new IllegalArgumentException("Backup too large");
                            out.write(block, 0, count);
                        }
                        byte[] loaded = out.toByteArray();
                        runOnUiThread(() -> result.success(loaded));
                    }
                }
            } catch (Exception e) {
                runOnUiThread(() -> result.error("io", "Could not access selected file", null));
            }
        });
    }

    private void print(MethodCall call, MethodChannel.Result result) {
        byte[] bytes = call.argument("bytes");
        String name = call.argument("name");
        if (bytes == null || name == null) {
            result.error("data", "Missing PDF", null);
            return;
        }
        boolean landscape = Boolean.TRUE.equals(call.argument("landscape"));
        Integer count = call.argument("pageCount");
        PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (manager == null) {
            result.error("print", "Print service unavailable", null);
            return;
        }
        try {
            manager.print(name, new PrintDocumentAdapter() {
                @Override public void onLayout(PrintAttributes oldAttrs, PrintAttributes newAttrs,
                    CancellationSignal cancellation, LayoutResultCallback callback, Bundle extras) {
                    if (cancellation.isCanceled()) { callback.onLayoutCancelled(); return; }
                    callback.onLayoutFinished(new PrintDocumentInfo.Builder(name + ".pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(count == null ? PrintDocumentInfo.PAGE_COUNT_UNKNOWN : count).build(),
                        !newAttrs.equals(oldAttrs));
                }
                @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor fd,
                    CancellationSignal cancellation, WriteResultCallback callback) {
                    files.execute(() -> {
                        try (OutputStream out = new ParcelFileDescriptor.AutoCloseOutputStream(fd)) {
                            if (cancellation.isCanceled()) {
                                runOnUiThread(callback::onWriteCancelled);
                                return;
                            }
                            out.write(bytes);
                        } catch (Exception error) {
                            runOnUiThread(() -> callback.onWriteFailed("Could not write PDF"));
                            return;
                        }
                        runOnUiThread(() -> {
                            if (cancellation.isCanceled()) callback.onWriteCancelled();
                            else callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                        });
                    });
                }
            }, new PrintAttributes.Builder()
                .setMediaSize(landscape ? PrintAttributes.MediaSize.ISO_A4.asLandscape()
                    : PrintAttributes.MediaSize.ISO_A4.asPortrait())
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build());
            result.success(null);
        } catch (RuntimeException e) {
            result.error("print", "Could not start print service", null);
        }
    }
}
