import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:iraqi_school_library_dual/admin/admin_library_app.dart';
import 'package:iraqi_school_library_dual/user/user_library_app.dart';
import 'package:iraqi_school_timetable/app/app.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:local_auth/local_auth.dart';
import 'package:mustamsakati/main.dart';
import 'package:sajli/main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:teacher_bell/domain.dart' as bell;
import 'package:teacher_bell/main.dart' as bell_ui;
import 'package:teacher_bell/platform_service.dart';

import 'mosaic_home.dart';
import 'bottom_nav.dart';
import 'day_cards.dart';
import 'pin_dialog.dart';
import 'school_day.dart';
import 'security_store.dart';

const _prefix = 'madrasati.';
const _version = '1.2.3';

const _swatches = <(String, int)>[
  ('زمردي', 0xff147c70), ('أخضر', 0xff276b59),
  ('تركوازي', 0xff168895), ('بحري', 0xff246d81),
  ('أزرق', 0xff2962a3), ('نيلي', 0xff3e5e9b),
  ('بنفسجي', 0xff6650a6), ('أرجواني', 0xff87559c),
  ('وردي', 0xffb44f79), ('توتي', 0xff9a4362),
  ('أحمر', 0xffb74b50), ('مرجاني', 0xffc85d48),
  ('برتقالي', 0xffc57633), ('نحاسي', 0xff91612f),
  ('ذهبي', 0xffae8524), ('زيتوني', 0xff6f8134),
  ('رمادي أزرق', 0xff536b81), ('فحمي', 0xff394658),
  ('داكن', 0xff283344), ('بترولي', 0xff286e69),
];

enum Section {
  today('اليوم', Icons.home_outlined, 0xff276b59),
  schedule('الجدول', Icons.calendar_month_outlined, 0xff2b5779),
  records('سجلّي', Icons.fact_check_outlined, 0xff57417c),
  notifications('الجرس', Icons.notifications_outlined, 0xff745124),
  scanner('المسح', Icons.document_scanner_outlined, 0xff295f65),
  library('المناهج', Icons.menu_book_outlined, 0xff3a5484),
  settings('الإعدادات', Icons.tune, 0xff376167),
  manager('إدارة المناهج', Icons.admin_panel_settings_outlined, 0xff57417c);

  const Section(this.label, this.icon, this.tone);
  final String label;
  final IconData icon;
  final int tone;
}

const _mainSections = [
  Section.today,
  Section.schedule,
  Section.records,
  Section.notifications,
  Section.scanner,
  Section.library,
];
const _protectable = [
  Section.schedule,
  Section.records,
  Section.notifications,
  Section.scanner,
  Section.library,
];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final preferences = await SharedPreferences.getInstance();
  runApp(Madrasati(preferences: preferences));
}

class Madrasati extends StatefulWidget {
  const Madrasati({required this.preferences, super.key});
  final SharedPreferences preferences;

  @override
  State<Madrasati> createState() => _MadrasatiState();
}

class _MadrasatiState extends State<Madrasati> with WidgetsBindingObserver {
  final _bell = GlobalKey<bell_ui.TeacherBellAppState>();
  final _attendance = ValueNotifier<({String grade, DateTime date})?>(null);
  final _books = ValueNotifier<String?>(null);
  final _auth = LocalAuthentication();
  final _pinStore = MadrasatiPinStore();
  final _database = DatabaseService.instance;
  final _visited = <Section>{Section.today};
  final _messenger = GlobalKey<ScaffoldMessengerState>();
  late final Future<SajliApp> _records = loadSajli(attendance: _attendance);

  late ThemeMode _mode;
  late bool _reduceMotion;
  late double _textScale;
  late Color _accent;
  late Map<Section, Color> _cardColors;
  late bool _compactHome;
  late bool _showDayCard;
  late bool _showQuickActions;
  late bool _showCardDetails;
  late bool _showHeroDecoration;
  late bool _showBottomNavigation;
  late bool _appLockEnabled;
  late bool _biometricUnlock;
  late double _cardRadius;
  bool _appLocked = false;
  bool _unlockBusy = false;
  int _failedPins = 0;
  DateTime? _pinBlockedUntil;
  late String _school;
  late int _sessionMinutes;
  late Set<String> _locked;
  late DateTime _date;
  late Future<SchoolDay> _schoolDay;
  Timer? _sessionTimer;
  DateTime? _sessionExpiry;
  bool _admin = false;
  bool _checking = false;
  bool _transferring = false;
  Section _section = Section.today;
  int? _sectionId;

  SharedPreferences get _prefs => widget.preferences;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _mode = ThemeMode.values.firstWhere(
      (mode) => mode.name == _prefs.getString('${_prefix}theme'),
      orElse: () => ThemeMode.system,
    );
    _school = _prefs.getString('${_prefix}school') ?? 'مدرستي';
    _reduceMotion = _prefs.getBool('${_prefix}motion') ?? false;
    _textScale = (_prefs.getDouble('${_prefix}text') ?? 1)
        .clamp(.9, 1.2)
        .toDouble();
    _accent = Color(_prefs.getInt('${_prefix}accent') ?? 0xff276b59);
    _cardColors = {
      for (final section in _mainSections.skip(1))
        section: Color(_prefs.getInt('${_prefix}card.${section.name}') ?? section.tone),
    };
    _compactHome = _prefs.getBool('${_prefix}compactHome') ?? false;
    _showDayCard = _prefs.getBool('${_prefix}showDay') ?? true;
    _showQuickActions = _prefs.getBool('${_prefix}showQuick') ?? true;
    _showCardDetails = _prefs.getBool('${_prefix}showDescriptions') ?? true;
    _showHeroDecoration = _prefs.getBool('${_prefix}heroDecoration') ?? true;
    _showBottomNavigation = _prefs.getBool('${_prefix}bottomNavigation') ?? true;
    _cardRadius = (_prefs.getDouble('${_prefix}cardRadius') ?? 20.0)
        .clamp(8.0, 32.0)
        .toDouble();
    _appLockEnabled = _prefs.getBool('${_prefix}appLock') ?? false;
    _biometricUnlock = _prefs.getBool('${_prefix}biometricUnlock') ?? false;
    _appLocked = _appLockEnabled;
    _sessionMinutes = _prefs.getInt('${_prefix}session') ?? 5;
    _locked = (_prefs.getStringList('${_prefix}protected') ?? []).toSet();
    _sectionId = _prefs.getInt('${_prefix}section');
    _date = baghdadDate();
    _schoolDay = _loadDay();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sessionTimer?.cancel();
    _attendance.dispose();
    _books.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden) {
      // Never re-lock during a platform biometric prompt.
      if (_appLockEnabled && !_unlockBusy && !_checking && mounted) {
        setState(() => _appLocked = true);
      }
      if (_admin && !_checking) _lock();
    } else if (state == AppLifecycleState.resumed &&
        _admin && _sessionExpiry?.isAfter(DateTime.now()) == false) {
      _lock();
    }
  }

  Future<SchoolDay> _loadDay() async {
    final sections = await _database.sectionsDetailed();
    final entries = await _database.entriesDetailed();
    return SchoolDay.select(sections, entries, _sectionId, _date);
  }

  void _message(String text) {
    _messenger.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _savePreference(Future<bool> write) async {
    try {
      if (!await write) _message('تعذّر حفظ التفضيل على الجهاز.');
    } catch (_) {
      _message('تعذّر حفظ التفضيل على الجهاز.');
    }
  }

  void _lock() {
    _sessionTimer?.cancel();
    _sessionExpiry = null;
    if (!mounted) return;
    setState(() {
      _admin = false;
      _visited.remove(Section.manager);
      _visited.removeWhere((section) => _locked.contains(section.name));
      if (_section == Section.manager || _locked.contains(_section.name)) {
        _section = Section.settings;
      }
    });
  }

  void _startSession() {
    _sessionTimer?.cancel();
    final duration = Duration(minutes: _sessionMinutes);
    _sessionExpiry = DateTime.now().add(duration);
    _sessionTimer = Timer(duration, _lock);
  }

  Future<bool> _authenticate() async {
    if (_admin) return true;
    if (_checking || _appLocked) return false;
    setState(() => _checking = true);
    try {
      // First-time enrolment is distinct from later administrator sign-in:
      // without any existing PIN there is no previous admin identity to verify.
      // Always require a deliberate, confirmed setup, then verify the value
      // round-trips through encrypted storage before granting permissions.
      final hasManagerPin = await _pinStore.hasPin('manager');
      if (!mounted) return false;
      if (!hasManagerPin) {
        final setup = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (dialog) => AlertDialog(
            title: const Text('تهيئة صلاحية المدير'),
            content: const Text(
              'لم يُنشأ رمز للمدير على هذا الجهاز بعد. يمكنك تعيين رمز مستقل من 4 إلى 8 أرقام. '
              'من يُكمل الإعداد أولاً يصبح مدير هذا التطبيق؛ أنجز هذه الخطوة على جهازك الشخصي ولا تشارك الرمز.'
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialog).pop(false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialog).pop(true),
                child: const Text('إعداد رمز المدير'),
              ),
            ],
          ),
        );
        if (setup != true || !mounted) return false;
        final newPin = await _askPin('إنشاء رمز المدير', confirm: true);
        if (newPin == null || !mounted) return false;
        await _pinStore.setPin('manager', newPin);
        if (!await _pinStore.verify('manager', newPin)) {
          if (mounted) _message('فشل تأكيد حفظ رمز المدير.');
          return false;
        }
      } else {
        final pin = await _askPin('أدخل رمز المدير');
        if (pin == null || !mounted) return false;
        final valid = await _pinStore.verify('manager', pin);
        if (!valid) {
          if (mounted) _message('رمز المدير غير صحيح.');
          return false;
        }
      }
      if (!mounted) return false;
      setState(() => _admin = true);
      _startSession();
      return true;
    } catch (_) {
      if (mounted) _message('تعذّر الوصول إلى مخزن رمز المدير الآمن.');
      return false;
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  Future<String?> _askPin(String title, {bool confirm = false}) =>
      showDialog<String>(
        context: context,
        barrierDismissible: false,
        builder: (_) => MadrasatiPinDialog(title: title, confirm: confirm),
      );

  Future<void> _enableAppLock() async {
    try {
      final pin = await _askPin('إنشاء رمز قفل التطبيق', confirm: true);
      if (!mounted || pin == null) return;
      await _pinStore.setPin('app', pin);
      final saved = await _prefs.setBool('${_prefix}appLock', true);
      if (!saved) throw StateError('Cannot persist lock state');
      if (mounted) {
        setState(() => _appLockEnabled = true);
        _message('تم تفعيل قفل التطبيق. يمكنك إضافة البصمة من الإعدادات.');
      }
    } catch (_) {
      if (mounted) _message('لم يُفعّل القفل: تعذّر حفظ الرمز بأمان.');
    }
  }

  Future<bool> _verifyAppPin() async {
    final pin = await _askPin('أدخل الرمز الحالي للتطبيق');
    if (pin == null || !mounted) return false;
    try {
      final valid = await _pinStore.verify('app', pin);
      if (!valid && mounted) _message('رمز التطبيق غير صحيح.');
      return valid;
    } catch (_) {
      if (mounted) _message('تعذّر الوصول إلى مخزن الرموز الآمن.');
      return false;
    }
  }

  Future<void> _disableAppLock() async {
    if (!await _verifyAppPin() || !mounted) return;
    try {
      if (!await _prefs.setBool('${_prefix}appLock', false)) return;
      await _prefs.setBool('${_prefix}biometricUnlock', false);
      if (mounted) {
        setState(() {
          _appLockEnabled = false;
          _biometricUnlock = false;
          _appLocked = false;
        });
      }
      await _pinStore.remove('app');
    } catch (_) {
      if (mounted) _message('تعذّر إلغاء القفل بالكامل.');
    }
  }

  Future<void> _changeAppPin() async {
    if (!await _verifyAppPin() || !mounted) return;
    final pin = await _askPin('الرمز الجديد', confirm: true);
    if (pin == null || !mounted) return;
    try {
      await _pinStore.setPin('app', pin);
      if (mounted) _message('تم تغيير رمز التطبيق بنجاح.');
    } catch (_) {
      if (mounted) _message('لم يتم تغيير الرمز.');
    }
  }

  Future<void> _toggleBiometrics(bool enabled) async {
    if (!_appLockEnabled) return;
    if (enabled) {
      try {
        final available = await _auth.getAvailableBiometrics();
        if (available.isEmpty) {
          _message('لا توجد بصمة مسجلة على هذا الجهاز.');
          return;
        }
        final verified = await _auth.authenticate(
          localizedReason: 'أكد بصمتك لتفعيل فتح مدرستي',
          biometricOnly: true,
          persistAcrossBackgrounding: true,
        );
        if (!verified || !mounted) return;
      } catch (_) {
        if (mounted) _message('تعذر تفعيل البصمة. تأكد من تسجيلها في الجهاز.');
        return;
      }
    } else {
      if (!await _verifyAppPin() || !mounted) return;
    }
    if (!await _prefs.setBool('${_prefix}biometricUnlock', enabled)) {
      _message('تعذر حفظ خيار البصمة.');
      return;
    }
    if (mounted) setState(() => _biometricUnlock = enabled);
  }

  Future<void> _unlockWithPin() async {
    if (_unlockBusy) return;
    final until = _pinBlockedUntil;
    if (until != null && until.isAfter(DateTime.now())) {
      _message('محاولات كثيرة. أعد المحاولة بعد قليل.');
      return;
    }
    setState(() => _unlockBusy = true);
    try {
      final pin = await _askPin('فتح مدرستي بالرمز');
      if (pin == null || !mounted) return;
      if (await _pinStore.verify('app', pin)) {
        setState(() {
          _appLocked = false;
          _failedPins = 0;
          _pinBlockedUntil = null;
        });
      } else {
        _failedPins++;
        if (_failedPins >= 5) {
          _pinBlockedUntil = DateTime.now().add(const Duration(seconds: 30));
          _failedPins = 0;
        }
        _message('الرمز غير صحيح.');
      }
    } catch (_) {
      if (mounted) _message('تعذر فتح مخزن الرموز الآمن.');
    } finally {
      if (mounted) setState(() => _unlockBusy = false);
    }
  }

  Future<void> _unlockWithBiometrics() async {
    if (!_biometricUnlock || _unlockBusy) return;
    setState(() => _unlockBusy = true);
    try {
      final verified = await _auth.authenticate(
        localizedReason: 'فتح تطبيق مدرستي',
        biometricOnly: true,
        persistAcrossBackgrounding: true,
      );
      if (mounted && verified) setState(() => _appLocked = false);
    } catch (_) {
      if (mounted) _message('تعذرت البصمة. استخدم رمز التطبيق بدلاً منها.');
    } finally {
      if (mounted) setState(() => _unlockBusy = false);
    }
  }

  Future<void> _setManagerPin() async {
    if (!_admin) return;
    try {
      if (await _pinStore.hasPin('manager')) {
        final old = await _askPin('الرمز الحالي للمدير');
        if (old == null || !await _pinStore.verify('manager', old)) {
          if (mounted) _message('رمز المدير الحالي غير صحيح.');
          return;
        }
      }
      if (!mounted) return;
      final pin = await _askPin('تعيين رمز خاص بالمدير', confirm: true);
      if (pin == null || !mounted) return;
      await _pinStore.setPin('manager', pin);
      if (mounted) _message('حُفظ رمز المدير بشكل آمن.');
    } catch (_) {
      if (mounted) _message('تعذّر حفظ رمز المدير.');
    }
  }

  Future<void> _open(Section section) async {
    if (_appLocked) return;
    if (section == Section.manager || _locked.contains(section.name)) {
      if (!await _authenticate()) return;
    }
    if (!mounted) return;
    if (section == _section) {
      if (section == Section.today) setState(() => _schoolDay = _loadDay());
      return;
    }
    setState(() {
      if (section == Section.today) _schoolDay = _loadDay();
      _section = section;
      _visited.add(section);
    });
  }

  Future<void> _updateProtection(Section section, bool locked) async {
    if (!_admin) return;
    final updated = {..._locked};
    if (locked) {
      updated.add(section.name);
    } else {
      updated.remove(section.name);
    }
    try {
      if (!await _prefs.setStringList(
        '${_prefix}protected',
        updated.toList(),
      )) {
        throw StateError('settings');
      }
      if (mounted) setState(() => _locked = updated);
    } catch (_) {
      _message('تعذّر حفظ سياسة الصلاحيات.');
    }
  }

  Future<void> _openAttendance(SchoolDay day) async {
    if (day.grade.isEmpty) return;
    await _open(Section.records);
    if (_section == Section.records) {
      _attendance.value = null;
      _attendance.value = (grade: day.grade, date: day.date);
    }
  }

  Future<void> _openBooks(SchoolDay day) async {
    if (day.grade.isEmpty) return;
    await _open(Section.library);
    if (_section == Section.library) {
      _books.value = null;
      _books.value = day.grade;
    }
  }

  Future<void> _transfer(BuildContext context, SchoolDay day) async {
    if (_transferring || day.lessons.isEmpty) return;
    final entries = day.toBellLessons();
    if (entries == null) {
      _message('أوقات الحصص متداخلة أو ناقصة. راجعها في الجدول.');
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تهيئة جرس الحصص'),
        content: Text(
          'نقل ${entries.length} حصص من ${day.sectionLabel} ليوم ${day.dayName} وتحديث جدول الجرس الأسبوعي لهذا اليوم؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تطبيق'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    if (_locked.contains(Section.schedule.name) && !_admin) {
      _message('انتهت جلسة المدير. افتح الجدول وأعد المحاولة.');
      return;
    }
    setState(() => _transferring = true);
    try {
      await _open(Section.notifications);
      await WidgetsBinding.instance.endOfFrame;
      if (!mounted) return;
      final saved = await _bell.currentState?.importSchoolDay(
        bell.dayIndex(day.date),
        entries,
      );
      _message(
        saved == true
            ? 'تم نقل الحصص إلى جدول الجرس.'
            : 'تعذّر نقل الحصص إلى الجرس.',
      );
    } catch (_) {
      _message('تعذّر حفظ حصص الجرس.');
    } finally {
      if (mounted) setState(() => _transferring = false);
    }
  }

  ThemeData _theme(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(
      seedColor: _accent,
      brightness: brightness,
    );
    return ThemeData(
      colorScheme: scheme,
      useMaterial3: true,
      fontFamily: 'NotoSansArabic',
      scaffoldBackgroundColor: brightness == Brightness.dark
          ? const Color(0xff101820)
          : const Color(0xfff1f6f8),
      cardTheme: CardThemeData(
        color: brightness == Brightness.dark
            ? const Color(0xff1a2834)
            : Colors.white,
        margin: EdgeInsets.zero,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: _school,
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar', 'IQ'),
    supportedLocales: const [Locale('ar', 'IQ'), Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: _theme(Brightness.light),
    darkTheme: _theme(Brightness.dark),
    themeMode: _mode,
    themeAnimationDuration: _reduceMotion
        ? Duration.zero
        : const Duration(milliseconds: 180),
    scaffoldMessengerKey: _messenger,
    builder: (context, child) {
      final media = MediaQuery.of(context);
      return MediaQuery(
        data: media.copyWith(
          disableAnimations: _reduceMotion || media.disableAnimations,
          textScaler: TextScaler.linear(
            media.textScaler.scale(14) / 14 * _textScale,
          ),
        ),
        child: child!,
      );
    },
    home: Builder(builder: _shell),
  );

  Widget _shell(BuildContext context) => Stack(
    children: [
      Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              _header(context),
              Expanded(
                child: IndexedStack(
                  index: _section.index,
                  children: [
                    for (final section in Section.values)
                      KeyedSubtree(
                        key: ValueKey(section),
                        child: _visited.contains(section)
                            ? TickerMode(
                                enabled: _section == section,
                                child: _page(context, section),
                              )
                            : const SizedBox.shrink(),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: _showBottomNavigation &&
                (_section == Section.today || _section == Section.settings)
            ? _bottomNav()
            : null,
      ),
      if (_appLocked) Positioned.fill(child: _appLockScreen(context)),
    ],
  );

  Widget _header(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(8, 3, 8, 3),
          child: Row(
            children: [
              IconButton(
                tooltip: 'الصفحة الرئيسية',
                onPressed: () => _open(Section.today),
                icon: Icon(Icons.apps_rounded, color: scheme.primary),
              ),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  _section == Section.today ? _school : _section.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 18,
                      fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                tooltip: 'الإعدادات العامة',
                onPressed: () => _open(Section.settings),
                icon: const Icon(Icons.settings_outlined),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bottomNav() {
    const sections = [
      Section.today, Section.schedule, Section.records, Section.settings,
    ];
    const colors = [
      Color(0xff16805e), // Emerald for Today
      Color(0xff3574b9), // Blue for Timetable
      Color(0xff805bb6), // Violet for Sajli
      Color(0xffbd7942), // Amber for Settings
    ];
    return MadrasatiBottomNav(
      items: [
        for (var i = 0; i < sections.length; i++)
          MadrasatiNavItem(sections[i].label, sections[i].icon, colors[i]),
      ],
      selectedIndex: sections.indexOf(_section),
      onSelect: (index) => _open(sections[index]),
    );
  }

  Widget _appLockScreen(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surface,
      child: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.all(23),
                    decoration: BoxDecoration(
                      color: scheme.primaryContainer,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.lock_outline_rounded,
                        size: 48, color: scheme.onPrimaryContainer),
                  ),
                  const SizedBox(height: 20),
                  const Text('مدرستي مقفل',
                      style: TextStyle(fontSize: 24,
                          fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text('أدخل رمز التطبيق أو استخدم بصمتك لفتحه.',
                      textAlign: TextAlign.center),
                  const SizedBox(height: 22),
                  FilledButton.icon(
                    onPressed: _unlockBusy ? null : _unlockWithPin,
                    icon: const Icon(Icons.password),
                    label: const Text('فتح بالرمز'),
                  ),
                  if (_biometricUnlock) ...[
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: _unlockBusy ? null : _unlockWithBiometrics,
                      icon: const Icon(Icons.fingerprint),
                      label: const Text('فتح بالبصمة'),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _page(BuildContext context, Section section) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return switch (section) {
      Section.today => _today(context),
      Section.schedule => TimetableApp(darkOverride: dark),
      Section.records => FutureBuilder<SajliApp>(
        future: _records,
        builder: (context, snapshot) {
          if (snapshot.hasError)
            return const Center(child: Text('تعذّر فتح بيانات سجلّي.'));
          if (!snapshot.hasData)
            return const Center(child: CircularProgressIndicator());
          final source = snapshot.data!;
          return SajliApp(
            records: source.records,
            file: source.file,
            darkOverride: dark,
            attendance: _attendance,
          );
        },
      ),
      Section.notifications => bell_ui.TeacherBellApp(
        key: _bell,
        darkOverride: dark,
      ),
      Section.scanner => MustamsakatiApp(darkOverride: dark),
      Section.library => IraqiLibraryUserApp(
        darkOverride: dark,
        openGrade: _books,
      ),
      Section.settings => _settings(context),
      Section.manager =>
        _admin ? IraqiLibraryAdminApp(dark: dark) : const SizedBox.shrink(),
    };
  }

  Widget _today(BuildContext context) {
    final choices = <(Section, String, String)>[
      (Section.schedule, 'جدولي', 'توزيع الحصص والإصلاح'),
      (Section.records, 'سجلّي', 'الدرجات والحضور والتقارير'),
      (Section.notifications, 'جرس المعلم', 'تنبيهات الحصص اليومية'),
      (Section.library, 'المناهج', 'الكتب الدراسية والمراجعات'),
      (Section.scanner, 'مستمسكاتي', 'تصوير وحفظ المستمسكات'),
    ];
    return MosaicHome(
      school: _school,
      accent: _accent,
      compact: _compactHome,
      rounded: _cardRadius,
      showDescriptions: _showCardDetails,
      showDecoration: _showHeroDecoration,
      showDay: _showDayCard,
      showShortcuts: _showQuickActions,
      entries: [
        for (final choice in choices)
          MosaicEntry(
            title: choice.$2,
            description: choice.$3,
            icon: choice.$1.icon,
            color: _cardColors[choice.$1] ?? Color(choice.$1.tone),
            onTap: () => _open(choice.$1),
          ),
      ],
      day: _daySummary(context),
      quickAttendance: () async {
        try {
          if (_locked.contains(Section.schedule.name) && !_admin) {
            await _open(Section.schedule);
            if (!mounted || !_admin) return;
          }
          final day = await _schoolDay;
          if (mounted && day.grade.isNotEmpty) {
            await _openAttendance(day);
          } else if (mounted) {
            _message('اختر صفاً وشعبة في جدول اليوم أولاً.');
          }
        } catch (_) {
          if (mounted) _message('تعذّر قراءة الصف الحالي من الجدول.');
        }
      },
      quickBell: () => _open(Section.notifications),
      quickSettings: () => _open(Section.settings),
    );
  }

  Widget _daySummary(BuildContext context) {
    if (_locked.contains(Section.schedule.name) && !_admin) {
      return _card('جدول اليوم', [
        _tile(Section.schedule, 'فتح الجدول المحمي',
            () => _open(Section.schedule)),
      ]);
    }
    return FutureBuilder<SchoolDay>(
      future: _schoolDay,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _card('جدول اليوم', [
            const Text('تعذّر قراءة بيانات الجدول.'),
            TextButton(
              onPressed: () => setState(() => _schoolDay = _loadDay()),
              child: const Text('إعادة المحاولة'),
            ),
          ]);
        }
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(12),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final day = snapshot.data!;
        return DayCards(
          day: day,
          accent: _accent,
          rounded: _cardRadius,
          transferring: _transferring,
          onSectionChanged: (id) {
            setState(() {
              _sectionId = id;
              _schoolDay = _loadDay();
            });
            unawaited(_savePreference(_prefs.setInt('${_prefix}section', id)));
          },
          onChangeDate: () async {
            final selected = await showDatePicker(
              context: context,
              initialDate: day.date,
              firstDate: DateTime(2022),
              lastDate: DateTime(2038),
            );
            if (selected == null || !mounted) return;
            setState(() {
              _date = selected;
              _schoolDay = _loadDay();
            });
          },
          onSchedule: () => _open(Section.schedule),
          onTransfer: () => _transfer(context, day),
          onBooks: () => _openBooks(day),
        );
      },
    );
  }

  Widget _card(String title, List<Widget> children) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
          ),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    ),
  );

  Widget _tile(Section section, String label, VoidCallback onTap) => Builder(
    builder: (context) {
      final scheme = Theme.of(context).colorScheme;
      final base = Color(section.tone);
      final ink = scheme.brightness == Brightness.dark
          ? Color.lerp(base, Colors.white, .68)!
          : base;
      return Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: ListTile(
          dense: true,
          leading: Icon(section.icon, color: ink),
          title: Text(label, style: TextStyle(color: ink)),
          trailing: Icon(Icons.chevron_left, color: ink),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: ink.withValues(alpha: .21)),
          ),
          tileColor: Color.alphaBlend(
            base.withValues(alpha: .09),
            scheme.surface,
          ),
          onTap: onTap,
        ),
      );
    },
  );

  Widget _colorSwatches({
    required Color selected,
    required ValueChanged<Color> onSelect,
    required String prefix,
  }) => Wrap(
    spacing: 7,
    runSpacing: 8,
    children: [
      for (final item in _swatches)
        Tooltip(
          message: '$prefix: ${item.$1}',
          child: Semantics(
            button: true,
            selected: selected.toARGB32() == item.$2,
            label: '$prefix ${item.$1}',
            child: InkWell(
              key: ValueKey('palette-$prefix-${item.$2}'),
              borderRadius: BorderRadius.circular(11),
              onTap: () => onSelect(Color(item.$2)),
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: Color(item.$2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: selected.toARGB32() == item.$2
                        ? Theme.of(context).colorScheme.onSurface
                        : Colors.transparent,
                    width: 2.5,
                  ),
                ),
                child: selected.toARGB32() == item.$2
                    ? const Icon(Icons.check, size: 20, color: Colors.white)
                    : null,
              ),
            ),
          ),
        ),
    ],
  );

  Future<void> _resetAppearance() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('استعادة ألوان الواجهة؟'),
        content: const Text(
          'يعيد الألوان وتخطيط الصفحة الرئيسية فقط إلى الإعدادات الافتراضية، '
          'دون حذف أي جدول أو سجل أو كتاب.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('استعادة')),
        ],
      ),
    );
    if (yes != true || !mounted) return;
    setState(() {
      _accent = const Color(0xff276b59);
      _cardColors = {
        for (final section in _mainSections.skip(1))
          section: Color(section.tone),
      };
      _compactHome = false;
      _cardRadius = 20;
      _showDayCard = true;
      _showQuickActions = true;
      _showCardDetails = true;
      _showHeroDecoration = true;
      _showBottomNavigation = true;
    });
    final changes = <Future<bool>>[
      _prefs.setInt('${_prefix}accent', _accent.toARGB32()),
      for (final section in _mainSections.skip(1))
        _prefs.setInt('${_prefix}card.${section.name}', section.tone),
      _prefs.setBool('${_prefix}compactHome', false),
      _prefs.setDouble('${_prefix}cardRadius', 20),
      _prefs.setBool('${_prefix}showDay', true),
      _prefs.setBool('${_prefix}showQuick', true),
      _prefs.setBool('${_prefix}showDescriptions', true),
      _prefs.setBool('${_prefix}heroDecoration', true),
      _prefs.setBool('${_prefix}bottomNavigation', true),
    ];
    final saved = await Future.wait(changes);
    if (mounted) {
      _message(saved.every((item) => item)
          ? 'أُعيدت إعدادات المظهر دون المساس ببياناتك.'
          : 'بعض إعدادات المظهر لم تُحفظ.');
    }
  }

  Widget _settingToggle(String title, String subtitle, bool value,
      String key, void Function(bool) change) => SwitchListTile(
    contentPadding: EdgeInsets.zero,
    title: Text(title),
    subtitle: Text(subtitle, style: const TextStyle(fontSize: 11)),
    value: value,
    onChanged: (next) {
      setState(() => change(next));
      unawaited(_savePreference(_prefs.setBool('${_prefix}$key', next)));
    },
  );

  Widget _settings(BuildContext context) {
    final themeLabels = {
      ThemeMode.system: 'حسب الجهاز',
      ThemeMode.light: 'فاتح',
      ThemeMode.dark: 'ليلي أسود',
    };
    return ListView(
      key: const PageStorageKey('madrasati-settings'),
      padding: const EdgeInsets.all(14),
      children: [
        _card('المظهر وألوان التطبيق', [
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('المظهر العام'),
            subtitle: const Text('لا يغيّر الألوان الداخلية للتطبيقات الخمسة'),
            trailing: DropdownButton<ThemeMode>(
              value: _mode,
              items: [
                for (final entry in themeLabels.entries)
                  DropdownMenuItem(value: entry.key, child: Text(entry.value)),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() => _mode = value);
                unawaited(_savePreference(
                    _prefs.setString('${_prefix}theme', value.name)));
              },
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('اختر لون الواجهة · 20 لوناً',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          _colorSwatches(
            selected: _accent,
            prefix: 'الواجهة',
            onSelect: (color) {
              setState(() => _accent = color);
              unawaited(_savePreference(
                  _prefs.setInt('${_prefix}accent', color.toARGB32())));
            },
          ),
        ]),
        const SizedBox(height: 10),
        _card('ألوان بطاقات التطبيقات · مستقلة عن لون الواجهة', [
          const Text('لكل بطاقة لونها الخاص، ولا تتغير بقية البطاقات عند الاختيار.'),
          for (final section in _mainSections.skip(1))
            ExpansionTile(
              key: PageStorageKey('palette-${section.name}'),
              leading: Icon(section.icon,
                  color: _cardColors[section] ?? Color(section.tone)),
              title: Text('بطاقة ${section.label}'),
              subtitle: Text(
                _swatches.where((item) => item.$2 ==
                    (_cardColors[section] ?? Color(section.tone)).toARGB32())
                    .firstOrNull?.$1 ?? 'لون خاص',
              ),
              childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 14),
              children: [
                _colorSwatches(
                  selected: _cardColors[section] ?? Color(section.tone),
                  prefix: section.label,
                  onSelect: (color) {
                    setState(() => _cardColors[section] = color);
                    unawaited(_savePreference(_prefs.setInt(
                        '${_prefix}card.${section.name}', color.toARGB32())));
                  },
                ),
              ],
            ),
        ]),
        const SizedBox(height: 10),
        _card('ترتيب الصفحة الرئيسية وحجم العناصر', [
          _settingToggle('بطاقات مدمجة', 'لتظهر أقسام أكثر على الشاشة',
              _compactHome, 'compactHome', (v) => _compactHome = v),
          _settingToggle('إظهار حصص اليوم', 'يعرض صفوف وحصص جدولي',
              _showDayCard, 'showDay', (v) => _showDayCard = v),
          _settingToggle('إظهار الاختصارات', 'الحضور والجرس والتخصيص',
              _showQuickActions, 'showQuick', (v) => _showQuickActions = v),
          _settingToggle('وصف البطاقات', 'نص مختصر تحت اسم كل تطبيق',
              _showCardDetails, 'showDescriptions',
              (v) => _showCardDetails = v),
          _settingToggle('زخرفة البطاقة الرئيسية', 'تدرج الألوان ورمز المدرسة',
              _showHeroDecoration, 'heroDecoration',
              (v) => _showHeroDecoration = v),
          _settingToggle('شريط التنقل السفلي', 'اختصارات للوصول إلى الصفحات',
              _showBottomNavigation, 'bottomNavigation',
              (v) => _showBottomNavigation = v),
          _settingToggle('تقليل الحركة', 'مناسب للأجهزة الأبطأ',
              _reduceMotion, 'motion', (v) => _reduceMotion = v),
          ListTile(
            title: const Text('تدوير زوايا البطاقات'),
            subtitle: Text('${_cardRadius.round()}'),
          ),
          Slider(
            value: _cardRadius,
            min: 8,
            max: 32,
            divisions: 12,
            onChanged: (v) => setState(() => _cardRadius = v),
            onChangeEnd: (v) => unawaited(_savePreference(
                _prefs.setDouble('${_prefix}cardRadius', v))),
          ),
          ListTile(title: const Text('تكبير النص في مدرستي'),
              trailing: Text('${(_textScale * 100).round()}%')),
          Slider(
            value: _textScale,
            min: .9,
            max: 1.2,
            divisions: 6,
            onChanged: (v) => setState(() => _textScale = v),
            onChangeEnd: (v) => unawaited(_savePreference(
                _prefs.setDouble('${_prefix}text', v))),
          ),
          TextButton.icon(
            onPressed: _resetAppearance,
            icon: const Icon(Icons.restore_rounded),
            label: const Text('إعادة ضبط المظهر فقط'),
          ),
        ]),
        const SizedBox(height: 10),
        _card('حماية التطبيق والبصمة والرمز', [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('قفل التطبيق بالرمز'),
            subtitle: const Text('رمز خاص من 4 إلى 8 أرقام يُحفظ بأمان'),
            value: _appLockEnabled,
            onChanged: (v) => v ? _enableAppLock() : _disableAppLock(),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('فتح بالبصمة'),
            subtitle: const Text('تحتاج رمز التطبيق أولاً وبصمة مسجلة في الجهاز'),
            value: _biometricUnlock,
            onChanged: _appLockEnabled ? _toggleBiometrics : null,
          ),
          if (_appLockEnabled) ...[
            ListTile(
              leading: const Icon(Icons.password),
              title: const Text('تغيير رمز قفل التطبيق'),
              onTap: _changeAppPin,
            ),
            ListTile(
              leading: const Icon(Icons.lock_clock_outlined),
              title: const Text('قفل التطبيق الآن'),
              onTap: () => setState(() => _appLocked = true),
            ),
          ],
          const Text('قفل التطبيق مختلف عن رمز المدير وصلاحياته.',
              style: TextStyle(fontSize: 11)),
        ]),
        const SizedBox(height: 10),
        _card('صلاحيات المدير وإعداداته', [
          if (!_admin)
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: const Text('الدخول إلى إعدادات المدير'),
              subtitle: const Text('رمز المدير، أو إنشاؤه بأمان عند الدخول الأول'),
              onTap: _checking ? null : () => _authenticate(),
            )
          else ...[
            ListTile(
              leading: const Icon(Icons.lock_open_outlined),
              title: const Text('إنهاء جلسة المدير'),
              onTap: _lock,
            ),
            ListTile(
              title: const Text('مدة جلسة المدير'),
              trailing: DropdownButton<int>(
                value: _sessionMinutes,
                items: const [
                  DropdownMenuItem(value: 5, child: Text('٥ دقائق')),
                  DropdownMenuItem(value: 10, child: Text('١٠ دقائق')),
                  DropdownMenuItem(value: 15, child: Text('١٥ دقيقة')),
                  DropdownMenuItem(value: 30, child: Text('٣٠ دقيقة')),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _sessionMinutes = v);
                  _startSession();
                  unawaited(_savePreference(
                      _prefs.setInt('${_prefix}session', v)));
                },
              ),
            ),
            ListTile(
              title: const Text('اسم المدرسة في الرئيسية'),
              subtitle: Text(_school),
              onTap: () => _rename(context),
            ),
            ListTile(
              leading: const Icon(Icons.key_outlined),
              title: const Text('إضافة أو تغيير رمز المدير'),
              onTap: _setManagerPin,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('تقييد الدخول إلى الأقسام',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
            for (final section in _protectable)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('تقييد ${section.label}'),
                subtitle: const Text('يتطلب فتح هذا القسم جلسة المدير'),
                value: _locked.contains(section.name),
                onChanged: (v) => _updateProtection(section, v),
              ),
            _tile(Section.manager, 'إدارة المناهج والنشر',
                () => _open(Section.manager)),
          ],
        ]),
        const SizedBox(height: 10),
        _card('الأذونات والتنبيهات', [
          ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: const Text('طلب إذن الإشعارات'),
            onTap: () => _device(DeviceService.requestNotifications),
          ),
          ListTile(
            leading: const Icon(Icons.access_time_outlined),
            title: const Text('إذن التنبيهات الدقيقة'),
            onTap: () => _device(() => DeviceService.openSettings('exact')),
          ),
          ListTile(
            leading: const Icon(Icons.vibration_outlined),
            title: const Text('إعدادات الاهتزاز'),
            onTap: () => _device(() => DeviceService.openSettings('vibration')),
          ),
          ListTile(
            leading: const Icon(Icons.battery_saver_outlined),
            title: const Text('إعدادات تحسين البطارية'),
            onTap: () => _device(() => DeviceService.openSettings('battery')),
          ),
        ]),
        const SizedBox(height: 10),
        _card('معلومات التطبيق', [
          const ListTile(title: Text('النسخة'), trailing: Text(_version)),
          const ListTile(
            title: Text('خصوصية البيانات'),
            subtitle: Text('تخزن إعدادات الواجهة على الجهاز، ورموز القفل في مخزن مشفر. '
                'بيانات الجدول والسجل تبقى داخل التطبيقات ما لم تستخدم وظائف النشر أو المشاركة.'),
          ),
        ]),
        const SizedBox(height: 26),
      ],
    );
  }

  Future<void> _device(Future<void> Function() action) async {
    try {
      await action();
    } catch (_) {
      _message('تعذّر فتح إعداد الجهاز.');
    }
  }

  Future<void> _rename(BuildContext context) async {
    final name = await showDialog<String>(
      context: context,
      builder: (context) => _SchoolNameDialog(initial: _school),
    );
    if (!mounted || !_admin || name == null || name.isEmpty) return;
    setState(() => _school = name);
    await _savePreference(_prefs.setString('${_prefix}school', name));
  }
}

class _SchoolNameDialog extends StatefulWidget {
  const _SchoolNameDialog({required this.initial});
  final String initial;
  @override
  State<_SchoolNameDialog> createState() => _SchoolNameDialogState();
}

class _SchoolNameDialogState extends State<_SchoolNameDialog> {
  late final _controller = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('اسم المدرسة'),
    content: TextField(controller: _controller, maxLength: 65, autofocus: true),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(
        onPressed: () => Navigator.pop(context, _controller.text.trim()),
        child: const Text('حفظ'),
      ),
    ],
  );
}
