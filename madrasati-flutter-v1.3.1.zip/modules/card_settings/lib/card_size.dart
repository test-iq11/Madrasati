import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _Scale extends ValueNotifier<Size> {
  _Scale(this.section) : super(const Size(1, 1)) {
    _restore();
  }
  final String section;
  bool changed = false;
  String get key => 'section_card_size_$section';

  Future<void> _restore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final parts = prefs.getStringList(key);
      if (changed || parts == null || parts.length != 2) return;
      final w = double.tryParse(parts.first);
      final h = double.tryParse(parts.last);
      if (w != null && h != null && w >= .7 && w <= 1 &&
          h >= .8 && h <= 1.4) value = Size(w, h);
    } catch (_) {
      // Defaults also work when the local preferences service is unavailable.
    }
  }

  void update(Size next) {
    changed = true;
    value = next;
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(key, [value.width.toString(), value.height.toString()]);
  }
}

final _scales = <String, _Scale>{};
_Scale _scale(String section) => _scales.putIfAbsent(section, () => _Scale(section));

class SectionCard extends StatelessWidget {
  const SectionCard(this.section, {required this.child, super.key});
  final String section;
  final Widget child;
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<Size>(
    valueListenable: _scale(section),
    child: child,
    builder: (_, size, content) => FractionallySizedBox(
      widthFactor: size.width,
      child: Align(heightFactor: size.height, child: Transform.scale(
        scaleY: size.height, child: SizedBox(width: double.infinity, child: content),
      )),
    ),
  );
}

class CardSizeSettings extends StatelessWidget {
  const CardSizeSettings(this.section, {super.key});
  final String section;
  @override
  Widget build(BuildContext context) {
    final model = _scale(section);
    return ValueListenableBuilder<Size>(
      valueListenable: model,
      builder: (_, size, _) => Card(child: ExpansionTile(
        title: Text(section.startsWith('tile-') ? 'حجم بطاقة القسم في الرئيسية' : 'حجم البطاقة داخل القسم'),
        leading: const Icon(Icons.aspect_ratio),
        childrenPadding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          for (final width in [true, false]) ...[
            Text('${width ? 'العرض' : 'الارتفاع'} · ${((width ? size.width : size.height) * 100).round()}٪'),
            Slider(
              value: width ? size.width : size.height,
              min: width ? .7 : .8, max: width ? 1 : 1.4,
              divisions: width ? 6 : 12,
              onChanged: (v) => model.update(width ? Size(v, size.height) : Size(size.width, v)),
              onChangeEnd: (_) => model.save(),
            ),
          ],
        ],
      )),
    );
  }
}
