import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/school_tools.dart';
import 'package:sajli/records.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('real school statistics are rendered as colored square cards',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final prefs = await SharedPreferences.getInstance();
    final records = Records.decode(
      File('modules/sajli/assets/demo.json').readAsStringSync());
    await tester.pumpWidget(MaterialApp(home: SchoolToolsPage(
      tool: SchoolTool.statistics,
      records: Future.value(records),
      preferences: prefs,
      privateView: false,
    )));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('school-statistics-colored-grid')),
      findsOneWidget);
    expect(find.text('عدد التلاميذ'), findsOneWidget);
    final card = find.byKey(const ValueKey('school-stat-عدد التلاميذ'));
    expect(card, findsOneWidget);
    final size = tester.getSize(card);
    expect(size.width / size.height, closeTo(1.07, .07));
    expect(tester.takeException(), isNull);
  });
}
