import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/security_store.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _MemorySecureBackend implements ManagerSecurePinBackend {
  String? savedPin;
  bool readFails = false;
  bool writeFails = false;

  @override
  Future<bool> hasPin(String purpose) async {
    if (readFails) throw StateError('Android Keystore unavailable');
    return savedPin != null;
  }

  @override
  Future<void> setPin(String purpose, String pin) async {
    if (writeFails) throw StateError('Android Keystore unavailable');
    savedPin = pin;
  }

  @override
  Future<bool> verify(String purpose, String pin) async {
    if (readFails) throw StateError('Android Keystore unavailable');
    return savedPin == pin;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('PIN rules prevent empty and short values', () {
    expect(MadrasatiPinStore.valid('1234'), true);
    expect(MadrasatiPinStore.valid('12345678'), true);
    expect(MadrasatiPinStore.valid('123'), false);
    expect(MadrasatiPinStore.valid('abcdefgh'), false);
    expect(MadrasatiPinStore.valid('123456789'), false);
  });

  test('PIN verifier varies with salt and secret', () {
    expect(MadrasatiPinStore.hash('salt-1', '123456'),
        isNot(MadrasatiPinStore.hash('salt-2', '123456')));
    expect(MadrasatiPinStore.hash('salt-1', '123456'),
        isNot(MadrasatiPinStore.hash('salt-1', '654321')));
  });

  test('unreadable Keystore is never mistaken for a fresh admin PIN', () async {
    final prefs = await SharedPreferences.getInstance();
    final secure = _MemorySecureBackend()..readFails = true;
    final store = ManagerPinStore(preferences: prefs, secure: secure);
    expect(await store.locate(), ManagerPinLocation.unavailable);
    expect(store.lastSecureError, isNotNull);
    expect(await store.verify('1234', ManagerPinLocation.unavailable), false);
  });

  test('valid encrypted PIN is still verified, never bypassed', () async {
    final prefs = await SharedPreferences.getInstance();
    final secure = _MemorySecureBackend()..savedPin = '654321';
    final store = ManagerPinStore(preferences: prefs, secure: secure);
    expect(await store.locate(), ManagerPinLocation.encrypted);
    expect(await store.verify('1234', ManagerPinLocation.encrypted), false);
    expect(await store.verify('654321', ManagerPinLocation.encrypted), true);
  });

  test('local manager PIN is salted, never plaintext, and survives restart',
      () async {
    final prefs = await SharedPreferences.getInstance();
    final secure = _MemorySecureBackend()..readFails = true;
    final store = ManagerPinStore(preferences: prefs, secure: secure);
    expect(await store.setLocal('574193'), true);
    final stored = prefs.getString('madrasati.manager.localVerifier.v1');
    expect(stored, isNotNull);
    expect(stored, startsWith('pbkdf2-v1:60000:'));
    expect(stored!.split(':').last, isNot('574193'));
    expect(await store.locate(), ManagerPinLocation.local);
    expect(await store.verify('000000', ManagerPinLocation.local), false);
    expect(await store.verify('574193', ManagerPinLocation.local), true);
    final restarted = ManagerPinStore(preferences: prefs, secure: secure);
    expect(await restarted.locate(), ManagerPinLocation.local);
    expect(await restarted.verify('574193', ManagerPinLocation.local), true);
  });

  test('corrupted local admin verifier is not treated as first enrollment',
      () async {
    SharedPreferences.setMockInitialValues({
      'madrasati.manager.localVerifier.v1': 'invalid',
    });
    final prefs = await SharedPreferences.getInstance();
    final secure = _MemorySecureBackend();
    final store = ManagerPinStore(preferences: prefs, secure: secure);
    expect(await store.locate(), ManagerPinLocation.damagedLocal);
    expect(await store.verify('1234', ManagerPinLocation.damagedLocal), false);
  });
}
