import 'package:flutter/material.dart';
import 'package:iraqi_school_library_dual/services/library_repository.dart';

/// No credential is ever printed, logged or put in the navigation URL.
/// The controller belongs to the dialog and survives the dismissal animation.
class ManagerTokenDialog extends StatefulWidget {
  const ManagerTokenDialog({super.key});

  @override
  State<ManagerTokenDialog> createState() => _ManagerTokenDialogState();
}

class _ManagerTokenDialogState extends State<ManagerTokenDialog> {
  final _controller = TextEditingController();
  bool _obscured = true;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('تفعيل إدارة المناهج'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('كل أقسام مدرستي متاحة للمستخدم العادي دون حساب. '
              'لتفعيل إدارة المناهج لأول مرة على هذا الهاتف، أدخل رمز '
              'GitHub خاصاً بالمالك وبالمستودع فقط، بصلاحية '
              'Contents: Read and write. لا تشارك هذا الرمز مع المستخدمين.'),
          const SizedBox(height: 10),
          Text('${LibraryEndpoint.owner}/${LibraryEndpoint.repo}',
              textAlign: TextAlign.center),
          const SizedBox(height: 12),
          TextField(
            controller: _controller,
            obscureText: _obscured,
            autocorrect: false,
            enableSuggestions: false,
            keyboardType: TextInputType.visiblePassword,
            decoration: InputDecoration(
              labelText: 'رمز GitHub الخاص بالمالك',
              prefixIcon: const Icon(Icons.key_outlined),
              suffixIcon: IconButton(
                icon: Icon(_obscured ? Icons.visibility_outlined :
                    Icons.visibility_off_outlined),
                onPressed: () => setState(() => _obscured = !_obscured),
              ),
              border: const OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          const Text('يحتاج التفعيل الأول إلى الإنترنت. بعدها يمكن '
              'تعديل مسودات المناهج دون إنترنت والنشر عند عودة الاتصال.'),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.of(context).pop(),
        child: const Text('إلغاء'),
      ),
      FilledButton(
        onPressed: () {
          final token = _controller.text.trim();
          if (token.isNotEmpty) Navigator.of(context).pop(token);
        },
        child: const Text('التحقق والتفعيل'),
      ),
    ],
  );
}
