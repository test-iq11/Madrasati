import 'dart:convert';
import 'dart:math';
import 'dart:isolate';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Only salted PIN verifiers are stored, never PINs in SharedPreferences.
/// The underlying encrypted storage is provided by Android Keystore.
class MadrasatiPinStore implements ManagerSecurePinBackend {
  MadrasatiPinStore({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  /// Never clear a possibly existing manager PIN just because the Keystore
  /// cannot decrypt it. A device-authenticated recovery is required instead.
  MadrasatiPinStore.forManager()
      : _storage = const FlutterSecureStorage(
          aOptions: AndroidOptions(
            resetOnError: false,
            migrateWithBackup: true,
          ),
        );

  final FlutterSecureStorage _storage;

  String _key(String purpose) => 'madrasati.pin.$purpose';

  static bool valid(String pin) => RegExp(r'^[0-9]{4,8}$').hasMatch(pin);

  static String hash(String salt, String pin) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<bool> hasPin(String purpose) async =>
      (await _storage.read(key: _key(purpose))) != null;

  Future<void> setPin(String purpose, String pin) async {
    if (!valid(pin)) {
      throw const FormatException('يجب أن يتكون الرمز من 4 إلى 8 أرقام.');
    }
    final random = Random.secure();
    final salt = base64UrlEncode(
      List<int>.generate(24, (_) => random.nextInt(256)),
    );
    await _storage.write(
      key: _key(purpose),
      value: '$salt:${hash(salt, pin)}',
    );
  }

  Future<bool> verify(String purpose, String pin) async {
    final saved = await _storage.read(key: _key(purpose));
    if (saved == null || !valid(pin)) return false;
    final separator = saved.indexOf(':');
    if (separator < 0) return false;
    final expected = saved.substring(separator + 1);
    final actual = hash(saved.substring(0, separator), pin);
    if (expected.length != actual.length) return false;
    var diff = 0;
    for (var i = 0; i < actual.length; i++) {
      diff |= expected.codeUnitAt(i) ^ actual.codeUnitAt(i);
    }
    return diff == 0;
  }

  Future<void> remove(String purpose) => _storage.delete(key: _key(purpose));
}

/// The administrator PIN is never stored in plaintext. A local verifier is a
/// last-resort, explicitly approved option if the Android KeyStore cannot be
/// read. Unlike Keystore, local preferences are not hardware-protected.
/// Recovery must be gated by the device's own authentication in the UI.
enum ManagerPinLocation { unconfigured, encrypted, local, unavailable, damagedLocal }

abstract class ManagerSecurePinBackend {
  Future<bool> hasPin(String purpose);
  Future<void> setPin(String purpose, String pin);
  Future<bool> verify(String purpose, String pin);
}

/// A device-local PBKDF2-HMAC-SHA256 PIN verifier. Do not use for tokens or
/// credentials; this is only a fallback for the administrator's local PIN.
class ManagerPinStore {
  ManagerPinStore({
    required this.preferences,
    required this.secure,
  });

  final SharedPreferences preferences;
  final ManagerSecurePinBackend secure;
  String? lastSecureError;

  static const _localKey = 'madrasati.manager.localVerifier.v1';
  static const _rounds = 60000;

  static bool _validRecord(String record) {
    final parts = record.split(':');
    if (parts.length != 4 || parts[0] != 'pbkdf2-v1') return false;
    if (int.tryParse(parts[1]) != _rounds) return false;
    try {
      return base64Url.decode(parts[2]).length == 24 &&
          base64Url.decode(parts[3]).length == 32;
    } catch (_) {
      return false;
    }
  }

  Future<ManagerPinLocation> locate() async {
    final local = preferences.getString(_localKey);
    if (local != null) {
      return _validRecord(local)
          ? ManagerPinLocation.local
          : ManagerPinLocation.damagedLocal;
    }
    lastSecureError = null;
    try {
      return await secure.hasPin('manager')
          ? ManagerPinLocation.encrypted
          : ManagerPinLocation.unconfigured;
    } catch (error) {
      // Keep the exception type for diagnostics but never log secrets.
      lastSecureError = error.runtimeType.toString();
      return ManagerPinLocation.unavailable;
    }
  }

  Future<bool> verify(String pin, ManagerPinLocation location) async {
    if (!MadrasatiPinStore.valid(pin)) return false;
    if (location == ManagerPinLocation.encrypted) {
      return secure.verify('manager', pin);
    }
    if (location != ManagerPinLocation.local) return false;
    final record = preferences.getString(_localKey);
    if (record == null || !_validRecord(record)) return false;
    final parts = record.split(':');
    final calculated = await _derive(pin, parts[2]);
    final expected = parts[3];
    if (calculated.length != expected.length) return false;
    var difference = 0;
    for (var i = 0; i < expected.length; i++) {
      difference |= calculated.codeUnitAt(i) ^ expected.codeUnitAt(i);
    }
    return difference == 0;
  }

  Future<bool> setLocal(String pin) async {
    if (!MadrasatiPinStore.valid(pin)) {
      throw const FormatException('يجب أن يتكون الرمز من 4 إلى 8 أرقام.');
    }
    final random = Random.secure();
    final salt = base64UrlEncode(
      List<int>.generate(24, (_) => random.nextInt(256)),
    );
    final digest = await _derive(pin, salt);
    return preferences.setString(
      _localKey,
      'pbkdf2-v1:$_rounds:$salt:$digest',
    );
  }

  Future<void> setEncrypted(String pin) => secure.setPin('manager', pin);

  static Future<String> _derive(String pin, String salt) =>
      Isolate.run(() => _pbkdf2(pin, salt));

  static String _pbkdf2(String pin, String salt) {
    final mac = Hmac(sha256, utf8.encode(pin));
    final bytes = base64Url.decode(salt);
    var block = mac.convert([...bytes, 0, 0, 0, 1]).bytes;
    final output = List<int>.from(block);
    for (var round = 1; round < _rounds; round++) {
      block = mac.convert(block).bytes;
      for (var i = 0; i < output.length; i++) {
        output[i] ^= block[i];
      }
    }
    return base64UrlEncode(output);
  }
}
