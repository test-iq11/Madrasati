"""Extract and validate the release source archive on the Actions runner."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import re
import stat
import sys

VERSION = '1.2.5+8'
ARCHIVE = 'madrasati-flutter-v1.2.5.zip'
REQUIRED = {'pubspec.yaml', 'lib/main.dart', 'android/app/build.gradle',
            'android/gradle/wrapper/gradle-wrapper.jar',
            'android/app/src/main/AndroidManifest.xml', 'ci/check_source.py',
            'modules/jadwali/pubspec.yaml', 'modules/sajli/pubspec.yaml',
            'modules/bell/pubspec.yaml', 'modules/scanner/pubspec.yaml',
            'modules/library/pubspec.yaml'}


def extract(archive: Path, target: Path) -> None:
    # Validate archive *contents*, not its name: Android uploaders may append (1).
    if not archive.is_file() or archive.suffix.lower() != '.zip':
        raise SystemExit('Provide the complete Madrasati source ZIP archive.')
    if target.exists():
        raise SystemExit('The build directory must be new.')
    with ZipFile(archive) as source:
        names = source.namelist()
        if len(set(names)) != len(names) or not REQUIRED.issubset(names):
            raise SystemExit('The ZIP is missing required project files or has duplicate paths.')
        if len(names) > 6000 or sum(entry.file_size for entry in source.infolist()) > 150_000_000:
            raise SystemExit('Unexpected size for the source archive.')
        for entry in source.infolist():
            name = PurePosixPath(entry.filename)
            if name.is_absolute() or '..' in name.parts or chr(92) in entry.filename or stat.S_ISLNK(entry.external_attr >> 16):
                raise SystemExit('Unsafe path in the source archive.')
        if source.testzip() is not None:
            raise SystemExit('The ZIP contents are damaged.')
        spec = source.read('pubspec.yaml').decode()
        if not re.search(r'^version:\s*' + re.escape(VERSION) + r'\s*$', spec, re.M):
            raise SystemExit(f'The project in the ZIP must have version {VERSION}.')
        source.extractall(target)


if __name__ == '__main__':
    extract(Path(sys.argv[1]), Path(sys.argv[2]))
