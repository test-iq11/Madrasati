import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path_provider/path_provider.dart';

import 'design.dart';
import 'office.dart';
import 'records.dart';
import 'report.dart';
import 'report_data.dart';
import 'student_sheet.dart';

const platform = MethodChannel('sajli/files');
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    runApp(await loadSajli());
  } catch (_) {
    runApp(
      const MaterialApp(
        home: Scaffold(
          body: Center(
            child: Text(
              'تعذّر فتح بيانات سجلّي. أغلق التطبيق ثم أعد فتحه.',
              textDirection: TextDirection.rtl,
            ),
          ),
        ),
      ),
    );
  }
}

Future<SajliApp> loadSajli({
  bool? darkOverride,
  ValueNotifier<({String grade, DateTime date})?>? attendance,
}) async {
  final dir = await getApplicationSupportDirectory();
  final file = File('${dir.path}/sajli.json');
  final records = Records.decode(
    await (file.existsSync()
        ? file.readAsString()
        : rootBundle
              .loadString('packages/sajli/assets/demo.json')
              .onError((_, _) => rootBundle.loadString('assets/demo.json'))),
  );
  return SajliApp(
    records: records,
    file: file,
    darkOverride: darkOverride,
    attendance: attendance,
  );
}

class SajliApp extends StatefulWidget {
  const SajliApp({
    super.key,
    required this.records,
    required this.file,
    this.darkOverride,
    this.attendance,
  });
  final Records records;
  final File file;
  final bool? darkOverride;
  final ValueNotifier<({String grade, DateTime date})?>? attendance;
  @override
  State<SajliApp> createState() => _SajliAppState();
}

class _SajliAppState extends State<SajliApp> with WidgetsBindingObserver {
  late Records records;
  late String classId;
  late String subject;
  late String period;
  late String studentId;
  var page = 0;
  var missingOnly = false;
  var query = '';
  var date = DateTime.now();
  var reportMonth = DateTime.now();
  var reportKind = ReportKind.annual;
  String? followId;
  var landscape = true;
  var settingsPanel = '';
  var reportNote = '';
  var busy = false;
  RenderedReport? preview;
  SchoolReport? prepared;
  String? error;
  int reportRevision = 0;
  final fields = {...ParentField.values};
  final search = TextEditingController();
  Future<void> writes = Future<void>.value();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    widget.attendance?.addListener(_sharedAttendance);
    WidgetsBinding.instance.addPostFrameCallback((_) => _sharedAttendance());
    records = widget.records;
    migrateDefaultPalette();
    applyStartupPreferences();
    classId = records.activeClasses.firstOrNull?['id']?.toString() ?? '';
    subject = records.subjects(classId).firstOrNull ?? '';
    period = records.periods.firstOrNull?['key']?.toString() ?? '';
    studentId = students.firstOrNull?['id']?.toString() ?? '';
  }

  void _sharedAttendance() {
    final request = widget.attendance?.value;
    if (request == null || !mounted) return;
    final matching = records.activeClasses.where(
      (row) => (row['name']?.toString() ?? '').contains(request.grade),
    );
    if (matching.isEmpty) {
      messenger.currentState?.showSnackBar(
        const SnackBar(
          content: Text('أضف الصف المطابق في إعدادات سجلّي لربط حضوره.'),
        ),
      );
      return;
    }
    selectClass(matching.first['id'].toString());
    setState(() {
      page = 1;
      date = request.date;
    });
  }

  @override
  void dispose() {
    widget.attendance?.removeListener(_sharedAttendance);
    WidgetsBinding.instance.removeObserver(this);
    search.dispose();
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    if (preference('theme', 'light') == 'system') setState(() {});
  }

  List<Json> get students => records.students(classId);
  String get day => dayKey(date);
  String id(Json row) => row['id'].toString();
  String name(Json row) => row['name'].toString();

  Color color(String key) {
    final colors = object(records.data['focusColors']);
    final raw = (colors[key] ?? colors['primary'])?.toString();
    return raw != null && RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(raw)
        ? Color(int.parse('ff${raw.substring(1)}', radix: 16))
        : sajliPalettes.values.first;
  }

  void migrateDefaultPalette() {
    const previous = {
      'primary': '#176f65',
      'grades': '#1d8375',
      'attendance': '#378467',
      'reports': '#a97135',
      'strength': 14,
    };
    final colors = object(records.data['focusColors']);
    if (colors.length == previous.length &&
        previous.entries.every((entry) => colors[entry.key] == entry.value)) {
      records.data.remove('focusColors');
    }
  }

  void applyStartupPreferences() {
    page = switch (preference('start', 'grades')) {
      'attendance' => 1,
      'reports' => 2,
      _ => 0,
    };
    landscape = preference('a4', 'portrait') == 'landscape';
  }

  void invalidate() {
    reportRevision++;
    preview = null;
    prepared = null;
  }

  void notify(String message) {
    if (!mounted) return;
    messenger.currentState?.showSnackBar(SnackBar(content: Text(message)));
  }

  final messenger = GlobalKey<ScaffoldMessengerState>();

  void update(VoidCallback change, {bool persist = false}) {
    setState(() {
      change();
      invalidate();
    });
    if (persist) save();
  }

  void save() {
    final snapshot = jsonEncode(records.data);
    writes = writes
        .then((_) async {
          final tmp = File('${widget.file.path}.tmp');
          await tmp.writeAsString(snapshot, flush: true);
          await tmp.rename(widget.file.path);
          if (mounted && error != null) setState(() => error = null);
        })
        .catchError((Object e) {
          if (mounted)
            setState(
              () => error =
                  'تعذّر حفظ التغييرات. صدّر نسخة احتياطية من الإعدادات.',
            );
        });
  }

  void selectClass(String value) {
    query = '';
    search.clear();
    classId = value;
    if (!records.subjects(classId).contains(subject))
      subject = records.subjects(classId).firstOrNull ?? '';
    studentId = students.firstOrNull?['id']?.toString() ?? '';
    reportNote = '';
    followId = null;
    missingOnly = false;
  }

  void openPage(int value) {
    setState(() {
      page = value;
      query = '';
      search.clear();
      if (value == 3) settingsPanel = '';
    });
  }

  Map<String, dynamic> get appearance => object(records.data['appearance']);

  String preference(String key, String fallback) =>
      appearance[key] is String ? appearance[key] as String : fallback;

  bool enabled(String key) => appearance[key] != false;

  void setPreference(String key, Object value) => update(
    () => records.data['appearance'] = {...appearance, key: value},
    persist: true,
  );

  bool get dark =>
      widget.darkOverride ??
      (switch (preference(
        'theme',
        records.data['dark'] == true ? 'dark' : 'light',
      )) {
        'dark' => true,
        'system' =>
          WidgetsBinding.instance.platformDispatcher.platformBrightness ==
              Brightness.dark,
        _ => false,
      });

  Color get surface => dark ? const Color(0xff231f2b) : const Color(0xfffffefd);
  Color get line => dark ? const Color(0xff3e3749) : const Color(0xffe9e4eb);
  Color get muted => dark ? const Color(0xffcfc6d7) : const Color(0xff635e70);
  Color get sectionAccent => color(_colorSections[page]);
  Color get soft => Color.alphaBlend(
    sectionAccent.withValues(alpha: dark ? .33 : .13),
    surface,
  );
  Color get accentText => dark
      ? Color.lerp(sectionAccent, Colors.white, .63)!
      : Color.lerp(
          sectionAccent,
          const Color(0xff231931),
          sectionAccent.computeLuminance() > .25 ? .65 : 0,
        )!;

  static const _colorSections = ['grades', 'attendance', 'reports', 'primary'];
  static const _sections = [
    ('الدرجات', Icons.bar_chart_outlined),
    ('الحضور', Icons.event_available_outlined),
    ('التقارير', Icons.description_outlined),
    ('الإعدادات', Icons.settings_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    final foreground = dark ? const Color(0xfff0eaf3) : const Color(0xff292437);
    final theme = ThemeData(
      colorScheme:
          ColorScheme.fromSeed(
            seedColor: sectionAccent,
            brightness: dark ? Brightness.dark : Brightness.light,
          ).copyWith(
            surface: surface,
            onSurface: foreground,
            onSurfaceVariant: muted,
            outline: line,
          ),
      fontFamily: 'NotoSansArabic',
      scaffoldBackgroundColor: dark
          ? const Color(0xff19161f)
          : const Color(0xfff7f5ef),
      visualDensity: preference('density', 'normal') == 'compact'
          ? VisualDensity.compact
          : VisualDensity.standard,
      dividerColor: line,
      useMaterial3: true,
      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: line),
        ),
        filled: true,
        fillColor: surface,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 11,
          vertical: 11,
        ),
      ),
    );
    return MaterialApp(
      title: 'سجلّي',
      debugShowCheckedModeBanner: false,
      theme: theme,
      locale: const Locale('ar', 'IQ'),
      supportedLocales: const [Locale('ar', 'IQ'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      scaffoldMessengerKey: messenger,
      builder: (context, child) {
        final media = MediaQuery.of(context);
        final scale = switch (preference('font', 'normal')) {
          'small' => .92,
          'large' => 1.14,
          'largest' => 1.25,
          _ => 1.0,
        };
        return MediaQuery(
          data: media.copyWith(
            textScaler: TextScaler.linear(
              media.textScaler.scale(14) / 14 * scale,
            ),
          ),
          child: child!,
        );
      },
      home: Builder(
        builder: (context) => LayoutBuilder(
          builder: (context, size) {
            final wide = size.maxWidth >= 780;
            final settingsDetail = page == 3 && settingsPanel.isNotEmpty;
            final content = SafeArea(
              top: false,
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1276),
                  child: ListView(
                    key: PageStorageKey('$page:$settingsPanel'),
                    padding: EdgeInsets.fromLTRB(
                      wide ? 24 : 12,
                      wide ? 22 : 13,
                      wide ? 24 : 12,
                      24,
                    ),
                    children: [
                      if (error != null) panel([Text(error!)]),
                      ...pageContent(context),
                    ],
                  ),
                ),
              ),
            );
            return PopScope(
              canPop: !settingsDetail,
              onPopInvokedWithResult: (didPop, _) {
                if (!didPop && settingsDetail)
                  setState(() => settingsPanel = '');
              },
              child: Scaffold(
                appBar: wide
                    ? null
                    : AppBar(
                        backgroundColor: surface,
                        surfaceTintColor: Colors.transparent,
                        shape: Border(bottom: BorderSide(color: line)),
                        toolbarHeight: 56,
                        titleSpacing: 13,
                        title: _brand(),
                        leading: settingsDetail
                            ? IconButton(
                                tooltip: 'رجوع',
                                icon: const Icon(Icons.arrow_back),
                                onPressed: () =>
                                    setState(() => settingsPanel = ''),
                              )
                            : null,
                      ),
                body: wide
                    ? Row(
                        children: [
                          Container(
                            width: size.maxWidth >= 1120 ? 225 : 174,
                            decoration: BoxDecoration(
                              color: surface,
                              border: BorderDirectional(
                                end: BorderSide(color: line),
                              ),
                            ),
                            child: SafeArea(
                              child: Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(18),
                                    child: _brand(),
                                  ),
                                  for (var i = 0; i < _sections.length; i++)
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 3,
                                      ),
                                      child: _destination(i, vertical: false),
                                    ),
                                  const Spacer(),
                                  Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Text(
                                      records.school,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(color: muted),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  height: 59,
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 18,
                                  ),
                                  decoration: BoxDecoration(
                                    color: surface,
                                    border: Border(
                                      bottom: BorderSide(color: line),
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      if (settingsDetail)
                                        IconButton(
                                          tooltip: 'رجوع',
                                          icon: const Icon(Icons.arrow_back),
                                          onPressed: () => setState(
                                            () => settingsPanel = '',
                                          ),
                                        ),
                                      Text(
                                        'سجلّي  ‹  ${_sections[page].$1}',
                                        style: TextStyle(color: muted),
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(child: content),
                              ],
                            ),
                          ),
                        ],
                      )
                    : content,
                bottomNavigationBar: wide
                    ? null
                    : DecoratedBox(
                        decoration: BoxDecoration(
                          color: surface,
                          border: Border(top: BorderSide(color: line)),
                        ),
                        child: SafeArea(
                          top: false,
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(7, 5, 7, 5),
                            child: Row(
                              children: [
                                for (var i = 0; i < _sections.length; i++)
                                  Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 2,
                                      ),
                                      child: _destination(i, vertical: true),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _brand() => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      DecoratedBox(
        decoration: BoxDecoration(
          color: color('primary'),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Icon(
            Icons.menu_book_outlined,
            size: 20,
            color: contrastInk(color('primary')),
          ),
        ),
      ),
      const SizedBox(width: 9),
      const Text(
        'سجلّي',
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
      ),
    ],
  );

  Widget _destination(int index, {required bool vertical}) {
    final selected = page == index;
    final text = Text(
      _sections[index].$1,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontSize: vertical ? 10 : 13,
        fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
      ),
    );
    final icon = Icon(_sections[index].$2, size: vertical ? 20 : 22);
    return Semantics(
      selected: selected,
      child: TextButton(
        style: TextButton.styleFrom(
          foregroundColor: selected ? accentText : muted,
          backgroundColor: selected ? soft : Colors.transparent,
          minimumSize: const Size.fromHeight(48),
          padding: EdgeInsets.symmetric(
            horizontal: vertical ? 2 : 10,
            vertical: 5,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(11),
          ),
        ),
        onPressed: () => openPage(index),
        child: vertical
            ? Column(mainAxisSize: MainAxisSize.min, children: [icon, text])
            : Row(
                children: [
                  icon,
                  const SizedBox(width: 8),
                  Flexible(child: text),
                ],
              ),
      ),
    );
  }

  Widget hero(
    String heading,
    String description,
    IconData icon, {
    bool main = false,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: SajliHero(
      key: ValueKey(main ? 'main-hero' : 'section-hero'),
      school: records.school,
      title: heading,
      hint: description,
      icon: icon,
      accent: sectionAccent,
      art: enabled('art'),
      chart: main,
      height: main
          ? switch (preference('hero', 'tall')) {
              'compact' => 136,
              'extra' => 224,
              _ => 174,
            }
          : 124,
    ),
  );

  Widget panel(List<Widget> children) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Material(
      color: surface,
      shape: RoundedRectangleBorder(
        side: BorderSide(color: line),
        borderRadius: BorderRadius.circular(18),
      ),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: children,
        ),
      ),
    ),
  );

  Widget select<T>(
    String title,
    T value,
    Iterable<MapEntry<T, String>> values,
    ValueChanged<T> onChange,
  ) {
    final items = values.toList();
    return DropdownButtonFormField<T>(
      key: ValueKey('$title/$value/${items.map((e) => e.key).join('/')}'),
      initialValue: items.any((e) => e.key == value) ? value : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: title),
      items: items
          .map(
            (e) => DropdownMenuItem(
              value: e.key,
              child: Text(e.value, overflow: TextOverflow.ellipsis),
            ),
          )
          .toList(),
      onChanged: (v) {
        if (v != null) onChange(v);
      },
    );
  }

  List<Widget> pageContent(BuildContext context) {
    if (page == 3) return settingsPage(context);
    if (classId.isEmpty) {
      return [
        panel([
          const Text('لا توجد صفوف بعد'),
          FilledButton(
            onPressed: () => editClass(context),
            child: const Text('إضافة صف'),
          ),
        ]),
      ];
    }
    if (page == 0 && (subject.isEmpty || period.isEmpty)) {
      return [
        panel([
          Text(
            subject.isEmpty
                ? 'أضف مادة إلى هذا الصف لإعداد كشف الدرجات.'
                : 'أضف فترة تقييم لإعداد كشف الدرجات.',
          ),
          OutlinedButton(
            onPressed: subject.isEmpty
                ? () => editCourse(context)
                : () => editPeriod(context),
            child: Text(subject.isEmpty ? 'إضافة مادة' : 'إضافة فترة'),
          ),
          gap(),
          classPicker(),
        ]),
      ];
    }
    return switch (page) {
      0 => gradesPage(context),
      1 => attendancePage(context),
      _ => reportsPage(context),
    };
  }

  Widget classPicker() => select(
    'الصف والشعبة',
    classId,
    records.activeClasses.map((c) => MapEntry(id(c), name(c))),
    (value) => update(() => selectClass(value)),
  );

  Widget subjectPicker() => select(
    'المادة',
    subject,
    records.subjects(classId).map((s) => MapEntry(s, s)),
    (value) => update(() => subject = value),
  );

  Widget periodPicker() => select(
    'الفترة',
    period,
    records.periods.map(
      (p) => MapEntry(p['key'].toString(), p['key'].toString()),
    ),
    (value) => update(() => period = value),
  );

  Widget gap([double size = 10]) => SizedBox(height: size);
  Widget title(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Text(
      text,
      style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
    ),
  );

  bool pending(Json s) =>
      records.gradeStatus(id(s), subject, period) == 'score' &&
      records.score(id(s), subject, period) == null;
  String searchText(String value) =>
      asciiDigits(value.trim().toLowerCase())
          .replaceAll(RegExp('[أإآ]'), 'ا')
          .replaceAll(RegExp(r'[ً-ٟـ]'), '');

  List<Json> get matches {
    final term = searchText(query);
    return students
        .where(
          (s) =>
              searchText(name(s)).contains(term) ||
              searchText(s['number']?.toString() ?? '').contains(term),
        )
        .toList();
  }

  Widget searchBox() => TextField(
    controller: search,
    onChanged: (v) => setState(() => query = v),
    decoration: const InputDecoration(
      prefixIcon: Icon(Icons.search, size: 17),
      hintText: 'بحث عن تلميذ',
    ),
  );

  Widget badge(IconData icon, [int tone = 0]) {
    final (foreground, background) = switch (tone) {
      1 => (
        dark ? const Color(0xffb8e6d3) : const Color(0xff276a57),
        dark ? const Color(0xff25483e) : const Color(0xffe5f2ea),
      ),
      2 => (
        dark ? const Color(0xfff1c9db) : const Color(0xffa04056),
        dark ? const Color(0xff553447) : const Color(0xfffcebf0),
      ),
      3 => (
        dark ? const Color(0xfff4d8a2) : const Color(0xff78520b),
        dark ? const Color(0xff514125) : const Color(0xfffaedcd),
      ),
      _ => (accentText, soft),
    };
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(9),
      ),
      child: Icon(icon, color: foreground, size: 17),
    );
  }

  Widget avatar(Json s) {
    final letters = name(s).trim().runes;
    final tone = id(s).codeUnits.fold<int>(0, (n, ch) => n + ch) % 4;
    final background = switch (tone) {
      1 => const Color(0xffe5f2ea),
      2 => const Color(0xfffcebf0),
      3 => const Color(0xfffaedcd),
      _ => soft,
    };
    return Container(
      width: 34,
      height: 34,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        letters.isEmpty ? '—' : String.fromCharCode(letters.first),
        style: TextStyle(
          color: tone == 0 ? accentText : contrastInk(background),
          fontSize: 14,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }

  Widget summary(List<(String, String, IconData, int)> entries) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      children: [
        for (var i = 0; i < entries.length; i++) ...[
          if (i > 0) const SizedBox(width: 5),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: surface,
                border: Border.all(color: line),
                borderRadius: BorderRadius.circular(13),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 8),
              child: LayoutBuilder(
                builder: (context, layout) {
                  final (label, value, icon, tone) = entries[i];
                  return Row(
                    children: [
                      if (layout.maxWidth >= 87 &&
                          MediaQuery.textScalerOf(context).scale(11) <= 15) ...[
                        badge(icon, tone),
                        const SizedBox(width: 5),
                      ],
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              label,
                              style: TextStyle(
                                color: muted,
                                fontSize: 10,
                                height: 1.4,
                              ),
                            ),
                            Text(
                              displayNumber(value),
                              style: const TextStyle(
                                fontSize: 19,
                                height: 1.4,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ],
    ),
  );

  String displayNumber(String value) {
    if (preference('digits', 'arabic') == 'latin') return value;
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    return value
        .replaceAllMapped(RegExp('[0-9]'), (m) => arabic[int.parse(m[0]!)])
        .replaceAll('.', '٫');
  }

  Widget filters(List<Widget> controls) => panel([
    Row(
      children: [
        Icon(Icons.tune, color: accentText, size: 17),
        const SizedBox(width: 6),
        const Text(
          'نطاق العرض',
          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
        ),
      ],
    ),
    gap(),
    ...controls,
  ]);

  Widget gradeScope() => filters([
    LayoutBuilder(
      builder: (context, layout) {
        final full = layout.maxWidth >= 650;
        if (full) {
          return Row(
            children: [
              Expanded(child: classPicker()),
              const SizedBox(width: 8),
              Expanded(child: subjectPicker()),
              const SizedBox(width: 8),
              Expanded(child: periodPicker()),
            ],
          );
        }
        return Column(
          children: [
            classPicker(),
            gap(),
            Row(
              children: [
                Expanded(child: subjectPicker()),
                const SizedBox(width: 8),
                Expanded(child: periodPicker()),
              ],
            ),
          ],
        );
      },
    ),
  ]);

  List<Widget> gradesPage(BuildContext context) {
    final incomplete = students.where(pending).length;
    final recorded = students
        .map((s) => records.score(id(s), subject, period))
        .whereType<num>()
        .toList();
    final average = recorded.isEmpty
        ? '—'
        : numText(recorded.reduce((a, b) => a + b) / recorded.length);
    final rows = matches.where((s) => !missingOnly || pending(s)).toList();
    final selected =
        students.where((s) => id(s) == followId).firstOrNull ??
        students.firstOrNull;

    Widget book({required bool inlineFollow}) => panel([
      Row(
        children: [
          const Expanded(
            child: Text(
              'كشف الدرجات',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
          ),
          PopupMenuButton<String>(
            tooltip: 'خيارات كشف الدرجات',
            onSelected: (value) {
              if (value == 'paste') pasteGrades(context);
              if (value == 'missing')
                setState(() => missingOnly = !missingOnly);
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'paste',
                child: Text('لصق درجات من Excel'),
              ),
              PopupMenuItem(
                value: 'missing',
                child: Text(
                  missingOnly ? 'عرض جميع الدرجات' : 'عرض الدرجات الناقصة',
                ),
              ),
            ],
          ),
        ],
      ),
      Text('$subject · $period', style: TextStyle(color: muted, fontSize: 11)),
      gap(),
      searchBox(),
      gap(),
      if (missingOnly)
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: FilterChip(
            label: const Text('الدرجات الناقصة'),
            selected: true,
            onSelected: (_) => setState(() => missingOnly = false),
          ),
        ),
      DecoratedBox(
        decoration: BoxDecoration(
          color: soft,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            children: [
              const Expanded(
                child: Text(
                  'اسم التلميذ',
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                ),
              ),
              Flexible(
                child: Text(
                  'الدرجة / ${displayNumber(numText(records.maximum(subject)))}',
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 42),
            ],
          ),
        ),
      ),
      if (rows.isEmpty)
        const Padding(
          padding: EdgeInsets.all(14),
          child: Text('لا توجد أسماء مطابقة'),
        ),
      for (final s in rows)
        studentRow(
          s,
          active: selected != null && id(selected) == id(s),
          onName: () {
            setState(() => followId = id(s));
            // Open the same tested student-profile path as the chevron.
            // The former nested follow-up dialog could show a blank surface.
            studentProfile(context, s);
          },
          controls: [
            OutlinedButton.icon(
              key: ValueKey('grade-${id(s)}'),
              onPressed: () => editGrade(context, s),
              label: Text(
                displayNumber(records.gradeText(id(s), subject, period)),
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
              icon: const Icon(Icons.edit_outlined, size: 13),
              style: OutlinedButton.styleFrom(
                backgroundColor: surface,
                side: BorderSide(color: line),
                minimumSize: const Size(48, 40),
                padding: const EdgeInsets.symmetric(horizontal: 7),
              ),
            ),
            profileButton(context, s),
          ],
        ),
    ]);

    return [
      hero(
        'سجل الدرجات',
        'اختر الصف والمادة والفترة، ثم اضغط على الدرجة لتعديلها.',
        Icons.bar_chart_outlined,
        main: true,
      ),
      if (enabled('summary'))
        summary([
          ('التلاميذ', students.length.toString(), Icons.people_outline, 0),
          ('متوسط الدرجات', average, Icons.bar_chart_outlined, 1),
          ('درجات غير مدخلة', incomplete.toString(), Icons.schedule, 3),
        ]),
      gradeScope(),
      LayoutBuilder(
        builder: (context, layout) {
          if (layout.maxWidth >= 760 && enabled('follow') && selected != null) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: book(inlineFollow: true)),
                const SizedBox(width: 14),
                SizedBox(width: 285, child: followCard(context, selected)),
              ],
            );
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              book(inlineFollow: false),
              if (enabled('follow') && selected != null)
                followCard(context, selected),
            ],
          );
        },
      ),
    ];
  }

  Widget profileButton(
    BuildContext context,
    Json s, {
    bool insideCard = false,
  }) => IconButton(
    key: ValueKey('${insideCard ? 'follow-profile' : 'profile'}-${id(s)}'),
    tooltip: 'فتح ملف ${name(s)}',
    icon: const Icon(Icons.chevron_left, size: 19),
    constraints: const BoxConstraints(minWidth: 40, minHeight: 44),
    padding: EdgeInsets.zero,
    onPressed: () => studentProfile(context, s),
  );

  Widget studentRow(
    Json s, {
    required VoidCallback onName,
    required List<Widget> controls,
    bool active = false,
    String? subline,
  }) => Container(
    decoration: BoxDecoration(
      color: active ? soft.withValues(alpha: .62) : null,
      border: Border(bottom: BorderSide(color: line)),
    ),
    padding: EdgeInsets.symmetric(
      vertical: preference('density', 'normal') == 'compact' ? 0 : 4,
    ),
    child: Row(
      children: [
        Expanded(
          child: TextButton(
            key: ValueKey('student-name-${id(s)}'),
            onPressed: onName,
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            ),
            child: Row(
              children: [
                avatar(s),
                const SizedBox(width: 6),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name(s),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: dark
                              ? const Color(0xfff0eaf3)
                              : const Color(0xff292437),
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      if (subline != null ||
                          preference('numbers', 'show') == 'show')
                        Text(
                          subline ?? s['number']?.toString() ?? '',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: muted, fontSize: 10),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        ...controls,
      ],
    ),
  );

  void parentReport(Json s, {DateTime? month}) {
    update(() {
      reportKind = ReportKind.parent;
      studentId = id(s);
      reportNote = '';
      if (month != null) reportMonth = month;
    });
    openPage(2);
  }

  Widget followCard(BuildContext context, Json s, {BuildContext? dialog}) {
    final series = records.periods
        .map(
          (p) => (
            p['key'].toString(),
            records.score(id(s), subject, p['key'].toString()),
          ),
        )
        .where((entry) => entry.$2 != null)
        .toList();
    final mean = series.isEmpty
        ? '—'
        : numText(
            series.fold<num>(0, (sum, entry) => sum + entry.$2!) /
                series.length,
          );
    final month = dayKey(date).substring(0, 7);
    final attendance = records.attendanceSummary(id(s), month);
    return panel([
      if (dialog == null) ...[
        DecoratedBox(
          decoration: BoxDecoration(
            color: soft,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              'بطاقة المتابعة الفردية',
              style: TextStyle(fontWeight: FontWeight.w800, color: accentText),
            ),
          ),
        ),
        gap(),
      ],
      Row(
        children: [
          avatar(s),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name(s),
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                Text(
                  records.className(s['classId'].toString()),
                  style: TextStyle(color: muted, fontSize: 11),
                ),
              ],
            ),
          ),
          if (dialog == null) profileButton(context, s, insideCard: true),
        ],
      ),
      gap(),
      summary([
        ('متوسط $subject', mean, Icons.bar_chart_outlined, 0),
        (
          'غياب الشهر',
          (attendance['absent']! + attendance['excused']!).toString(),
          Icons.event_busy_outlined,
          2,
        ),
      ]),
      if (series.isNotEmpty) ...[
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final (label, value) in series.skip(
              series.length > 3 ? series.length - 3 : 0,
            ))
              Expanded(
                child: Column(
                  children: [
                    Text(
                      displayNumber(numText(value ?? 0)),
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Container(
                      width: 26,
                      height: 39,
                      alignment: Alignment.bottomCenter,
                      decoration: BoxDecoration(
                        color: soft,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: FractionallySizedBox(
                        heightFactor: ((value ?? 0) / records.maximum(subject))
                            .clamp(0, 1)
                            .toDouble(),
                        widthFactor: 1,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: sectionAccent,
                            borderRadius: BorderRadius.circular(5),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(2),
                      child: Text(
                        label,
                        textAlign: TextAlign.center,
                        style: TextStyle(color: muted, fontSize: 10),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
        gap(),
      ],
      FilledButton.icon(
        onPressed: () {
          if (dialog != null) Navigator.pop(dialog);
          parentReport(s, month: date);
        },
        icon: const Icon(Icons.description_outlined),
        label: const Text('فتح بطاقة ولي الأمر'),
      ),
      if (dialog != null)
        OutlinedButton(
          onPressed: () {
            Navigator.pop(dialog);
            studentProfile(context, s);
          },
          child: const Text('فتح ملف التلميذ'),
        ),
    ]);
  }

  Future<void> editGrade(BuildContext context, Json student) async {
    final studentId = id(student);
    final maximum = records.maximum(subject);
    final course = subject;
    final term = period;
    final current = records.score(studentId, course, term);
    var typed = current == null ? '' : numText(current);
    var status = records.gradeStatus(studentId, course, term);
    String? validation;
    await showDialog<void>(
      context: context,
      useRootNavigator: false,
      builder: (dialog) => StatefulBuilder(
        builder: (context, setDialog) => AlertDialog(
          title: Text(name(student)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('$course · $term'),
                gap(),
                select(
                  'الحالة',
                  status,
                  gradeLabels.entries,
                  (v) => setDialog(() => status = v),
                ),
                gap(),
                TextFormField(
                  initialValue: typed,
                  onChanged: (v) => typed = v,
                  enabled: status == 'score',
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: InputDecoration(
                    labelText: 'من ${numText(maximum)}',
                    errorText: validation,
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialog),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () {
                final text = asciiDigits(typed.trim());
                final value = num.tryParse(text);
                if (status == 'score' &&
                    text.isNotEmpty &&
                    (value == null ||
                        !value.isFinite ||
                        value < 0 ||
                        value > maximum)) {
                  setDialog(
                    () =>
                        validation = 'أدخل رقماً بين صفر و${numText(maximum)}',
                  );
                  return;
                }
                update(() {
                  records.setGradeStatus(studentId, course, term, status);
                  if (status == 'score')
                    records.setScore(studentId, course, term, value);
                }, persist: true);
                Navigator.pop(dialog);
              },
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> pasteGrades(BuildContext context) async {
    final roster = students;
    final course = subject;
    final term = period;
    final text = await ask(
      context,
      'الصق عمود الدرجات بترتيب تلاميذ الصف',
      '',
      lines: 6,
    );
    if (text == null || text.isEmpty || !context.mounted) return;
    final lines = text
        .split(RegExp(r'\r?\n'))
        .map((line) => asciiDigits(line.trim()))
        .toList();
    if (lines.length != roster.length) {
      notify('يلزم إدخال سطر لكل تلميذ. عدد التلاميذ ${roster.length}.');
      return;
    }
    final values = lines.map(num.tryParse).toList();
    final maximum = records.maximum(course);
    if (values.any((v) => v == null || !v.isFinite || v < 0 || v > maximum)) {
      notify(
        'راجع عمود الدرجات. القيم المقبولة من صفر إلى ${numText(maximum)}.',
      );
      return;
    }
    final accepted = await showDialog<bool>(
      context: context,
      useRootNavigator: false,
      builder: (dialog) => AlertDialog(
        title: Text('$course · $term'),
        content: SizedBox(
          width: 380,
          child: ListView(
            shrinkWrap: true,
            children: [
              for (var i = 0; i < roster.length; i++)
                ListTile(
                  title: Text(name(roster[i])),
                  subtitle: Text(
                    'الدرجة الحالية ${records.gradeText(id(roster[i]), course, term)}',
                  ),
                  trailing: Text(numText(values[i]!)),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialog, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialog, true),
            child: const Text('حفظ الدرجات'),
          ),
        ],
      ),
    );
    if (accepted != true || !mounted) return;
    update(() {
      for (var i = 0; i < roster.length; i++) {
        records.setGradeStatus(id(roster[i]), course, term, 'score');
        records.setScore(id(roster[i]), course, term, values[i]);
      }
    }, persist: true);
  }

  Future<void> chooseDate(
    BuildContext context, {
    required bool forReport,
  }) async {
    final selection = await showDatePicker(
      context: context,
      useRootNavigator: false,
      initialDate: forReport ? reportMonth : date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100, 12, 31),
    );
    if (selection == null || !mounted) return;
    update(() {
      if (forReport) {
        reportMonth = selection;
      } else {
        date = selection;
      }
    });
  }

  List<Widget> attendancePage(BuildContext context) {
    final statuses = records.attendance(day);
    final present = students.where((s) => statuses[id(s)] == 'present').length;
    final absent = students
        .where((s) => ['absent', 'excused'].contains(statuses[id(s)]))
        .length;
    final pending = students
        .where((s) => !attendanceLabels.containsKey(statuses[id(s)]))
        .length;
    return [
      hero(
        'سجل الحضور',
        'سجّل الحضور والغياب لكل تلميذ حسب التاريخ.',
        Icons.event_available_outlined,
      ),
      if (enabled('summary'))
        summary([
          ('حاضر', present.toString(), Icons.check, 1),
          ('غياب', absent.toString(), Icons.event_busy_outlined, 2),
          ('غير مسجل', pending.toString(), Icons.schedule, 3),
        ]),
      filters([
        classPicker(),
        gap(),
        OutlinedButton.icon(
          onPressed: () => chooseDate(context, forReport: false),
          icon: const Icon(Icons.event),
          label: Text(displayNumber(day)),
        ),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: [
            TextButton.icon(
              onPressed: () => update(() => date = DateTime.now()),
              icon: const Icon(Icons.today_outlined),
              label: const Text('اليوم'),
            ),
            FilledButton.tonalIcon(
              onPressed: pending == 0
                  ? null
                  : () => update(() {
                      for (final s in students) {
                        if (!attendanceLabels.containsKey(statuses[id(s)])) {
                          records.setAttendance(day, id(s), 'present');
                        }
                      }
                    }, persist: true),
              icon: const Icon(Icons.check),
              label: const Text('تسجيل المتبقين حاضرين'),
            ),
          ],
        ),
      ]),
      panel([
        const Text(
          'كشف الحضور',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
        ),
        Text(
          'تُحفظ الحالة فور اختيارها',
          style: TextStyle(color: muted, fontSize: 11),
        ),
        gap(),
        searchBox(),
        gap(),
        if (matches.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('لا توجد أسماء مطابقة'),
          ),
        for (final s in matches)
          studentRow(
            s,
            onName: () => studentProfile(context, s),
            subline: object(
              object(records.data['attNotes'])[day],
            )[id(s)]?.toString(),
            controls: [
              IconButton(
                tooltip: 'ملاحظة الحضور',
                icon: const Icon(Icons.edit_note, size: 19),
                onPressed: () => editAttendanceNote(context, s),
              ),
              SizedBox(
                width: 110,
                child: select(
                  'الحالة',
                  statuses[id(s)]?.toString() ?? '',
                  [
                    const MapEntry('', 'غير مسجّل'),
                    ...attendanceLabels.entries,
                  ],
                  (v) => update(
                    () => records.setAttendance(day, id(s), v),
                    persist: true,
                  ),
                ),
              ),
            ],
          ),
      ]),
      OutlinedButton.icon(
        onPressed: () {
          update(() {
            reportKind = ReportKind.attendance;
            reportMonth = date;
          });
          openPage(2);
        },
        icon: const Icon(Icons.description_outlined),
        label: const Text('تقرير الحضور'),
      ),
    ];
  }

  Future<void> editAttendanceNote(BuildContext context, Json student) async {
    final selectedDay = day;
    final studentId = id(student);
    final existing =
        object(
          object(records.data['attNotes'])[selectedDay],
        )[studentId]?.toString() ??
        '';
    final value = await ask(
      context,
      'ملاحظة حضور ${name(student)}',
      existing,
      lines: 3,
    );
    if (value == null || !mounted) return;
    update(() {
      final all = object(records.data['attNotes']);
      final notes = object(all[selectedDay]);
      if (value.isEmpty) {
        notes.remove(studentId);
      } else {
        notes[studentId] = value;
      }
      all[selectedDay] = notes;
      records.data['attNotes'] = all;
    }, persist: true);
  }

  bool get parent => reportKind == ReportKind.parent;
  bool get needsStudent => parent || reportKind == ReportKind.student;
  bool get reportNeedsGrades => switch (reportKind) {
    ReportKind.annual || ReportKind.monthly || ReportKind.student => true,
    ReportKind.parent => fields.contains(ParentField.grades),
    ReportKind.attendance => false,
  };
  String? get reportMissingGrades {
    if (!reportNeedsGrades) return null;
    if (subject.isEmpty) return 'أضف مادة إلى هذا الصف لإعداد التقرير.';
    if (period.isEmpty) return 'أضف فترة تقييم لإعداد التقرير.';
    return null;
  }

  SchoolReport buildReport() => prepareReport(
    records: records,
    kind: reportKind,
    classId: classId,
    subject: subject,
    period: period,
    month: reportMonth,
    studentId: studentId,
    landscape: landscape,
    fields: fields,
    note: reportNote,
  );

  Future<void> makePreview() async {
    if (busy) return;
    final rev = reportRevision;
    setState(() => busy = true);
    try {
      final report = buildReport();
      final images = await renderReport(report);
      if (!mounted || rev != reportRevision) return;
      setState(() {
        preview = images;
        prepared = report;
      });
    } catch (e) {
      notify(
        e is FormatException ? e.message.toString() : 'تعذّر تجهيز التقرير',
      );
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> export(String extension) async {
    final report = prepared;
    final document = preview;
    if (report == null || document == null) return;
    try {
      final bytes = switch (extension) {
        'docx' => wordReport(report),
        'xlsx' => excelReport(report),
        _ => document.pdf,
      };
      final mime = switch (extension) {
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xlsx' =>
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        _ => 'application/pdf',
      };
      final saved = await platform.invokeMethod<bool>('saveFile', {
        'name': '${report.title}-${dayKey(DateTime.now())}.$extension',
        'mime': mime,
        'bytes': bytes,
      });
      if (saved == true) notify('تم حفظ الملف');
    } catch (_) {
      notify('تعذّر حفظ الملف');
    }
  }

  Future<void> printPreview() async {
    final document = preview;
    final report = prepared;
    if (document == null || report == null) return;
    try {
      await platform.invokeMethod<void>('printPdf', {
        'name': report.title,
        'bytes': document.pdf,
        'landscape': report.landscape,
        'pageCount': document.images.length,
      });
    } catch (_) {
      notify('تعذّرت الطباعة');
    }
  }

  List<Widget> reportsPage(BuildContext context) => [
    hero(
      'التقارير',
      'اختر التقرير وراجع محتواه قبل الطباعة.',
      Icons.description_outlined,
    ),
    filters([
      select(
        'نوع التقرير',
        reportKind,
        ReportKind.values.map((v) => MapEntry(v, v.label)),
        (v) => update(() {
          reportKind = v;
          reportNote = '';
        }),
      ),
      gap(),
      classPicker(),
      gap(),
      if (reportKind == ReportKind.annual ||
          reportKind == ReportKind.monthly) ...[
        subjectPicker(),
        gap(),
      ],
      if (needsStudent) ...[
        select(
          'التلميذ',
          studentId,
          students.map((s) => MapEntry(id(s), name(s))),
          (v) => update(() {
            studentId = v;
            reportNote = '';
          }),
        ),
        gap(),
      ],
      if (reportKind == ReportKind.monthly ||
          reportKind == ReportKind.student ||
          (parent && fields.contains(ParentField.grades))) ...[
        periodPicker(),
        gap(),
      ],
      if (reportKind == ReportKind.attendance ||
          (parent && fields.contains(ParentField.attendance))) ...[
        OutlinedButton.icon(
          onPressed: () => chooseDate(context, forReport: true),
          icon: const Icon(Icons.calendar_month),
          label: Text(
            'شهر الحضور · ${monthNames[reportMonth.month - 1]} ${reportMonth.year}',
          ),
        ),
        gap(),
      ],
      select('اتجاه ورقة A4', landscape, const [
        MapEntry(true, 'أفقي'),
        MapEntry(false, 'عمودي'),
      ], (v) => update(() => landscape = v)),
      if (parent) ...[
        const Text('الحقول الظاهرة في بطاقة A4'),
        Wrap(
          spacing: 7,
          runSpacing: 4,
          children: [
            for (final field in ParentField.values)
              FilterChip(
                label: Text(field.label),
                selected: fields.contains(field),
                onSelected: (v) => update(() {
                  if (v) {
                    fields.add(field);
                  } else {
                    fields.remove(field);
                  }
                }),
              ),
          ],
        ),
        if (fields.contains(ParentField.note)) ...[
          gap(),
          TextFormField(
            key: ValueKey('note-$classId-$studentId'),
            initialValue: reportNote,
            maxLength: 240,
            maxLines: 3,
            onChanged: (v) => update(() => reportNote = v),
            decoration: const InputDecoration(
              labelText: 'ملاحظة تظهر لولي الأمر',
            ),
          ),
        ],
      ],
      gap(),
      if (reportMissingGrades case final message?) ...[Text(message), gap()],
      FilledButton.icon(
        onPressed:
            busy ||
                reportMissingGrades != null ||
                (needsStudent && studentId.isEmpty) ||
                (parent && fields.isEmpty)
            ? null
            : makePreview,
        icon: busy
            ? const SizedBox.square(
                dimension: 16,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : const Icon(Icons.preview_outlined),
        label: Text(busy ? 'جارٍ التجهيز' : 'معاينة التقرير'),
      ),
    ]),
    if (preview != null) ...[
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          FilledButton.tonalIcon(
            onPressed: () => export('pdf'),
            icon: const Icon(Icons.download_outlined),
            label: const Text('حفظ PDF'),
          ),
          OutlinedButton(onPressed: printPreview, child: const Text('طباعة')),
          OutlinedButton(
            onPressed: () => export('docx'),
            child: const Text('Word'),
          ),
          OutlinedButton(
            onPressed: () => export('xlsx'),
            child: const Text('Excel'),
          ),
        ],
      ),
      gap(),
      for (final image in preview!.images)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: InteractiveViewer(
            maxScale: 4,
            child: Image.memory(image, fit: BoxFit.contain),
          ),
        ),
    ],
  ];

  List<Widget> settingsPage(BuildContext context) {
    if (settingsPanel == 'school')
      return [
        title('بيانات المدرسة'),
        panel([
          for (final e in const {
            'school': 'اسم المدرسة',
            'teacher': 'اسم المعلم',
            'director': 'اسم المدير',
            'year': 'السنة الدراسية',
          }.entries) ...[
            TextFormField(
              initialValue: records.data[e.key]?.toString() ?? '',
              decoration: InputDecoration(labelText: e.value),
              onChanged: (v) {
                records.data[e.key] = v;
              },
              onFieldSubmitted: (_) => update(() {}, persist: true),
            ),
            gap(),
          ],
          FilledButton(
            onPressed: () {
              update(() {}, persist: true);
            },
            child: const Text('حفظ البيانات'),
          ),
        ]),
      ];
    if (settingsPanel == 'people') {
      final roster = students;
      final visibleIds = matches.map(id).toSet();
      return [
        title('الصفوف والتلاميذ'),
        panel([
          classPicker(),
          gap(),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              OutlinedButton(
                onPressed: () => editClass(context),
                child: const Text('إضافة صف'),
              ),
              FilledButton(
                onPressed: classId.isEmpty ? null : () => editStudent(context),
                child: const Text('إضافة تلميذ'),
              ),
            ],
          ),
        ]),
        panel([
          const Text(
            'إدارة الصفوف',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          for (final (index, row) in records.classes.indexed)
            ListTile(
              title: Text(name(row)),
              subtitle: row['archived'] == true ? const Text('مؤرشف') : null,
              trailing: itemActions(
                edit: () => editClass(context, target: row),
                remove: () => deleteClass(context, row),
                up: index > 0
                    ? () => update(
                        () => records.moveClass(id(row), -1),
                        persist: true,
                      )
                    : null,
                down: index + 1 < records.classes.length
                    ? () => update(
                        () => records.moveClass(id(row), 1),
                        persist: true,
                      )
                    : null,
              ),
            ),
        ]),
        panel([
          const Text(
            'قائمة التلاميذ',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
          ),
          gap(),
          searchBox(),
          gap(),
          if (matches.isEmpty)
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('لا توجد أسماء مطابقة'),
            ),
          OutlinedButton.icon(
            onPressed: records.manualStudentOrder(classId)
                ? () => update(
                    () => records.alphabeticalStudentOrder(classId),
                    persist: true,
                  )
                : null,
            icon: const Icon(Icons.sort_by_alpha),
            label: const Text('الذكور ثم الإناث أبجديًا'),
          ),
          for (final (index, student) in roster.indexed)
            if (visibleIds.contains(id(student)))
              ListTile(
                title: Text(name(student)),
                subtitle: Text(studentGenders[studentGender(student)]!),
                onTap: () => studentProfile(context, student),
                trailing: itemActions(
                  edit: () => editStudent(context, student),
                  remove: () => confirmDelete(context, student),
                  up: index > 0
                      ? () => update(
                          () => records.moveStudent(classId, id(student), -1),
                          persist: true,
                        )
                      : null,
                  down: index + 1 < roster.length
                      ? () => update(
                          () => records.moveStudent(classId, id(student), 1),
                          persist: true,
                        )
                      : null,
                ),
              ),
        ]),
        if (records.people.any(
          (s) => s['archived'] == true && s['classId'].toString() == classId,
        ))
          ExpansionTile(
            title: const Text('الأسماء المؤرشفة'),
            children: [
              for (final s in records.people.where(
                (s) =>
                    s['archived'] == true && s['classId'].toString() == classId,
              ))
                ListTile(
                  title: Text(name(s)),
                  onTap: () => studentProfile(context, s),
                  trailing: TextButton(
                    onPressed: () => update(() {
                      records.data['students'] = records.people
                          .map(
                            (r) =>
                                id(r) == id(s) ? {...r, 'archived': false} : r,
                          )
                          .toList();
                    }, persist: true),
                    child: const Text('استعادة'),
                  ),
                ),
            ],
          ),
      ];
    }
    if (settingsPanel == 'courses')
      return [
        title('المواد والفترات'),
        panel([
          classPicker(),
          gap(),
          Text('المواد في ${records.className(classId)}'),
          if (classId.isNotEmpty)
            for (final (index, course) in records.subjects(classId).indexed)
              ListTile(
                title: Text(course),
                subtitle: Text(
                  'الدرجة من ${displayNumber(numText(records.maximum(course)))}',
                ),
                trailing: itemActions(
                  edit: () => changeCourse(context, course, rename: true),
                  extra: MapEntry(
                    'تعديل الدرجة القصوى',
                    () => editCourse(context, course),
                  ),
                  remove: () => changeCourse(context, course),
                  up: index > 0
                      ? () => update(
                          () => records.moveSubject(classId, course, -1),
                          persist: true,
                        )
                      : null,
                  down: index + 1 < records.subjects(classId).length
                      ? () => update(
                          () => records.moveSubject(classId, course, 1),
                          persist: true,
                        )
                      : null,
                ),
              ),
          OutlinedButton(
            onPressed: classId.isEmpty ? null : () => editCourse(context),
            child: const Text('إضافة مادة'),
          ),
        ]),
        panel([
          for (final (index, p) in records.periods.indexed)
            ListTile(
              title: Text(p['key'].toString()),
              subtitle: Text(p['section'].toString()),
              trailing: itemActions(
                edit: () => editPeriod(context, p),
                remove: () => deletePeriod(context, p['key'].toString()),
                up: index > 0
                    ? () => update(
                        () => records.movePeriod(p['key'].toString(), -1),
                        persist: true,
                      )
                    : null,
                down: index + 1 < records.periods.length
                    ? () => update(
                        () => records.movePeriod(p['key'].toString(), 1),
                        persist: true,
                      )
                    : null,
              ),
            ),
          OutlinedButton(
            onPressed: () => editPeriod(context),
            child: const Text('إضافة فترة'),
          ),
        ]),
      ];
    if (settingsPanel == 'calculation')
      return [
        title('طريقة احتساب النتائج'),
        panel([
          for (final e in const {
            'f1': 'وزن معدل الفصل الأول',
            'mid': 'وزن نصف السنة',
            'f2': 'وزن معدل الفصل الثاني',
            'sai': 'وزن السعي',
            'exam': 'وزن الامتحان النهائي',
          }.entries)
            ListTile(
              title: Text(e.value),
              trailing: TextButton(
                onPressed: () => editWeight(context, e.key, e.value),
                child: Text(
                  (object(records.data['calc'])[e.key] ?? 1).toString(),
                ),
              ),
            ),
          select(
            'التقريب',
            (records.data['rounding'] ?? 'nearest').toString(),
            const [
              MapEntry('nearest', 'أقرب عدد صحيح'),
              MapEntry('floor', 'نزولاً'),
              MapEntry('decimal', 'منزلة عشرية'),
            ],
            (v) => update(() => records.data['rounding'] = v, persist: true),
          ),
        ]),
      ];
    if (settingsPanel == 'style') return styleSettings(context);
    if (settingsPanel == 'display') return displaySettings();
    if (settingsPanel == 'backup')
      return [
        title('النسخ الاحتياطية'),
        panel([
          FilledButton.icon(
            onPressed: backup,
            icon: const Icon(Icons.download_outlined),
            label: const Text('حفظ نسخة احتياطية'),
          ),
          gap(),
          OutlinedButton.icon(
            onPressed: () => restore(context),
            icon: const Icon(Icons.upload_file),
            label: const Text('استيراد نسخة سجلّي JSON'),
          ),
        ]),
      ];
    return [
      hero(
        'الإعدادات',
        'إدارة التلاميذ وضبط بيانات المدرسة وألوان الواجهة.',
        Icons.settings_outlined,
      ),
      settingsCards(),
    ];
  }

  Widget preferencePicker(
    String label,
    String key,
    String fallback,
    List<MapEntry<String, String>> options, {
    IconData icon = Icons.tune,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 11),
    child: Row(
      children: [
        badge(icon),
        const SizedBox(width: 9),
        Expanded(
          child: select(label, preference(key, fallback), options, (value) {
            if (key == 'a4') landscape = value == 'landscape';
            setPreference(key, value);
          }),
        ),
      ],
    ),
  );

  Widget toggled(String label, String key, IconData icon) => SwitchListTile(
    contentPadding: EdgeInsets.zero,
    secondary: badge(icon),
    title: Text(label),
    value: enabled(key),
    onChanged: (value) => setPreference(key, value),
  );

  Widget colorGroup(BuildContext context, String key, String label) {
    final active = color(key),
        customized = object(records.data['focusColors']).containsKey(key);
    return panel([
      Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
          OutlinedButton(
            onPressed: () => editColor(context, key),
            child: const Text('لون مخصص'),
          ),
        ],
      ),
      gap(5),
      Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final entry in sajliPalettes.entries)
            ChoiceChip(
              label: Text(entry.key),
              avatar: CircleAvatar(backgroundColor: entry.value),
              selected: active == entry.value,
              showCheckmark: false,
              onSelected: (_) => setColor(key, entry.value),
            ),
          if (key != 'primary')
            TextButton(
              onPressed: customized
                  ? () => update(() {
                      final colors = object(records.data['focusColors'])
                        ..remove(key);
                      records.data['focusColors'] = colors;
                    }, persist: true)
                  : null,
              child: const Text('اتّباع لون التطبيق'),
            ),
        ],
      ),
    ]);
  }

  void setColor(String key, Color value) => update(() {
    final hex = value.toARGB32().toRadixString(16).padLeft(8, '0').substring(2);
    records.data['focusColors'] = {
      ...object(records.data['focusColors']),
      key: '#$hex',
    };
  }, persist: true);

  List<Widget> styleSettings(BuildContext context) => [
    title('المظهر والألوان'),
    panel([
      if (widget.darkOverride == null)
        preferencePicker(
          'مظهر التطبيق',
          'theme',
          records.data['dark'] == true ? 'dark' : 'light',
          const [
            MapEntry('light', 'فاتح'),
            MapEntry('dark', 'داكن'),
            MapEntry('system', 'حسب الجهاز'),
          ],
          icon: Icons.brightness_6_outlined,
        ),
      preferencePicker('حجم الخط', 'font', 'normal', const [
        MapEntry('small', 'صغير'),
        MapEntry('normal', 'عادي'),
        MapEntry('large', 'كبير'),
        MapEntry('largest', 'كبير جدًا'),
      ], icon: Icons.text_fields),
      preferencePicker('كثافة القوائم', 'density', 'normal', const [
        MapEntry('normal', 'مريحة'),
        MapEntry('compact', 'مدمجة'),
      ], icon: Icons.view_agenda_outlined),
      preferencePicker('شكل الأرقام في الواجهة', 'digits', 'arabic', const [
        MapEntry('arabic', '١٢٣'),
        MapEntry('latin', '123'),
      ], icon: Icons.pin_outlined),
    ]),
    for (final entry in const {
      'primary': 'لون التطبيق',
      'grades': 'الدرجات',
      'attendance': 'الحضور',
      'reports': 'التقارير',
    }.entries)
      colorGroup(context, entry.key, entry.value),
    OutlinedButton(
      onPressed: () =>
          update(() => records.data.remove('focusColors'), persist: true),
      child: const Text('استعادة الألوان الافتراضية'),
    ),
  ];

  List<Widget> displaySettings() => [
    title('تفضيلات العرض'),
    panel([
      preferencePicker('ارتفاع البطاقة الرئيسية', 'hero', 'tall', const [
        MapEntry('compact', 'متوسطة'),
        MapEntry('tall', 'مرتفعة'),
        MapEntry('extra', 'مرتفعة جدًا'),
      ], icon: Icons.height),
      toggled('رسوم البطاقات الرئيسية', 'art', Icons.auto_awesome_outlined),
      toggled('ملخصات الدرجات والحضور', 'summary', Icons.dashboard_outlined),
      toggled(
        'بطاقة المتابعة على شاشة الدرجات',
        'follow',
        Icons.contact_page_outlined,
      ),
      preferencePicker('أرقام التلاميذ في القوائم', 'numbers', 'show', const [
        MapEntry('show', 'إظهار'),
        MapEntry('hide', 'إخفاء'),
      ], icon: Icons.badge_outlined),
    ]),
    panel([
      preferencePicker('شاشة البداية', 'start', 'grades', const [
        MapEntry('grades', 'الدرجات'),
        MapEntry('attendance', 'الحضور'),
        MapEntry('reports', 'التقارير'),
      ], icon: Icons.home_outlined),
      preferencePicker('اتجاه A4 الافتراضي', 'a4', 'portrait', const [
        MapEntry('portrait', 'عمودي'),
        MapEntry('landscape', 'أفقي'),
      ], icon: Icons.description_outlined),
    ]),
  ];

  Widget settingsCards() {
    const cards = [
      (
        'people',
        'الصفوف والتلاميذ',
        'إضافة الأسماء وإدارتها',
        Icons.people_outline,
        0,
      ),
      (
        'style',
        'المظهر والألوان',
        'ألوان الأقسام والخط',
        Icons.palette_outlined,
        2,
      ),
      (
        'display',
        'تفضيلات العرض',
        'البطاقة الرئيسية وشاشة البداية',
        Icons.tune,
        3,
      ),
      (
        'school',
        'بيانات المدرسة',
        'الاسم والعام الدراسي',
        Icons.school_outlined,
        1,
      ),
      (
        'courses',
        'المواد والفترات',
        'الحدود القصوى وفترات التقييم',
        Icons.menu_book_outlined,
        0,
      ),
      (
        'calculation',
        'الاحتساب',
        'أوزان الدرجات وطريقة التقريب',
        Icons.calculate_outlined,
        3,
      ),
      (
        'backup',
        'النسخ الاحتياطية',
        'حفظ البيانات أو استعادتها',
        Icons.backup_outlined,
        1,
      ),
    ];
    return LayoutBuilder(
      builder: (context, layout) {
        final columns = layout.maxWidth >= 850
            ? 3
            : layout.maxWidth < 285
            ? 1
            : 2;
        final width = (layout.maxWidth - 10 * (columns - 1)) / columns;
        return Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final (id, label, hint, icon, tone) in cards)
              SizedBox(
                width: width,
                child: Material(
                  color: surface,
                  clipBehavior: Clip.antiAlias,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                    side: BorderSide(color: line),
                  ),
                  child: InkWell(
                    onTap: () => setState(() {
                      settingsPanel = id;
                      query = '';
                      search.clear();
                    }),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(minHeight: 100),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          children: [
                            badge(icon, tone),
                            const SizedBox(width: 7),
                            Expanded(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    label,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 13,
                                    ),
                                  ),
                                  Text(
                                    hint,
                                    style: TextStyle(
                                      color: muted,
                                      fontSize: 10,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  Future<String?> ask(
    BuildContext context,
    String titleText,
    String initial, {
    TextInputType? keyboardType,
    int lines = 1,
  }) async {
    var result = initial;
    return showDialog<String>(
      context: context,
      useRootNavigator: false,
      builder: (dialog) => AlertDialog(
        title: Text(titleText),
        content: TextFormField(
          initialValue: initial,
          autofocus: true,
          keyboardType: keyboardType,
          maxLines: lines,
          onChanged: (value) => result = value,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialog),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialog, result.trim()),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Widget itemActions({
    required VoidCallback edit,
    required VoidCallback remove,
    VoidCallback? up,
    VoidCallback? down,
    MapEntry<String, VoidCallback>? extra,
  }) {
    final actions = [
      MapEntry('تعديل', edit),
      if (extra != null) extra,
      if (up != null) MapEntry('نقل لأعلى', up),
      if (down != null) MapEntry('نقل لأسفل', down),
      MapEntry('حذف', remove),
    ];
    return PopupMenuButton<int>(
      tooltip: 'إجراءات',
      onSelected: (index) => actions[index].value(),
      itemBuilder: (_) => [
        for (final (index, action) in actions.indexed)
          PopupMenuItem(value: index, child: Text(action.key)),
      ],
    );
  }

  Future<bool> confirmRemoval(
    BuildContext context,
    String title,
    String detail,
  ) async =>
      await showDialog<bool>(
        context: context,
        useRootNavigator: false,
        builder: (dialog) => AlertDialog(
          title: Text(title),
          content: Text(detail),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialog, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialog, true),
              child: const Text('تأكيد الحذف'),
            ),
          ],
        ),
      ) ==
      true;

  Future<void> editClass(BuildContext context, {Json? target}) async {
    final value = await ask(
      context,
      target == null ? 'الصف الجديد' : 'اسم الصف والشعبة',
      target == null ? '' : name(target),
    );
    if (value == null || value.isEmpty || !mounted) return;
    if (records.classes.any(
      (c) => name(c) == value && (target == null || id(c) != id(target)),
    )) {
      notify('يوجد صف بهذا الاسم');
      return;
    }
    update(() {
      final rows = records.classes;
      if (target != null) {
        rows.firstWhere((r) => id(r) == id(target))['name'] = value;
        records.data['classes'] = rows;
      } else {
        final key = 'c${DateTime.now().microsecondsSinceEpoch}';
        rows.add({'id': key, 'name': value});
        records.data['classes'] = rows;
        selectClass(key);
      }
    }, persist: true);
  }

  Future<void> deleteClass(BuildContext context, Json row) async {
    final key = id(row);
    if (!await confirmRemoval(
      context,
      'حذف الصف',
      'سيُحذف «${name(row)}» مع جميع تلاميذه ودرجاتهم وحضورهم.',
    ))
      return;
    if (!mounted || !records.deleteClass(key)) return;
    update(() {
      if (classId == key)
        selectClass(records.activeClasses.firstOrNull?['id']?.toString() ?? '');
    }, persist: true);
    notify('حُذف الصف');
  }

  Future<void> changeCourse(
    BuildContext context,
    String course, {
    bool rename = false,
  }) async {
    final target = classId;
    String? replacement;
    if (rename) {
      replacement = await ask(context, 'تعديل اسم المادة', course);
      if (replacement == null ||
          replacement.isEmpty ||
          replacement == course ||
          !mounted)
        return;
      if (records.subjects(target).contains(replacement)) {
        notify('المادة موجودة في هذا الصف');
        return;
      }
    } else {
      if (!await confirmRemoval(
        context,
        'حذف المادة',
        'سيُحذف «$course» من الصف المحدد مع درجاتها في هذا الصف.',
      ))
        return;
    }
    if (!mounted) return;
    try {
      if (!records.changeSubject(target, course, replacement)) return;
      update(() {
        if (classId == target && subject == course) {
          subject = replacement ?? records.subjects(target).firstOrNull ?? '';
        }
      }, persist: true);
    } on FormatException catch (error) {
      notify(error.message);
    }
  }

  Future<void> deletePeriod(BuildContext context, String key) async {
    if (!await confirmRemoval(
      context,
      'حذف الفترة',
      'سيُحذف «$key» مع الدرجات المسجّلة فيه لجميع الصفوف.',
    ))
      return;
    if (!mounted || !records.deletePeriod(key)) return;
    update(() {
      if (period == key)
        period = records.periods.firstOrNull?['key']?.toString() ?? '';
    }, persist: true);
  }

  Future<void> studentProfile(BuildContext context, Json student) async {
    // Sajli is a nested MaterialApp inside Madrasati. Its Material widgets
    // must be presented by Sajli's own Navigator, never the outer application's
    // incompatible Material overlay. Keep the approved bottom-aligned design.
    final action = await showDialog<String>(
      context: context,
      useRootNavigator: false,
      barrierDismissible: true,
      barrierColor: const Color(0x66000000),
      builder: (_) => Dialog(
        alignment: Alignment.bottomCenter,
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        clipBehavior: Clip.antiAlias,
        insetPadding: const EdgeInsets.fromLTRB(12, 24, 12, 8),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(26),
              bottom: Radius.circular(18)),
        ),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 540),
          child: StudentGradeSheet(
            records: records,
            student: student,
            initialSubject: subject,
            initialPeriod: period,
            onSave: (course, term, status, score) {
              update(() {
                records.setGradeStatus(id(student), course, term, status);
                if (status == 'score') {
                  records.setScore(id(student), course, term, score);
                }
                subject = course;
                period = term;
              }, persist: true);
              notify('حُفظت درجة ${name(student)}.');
            },
          ),
        ),
      ),
    );
    if (!context.mounted) return;
    switch (action) {
      case 'parent':
        parentReport(student, month: date);
      case 'edit':
        await editStudent(context, student);
      case 'delete':
        await confirmDelete(context, student);
      case 'attendance':
        setState(() => page = 1);
    }
  }

  Future<void> confirmDelete(BuildContext context, Json student) async {
    final accepted = await showDialog<bool>(
      context: context,
      useRootNavigator: false,
      builder: (dialog) => AlertDialog(
        title: const Text('حذف التلميذ'),
        content: Text(
          'حذف ${name(student)} من ${records.className(student['classId'].toString())}؟ '
          'ستحذف درجاته وسجلات حضوره وملاحظات الحضور أيضًا.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialog, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(dialog).colorScheme.error,
              foregroundColor: Theme.of(dialog).colorScheme.onError,
            ),
            onPressed: () => Navigator.pop(dialog, true),
            child: const Text('تأكيد الحذف'),
          ),
        ],
      ),
    );
    if (accepted != true || !mounted) return;
    final store = records;
    final key = id(student);
    final removed = store.deleteStudent(key);
    if (removed == null) return;
    update(() {
      if (followId == key) followId = null;
      if (studentId == key) {
        studentId = students.firstOrNull?['id']?.toString() ?? '';
        reportNote = '';
      }
    }, persist: true);
    messenger.currentState?.clearSnackBars();
    messenger.currentState?.showSnackBar(
      SnackBar(
        content: Text('حُذف ملف ${name(student)}'),
        duration: const Duration(seconds: 10),
        action: SnackBarAction(
          label: 'تراجع',
          onPressed: () {
            if (identical(records, store) && records.restoreStudent(removed)) {
              update(() {
                if (student['classId'].toString() == classId &&
                    student['archived'] != true) {
                  followId = key;
                  if (studentId.isEmpty) studentId = key;
                }
              }, persist: true);
              notify('استُعيد ملف ${name(student)}');
            }
          },
        ),
      ),
    );
  }

  Future<void> editStudent(BuildContext context, [Json? student]) async {
    var typed = student == null ? '' : name(student);
    var gender = student == null ? 'unknown' : studentGender(student);
    var number = student?['number']?.toString() ?? '';
    var notes = student?['notes']?.toString() ?? '';
    final value =
        await showDialog<
          ({
            String name,
            String gender,
            String number,
            String notes,
            bool archive,
          })
        >(
          context: context,
          useRootNavigator: false,
          builder: (dialog) => StatefulBuilder(
            builder: (context, setDialog) => AlertDialog(
              title: Text(student == null ? 'إضافة تلميذ' : 'تعديل التلميذ'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      initialValue: typed,
                      autofocus: true,
                      onChanged: (v) => typed = v,
                      decoration: const InputDecoration(
                        labelText: 'اسم التلميذ',
                      ),
                    ),
                    gap(),
                    select(
                      'الجنس',
                      gender,
                      studentGenders.entries,
                      (v) => setDialog(() => gender = v),
                    ),
                    gap(),
                    TextFormField(
                      initialValue: number,
                      onChanged: (v) => number = v,
                      decoration: const InputDecoration(
                        labelText: 'رقم التلميذ',
                      ),
                    ),
                    gap(),
                    TextFormField(
                      initialValue: notes,
                      onChanged: (v) => notes = v,
                      maxLines: 2,
                      decoration: const InputDecoration(labelText: 'ملاحظات'),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialog),
                  child: const Text('إلغاء'),
                ),
                if (student != null)
                  TextButton(
                    onPressed: () => Navigator.pop(dialog, (
                      name: typed.trim(),
                      gender: gender,
                      number: number.trim(),
                      notes: notes.trim(),
                      archive: true,
                    )),
                    child: const Text('أرشفة'),
                  ),
                FilledButton(
                  onPressed: () => Navigator.pop(dialog, (
                    name: typed.trim(),
                    gender: gender,
                    number: number.trim(),
                    notes: notes.trim(),
                    archive: false,
                  )),
                  child: const Text('حفظ'),
                ),
              ],
            ),
          ),
        );
    if (value == null || (!value.archive && value.name.isEmpty) || !mounted)
      return;
    update(() {
      final people = records.people;
      if (student == null) {
        final newId = DateTime.now().microsecondsSinceEpoch.toString();
        people.add({
          'id': newId,
          'classId': classId,
          'name': value.name,
          'gender': value.gender,
          'notes': value.notes,
          'number': value.number.isEmpty ? 'ST-$newId' : value.number,
        });
        if (studentId.isEmpty) studentId = newId;
      } else {
        final row = people.firstWhere((r) => id(r) == id(student));
        if (value.archive) {
          row['archived'] = true;
        } else {
          row.addAll({
            'name': value.name,
            'gender': value.gender,
            'number': value.number,
            'notes': value.notes,
          });
        }
      }
      records.data['students'] = people;
      if (!students.any((s) => id(s) == studentId)) {
        studentId = students.firstOrNull?['id']?.toString() ?? '';
        reportNote = '';
      }
    }, persist: true);
  }

  Future<void> editCourse(BuildContext context, [String? current]) async {
    if (current == null) {
      final value = await ask(context, 'اسم المادة', '');
      if (value == null || value.isEmpty || !mounted) return;
      if (records.subjects(classId).contains(value)) {
        notify('المادة موجودة');
        return;
      }
      update(() {
        records.addSubject(classId, value);
        if (subject.isEmpty) subject = value;
      }, persist: true);
      return;
    }
    final value = await ask(
      context,
      'الدرجة القصوى لمادة $current',
      numText(records.maximum(current)),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
    );
    if (value == null || !mounted) return;
    final maximum = num.tryParse(asciiDigits(value));
    if (maximum == null || !maximum.isFinite || maximum < 1 || maximum > 1000) {
      notify('أدخل درجة قصوى بين 1 و1000');
      return;
    }
    final oldGrades = object(records.data['grades']).values
        .expand((s) => object(object(s)[current]).values);
    if (oldGrades.any((v) => v is num && v > maximum)) {
      notify('هناك درجات مسجّلة تتجاوز الحد الجديد');
      return;
    }
    update(
      () => records.data['gradeMax'] = {
        ...object(records.data['gradeMax']),
        current: maximum,
      },
      persist: true,
    );
  }

  Future<void> editPeriod(BuildContext context, [Json? current]) async {
    var term = current?['section']?.toString() ?? groups.first;
    var value = current?['key']?.toString() ?? '';
    final result = await showDialog<({String name, String term})>(
      context: context,
      useRootNavigator: false,
      builder: (dialog) => StatefulBuilder(
        builder: (context, setDialog) => AlertDialog(
          title: Text(current == null ? 'إضافة فترة' : 'تعديل الفترة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                initialValue: value,
                onChanged: (v) => value = v,
                decoration: const InputDecoration(labelText: 'اسم الفترة'),
              ),
              gap(),
              select(
                'المجموعة',
                term,
                groups.map((g) => MapEntry(g, g)),
                (v) => setDialog(() => term = v),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialog),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.pop(dialog, (name: value.trim(), term: term)),
              child: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
    if (result == null || result.name.isEmpty || !mounted) return;
    if (records.periods.any(
      (p) => p['key'] == result.name && p['key'] != current?['key'],
    )) {
      notify('اسم الفترة مكرر');
      return;
    }
    if ([groups[1], groups[3]].contains(result.term) &&
        records.periods.any(
          (p) => p['section'] == result.term && p['key'] != current?['key'],
        )) {
      notify('هذه المجموعة تقبل فترة واحدة');
      return;
    }
    update(() {
      final periods = records.periods;
      final next = {
        'key': result.name,
        'short': result.name,
        'section': result.term,
      };
      final previous = current?['key']?.toString();
      if (previous == null) {
        periods.add(next);
        if (period.isEmpty) period = result.name;
      } else {
        periods[periods.indexWhere((p) => p['key'] == previous)] = next;
        if (period == previous) period = result.name;
        if (previous != result.name) {
          for (final key in ['grades', 'gradeStates']) {
            final root = object(records.data[key]);
            for (final student in root.keys.toList()) {
              final courses = object(root[student]);
              for (final subject in courses.keys.toList()) {
                final values = object(courses[subject]);
                if (values.containsKey(previous))
                  values[result.name] = values.remove(previous);
                courses[subject] = values;
              }
              root[student] = courses;
            }
            records.data[key] = root;
          }
        }
      }
      records.data['periods'] = periods;
    }, persist: true);
  }

  Future<void> editWeight(
    BuildContext context,
    String key,
    String label,
  ) async {
    final raw = await ask(
      context,
      label,
      (object(records.data['calc'])[key] ?? 1).toString(),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
    );
    if (raw == null || !mounted) return;
    final value = num.tryParse(asciiDigits(raw));
    if (value == null || !value.isFinite || value < 0 || value > 100) {
      notify('الوزن المقبول بين صفر و100');
      return;
    }
    final calc = {...object(records.data['calc']), key: value};
    num w(String k) => calc[k] is num ? calc[k] as num : 1;
    if (w('f1') + w('mid') + w('f2') <= 0 || w('sai') + w('exam') <= 0) {
      notify('مجموع الأوزان يجب أن يكون أكبر من صفر');
      return;
    }
    update(() => records.data['calc'] = calc, persist: true);
  }

  Future<void> editColor(BuildContext context, String key) async {
    final value = await ask(
      context,
      'اللون بصيغة HEX',
      '#${color(key).toARGB32().toRadixString(16).padLeft(8, '0').substring(2)}',
    );
    if (value == null || !mounted) return;
    if (!RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(value)) {
      notify('أدخل لوناً مثل #176f65');
      return;
    }
    setColor(key, Color(int.parse('ff${value.substring(1)}', radix: 16)));
  }

  Future<void> backup() async {
    try {
      final saved = await platform.invokeMethod<bool>('saveFile', {
        'name': 'sajli-backup-${dayKey(DateTime.now())}.json',
        'mime': 'application/json',
        'bytes': Uint8List.fromList(utf8.encode(jsonEncode(records.data))),
      });
      if (saved == true) notify('تم حفظ النسخة الاحتياطية');
    } catch (_) {
      notify('تعذّر حفظ النسخة الاحتياطية');
    }
  }

  Future<void> restore(BuildContext context) async {
    try {
      final bytes = await platform.invokeMethod<Uint8List>('openJson');
      if (bytes == null || !context.mounted) return;
      final incoming = Records.decode(utf8.decode(bytes));
      final confirmed = await showDialog<bool>(
        context: context,
        useRootNavigator: false,
        builder: (dialog) => AlertDialog(
          title: const Text('استيراد النسخة الاحتياطية'),
          content: Text(
            '${incoming.school}\n${incoming.people.length} تلميذ\nستحل هذه البيانات محل البيانات الحالية.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialog, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialog, true),
              child: const Text('استيراد'),
            ),
          ],
        ),
      );
      if (confirmed != true || !mounted) return;
      update(() {
        messenger.currentState?.clearSnackBars();
        records = incoming;
        migrateDefaultPalette();
        landscape = preference('a4', 'portrait') == 'landscape';
        selectClass(
          incoming.activeClasses.firstOrNull?['id']?.toString() ?? '',
        );
        period = incoming.periods.firstOrNull?['key']?.toString() ?? '';
      }, persist: true);
    } catch (_) {
      notify('تعذّر قراءة النسخة الاحتياطية أو أنها غير صالحة');
    }
  }
}
