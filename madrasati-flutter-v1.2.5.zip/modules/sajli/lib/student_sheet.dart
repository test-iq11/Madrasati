import 'package:material_ui/material_ui.dart';

import 'records.dart';

/// The grade editor uses the same Material implementation as SajliApp.
/// Mixing Flutter Material with material_ui causes missing Material ancestors.
class StudentGradeSheet extends StatefulWidget {
  const StudentGradeSheet({
    required this.records,
    required this.student,
    required this.initialSubject,
    required this.initialPeriod,
    required this.onSave,
    super.key,
  });

  final Records records;
  final Json student;
  final String initialSubject;
  final String initialPeriod;
  final void Function(String subject, String period, String status, num? score)
      onSave;

  @override
  State<StudentGradeSheet> createState() => _StudentGradeSheetState();
}

class _StudentGradeSheetState extends State<StudentGradeSheet> {
  final _gradeController = TextEditingController();
  late String _course;
  late String _period;
  late String _status;
  int _tab = 0;
  String? _validation;

  String get _studentId => widget.student['id'].toString();
  List<String> get _courses => widget.records.subjects(
      widget.student['classId'].toString());
  List<String> get _periods => widget.records.periods
      .map((p) => p['key'].toString()).toList();

  @override
  void initState() {
    super.initState();
    _course = _courses.contains(widget.initialSubject)
        ? widget.initialSubject : (_courses.firstOrNull ?? '');
    _period = _periods.contains(widget.initialPeriod)
        ? widget.initialPeriod : (_periods.firstOrNull ?? '');
    _loadScore();
  }

  void _loadScore() {
    _status = widget.records.gradeStatus(_studentId, _course, _period);
    final score = widget.records.score(_studentId, _course, _period);
    _gradeController.text = score == null ? '' : numText(score);
    _validation = null;
  }

  @override
  void dispose() {
    _gradeController.dispose();
    super.dispose();
  }

  void _save() {
    if (_course.isEmpty || _period.isEmpty) {
      setState(() => _validation = 'اختر المادة والفترة أولاً');
      return;
    }
    final typed = asciiDigits(_gradeController.text.trim());
    final value = typed.isEmpty ? null : num.tryParse(typed);
    final maximum = widget.records.maximum(_course);
    if (_status == 'score' && typed.isNotEmpty &&
        (value == null || !value.isFinite || value < 0 || value > maximum)) {
      setState(() => _validation = 'أدخل درجة بين 0 و${numText(maximum)}');
      return;
    }
    widget.onSave(_course, _period, _status,
        _status == 'score' ? value : null);
    Navigator.of(context).pop('saved');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final dark = theme.brightness == Brightness.dark;
    const green = Color(0xff13765a);
    final softGreen = dark ? const Color(0xff1e3b35) : const Color(0xffe0f2e9);
    final ink = theme.colorScheme.onSurface;
    // The student sheet must fit compact phones and remain above the keyboard.
    // Keep destructive and navigation actions in a fixed footer: previously
    // the delete button was more than 600000 px below a 390x844 test viewport.
    final media = MediaQuery.of(context);
    final availableHeight =
        (media.size.height - media.viewInsets.bottom - 72)
            .clamp(240.0, 900.0)
            .toDouble();
    final panelHeight = availableHeight * .90;
    return SizedBox(
      height: panelHeight,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: SingleChildScrollView(
              key: const ValueKey('student-sheet-scrollable'),
              padding: const EdgeInsets.fromLTRB(18, 4, 18, 14),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Padding(
                    padding: EdgeInsets.only(bottom: 12),
                    child: Text('ملف التلميذ',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w900)),
                  ),
                  Row(children: [
                    Container(
                      padding: const EdgeInsets.all(11),
                      decoration: BoxDecoration(
                        color: softGreen,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Icon(Icons.person_outline_rounded,
                          color: dark ? Colors.greenAccent : green, size: 27),
                    ),
                    const SizedBox(width: 10),
                    Expanded(child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.student['name']?.toString() ?? 'التلميذ',
                            key: const ValueKey('student-sheet-name'),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 17,
                                fontWeight: FontWeight.w900, color: ink)),
                        Text(widget.student['number']?.toString() ?? '',
                            style: theme.textTheme.bodySmall),
                      ],
                    )),
                    IconButton(
                      key: const ValueKey('student-sheet-close'),
                      tooltip: 'إغلاق',
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close_rounded),
                    ),
                  ]),
                  const SizedBox(height: 16),
                  Row(children: [
                    _tabButton('الدرجات', 0),
                    const SizedBox(width: 7),
                    _tabButton('الحضور', 1),
                    const SizedBox(width: 7),
                    _tabButton('ملاحظات', 2),
                  ]),
                  const SizedBox(height: 17),
                  if (_tab == 0) ..._gradeInputs(context, green)
                  else if (_tab == 1) ..._attendance(context)
                  else ..._notes(context),
                ],
              ),
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 6, 18, 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(children: [
                  Expanded(child: OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).pop('parent'),
                    icon: const Icon(Icons.description_outlined, size: 17),
                    label: const Text('ولي الأمر'),
                  )),
                  const SizedBox(width: 7),
                  Expanded(child: OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).pop('edit'),
                    icon: const Icon(Icons.edit_outlined, size: 17),
                    label: const Text('تعديل'),
                  )),
                ]),
                // This button stays visible and hit-testable even on a 390px
                // wide phone; the grade form above is independently scrollable.
                Tooltip(
                  message: 'حذف التلميذ',
                  child: TextButton.icon(
                    key: const ValueKey('student-sheet-delete'),
                    onPressed: () => Navigator.of(context).pop('delete'),
                    icon: Icon(Icons.delete_outline,
                        color: theme.colorScheme.error),
                    label: Text('حذف التلميذ',
                        style: TextStyle(color: theme.colorScheme.error)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tabButton(String label, int value) {
    final active = _tab == value;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Expanded(child: Material(
      color: active ? const Color(0xff147e5a)
          : dark ? const Color(0xff303a3c) : const Color(0xffeef1f2),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        key: ValueKey('student-sheet-tab-$value'),
        borderRadius: BorderRadius.circular(18),
        onTap: () => setState(() => _tab = value),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 3),
          child: Text(label, textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800,
              color: active ? Colors.white : null)),
        ),
      ),
    ));
  }

  List<Widget> _gradeInputs(BuildContext context, Color green) {
    final inputTheme = Theme.of(context);
    return [
      if (_courses.isEmpty || _periods.isEmpty)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Text('أضف مادة وفترة تقييم من إعدادات سجلّي أولاً.'),
        )
      else ...[
        Text('المادة', style: inputTheme.textTheme.labelLarge),
        const SizedBox(height: 7),
        DropdownButtonFormField<String>(
          key: const ValueKey('student-sheet-subject'),
          initialValue: _course,
          isExpanded: true,
          items: [for (final course in _courses)
            DropdownMenuItem(value: course, child: Text(course))],
          onChanged: (course) {
            if (course == null) return;
            setState(() { _course = course; _loadScore(); });
          },
        ),
        const SizedBox(height: 10),
        Text('الشهر / فترة التقييم', style: inputTheme.textTheme.labelLarge),
        const SizedBox(height: 7),
        DropdownButtonFormField<String>(
          key: const ValueKey('student-sheet-period'),
          initialValue: _period,
          isExpanded: true,
          items: [for (final term in _periods)
            DropdownMenuItem(value: term, child: Text(term))],
          onChanged: (term) {
            if (term == null) return;
            setState(() { _period = term; _loadScore(); });
          },
        ),
        const SizedBox(height: 10),
        Text('حالة الدرجة', style: inputTheme.textTheme.labelLarge),
        const SizedBox(height: 6),
        Wrap(spacing: 6, runSpacing: 5, children: [
          for (final status in gradeLabels.entries)
            ChoiceChip(
              label: Text(status.value),
              selected: _status == status.key,
              onSelected: (_) => setState(() => _status = status.key),
            ),
        ]),
        const SizedBox(height: 10),
        TextField(
          key: const ValueKey('student-sheet-grade-input'),
          controller: _gradeController,
          enabled: _status == 'score',
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: 'الدرجة (من ${numText(widget.records.maximum(_course))})',
            hintText: 'أدخل الدرجة',
            errorText: _validation,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
          ),
        ),
        const SizedBox(height: 15),
        FilledButton.icon(
          key: const ValueKey('student-sheet-save-grade'),
          style: FilledButton.styleFrom(
            backgroundColor: green,
            minimumSize: const Size.fromHeight(49),
          ),
          onPressed: _save,
          icon: const Icon(Icons.save_outlined),
          label: const Text('حفظ الدرجة'),
        ),
        const SizedBox(height: 5),
        Text('ترك الدرجة فارغة ثم حفظها يمسح الدرجة لهذه المادة والفترة فقط.',
          style: inputTheme.textTheme.bodySmall),
      ],
    ];
  }

  List<Widget> _attendance(BuildContext context) {
    final month = dayKey(DateTime.now()).substring(0, 7);
    final summary = widget.records.attendanceSummary(_studentId, month);
    return [
      Text('حضور هذا الشهر', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      Wrap(spacing: 7, runSpacing: 7, children: [
        for (final entry in attendanceLabels.entries)
          Chip(label: Text('${entry.value}: ${summary[entry.key] ?? 0}')),
      ]),
      const SizedBox(height: 11),
      OutlinedButton.icon(
        onPressed: () => Navigator.of(context).pop('attendance'),
        icon: const Icon(Icons.how_to_reg_outlined),
        label: const Text('فتح سجل الحضور'),
      ),
    ];
  }

  List<Widget> _notes(BuildContext context) => [
    Text('ملاحظات التلميذ', style: Theme.of(context).textTheme.titleMedium),
    const SizedBox(height: 9),
    Text(widget.student['notes']?.toString().trim().isNotEmpty == true
        ? widget.student['notes'].toString() : 'لا توجد ملاحظات.'),
    const SizedBox(height: 12),
    OutlinedButton.icon(
      onPressed: () => Navigator.of(context).pop('edit'),
      icon: const Icon(Icons.edit_note_outlined),
      label: const Text('تعديل ملاحظات التلميذ'),
    ),
  ];
}
