import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../models/library_catalog.dart';
import 'library_repository.dart';

class RemoteSnapshot {
  const RemoteSnapshot(this.catalog, this.sha);
  final LibraryCatalog? catalog;
  final String? sha;
}

/// Uses repository-scoped, fine-grained PAT stored only on the manager device.
/// Never supply this credential to a webview or a user APK.
/// This is an online *enrollment* check, not a substitute for GitHub's
/// enforcement of Contents: write at publication time. Permission checks are
/// deliberately fail-closed on incomplete/missing API response fields.
class GitHubManagerVerifier {
  GitHubManagerVerifier({
    required this.owner,
    required this.repo,
    required this.client,
  });
  final String owner;
  final String repo;
  final http.Client client;

  Future<void> verify(String token) async {
    if (!RegExp(r'^[a-zA-Z0-9-]{1,100}$').hasMatch(owner) ||
        !RegExp(r'^[a-zA-Z0-9._-]{1,100}$').hasMatch(repo)) {
      throw StateError('المستودع غير محدد بصورة صحيحة في GitHub Actions.');
    }
    if (token.trim().isEmpty || token.contains(RegExp(r'\s'))) {
      throw const FormatException('أدخل رمز GitHub صحيحاً دون فراغات.');
    }
    final response = await client.get(
      Uri.https('api.github.com', '/repos/$owner/$repo'),
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'Madrasati-Manager-Enrollment',
      },
    ).timeout(const Duration(seconds: 20));
    if (response.statusCode == 401) {
      throw StateError('رمز GitHub غير صالح أو منتهي الصلاحية.');
    }
    if (response.statusCode != 200) {
      throw StateError('لا يمكن التحقق من المستودع (${response.statusCode}). ' 
          'تأكد من اتصال الإنترنت واسم المستودع وصلاحية الرمز.');
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes));
    if (payload is! Map<String, dynamic>) {
      throw StateError('استجابة GitHub غير صالحة.');
    }
    final name = (payload['full_name'] ?? '').toString().toLowerCase();
    final permission = payload['permissions'];
    if (name != '$owner/$repo'.toLowerCase() ||
        permission is! Map || permission['push'] != true) {
      throw StateError('ليس لهذا الرمز حق الدفع إلى مستودع المناهج. ' 
          'استخدم رمز المالك المخصص للمستودع مع Contents: Read and write.');
    }
    // API metadata alone cannot prove token-scoped Contents:write; the PUT
    // endpoint validates it when publishing. Never bypass that API check.
  }
}

class GitHubPublisher {
  GitHubPublisher({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  final FlutterSecureStorage _secure = const FlutterSecureStorage(
    aOptions: AndroidOptions(resetOnError: false, migrateWithBackup: true),
  );
  static const _key = 'github_manager_fine_grained_access_token';
  static const _enrollmentKey = 'madrasati_manager_verified_repository_v1';

  String get _repoId =>
      '${LibraryEndpoint.owner.toLowerCase()}/${LibraryEndpoint.repo.toLowerCase()}';

  /// Old local PINs or previously saved unverified tokens are NOT authority.
  /// Offline access is possible on this device after a successful online
  /// enrollment, but new installations need the owner's GitHub credential.
  Future<bool> get enrolledOnDevice async {
    final savedRepo = await _secure.read(key: _enrollmentKey);
    final token = await _secure.read(key: _key);
    return LibraryEndpoint.configured && savedRepo == _repoId &&
        token != null && token.isNotEmpty;
  }

  Future<bool> get hasToken => enrolledOnDevice;

  Future<void> activateWithToken(String token) async {
    if (!LibraryEndpoint.configured) {
      throw StateError('اضبط LIBRARY_OWNER وLIBRARY_REPO في متغيرات GitHub Actions أولاً.');
    }
    await GitHubManagerVerifier(
      owner: LibraryEndpoint.owner,
      repo: LibraryEndpoint.repo,
      client: _client,
    ).verify(token.trim());
    // Write credential first, then marker. An interrupted write does not
    // leave a verified enrollment without a token.
    await _secure.write(key: _key, value: token.trim());
    await _secure.write(key: _enrollmentKey, value: _repoId);
  }

  /// Do not allow an unverified credential to silently grant admin rights.
  Future<void> saveToken(String token) => activateWithToken(token);

  Future<void> clearToken() async {
    await _secure.delete(key: _enrollmentKey);
    await _secure.delete(key: _key);
  }

  Future<Map<String, String>> _headers() async {
    final token = await _secure.read(key: _key);
    if (token == null || token.isEmpty) throw StateError('أدخل رمز GitHub الخاص بالمدير أولاً');
    return {
      'Authorization': 'Bearer $token',
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'IraqiSchoolLibrary-Manager',
    };
  }

  Future<RemoteSnapshot> fetch() async {
    if (!LibraryEndpoint.configured) {
      throw StateError('لم تُحدد بيانات مستودع GitHub أثناء بناء التطبيق');
    }
    final uri = Uri.parse(LibraryEndpoint.apiUrl).replace(queryParameters: {
      'ref': LibraryEndpoint.branch,
    });
    final response = await _client.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 20));
    if (response.statusCode == 404) return const RemoteSnapshot(null, null);
    if (response.statusCode != 200) {
      throw StateError(_errorMessage('قراءة الفهرس', response));
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final encoded = (payload['content'] ?? '').toString().replaceAll('\n', '');
    final text = utf8.decode(base64Decode(base64.normalize(encoded)));
    return RemoteSnapshot(LibraryRepository.decode(text), payload['sha'] as String?);
  }

  Future<RemoteSnapshot> publish({
    required LibraryCatalog draft,
    required String? baseSha,
  }) async {
    if (!LibraryEndpoint.configured) throw StateError('المستودع غير مهيأ');
    draft.validate();
    // Read-before-write plus GitHub SHA CAS protects against concurrent editors.
    final latest = await fetch();
    if (latest.sha != baseSha) {
      throw StateError('تغير ملف الكتب على GitHub منذ آخر مزامنة؛ راجع أحدث نسخة قبل النشر حتى لا تفقد تعديلات أخرى.');
    }
    final next = draft.copy();
    next.revision = (latest.catalog?.revision ?? draft.revision) + 1;
    next.updatedAt = DateTime.now().toUtc().toIso8601String();
    final body = <String, dynamic>{
      'message': 'Update Iraqi library catalog (revision ${next.revision})',
      'content': base64Encode(utf8.encode(const JsonEncoder.withIndent('  ').convert(next.toJson()))),
      'branch': LibraryEndpoint.branch,
      'sha': ?baseSha,
    };
    final response = await _client.put(Uri.parse(LibraryEndpoint.apiUrl),
      headers: {...await _headers(), 'Content-Type': 'application/json'},
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 30));
    if (response.statusCode != 200 && response.statusCode != 201) {
      throw StateError(_errorMessage('نشر التعديلات', response));
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final content = payload['content'];
    final sha = content is Map ? content['sha'] as String? : null;
    return RemoteSnapshot(next, sha);
  }


  /// Recent published catalog commits, for history/rollback preview.
  Future<List<Map<String, String>>> recentCatalogCommits() async {
    final uri = Uri.https('api.github.com',
        '/repos/${LibraryEndpoint.owner}/${LibraryEndpoint.repo}/commits',
        {'path': LibraryEndpoint.path, 'sha': LibraryEndpoint.branch, 'per_page': '15'});
    final res = await _client.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw StateError(_errorMessage('سجل الإصدارات', res));
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    if (data is! List) return [];
    return data.whereType<Map>().map((m) {
      final commit = m['commit'];
      final details = commit is Map ? commit : <String, dynamic>{};
      final author = details['author'];
      final info = author is Map ? author : <String, dynamic>{};
      return <String, String>{
        'sha': (m['sha'] ?? '').toString(),
        'message': (details['message'] ?? 'تعديل الفهرس').toString(),
        'date': (info['date'] ?? '').toString(),
      };
    }).toList();
  }

  /// Reads an older version without modifying the remote repository.
  Future<LibraryCatalog> fetchCatalogRevision(String commitSha) async {
    if (!RegExp(r'^[0-9a-fA-F]{40}$').hasMatch(commitSha)) {
      throw const FormatException('معرّف إصدار GitHub غير صحيح');
    }
    final uri = Uri.parse(LibraryEndpoint.apiUrl)
        .replace(queryParameters: {'ref': commitSha});
    final res = await _client.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw StateError(_errorMessage('استعادة إصدار', res));
    final body = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    final encoded = (body['content'] ?? '').toString().replaceAll('\n', '');
    return LibraryRepository.decode(utf8.decode(base64Decode(base64.normalize(encoded))));
  }

  String _errorMessage(String action, http.Response response) {
    final status = response.statusCode;
    if (status == 401) return '$action: رمز GitHub غير صالح أو انتهت صلاحيته (401)';
    if (status == 403) return '$action: لا تمتلك إذن Contents: Read and write أو المستودع غير مسموح (403)';
    if (status == 409) return '$action: تعارض في نسخة الملف (409)، حمّل النسخة الحالية';
    if (status == 404) return '$action: المستودع غير موجود أو الرمز لا يملك صلاحية الوصول (404)';
    return '$action: خطأ GitHub ($status)';
  }
}
