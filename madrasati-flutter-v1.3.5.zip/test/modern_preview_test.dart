import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/mosaic_home.dart';

void main() {
  testWidgets('approved modern HTML sections are native Flutter and navigable', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var search = 0;
    var hub = 0;
    var students = 0;
    final entries = [
      for (final title in ['جدولي', 'سجلّي', 'جرس المعلم', 'المناهج', 'مستمسكاتي'])
        MosaicEntry(title: title, description: 'وصف قسم $title',
          icon: Icons.school_outlined, color: const Color(0xff2962a3), onTap: () {}),
    ];
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: MosaicHome(
      school: 'مدرستي', entries: entries, day: const Text('حصص حقيقية'),
      accent: const Color(0xff087c68), compact: false, rounded: 22,
      showDescriptions: true, showDay: true, showShortcuts: true,
      showDecoration: true,
      quickAttendance: () {}, quickBell: () {}, quickSettings: () {},
      onSearch: () => search++, onCenter: () => hub++,
      onStudent: () => students++,
    ))));
    await tester.pumpAndSettle();
    expect(find.text('منصتك المدرسية في مكان واحد'), findsOneWidget);
    expect(find.text('تبحث عن شيء؟'), findsOneWidget);
    expect(find.text('تطبيقات مدرستي'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('modern-global-search')));
    expect(search, 1);
    await tester.ensureVisible(find.text('مركز المعلم الذكي'));
    await tester.tap(find.text('مركز المعلم الذكي'));
    expect(hub, 1);
    await tester.ensureVisible(find.text('ملف التلميذ').last);
    await tester.tap(find.text('ملف التلميذ').last);
    expect(students, 1);
    expect(tester.takeException(), isNull);
  });
}
