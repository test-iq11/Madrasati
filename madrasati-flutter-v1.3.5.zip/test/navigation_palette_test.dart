import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/school_sidebar.dart';

void main() {
  testWidgets('sidebar opens search and selected destinations', (tester) async {
    var opened = '';
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: SchoolSidebar(
      school: 'مدرستي', onSearch: () => opened = 'search',
      sections: [
        (label: 'الرئيسية', icon: Icons.home, selected: true, open: () => opened = 'home'),
        (label: 'الإعدادات', icon: Icons.tune, selected: false, open: () => opened = 'settings'),
      ],
    ))));
    await tester.tap(find.text('البحث في مدرستي'));
    expect(opened, 'search');
    await tester.tap(find.text('الإعدادات'));
    expect(opened, 'settings');
    expect(tester.widget<ListTile>(find.widgetWithText(ListTile, 'الرئيسية')).selected, isTrue);
  });
}
