import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/main.dart';
import 'package:madrasati/school_banner.dart';
import 'package:madrasati/school_sidebar.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  for (final width in [390.0, 1100.0]) {
    testWidgets('home and sidebar destinations at width $width', (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = Size(width, 920);
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      SharedPreferences.setMockInitialValues({'madrasati.bottomNavigation': true});
      final prefs = await SharedPreferences.getInstance();
      await tester.pumpWidget(Madrasati(preferences: prefs));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));
      expect(find.byType(SchoolBanner), findsOneWidget);
      for (final title in ['جدولي', 'سجلّي', 'جرس المعلم', 'المناهج', 'مستمسكاتي']) {
        expect(find.byKey(ValueKey('mosaic-$title')), findsOneWidget);
      }
      if (width < 920) {
        await tester.tap(find.byTooltip('فتح القائمة والبحث'));
        await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));
      }
      final sidebar = find.byType(SchoolSidebar);
      expect(sidebar, findsOneWidget);
      expect(find.descendant(of: sidebar, matching: find.text('البحث في مدرستي')), findsOneWidget);
      await tester.tap(find.descendant(of: sidebar, matching: find.text('الإعدادات')));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));
      expect(find.text('شريط التنقل السفلي'), findsNothing);
      await tester.tap(find.byTooltip('الصفحة الرئيسية'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 500));
      expect(find.byType(SchoolBanner), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
