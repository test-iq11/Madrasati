import 'package:flutter/material.dart';
import 'school_day.dart';

class SchoolBanner extends StatelessWidget {
  const SchoolBanner({super.key, required this.school, required this.date,
    required this.day, required this.accent, required this.radius,
    required this.decorated, required this.compact, required this.openSchedule});

  final String school;
  final DateTime date;
  final SchoolDay? day;
  final Color accent;
  final double radius;
  final bool decorated, compact;
  final VoidCallback openSchedule;

  @override
  Widget build(BuildContext context) {
    final local = MaterialLocalizations.of(context);
    final dateLabel = local.formatFullDate(date);
    final lessons = day?.lessons;
    final summary = lessons == null ? null : lessons.isEmpty
        ? 'لا توجد حصص مسجّلة لهذا اليوم'
        : '${day!.sectionLabel}  ·  عدد الحصص ${local.formatDecimal(lessons.length)}';
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(begin: AlignmentDirectional.topStart,
          end: AlignmentDirectional.bottomEnd,
          colors: [Color.lerp(accent, const Color(0xff10392e), .50)!,
            Color.lerp(accent, const Color(0xff071f24), .72)!]),
      ),
      child: Padding(padding: EdgeInsets.all(compact ? 16 : 22),
        child: LayoutBuilder(builder: (context, box) => Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(school, style: const TextStyle(color: Color(0xffffdc9a), fontWeight: FontWeight.w700)),
            const Text('يومك الدراسي', style: TextStyle(fontSize: 30, color: Colors.white, fontWeight: FontWeight.w900)),
            Text(dateLabel, style: const TextStyle(color: Colors.white)),
            if (summary != null) Text(summary, style: const TextStyle(color: Color(0xffd7e6db), fontSize: 12)),
            const SizedBox(height: 12),
            FilledButton.icon(style: FilledButton.styleFrom(backgroundColor: const Color(0xfff4dba5),
                foregroundColor: const Color(0xff213e32)), onPressed: openSchedule,
              icon: const Icon(Icons.calendar_today_outlined,size: 17), label: const Text('فتح الجدول')),
          ])),
          if (decorated && box.maxWidth >= 255) Padding(
            padding: const EdgeInsetsDirectional.only(start: 12,end: 4),
            child: ExcludeSemantics(child: Transform.rotate(angle: -.10,
              child: Container(width: compact ? 70 : 82,
                padding: const EdgeInsets.symmetric(vertical: 9),
                decoration: BoxDecoration(color: const Color(0xfffaf3db),
                  borderRadius: BorderRadius.circular(12),
                  border: const Border(top: BorderSide(color: Color(0xffe5b66d), width: 9)),
                  boxShadow: const [BoxShadow(color: Color(0xff5e927e),offset: Offset(5,5))]),
                child: Column(children: [
                  const Icon(Icons.more_horiz, color: Color(0xff856c45)),
                  Text(local.formatDecimal(date.day),style: const TextStyle(color: Color(0xff21513f),
                    fontSize: 30,fontWeight: FontWeight.w900)),
                ])))),
          ),
        ]))),
    );
  }
}
