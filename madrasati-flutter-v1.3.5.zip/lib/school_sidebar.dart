import 'package:flutter/material.dart';

class SchoolSidebar extends StatelessWidget {
  const SchoolSidebar({required this.school, required this.sections,
    required this.onSearch, super.key});
  final String school;
  final List<({String label, IconData icon, bool selected, VoidCallback open})> sections;
  final VoidCallback onSearch;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(color: colors.surface, child: SafeArea(child: ListView(
      padding: const EdgeInsets.fromLTRB(14, 24, 14, 20),
      children: [
        ListTile(contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(backgroundColor: colors.primaryContainer,
            child: Icon(Icons.auto_stories_outlined, color: colors.onPrimaryContainer)),
          title: Text(school, style: const TextStyle(fontSize: 21,fontWeight: FontWeight.w900))),
        const SizedBox(height: 16),
        OutlinedButton.icon(onPressed: onSearch, icon: const Icon(Icons.search),
          label: const Text('البحث في مدرستي')),
        const SizedBox(height: 16),
        for (final entry in sections) ...[
          if (entry == sections.last) const Divider(height: 24),
          ListTile(selected: entry.selected, selectedTileColor: colors.primaryContainer,
            selectedColor: colors.onPrimaryContainer,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            leading: Icon(entry.icon), title: Text(entry.label), onTap: entry.open),
        ],
      ],
    )));
  }
}
