import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:iraqi_school_library_dual/admin/admin_library_app.dart';
import 'package:iraqi_school_library_dual/services/github_publisher.dart';
import 'package:iraqi_school_library_dual/services/library_repository.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:local_auth/local_auth.dart';
import 'package:sajli/main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:teacher_bell/domain.dart' as bell;
import 'package:teacher_bell/platform_service.dart';

import 'app_lock_gate.dart';
import 'mosaic_home.dart';
import 'manager_token_dialog.dart';
import 'bottom_nav.dart';
import 'modern_day_panel.dart';
import 'pin_dialog.dart';
import 'school_day.dart';
import 'school_tools.dart';
import 'security_store.dart';
import 'unified_design.dart';

const _prefix = 'madrasati.';
const _version = '1.4.5';

const _swatches = <(String, int)>[
  ('زمردي', 0xff147c70), ('أخضر', 0xff276b59),
  ('تركوازي', 0xff168895), ('بحري', 0xff246d81),
  ('أزرق', 0xff2962a3), ('نيلي', 0xff3e5e9b),
  ('بنفسجي', 0xff6650a6), ('أرجواني', 0xff87559c),
  ('وردي', 0xffb44f79), ('توتي', 0xff9a4362),
  ('أحمر', 0xffb74b50), ('مرجاني', 0xffc85d48),
  ('برتقالي', 0xffc57633), ('نحاسي', 0xff91612f),
  ('ذهبي', 0xffae8524), ('زيتوني', 0xff6f8134),
  ('رمادي أزرق', 0xff536b81), ('فحمي', 0xff394658),
  ('داكن', 0xff283344), ('بترولي', 0xff286e69),
];

enum Section {
  today('اليوم', Icons.home_outlined, 0xff276b59),
  schedule('الجدول', Icons.calendar_month_outlined, 0xff2b5779),
  records('سجلّي', Icons.fact_check_outlined, 0xff57417c),
  notifications('الجرس', Icons.notifications_outlined, 0xff745124),
  scanner('المسح', Icons.document_scanner_outlined, 0xff295f65),
  library('المناهج', Icons.menu_book_outlined, 0xff3a5484),
  settings('الإعدادات', Icons.tune, 0xff376167),
  manager('إدارة المناهج', Icons.admin_panel_settings_outlined, 0xff57417c);

  const Section(this.label, this.icon, this.tone);
  final String label;
  final IconData icon;
  final int tone;
}

const _mainSections = [
  Section.today,
  Section.schedule,
  Section.records,
  Section.notifications,
  Section.scanner,
  Section.library,
];


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final preferences = await SharedPreferences.getInstance();
  runApp(Madrasati(preferences: preferences));
}

class Madrasati extends StatefulWidget {
  const Madrasati({required this.preferences, super.key});
  final SharedPreferences preferences;

  @override
  State<Madrasati> createState() => _MadrasatiState();
}

class _MadrasatiState extends State<Madrasati> with WidgetsBindingObserver {
  final _center = ValueNotifier<String?>(null);
  final _attendance = ValueNotifier<AttendanceLink?>(null);
  final _auth = LocalAuthentication();
  final _managerPublisher = GitHubPublisher();
  final _pinStore = MadrasatiPinStore();
  late final _appPinStore = ManagerPinStore(
    preferences: widget.preferences,
    secure: _pinStore,
    purpose: 'app',
    localKey: 'madrasati.app.localVerifier.v1',
  );
  final _managerSecurePinStore = MadrasatiPinStore.forManager();
  late final _managerPinStore = ManagerPinStore(
    preferences: widget.preferences,
    secure: _managerSecurePinStore,
  );
  final _database = DatabaseService.instance;
  final _visited = <Section>{Section.today};
  final _messenger = GlobalKey<ScaffoldMessengerState>();
  final _shellScaffold = GlobalKey<ScaffoldState>();
  final _navigator = GlobalKey<NavigatorState>();

  BuildContext get _dialogContext => _navigator.currentState!.overlay!.context;
  late final Future<SajliApp> _records = loadSajli(attendance: _attendance);

  late ThemeMode _mode;
  late bool _reduceMotion;
  late double _textScale;
  late Color _accent;
  late Map<Section, Color> _cardColors;
  late bool _compactHome;
  late bool _showDayCard;
  late bool _showQuickActions;
  late bool _showCardDetails;
  late bool _showHeroDecoration;
  late bool _showBottomNavigation;
  late bool _presentation;
  late bool _appLockEnabled;
  late bool _biometricUnlock;
  late double _cardRadius;
  late bool _unifiedEnabled;
  late double _unifiedCardHeight;
  int _unifiedHomeTab = 0;
  final _unifiedTabs = <Section, String>{};
  String? _focusedPupil;
  bool _appLocked = false;
  bool _unlockBusy = false;
  int _failedPins = 0;
  DateTime? _pinBlockedUntil;
  late String _school;
  late int _sessionMinutes;
  late DateTime _date;
  late Future<SchoolDay> _schoolDay;
  Timer? _sessionTimer;
  DateTime? _sessionExpiry;
  bool _admin = false;
  bool _checking = false;
  bool _transferring = false;
  Section _section = Section.today;
  int? _sectionId;

  SharedPreferences get _prefs => widget.preferences;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _mode = ThemeMode.values.firstWhere(
      (mode) => mode.name == _prefs.getString('${_prefix}theme'),
      orElse: () => ThemeMode.system,
    );
    _school = _prefs.getString('${_prefix}school') ?? 'مدرستي';
    _reduceMotion = _prefs.getBool('${_prefix}motion') ?? false;
    _textScale = (_prefs.getDouble('${_prefix}text') ?? 1)
        .clamp(.9, 1.2)
        .toDouble();
    _accent = Color(_prefs.getInt('${_prefix}accent') ?? 0xff276b59);
    _cardColors = {
      for (final section in _mainSections.skip(1))
        section: Color(_prefs.getInt('${_prefix}card.${section.name}') ?? section.tone),
    };
    _compactHome = _prefs.getBool('${_prefix}compactHome') ?? false;
    _showDayCard = _prefs.getBool('${_prefix}showDay') ?? true;
    _showQuickActions = _prefs.getBool('${_prefix}showQuick') ?? true;
    _showCardDetails = _prefs.getBool('${_prefix}showDescriptions') ?? true;
    _showHeroDecoration = _prefs.getBool('${_prefix}heroDecoration') ?? true;
    _showBottomNavigation = _prefs.getBool('${_prefix}bottomNavigation') ?? true;
    _unifiedEnabled = true;
    _unifiedCardHeight = (_prefs.getDouble('${_prefix}unifiedCardHeight') ?? 158.0).clamp(132.0, 210.0).toDouble();
    _cardRadius = (_prefs.getDouble('${_prefix}cardRadius') ?? 20.0)
        .clamp(8.0, 32.0)
        .toDouble();
    _presentation = _prefs.getBool('${_prefix}presentation') ?? false;
    _appLockEnabled = _prefs.getBool('${_prefix}appLock') ?? false;
    _biometricUnlock = _prefs.getBool('${_prefix}biometricUnlock') ?? false;
    _appLocked = _appLockEnabled;
    _sessionMinutes = _prefs.getInt('${_prefix}session') ?? 5;
    _sectionId = _prefs.getInt('${_prefix}section');
    _date = baghdadDate();
    _schoolDay = _loadDay();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sessionTimer?.cancel();
    _center.dispose();
    _attendance.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden) {
      // Never re-lock during a platform biometric prompt.
      if (_appLockEnabled && !_unlockBusy && !_checking && mounted) {
        setState(() => _appLocked = true);
      }
      if (_admin && !_checking) _lock();
    } else if (state == AppLifecycleState.resumed &&
        _admin && _sessionExpiry?.isAfter(DateTime.now()) == false) {
      _lock();
    }
  }

  Future<SchoolDay> _loadDay() async {
    final sections = await _database.sectionsDetailed();
    final entries = await _database.entriesDetailed();
    final day = SchoolDay.select(sections, entries, _sectionId, _date);
    return SchoolDay(day.sections, [
      for (final lesson in day.lessons) _displayLesson(day, lesson),
    ], day.section, day.date);
  }

  String _lessonKey(SchoolDay day, Map<String, Object?> lesson, bool weekly) {
    final scope = weekly ? 'week-${day.date.weekday}' : 'date-${day.date.year}-${day.date.month}-${day.date.day}';
    return '${_prefix}lesson.${lesson['version_id']}.${day.sectionId}.$scope.${lesson['slot_id']}';
  }

  Map<String, Object?> _displayLesson(SchoolDay day, Map<String, Object?> lesson) {
    final weekly = _prefs.getString(_lessonKey(day, lesson, true));
    final once = _prefs.getString(_lessonKey(day, lesson, false));
    final subject = once ?? weekly ?? lesson['subject_name'];
    return {...lesson, 'subject_name': subject, 'weekly_subject': weekly ?? lesson['subject_name'],
      if (subject != lesson['subject_name']) 'teacher_name': ''};
  }

  Future<void> _editLesson(SchoolDay day, Map<String, Object?> lesson) async {
    var weekly = false;
    String? title;
    final result = await showDialog<String>(context: _dialogContext, builder: (ctx) =>
      StatefulBuilder(builder: (_, refresh) => AlertDialog(title: const Text('تعديل حصة اليوم الدراسي'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          SwitchListTile(title: Text(weekly ? 'يتكرر كل ${day.dayName}' : 'لهذا التاريخ فقط'),
            value: weekly, onChanged: (v) => refresh(() { weekly = v; title = null; })),
          TextFormField(key: ValueKey(weekly), initialValue: (weekly ? lesson['weekly_subject'] : lesson['subject_name']).toString(),
            onChanged: (v) => title = v, decoration: const InputDecoration(labelText: 'المادة')),
        ]), actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'reset'), child: const Text('إزالة التعديل')),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, 'save'), child: const Text('حفظ')),
        ])));
    if (!mounted || result == null) return;
    final key = _lessonKey(day, lesson, weekly);
    if (result == 'reset') {
      await _savePreference(_prefs.remove(key));
    } else {
      final subject = (title ?? (weekly ? lesson['weekly_subject'] : lesson['subject_name']).toString()).trim();
      if (subject.isEmpty) { _message('اسم المادة مطلوب'); return; }
      await _savePreference(_prefs.setString(key, subject));
    }
    if (mounted) setState(() => _schoolDay = _loadDay());
  }

  void _message(String text) {
    _messenger.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _savePreference(Future<bool> write) async {
    try {
      if (!await write) _message('تعذّر حفظ التفضيل على الجهاز.');
    } catch (_) {
      _message('تعذّر حفظ التفضيل على الجهاز.');
    }
  }

  void _lock() {
    _sessionTimer?.cancel();
    _sessionExpiry = null;
    if (!mounted) return;
    setState(() {
      _admin = false;
      _visited.remove(Section.manager);
      if (_section == Section.manager) {
        _section = Section.settings;
      }
    });
  }

  void _startSession() {
    _sessionTimer?.cancel();
    final duration = Duration(minutes: _sessionMinutes);
    _sessionExpiry = DateTime.now().add(duration);
    _sessionTimer = Timer(duration, _lock);
  }

  /// A broken Android Keystore is NOT treated as "no administrator".
  /// Recovery requires device-owner authentication and explicit consent.
  Future<bool> _recoverManagerPin() async {
    if (!mounted) return false;
    final approved = await showDialog<bool>(
      context: _dialogContext,
      barrierDismissible: false,
      builder: (dialog) => AlertDialog(
        title: const Text('استرداد صلاحية المدير'),
        content: const Text(
          'تعذّر قراءة رمز المدير من مخزن Android الآمن. قد يحدث ذلك بعد '
          'استعادة بيانات الجهاز أو تغيير مفاتيح التشفير. لن نفتح صلاحيات '
          'المدير دون تحقق. يمكنك إثبات ملكية الجهاز ببصمته أو رمز قفل '
          'الهاتف، ثم إنشاء رمز مدير محلي جديد. الرمز المحلي لا يُحفظ '
          'كنص واضح، لكنه أقل حماية من مخزن Android الآمن. '
          'لن تُحذف بيانات التلاميذ أو الجداول.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialog).pop(false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialog).pop(true),
            child: const Text('التحقق من هوية الجهاز'),
          ),
        ],
      ),
    );
    if (approved != true || !mounted) return false;
    bool verified;
    try {
      verified = await _auth.authenticate(
        localizedReason: 'تأكيد ملكية الهاتف لاسترداد صلاحية مدير مدرستي',
        biometricOnly: false,
        persistAcrossBackgrounding: true,
      );
    } catch (error) {
      if (mounted) _message(
        'تعذّر التحقق من هوية الهاتف (${error.runtimeType}). '
        'فعّل قفل الشاشة أو أعد المحاولة.',
      );
      return false;
    }
    if (!verified || !mounted) {
      if (mounted) _message('لم يتم التحقق من هوية الهاتف؛ صلاحية المدير مغلقة.');
      return false;
    }
    final newPin = await _askPin('تعيين رمز مدير محلي جديد', confirm: true);
    if (newPin == null || !mounted) return false;
    if (!await _managerPinStore.setLocal(newPin) ||
        !await _managerPinStore.verify(newPin, ManagerPinLocation.local)) {
      if (mounted) _message('تعذّر حفظ رمز المدير المحلي؛ لم تُفتح الصلاحيات.');
      return false;
    }
    return true;
  }

  Future<bool> _enrollManagerOnThisDevice() async {
    if (!LibraryEndpoint.configured) {
      _message('مستودع المناهج غير مرتبط. اضبط LIBRARY_OWNER وLIBRARY_REPO '
          'في GitHub Actions ثم ثبّت نسخة مرتبطة بالمستودع.');
      return false;
    }
    final token = await showDialog<String>(
      context: _dialogContext,
      barrierDismissible: false,
      builder: (_) => const ManagerTokenDialog(),
    );
    if (token == null || token.isEmpty || !mounted) return false;
    try {
      await _managerPublisher.activateWithToken(token);
      if (mounted) _message('تم التفعيل على هذا الجهاز. عيّن رمز مدير خاصاً بك.');
      return true;
    } catch (error) {
      if (mounted) {
        _message(error is TypeError
            ? 'تعذّر تخزين تفويض GitHub بسبب خطأ نوع في التخزين الآمن. '
              'لم تُفتح صلاحيات المدير. أعد المحاولة بعد التأكد من تحديث التطبيق.'
            : error is StateError || error is FormatException
                ? 'تعذّر تفعيل المدير: $error'
                : 'تعذّر تفعيل المدير (${error.runtimeType}). '
                  'لم تُفتح الصلاحيات؛ تحقّق من الإنترنت والمستودع.');
      }
      return false;
    }
  }

  Future<bool> _authenticate() async {
    if (_admin) return true;
    if (_checking || _appLocked) return false;
    setState(() => _checking = true);
    var stage = 'قراءة تفويض GitHub';
    try {
      bool enrolled;
      try {
        enrolled = await _managerPublisher.enrolledOnDevice;
      } catch (error) {
        if (mounted) _message('تعذّر التحقق من صلاحية المدير على الجهاز '
            '(${error.runtimeType}). لم تُفتح الصلاحيات.');
        return false;
      }
      if (!enrolled) {
        stage = 'التفعيل الأول عبر GitHub';
        if (!await _enrollManagerOnThisDevice()) return false;
      }
      if (!mounted) return false;
      stage = 'فحص رمز المدير المحلي';
      final location = await _managerPinStore.locate();
      if (!mounted) return false;
      bool allowed = false;
      if (location == ManagerPinLocation.unconfigured) {
        stage = 'إعداد رمز المدير';
        final setup = await showDialog<bool>(
          context: _dialogContext,
          barrierDismissible: false,
          builder: (dialog) => AlertDialog(
            title: const Text('إنشاء رمز المدير المعتمد'),
            content: const Text(
              'تم التحقق من حق إدارة مستودع المناهج على هذا الهاتف. يمكنك تعيين رمز '
              'مستقل من 4 إلى 8 أرقام. لا تشارك الرمز مع الآخرين.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialog).pop(false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialog).pop(true),
                child: const Text('إعداد رمز المدير'),
              ),
            ],
          ),
        );
        if (setup != true || !mounted) return false;
        final newPin = await _askPin('إنشاء رمز المدير', confirm: true);
        if (newPin == null || !mounted) return false;
        try {
          await _managerPinStore.setEncrypted(newPin);
          allowed = await _managerPinStore.verify(
            newPin, ManagerPinLocation.encrypted);
        } catch (_) {
          // Only a device-authenticated recovery may replace a failed store.
          allowed = await _recoverManagerPin();
        }
        if (!allowed && mounted) _message('فشل تأكيد حفظ رمز المدير.');
      } else if (location == ManagerPinLocation.encrypted ||
          location == ManagerPinLocation.local) {
        stage = 'التحقق من رمز المدير';
        final pin = await _askPin('أدخل رمز المدير');
        if (pin == null || !mounted) return false;
        try {
          allowed = await _managerPinStore.verify(pin, location);
          if (!allowed && mounted) _message('رمز المدير غير صحيح.');
        } catch (_) {
          allowed = await _recoverManagerPin();
        }
      } else {
        // There is no safe way to infer that an unreadable secure PIN is empty.
        stage = 'استرداد رمز المدير';
        allowed = await _recoverManagerPin();
      }
      if (!allowed || !mounted) return false;
      setState(() => _admin = true);
      _startSession();
      return true;
    } catch (error) {
      if (mounted) {
        _message('تعذّر إتمام الدخول أثناء $stage (${error.runtimeType}). '
            'لم تُفتح صلاحيات المدير؛ لا تحذف بيانات التطبيق.');
      }
      return false;
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  Future<String?> _askPin(String title, {bool confirm = false}) =>
      showDialog<String>(
        context: _dialogContext,
        barrierDismissible: false,
        builder: (_) => MadrasatiPinDialog(title: title, confirm: confirm),
      );

  /// The application lock is independent of the GitHub manager PIN. Verify
  /// that credentials are readable *before* advertising that it is enabled.
  Future<bool> _saveAppPin(String pin, {bool recovered = false}) async {
    try {
      await _appPinStore.setEncrypted(pin);
      if (!await _appPinStore.verify(pin, ManagerPinLocation.encrypted)) {
        throw StateError('The encrypted PIN did not survive a read-back');
      }
      if (!await _appPinStore.removeLocal()) {
        throw StateError('Could not retire an earlier local verifier');
      }
      return true;
    } catch (error) {
      if (!mounted) return false;
      if (pin.length < 6) {
        _message('تعذّر استخدام مخزن Android الآمن. اختر رمزاً من 6 إلى 8 أرقام للمخزن المحلي.');
        return false;
      }
      if (!recovered) {
        final consent = await showDialog<bool>(
          context: _dialogContext,
          barrierDismissible: false,
          builder: (dialog) => AlertDialog(
            title: const Text('المخزن الآمن غير متاح'),
            content: const Text('يمكن حفظ بصمة مشتقة من رمز القفل محلياً على الجهاز '
                'حتى تعمل الحماية، لكنها أقل مقاومة للاختراق من Android Keystore. '
                'لن نرسل الرمز إلى الشبكة. هل تقبل استخدام هذا البديل؟'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialog, false),
                  child: const Text('إلغاء')),
              FilledButton(onPressed: () => Navigator.pop(dialog, true),
                  child: const Text('الموافقة')),
            ],
          ),
        );
        if (consent != true || !mounted) return false;
      }
      try {
        if (!await _appPinStore.setLocal(pin)) return false;
        return await _appPinStore.verify(pin, ManagerPinLocation.local);
      } catch (_) {
        if (mounted) _message('تعذّر حفظ رمز القفل حتى في المخزن المحلي.');
        return false;
      }
    }
  }

  Future<void> _enableAppLock() async {
    final pin = await _askPin('إنشاء رمز قفل التطبيق', confirm: true);
    if (!mounted || pin == null) return;
    if (!await _saveAppPin(pin) || !mounted) {
      _message('لم يُفعّل القفل. لم يتم التأكد من حفظ الرمز.');
      return;
    }
    try {
      if (!await _prefs.setBool('${_prefix}appLock', true)) {
        _message('تعذّر حفظ حالة القفل؛ حاول مجدداً.');
        return;
      }
      if (mounted) setState(() {
        _appLockEnabled = true;
        _appLocked = true; // Immediate, observable protection; not after a restart only.
      });
    } catch (_) {
      if (mounted) _message('تعذّر تفعيل القفل على هذا الجهاز.');
    }
  }

  Future<bool> _verifyAppPin() async {
    final pin = await _askPin('أدخل الرمز الحالي للتطبيق');
    if (pin == null || !mounted) return false;
    try {
      final location = await _appPinStore.locate();
      final valid = await _appPinStore.verify(pin, location);
      if (!valid && mounted) _message(location == ManagerPinLocation.unavailable
          ? 'مخزن رموز Android غير متاح. افتح شاشة القفل واختر استرداد القفل.'
          : 'رمز التطبيق غير صحيح.');
      return valid;
    } catch (_) {
      if (mounted) _message('تعذّر التحقق من الرمز الحالي.');
      return false;
    }
  }

  Future<void> _disableAppLock() async {
    if (!await _verifyAppPin() || !mounted) return;
    try {
      if (!await _prefs.setBool('${_prefix}appLock', false)) return;
      await _prefs.setBool('${_prefix}biometricUnlock', false);
      if (mounted) setState(() {
        _appLockEnabled = false;
        _biometricUnlock = false;
        _appLocked = false;
      });
      // A broken Keystore should not keep the UI locked after a verified disable.
      try { await _pinStore.remove('app'); } catch (_) { /* old keys retained */ }
      try { await _appPinStore.removeLocal(); } catch (_) { /* no bypass */ }
    } catch (_) {
      if (mounted) _message('تعذّر إلغاء قفل التطبيق.');
    }
  }

  Future<void> _changeAppPin() async {
    if (!await _verifyAppPin() || !mounted) return;
    final pin = await _askPin('رمز التطبيق الجديد', confirm: true);
    if (pin == null || !mounted) return;
    final saved = await _saveAppPin(pin);
    if (mounted) _message(saved
        ? 'تم تغيير رمز التطبيق والتحقق من حفظه.'
        : 'لم يتم تغيير الرمز، بقي الرمز السابق.');
  }

  Future<void> _toggleBiometrics(bool enabled) async {
    if (!_appLockEnabled || _unlockBusy) return;
    if (enabled) {
      setState(() => _unlockBusy = true);
      try {
        final available = await _auth.getAvailableBiometrics();
        if (available.isEmpty) {
          if (mounted) _message('لا توجد بصمة مسجلة على هذا الجهاز.');
          return;
        }
        final verified = await _auth.authenticate(
          localizedReason: 'أكد بصمتك لتفعيل فتح مدرستي',
          biometricOnly: true,
          persistAcrossBackgrounding: true,
        );
        if (!verified || !mounted) return;
      } catch (error) {
        if (mounted) _message('تعذّر تفعيل البصمة (${error.runtimeType}).');
        return;
      } finally {
        if (mounted) setState(() => _unlockBusy = false);
      }
    } else {
      if (!await _verifyAppPin() || !mounted) return;
    }
    try {
      if (!await _prefs.setBool('${_prefix}biometricUnlock', enabled)) {
        if (mounted) _message('تعذّر حفظ خيار البصمة.');
        return;
      }
      if (mounted) setState(() => _biometricUnlock = enabled);
    } catch (_) {
      if (mounted) _message('تعذّر حفظ خيار البصمة.');
    }
  }

  Future<bool> _unlockWithPin(String pin) async {
    if (_unlockBusy) return false;
    final until = _pinBlockedUntil;
    if (until != null && until.isAfter(DateTime.now())) {
      _message('محاولات كثيرة. أعد المحاولة بعد قليل.');
      return false;
    }
    setState(() => _unlockBusy = true);
    try {
      final location = await _appPinStore.locate();
      final verified = await _appPinStore.verify(pin, location);
      if (mounted && verified) {
        setState(() {
          _appLocked = false;
          _failedPins = 0;
          _pinBlockedUntil = null;
        });
        return true;
      }
      if (location == ManagerPinLocation.unavailable ||
          location == ManagerPinLocation.damagedLocal) {
        _message('تعذّر قراءة رمز التطبيق، استخدم استرداد القفل بقفل شاشة الهاتف.');
      } else {
        _failedPins++;
        if (_failedPins >= 5) {
          _pinBlockedUntil = DateTime.now().add(const Duration(seconds: 30));
          _failedPins = 0;
        }
        _message('رمز التطبيق غير صحيح.');
      }
      return false;
    } catch (_) {
      if (mounted) _message('تعذّر التحقق من رمز التطبيق.');
      return false;
    } finally {
      if (mounted) setState(() => _unlockBusy = false);
    }
  }

  Future<bool> _unlockWithBiometrics() async {
    if (!_biometricUnlock || _unlockBusy) return false;
    setState(() => _unlockBusy = true);
    try {
      final verified = await _auth.authenticate(
        localizedReason: 'فتح تطبيق مدرستي',
        biometricOnly: true,
        persistAcrossBackgrounding: true,
      );
      if (mounted && verified) setState(() => _appLocked = false);
      return verified && mounted;
    } catch (error) {
      if (mounted) _message('تعذرت البصمة (${error.runtimeType}). استخدم رمز التطبيق.');
      return false;
    } finally {
      if (mounted) setState(() => _unlockBusy = false);
    }
  }

  /// Recovery can reset only the *application* lock after the operating system
  /// verifies this device owner. It never grants library manager permissions.
  Future<bool> _authorizeAppRecovery() async {
    if (_unlockBusy) return false;
    setState(() => _unlockBusy = true);
    try {
      return await _auth.authenticate(
        localizedReason: 'التحقق من قفل شاشة الهاتف لاسترداد قفل مدرستي',
        biometricOnly: false,
        persistAcrossBackgrounding: true,
      );
    } catch (error) {
      if (mounted) _message('تعذّر استرداد القفل (${error.runtimeType}). تأكد من قفل شاشة الهاتف.');
      return false;
    } finally {
      if (mounted) setState(() => _unlockBusy = false);
    }
  }

  Future<bool> _saveRecoveredAppPin(String pin) async {
    if (!MadrasatiPinStore.valid(pin) || pin.length < 6) return false;
    final saved = await _saveAppPin(pin, recovered: true);
    if (saved && mounted) {
      setState(() {
        _appLocked = false;
        _failedPins = 0;
        _pinBlockedUntil = null;
      });
    }
    return saved;
  }

  Future<void> _setManagerPin() async {
    if (!_admin) return;
    try {
      final location = await _managerPinStore.locate();
      if (location == ManagerPinLocation.unavailable ||
          location == ManagerPinLocation.damagedLocal) {
        if (await _recoverManagerPin() && mounted) {
          _message('تم استرداد رمز المدير بعد التحقق من هوية الهاتف.');
        }
        return;
      }
      if (location != ManagerPinLocation.unconfigured) {
        final old = await _askPin('الرمز الحالي للمدير');
        if (old == null || !mounted) return;
        bool valid;
        try {
          valid = await _managerPinStore.verify(old, location);
        } catch (_) {
          if (await _recoverManagerPin() && mounted) {
            _message('تم استرداد رمز المدير بعد التحقق من هوية الهاتف.');
          }
          return;
        }
        if (!valid) {
          if (mounted) _message('رمز المدير الحالي غير صحيح.');
          return;
        }
      }
      if (!mounted) return;
      final pin = await _askPin('تعيين رمز خاص بالمدير', confirm: true);
      if (pin == null || !mounted) return;
      if (location == ManagerPinLocation.local) {
        if (!await _managerPinStore.setLocal(pin)) {
          throw StateError('Failed to persist local PIN verifier');
        }
      } else {
        try {
          await _managerPinStore.setEncrypted(pin);
        } catch (_) {
          if (await _recoverManagerPin() && mounted) {
            _message('تم استرداد رمز المدير بعد التحقق من هوية الهاتف.');
          }
          return;
        }
      }
      if (mounted) _message('حُفظ رمز المدير.');
    } catch (error) {
      if (mounted) _message('تعذّر تغيير رمز المدير (${error.runtimeType}).');
    }
  }

  Future<void> _open(Section section) async {
    if (_appLocked) return;
    if (section == Section.manager) {
      if (!await _authenticate() || !mounted || _checking) return;
      setState(() => _checking = true);
      try {
        final enrolled = await _managerPublisher.enrolledOnDevice;
        if (!enrolled) {
          if (!await _enrollManagerOnThisDevice()) return;
        }
        if (!mounted || !_admin || _appLocked) return;
      } catch (error) {
        if (mounted) _message('تعذّر فتح إدارة المناهج (${error.runtimeType}).');
        return;
      } finally {
        if (mounted) setState(() => _checking = false);
      }
    }
    if (!mounted) return;
    if (section == _section) {
      if (section == Section.today) setState(() => _schoolDay = _loadDay());
      return;
    }
    setState(() {
      if (section == Section.today) _schoolDay = _loadDay();
      _section = section;

      _visited.add(section);
    });
  }

  Future<void> _openAttendance(SchoolDay day) async {
    if (day.grade.isEmpty) return;
    await _open(Section.records);
    if (_section == Section.records) {
      setState(() => _unifiedTabs[Section.records] = 'attendance');
    }
  }

  Future<void> _openBooks(SchoolDay day, [String? subject]) async {
    if (day.grade.isEmpty) return;
    await _open(Section.library);
    if (_section == Section.library) {
      setState(() => _unifiedTabs[Section.library] = 'books');
    }
  }

  Future<void> _transfer(BuildContext context, SchoolDay day) async {
    if (_transferring || day.lessons.isEmpty) return;
    final weekly = SchoolDay(day.sections, [for (final item in day.lessons)
      {...item, 'subject_name': item['weekly_subject'] ?? item['subject_name']}], day.section, day.date);
    final entries = weekly.toBellLessons();
    if (entries == null) {
      _message('أوقات الحصص متداخلة أو ناقصة. راجعها في الجدول.');
      return;
    }
    final confirmed = await showDialog<bool>(
      context: _dialogContext,
      builder: (context) => AlertDialog(
        title: const Text('تهيئة جرس الحصص'),
        content: Text(
          'نقل ${entries.length} حصص من ${day.sectionLabel} ليوم ${day.dayName} وتحديث جدول الجرس الأسبوعي لهذا اليوم؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تطبيق'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _transferring = true);
    try {
      final planner = await DeviceService.load();
      planner.week[bell.dayIndex(day.date)] = entries;
      await DeviceService.save(planner);
      await DeviceService.sync(planner);
      if (!mounted) return;
      await _open(Section.notifications);
      if (mounted) setState(() => _unifiedTabs[Section.notifications] = 'week');
      _message('نُقلت الحصص بنجاح إلى جرس المعلم.');
    } catch (_) {
      _message('تعذّر حفظ حصص الجرس.');
    } finally {
      if (mounted) setState(() => _transferring = false);
    }
  }

  ThemeData _theme(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: _accent, brightness: brightness);
    final bg = dark ? const Color(0xff000000) : const Color(0xfff5f7fb);
    final surface = dark ? const Color(0xff151d26) : Colors.white;
    return ThemeData(
      colorScheme: scheme.copyWith(surface: surface),
      useMaterial3: true,
      fontFamily: 'NotoSansArabic',
      scaffoldBackgroundColor: bg,
      appBarTheme: AppBarThemeData(backgroundColor: bg, elevation: 0,
        scrolledUnderElevation: 0, foregroundColor: scheme.onSurface,
        titleTextStyle: TextStyle(color: scheme.onSurface,
          fontFamily: 'NotoSansArabic', fontWeight: FontWeight.w900, fontSize: 19)),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true, fillColor: surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12)),
      cardTheme: CardThemeData(color: surface, elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(23),
          side: BorderSide(color: scheme.outlineVariant.withValues(alpha: .45)))),
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    navigatorKey: _navigator,
    title: _school,
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar', 'IQ'),
    supportedLocales: const [Locale('ar', 'IQ'), Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: _theme(Brightness.light),
    darkTheme: _theme(Brightness.dark),
    themeMode: _mode,
    themeAnimationDuration: _reduceMotion
        ? Duration.zero
        : const Duration(milliseconds: 180),
    scaffoldMessengerKey: _messenger,
    builder: (context, child) {
      final media = MediaQuery.of(context);
      return MediaQuery(
        data: media.copyWith(
          disableAnimations: _reduceMotion || media.disableAnimations,
          textScaler: TextScaler.linear(
            media.textScaler.scale(14) / 14 * _textScale,
          ),
        ),
        child: Stack(children: [
          child!,
          if (_appLocked) Positioned.fill(
            child: MadrasatiAppLockGate(
              verifyPin: _unlockWithPin,
              verifyBiometrics: _unlockWithBiometrics,
              authorizeRecovery: _authorizeAppRecovery,
              saveRecoveredPin: _saveRecoveredAppPin,
              biometricEnabled: _biometricUnlock,
            ),
          ),
        ]),
      );
    },
    home: Builder(builder: _shell),
  );

  /// Only the homepage owns Madrasati's bottom navigation. Each embedded
  /// application owns its own tabs; the other applications live in the drawer.
  Widget _shell(BuildContext context) => Scaffold(
    key: _shellScaffold,
    // Legacy rule: drawer: _section == Section.today ? null : _sectionDrawer(context)
    drawer: _sectionDrawer(context),
    body: SafeArea(bottom: false, child: Column(children: [
      _header(context),
      Expanded(child: IndexedStack(
        index: _section.index,
        children: [
          for (final section in Section.values)
            KeyedSubtree(
              key: ValueKey(section),
              child: _visited.contains(section)
                  ? TickerMode(enabled: _section == section,
                      child: _page(context, section))
                  : const SizedBox.shrink(),
            ),
        ],
      )),
    ])),
    bottomNavigationBar: _showBottomNavigation &&
            (_section == Section.today || _section == Section.settings)
        ? SafeArea(top: false, child: _bottomNav())
        : null,
  );

  Widget _sectionDrawer(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Drawer(
      key: const ValueKey('madrasati-section-drawer'),
      child: SafeArea(child: ListView(padding: const EdgeInsets.all(12), children: [
        Container(
          padding: const EdgeInsets.all(19),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xff087a67), Color(0xff064c58)]),
            borderRadius: BorderRadius.circular(21),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Icon(Icons.school_rounded, color: Colors.white, size: 33),
            const SizedBox(height: 12),
            Text(_school, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 20,
                fontWeight: FontWeight.w900)),
            const Text('اختر أحد أقسام مدرستي',
              style: TextStyle(color: Color(0xffd0f5e9), fontSize: 11)),
          ]),
        ),
        const SizedBox(height: 13),
        for (final section in _mainSections) ...[
          Padding(padding: const EdgeInsets.only(bottom: 6), child: Material(
            color: section == _section
                ? (_cardColors[section] ?? Color(section.tone)).withValues(alpha: .13)
                : scheme.surfaceContainerLowest,
            borderRadius: BorderRadius.circular(15),
            child: ListTile(
              key: ValueKey('drawer-section-${section.name}'),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              leading: Icon(section.icon,
                color: _cardColors[section] ?? Color(section.tone)),
              title: Text(section == Section.today ? 'الرئيسية' : section.label,
                style: TextStyle(fontWeight: section == _section
                    ? FontWeight.w900 : FontWeight.w700)),
              trailing: section == _section ? const Icon(Icons.check_circle, size: 19) :
                  const Icon(Icons.chevron_left_rounded, size: 18),
              selected: section == _section,
              onTap: () {
                Navigator.of(context).pop();
                _open(section);
              },
            ),
          )),
        ],
        const Divider(height: 24),
        ListTile(
          leading: const Icon(Icons.settings_outlined),
          title: const Text('إعدادات مدرستي'),
          onTap: () { Navigator.of(context).pop(); _open(Section.settings); },
        ),
      ])),
    );
  }

  Future<void> _openUnifiedStudent(String studentId) async {
    await _open(Section.records);
    if (!mounted || _section != Section.records) return;
    setState(() { _focusedPupil = studentId; _unifiedTabs[Section.records] = 'students'; });
  }

  Future<void> _openSajliReports() async {
    await _open(Section.records);
    if (mounted) setState(() => _unifiedTabs[Section.records] = 'reports');
  }

  List<UnifiedStudent> _actualStudents(SajliApp? app) {
    if (app == null || _presentation) return const [];
    final records = app.records;
    final currentDate = baghdadDate().toIso8601String().substring(0, 10);
    final statuses = records.attendance(currentDate);
    final students = <UnifiedStudent>[];
    for (final row in records.people) {
      if (row['archived'] == true) continue;
      final id = row['id']?.toString() ?? '';
      final classId = row['classId']?.toString() ?? '';
      final status = statuses[id]?.toString() ?? '';
      final attendance = switch (status) {
        'present' => 'حاضر', 'absent' => 'غائب',
        'late' => 'متأخر', 'excused' => 'بعذر', _ => 'غير مسجّل',
      };
      var gradesCount = 0;
      for (final subject in records.subjects(classId)) {
        for (final period in records.periods) {
          final key = period['key']?.toString() ?? '';
          if (key.isNotEmpty && records.score(id, subject, key) != null) {
            gradesCount++;
          }
        }
      }
      students.add(UnifiedStudent(
        id: id,
        name: row['name']?.toString() ?? '',
        group: records.className(classId),
        registerNumber: row['number']?.toString() ?? '',
        attendance: attendance,
        gradeCount: gradesCount,
      ));
    }
    return students;
  }

  List<UnifiedLesson> _actualLessons(SchoolDay? day) {
    if (day == null) return const [];
    return [for (var i = 0; i < day.lessons.length; i++)
      UnifiedLesson(
        subject: day.lessons[i]['subject_name']?.toString() ?? 'حصة',
        time: '${day.lessons[i]['start_time'] ?? '—'} - ${day.lessons[i]['end_time'] ?? '—'}',
        teacher: day.lessons[i]['teacher_name']?.toString() ?? '',
        period: i + 1,
      ),
    ];
  }

  Widget _unifiedHome(BuildContext context) => FutureBuilder<SchoolDay>(
    future: _schoolDay,
    builder: (_, daySnapshot) => FutureBuilder<SajliApp>(
      future: _records,
      builder: (_, recordsSnapshot) {
        final day = daySnapshot.data;
        final records = recordsSnapshot.data;
        return UnifiedHomePage(
          school: _school,
          dayName: day?.dayName ?? 'اليوم',
          lessons: _actualLessons(day),
          students: _actualStudents(records),
          classCount: records?.records.activeClasses.length ?? 0,
          tasks: _taskSummary(), progress: _progressSummary(),
          tab: _unifiedHomeTab,
          cardHeight: _unifiedCardHeight,
          onSection: _openUnifiedSection,
          onDay: () => setState(() => _unifiedHomeTab = 1),
          onAttendance: () async {
            final current = await _schoolDay;
            if (!mounted) return;
            if (current.grade.isEmpty) {
              _message('اختر الصف والشعبة من جدولي أولاً.');
              await _open(Section.schedule);
            } else {
              await _openAttendance(current);
            }
          },
          onStudent: () => _openRecordsCenter('student'),
          onStats: () => _openTool(SchoolTool.statistics),
          onTeacherHub: _openTeacherHub,
          onLibrary: () => _open(Section.library),
          onSearch: () => _openTool(SchoolTool.search),
        );
      },
    ),
  );


  Future<void> _swapUnifiedLessons(int first, int second) async {
    try {
      final day = await _schoolDay;
      if (first < 0 || second < 0 || first >= day.lessons.length ||
          second >= day.lessons.length || first == second) return;
      final year = await _database.activeYearId();
      if (year == null) { _message('لا توجد سنة دراسية نشطة'); return; }
      await _database.swapLessons(
        yearId: year, first: day.lessons[first], second: day.lessons[second]);
      if (mounted) {
        setState(() => _schoolDay = _loadDay());
        _message('تم التبديل بعد اجتياز قيود جدول المعلمين');
      }
    } catch (error) {
      if (mounted) _message('لم ينجح التبديل: $error');
    }
  }

  void _openUnifiedSection(String name) {
    for (final item in const <(String, Section)>[
      ('jadwali', Section.schedule), ('sajli', Section.records),
      ('bell', Section.notifications), ('library', Section.library),
      ('scanner', Section.scanner),
    ]) {
      if (item.$1 == name) {
        _open(item.$2);
        return;
      }
    }
  }

  Widget _unifiedDepartment(BuildContext context, Section section) {
    final module = switch (section) {
      Section.schedule => 'jadwali', Section.records => 'sajli',
      Section.notifications => 'bell', Section.library => 'library',
      Section.scanner => 'scanner', _ => 'jadwali',
    };
    final spec = unifiedSections.firstWhere((s) => s.id == module);
    return FutureBuilder<SchoolDay>(
      future: _schoolDay,
      builder: (_, daySnapshot) => FutureBuilder<SajliApp>(
        future: _records,
        builder: (_, recordSnapshot) {
          final day = daySnapshot.data;
          final records = recordSnapshot.data;
          if (section == Section.records && _presentation) {
            return const Center(child: ListTile(
              leading: Icon(Icons.visibility_off_outlined),
              title: Text('بيانات التلاميذ مخفية في وضع العرض.'),
            ));
          }
          return UnifiedSectionPage(
            key: ValueKey('madrasati-unified-$module'),
            spec: spec, school: _school,
            dayName: day?.dayName ?? 'اليوم',
            groupLabel: day?.sectionLabel ?? '',
            lessons: _actualLessons(day),
            students: _actualStudents(records),
            classCount: records?.records.activeClasses.length ?? 0,
            records: records?.records, recordsFile: records?.file,
            database: _database, initialTab: _unifiedTabs[section] ?? 'main',
            studentFocus: _focusedPupil,
            onDataChanged: () { if (mounted) setState(() => _schoolDay = _loadDay()); },
            onEditLesson: (index) async {
              final current = await _schoolDay;
              if (index < 0 || index >= current.lessons.length) return;
              await _editLesson(current, current.lessons[index]);
            },
            onSwap: _swapUnifiedLessons,
            onOpenNative: () {},
            onOpenSection: _openUnifiedSection,
            onStudent: _openUnifiedStudent,
            onOpenReports: _openSajliReports,
            onAttendance: () async {
              if (day == null || day.grade.isEmpty) {
                await _open(Section.records);
                if (mounted) setState(() => _unifiedTabs[Section.records] = 'attendance');
              } else {
                await _openAttendance(day);
              }
            },
            onStatistics: () => _openTool(SchoolTool.statistics),
            onTransferToBell: () async {
              final current = await _schoolDay;
              if (mounted) await _transfer(context, current);
            },
            onOpenBooks: () async {
              final current = await _schoolDay;
              if (!mounted) return;
              if (current.grade.isEmpty) {
                await _open(Section.library);
                if (mounted) setState(() => _unifiedTabs[Section.library] = 'books');
              } else {
                await _openBooks(current);
              }
            },
            onChangeDay: () async {
              final selected = await showDatePicker(
                context: _dialogContext,
                initialDate: _date,
                firstDate: DateTime(2022),
                lastDate: DateTime(2038),
              );
              if (selected == null || !mounted) return;
              setState(() {
                _date = selected;
                _schoolDay = _loadDay();
              });
            },
          );
        },
      ),
    );
  }

  Widget _unifiedHeader(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      color: UnifiedStyle.bg(context),
      height: 72,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(children: [
        Container(width: 43, height: 43,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xff087c77), Color(0xff3bbba9)]),
            borderRadius: BorderRadius.circular(15)),
          child: const Icon(Icons.school_outlined, color: Colors.white, size: 26)),
        const SizedBox(width: 10),
        Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(_section == Section.today ? _school : _section.label,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: UnifiedStyle.ink(context),
                fontSize: 18, fontWeight: FontWeight.w900)),
            Text('مساحة عملك المدرسي',
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: UnifiedStyle.muted(context), fontSize: 9)),
          ])),

        _unifiedHeaderButton(context, dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
          'تبديل المظهر', () {
            setState(() => _mode = dark ? ThemeMode.light : ThemeMode.dark);
            unawaited(_savePreference(_prefs.setString('${_prefix}theme', _mode.name)));
          }),
        _unifiedHeaderButton(context, Icons.settings_outlined, 'الإعدادات',
          () => _open(Section.settings)),
        Padding(padding: const EdgeInsetsDirectional.only(start: 6),
          child: SizedBox(width: 42, height: 42, child: Material(
            color: const Color(0xff087c77), borderRadius: BorderRadius.circular(14),
            child: IconButton(tooltip: 'القائمة الجانبية',
              onPressed: () => _shellScaffold.currentState?.openDrawer(),
              icon: const Icon(Icons.menu_rounded, color: Colors.white))))),
      ]),
    );
  }

  Widget _unifiedHeaderButton(BuildContext context, IconData icon,
      String tooltip, VoidCallback onTap) => Padding(
    padding: const EdgeInsetsDirectional.only(start: 5),
    child: SizedBox(width: 39, height: 39, child: Material(
      color: UnifiedStyle.surface(context),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13),
        side: BorderSide(color: UnifiedStyle.line(context))),
      child: IconButton(tooltip: tooltip, padding: EdgeInsets.zero,
        icon: Icon(icon, color: UnifiedStyle.ink(context), size: 20),
        onPressed: onTap))),
  );

  Widget _header(BuildContext context) {
    if (_unifiedEnabled) return _unifiedHeader(context);
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return LayoutBuilder(builder: (context, constraints) => Material(
      color: scheme.surface,
      child: Container(
        height: 70,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(border: Border(bottom: BorderSide(
          color: scheme.outlineVariant.withValues(alpha: .55)))),
        child: Row(children: [
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xff13a67e), Color(0xff056b6f)]),
              borderRadius: BorderRadius.circular(15)),
            child: IconButton(
              key: ValueKey(_section == Section.today
                  ? 'modern-home-button' : 'modern-sections-menu'),
              tooltip: _section == Section.today ? 'الرئيسية' : 'الأقسام الأخرى',
              onPressed: _section == Section.today
                  ? () => _open(Section.today)
                  : () => _shellScaffold.currentState?.openDrawer(),
              icon: Icon(_section == Section.today
                  ? Icons.grid_view_rounded : Icons.menu_rounded,
                color: Colors.white, size: 23)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(_section == Section.today ? _school : _section.label,
            maxLines: 1, overflow: TextOverflow.ellipsis,
            style: TextStyle(color: scheme.onSurface, fontSize: 18,
              fontWeight: FontWeight.w900))),
          if (constraints.maxWidth >= 390)
            Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(
                color: dark ? const Color(0xff1c483c) : const Color(0xffe4f7ee),
                borderRadius: BorderRadius.circular(20)),
              child: Text('تصميم 2026', style: TextStyle(
                color: dark ? const Color(0xffa0f0c8) : const Color(0xff107353),
                fontSize: 9, fontWeight: FontWeight.w800))),
          const SizedBox(width: 5),
          _headerAction(context, Icons.search_rounded, 'البحث الشامل',
            () => _openTool(SchoolTool.search)),
          _headerAction(context, dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
            'تغيير المظهر', () {
              setState(() => _mode = dark ? ThemeMode.light : ThemeMode.dark);
              unawaited(_savePreference(_prefs.setString('${_prefix}theme', _mode.name)));
            }),
          _headerAction(context, Icons.settings_outlined, 'الإعدادات',
            () => _open(Section.settings)),
        ]),
      ),
    ));
  }

  Widget _headerAction(BuildContext context, IconData icon, String tooltip,
      VoidCallback callback) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(padding: const EdgeInsetsDirectional.only(start: 3),
      child: Container(width: 39, height: 39,
        decoration: BoxDecoration(color: scheme.surfaceContainerLow,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: scheme.outlineVariant.withValues(alpha: .55))),
        child: IconButton(tooltip: tooltip, padding: EdgeInsets.zero,
          onPressed: callback, icon: Icon(icon, size: 19, color: scheme.onSurface))),
    );
  }

  Widget _bottomNav() {
    if (_unifiedEnabled && _section == Section.today) {
      const items = [
        MadrasatiNavItem('الرئيسية', Icons.home_outlined, Color(0xff087c77)),
        MadrasatiNavItem('اليوم', Icons.calendar_today_outlined, Color(0xff416fa8)),
        MadrasatiNavItem('المهام', Icons.task_alt_outlined, Color(0xff79669c)),
        MadrasatiNavItem('المؤشرات', Icons.stacked_bar_chart_outlined, Color(0xffb9864d)),
      ];
      return MadrasatiBottomNav(
        items: items,
        selectedIndex: _unifiedHomeTab,
        onSelect: (tab) => setState(() => _unifiedHomeTab = tab),
      );
    }
    const sections = [
      Section.today, Section.schedule, Section.records, Section.settings,
    ];
    const colors = [
      Color(0xff16805e), // Emerald for Today
      Color(0xff3574b9), // Blue for Timetable
      Color(0xff805bb6), // Violet for Sajli
      Color(0xffbd7942), // Amber for Settings
    ];
    return MadrasatiBottomNav(
      items: [
        for (var i = 0; i < sections.length; i++)
          MadrasatiNavItem(sections[i].label, sections[i].icon, colors[i]),
      ],
      selectedIndex: sections.indexOf(_section),
      onSelect: (index) => _open(sections[index]),
    );
  }

  Widget _page(BuildContext context, Section section) {
    if (section != Section.today &&
        section != Section.settings && section != Section.manager) {
      return _unifiedDepartment(context, section);
    }
    return _nativePage(context, section);
  }

  // Only the home, settings and protected manager area use this branch.
  // The five departments can NEVER instantiate legacy UI trees here.
  Widget _nativePage(BuildContext context, Section section) => switch (section) {
    Section.today => _today(context),
    Section.settings => _settings(context),
    Section.manager => _admin
        ? IraqiLibraryAdminApp(dark: Theme.of(context).brightness == Brightness.dark)
        : const SizedBox.shrink(),
    _ => _unifiedDepartment(context, section),
  };

  void _openTool(SchoolTool tool) {
    // School tools live in the new Records workspace, not old standalone screens.
    final target = tool == SchoolTool.search ? 'students' : 'tools';
    _open(Section.records).then((_) {
      if (mounted) setState(() => _unifiedTabs[Section.records] = target);
    });
  }

  Future<void> _openRecordsCenter(String destination) async {
    await _open(Section.records);
    if (mounted && _section == Section.records && !_presentation) {
      setState(() => _unifiedTabs[Section.records] =
        destination == 'student' ? 'students' : destination == 'reports' ? 'reports' : 'tools');
    }
  }

  Future<void> _openTeacherHub() async {
    await _open(Section.today);
    if (mounted) setState(() => _unifiedHomeTab = 2);
  }

  void _openCurriculumProgress() {
    _open(Section.today).then((_) {
      if (mounted) setState(() => _unifiedHomeTab = 2);
    });
  }

  String _progressSummary() {
    try {
      final rows = jsonDecode(_prefs.getString('madrasati.teacher.progress.v1') ?? '[]') as List;
      var done = 0, total = 0;
      for (final row in rows.whereType<Map>()) {
        final d = row['done'], t = row['total'];
        if (d is int && t is int && t > 0) {
          done += d.clamp(0, t); total += t;
        }
      }
      return total == 0 ? '—' : '${(done * 100 / total).round()}%';
    } catch (_) { return '—'; }
  }

  String _taskSummary() {
    try {
      final rows = jsonDecode(_prefs.getString('madrasati.teacher.tasks.v1') ?? '[]') as List;
      return '${rows.whereType<Map>().where((task) => task['done'] != true).length}';
    } catch (_) { return '—'; }
  }

  Widget _today(BuildContext context) {
    if (_unifiedEnabled) return _unifiedHome(context);
    return _classicToday(context);
  }

  Widget _classicToday(BuildContext context) {
    final choices = <(Section, String, String)>[
      (Section.schedule, 'جدولي', 'توزيع الحصص والإصلاح'),
      (Section.records, 'سجلّي', 'الدرجات والحضور والتقارير'),
      (Section.notifications, 'جرس المعلم', 'تنبيهات الحصص اليومية'),
      (Section.library, 'المناهج', 'الكتب الدراسية والمراجعات'),
      (Section.scanner, 'مستمسكاتي', 'تصوير وحفظ المستمسكات'),
    ];
    return MosaicHome(
      school: _school,
      banner: FutureBuilder<SchoolDay>(future: _schoolDay, builder: (_, snapshot) =>
        MosaicHero(
          school: _school, accent: _accent, rounded: _cardRadius,
          compact: _compactHome, showDecoration: _showHeroDecoration,
          lessons: snapshot.hasData ? '${snapshot.data!.lessons.length}' : '—',
          progress: _progressSummary(), tasks: _taskSummary(),
          onExplore: _openTeacherHub,
        )),
      accent: _accent,
      compact: _compactHome,
      rounded: _cardRadius,
      showDescriptions: _showCardDetails,
      showDecoration: _showHeroDecoration,
      showDay: _showDayCard,
      showShortcuts: _showQuickActions,
      entries: [
        for (final choice in choices)
          MosaicEntry(
            section: const {Section.schedule: 'jadwali', Section.records: 'sajli',
              Section.notifications: 'bell', Section.library: 'library',
              Section.scanner: 'scanner'}[choice.$1],
            title: choice.$2,
            description: choice.$3,
            icon: choice.$1.icon,
            color: _cardColors[choice.$1] ?? Color(choice.$1.tone),
            onTap: () => _open(choice.$1),
          ),
      ],
      onSearch: () => _openTool(SchoolTool.search),
      onCenter: _openTeacherHub,
      onStudent: () => _openRecordsCenter('student'),
      onClassroom: () => _openRecordsCenter('classroom'),
      onCurriculum: _openCurriculumProgress,
      onAnalytics: () => _openTool(SchoolTool.statistics),
      onSchedule: () => _open(Section.schedule),
      day: _daySummary(context),
      quickAttendance: () async {
        try {
          final day = await _schoolDay;
          if (mounted && day.grade.isNotEmpty) {
            await _openAttendance(day);
          } else if (mounted) {
            _message('اختر صفاً وشعبة في جدول اليوم أولاً.');
          }
        } catch (_) {
          if (mounted) _message('تعذّر قراءة الصف الحالي من الجدول.');
        }
      },
      quickBell: () => _open(Section.notifications),
      quickSettings: () => _open(Section.settings),
    );
  }

  Widget _daySummary(BuildContext context) {
    return FutureBuilder<SchoolDay>(
      future: _schoolDay,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _card('جدول اليوم', [
            const Text('تعذّر قراءة بيانات الجدول.'),
            TextButton(
              onPressed: () => setState(() => _schoolDay = _loadDay()),
              child: const Text('إعادة المحاولة'),
            ),
          ]);
        }
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(12),
            child: Center(child: CircularProgressIndicator()),
          );
        }
        final day = snapshot.data!;
        return ModernDayPanel(
          day: day,
          accent: _accent,
          rounded: _cardRadius,
          transferring: _transferring,
          onSectionChanged: (id) {
            setState(() {
              _sectionId = id;
              _schoolDay = _loadDay();
            });
            unawaited(_savePreference(_prefs.setInt('${_prefix}section', id)));
          },
          onChangeDate: () async {
            final selected = await showDatePicker(
              context: context,
              initialDate: day.date,
              firstDate: DateTime(2022),
              lastDate: DateTime(2038),
            );
            if (selected == null || !mounted) return;
            setState(() {
              _date = selected;
              _schoolDay = _loadDay();
            });
          },
          onSchedule: () => _open(Section.schedule),
          onTransfer: () => _transfer(context, day),
          onBooks: () => _openBooks(day),
          onAttendance: () => _openAttendance(day),
          onEditLesson: (lesson) => _editLesson(day, lesson),
          onLessonBook: (subject) => _openBooks(day, subject),
        );
      },
    );
  }

  Widget _card(String title, List<Widget> children) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
          ),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    ),
  );

  Widget _tile(Section section, String label, VoidCallback onTap) => Builder(
    builder: (context) {
      final scheme = Theme.of(context).colorScheme;
      final base = Color(section.tone);
      final ink = scheme.brightness == Brightness.dark
          ? Color.lerp(base, Colors.white, .68)!
          : base;
      return Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: ListTile(
          dense: true,
          leading: Icon(section.icon, color: ink),
          title: Text(label, style: TextStyle(color: ink)),
          trailing: Icon(Icons.chevron_left, color: ink),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: ink.withValues(alpha: .21)),
          ),
          tileColor: Color.alphaBlend(
            base.withValues(alpha: .09),
            scheme.surface,
          ),
          onTap: onTap,
        ),
      );
    },
  );

  Widget _colorSwatches({
    required Color selected,
    required ValueChanged<Color> onSelect,
    required String prefix,
  }) => Wrap(
    spacing: 7,
    runSpacing: 8,
    children: [
      for (final item in _swatches)
        Tooltip(
          message: '$prefix: ${item.$1}',
          child: Semantics(
            button: true,
            selected: selected.toARGB32() == item.$2,
            label: '$prefix ${item.$1}',
            child: InkWell(
              key: ValueKey('palette-$prefix-${item.$2}'),
              borderRadius: BorderRadius.circular(11),
              onTap: () => onSelect(Color(item.$2)),
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: Color(item.$2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: selected.toARGB32() == item.$2
                        ? Theme.of(context).colorScheme.onSurface
                        : Colors.transparent,
                    width: 2.5,
                  ),
                ),
                child: selected.toARGB32() == item.$2
                    ? const Icon(Icons.check, size: 20, color: Colors.white)
                    : null,
              ),
            ),
          ),
        ),
    ],
  );

  Future<void> _resetAppearance() async {
    final yes = await showDialog<bool>(
      context: _dialogContext,
      builder: (context) => AlertDialog(
        title: const Text('استعادة ألوان الواجهة؟'),
        content: const Text(
          'يعيد الألوان وتخطيط الصفحة الرئيسية فقط إلى الإعدادات الافتراضية، '
          'دون حذف أي جدول أو سجل أو كتاب.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('استعادة')),
        ],
      ),
    );
    if (yes != true || !mounted) return;
    setState(() {
      _accent = const Color(0xff276b59);
      _cardColors = {
        for (final section in _mainSections.skip(1))
          section: Color(section.tone),
      };
      _compactHome = false;
      _cardRadius = 20;
      _unifiedCardHeight = 158;
      _unifiedEnabled = true;
      _showDayCard = true;
      _showQuickActions = true;
      _showCardDetails = true;
      _showHeroDecoration = true;
      _showBottomNavigation = true;
    });
    final changes = <Future<bool>>[
      _prefs.setInt('${_prefix}accent', _accent.toARGB32()),
      for (final section in _mainSections.skip(1))
        _prefs.setInt('${_prefix}card.${section.name}', section.tone),
      _prefs.setBool('${_prefix}compactHome', false),
      _prefs.setDouble('${_prefix}cardRadius', 20),
      _prefs.setDouble('${_prefix}unifiedCardHeight', 158),
      _prefs.setBool('${_prefix}unifiedDesign', true),
      _prefs.setBool('${_prefix}showDay', true),
      _prefs.setBool('${_prefix}showQuick', true),
      _prefs.setBool('${_prefix}showDescriptions', true),
      _prefs.setBool('${_prefix}heroDecoration', true),
      _prefs.setBool('${_prefix}bottomNavigation', true),
    ];
    final saved = await Future.wait(changes);
    if (mounted) {
      _message(saved.every((item) => item)
          ? 'أُعيدت إعدادات المظهر دون المساس ببياناتك.'
          : 'بعض إعدادات المظهر لم تُحفظ.');
    }
  }

  Widget _settingToggle(String title, String subtitle, bool value,
      String key, void Function(bool) change) => SwitchListTile(
    contentPadding: EdgeInsets.zero,
    title: Text(title),
    subtitle: Text(subtitle, style: const TextStyle(fontSize: 11)),
    value: value,
    onChanged: (next) {
      setState(() => change(next));
      unawaited(_savePreference(_prefs.setBool('${_prefix}$key', next)));
    },
  );

  Widget _settings(BuildContext context) {
    final themeLabels = {
      ThemeMode.system: 'حسب الجهاز',
      ThemeMode.light: 'فاتح',
      ThemeMode.dark: 'ليلي أسود',
    };
    return ListView(
      key: const PageStorageKey('madrasati-settings'),
      padding: const EdgeInsets.all(14),
      children: [
        _card('التصميم الموحّد — HTML المعتمد', [
          const ListTile(leading: Icon(Icons.verified_outlined), title: Text('واجهة موحّدة واحدة'), subtitle: Text('التصميم الجديد ثابت داخل الأقسام الخمسة دون الواجهات السابقة.')),
          Text('ارتفاع بطاقة القسم: ${_unifiedCardHeight.round()} نقطة',
            style: const TextStyle(fontWeight: FontWeight.w700)),
          Slider(min: 132, max: 210, divisions: 39,
            value: _unifiedCardHeight,
            onChanged: (value) => setState(() => _unifiedCardHeight = value),
            onChangeEnd: (value) => unawaited(_savePreference(
              _prefs.setDouble('${_prefix}unifiedCardHeight', value))),
          ),
          const Text('تغيير التصميم لا يحذف أي بيانات أو يمنح صلاحية المدير.',
            style: TextStyle(fontSize: 11)),
        ]),
        _card('المظهر وألوان التطبيق', [
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('المظهر العام'),
            subtitle: const Text('لا يغيّر الألوان الداخلية للتطبيقات الخمسة'),
            trailing: DropdownButton<ThemeMode>(
              value: _mode,
              items: [
                for (final entry in themeLabels.entries)
                  DropdownMenuItem(value: entry.key, child: Text(entry.value)),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() => _mode = value);
                unawaited(_savePreference(
                    _prefs.setString('${_prefix}theme', value.name)));
              },
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('اختر لون الواجهة · 20 لوناً',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          _colorSwatches(
            selected: _accent,
            prefix: 'الواجهة',
            onSelect: (color) {
              setState(() => _accent = color);
              unawaited(_savePreference(
                  _prefs.setInt('${_prefix}accent', color.toARGB32())));
            },
          ),
        ]),
        const SizedBox(height: 10),
        _card('ألوان بطاقات التطبيقات · مستقلة عن لون الواجهة', [
          const Text('لكل بطاقة لونها الخاص، ولا تتغير بقية البطاقات عند الاختيار.'),
          for (final section in _mainSections.skip(1))
            ExpansionTile(
              key: PageStorageKey('palette-${section.name}'),
              leading: Icon(section.icon,
                  color: _cardColors[section] ?? Color(section.tone)),
              title: Text('بطاقة ${section.label}'),
              subtitle: Text(
                _swatches.where((item) => item.$2 ==
                    (_cardColors[section] ?? Color(section.tone)).toARGB32())
                    .firstOrNull?.$1 ?? 'لون خاص',
              ),
              childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 14),
              children: [
                _colorSwatches(
                  selected: _cardColors[section] ?? Color(section.tone),
                  prefix: section.label,
                  onSelect: (color) {
                    setState(() => _cardColors[section] = color);
                    unawaited(_savePreference(_prefs.setInt(
                        '${_prefix}card.${section.name}', color.toARGB32())));
                  },
                ),
              ],
            ),
        ]),
        const SizedBox(height: 10),
        _card('ترتيب الصفحة الرئيسية وحجم العناصر', [
          _settingToggle('وضع العرض أمام الصف', 'إخفاء أسماء التلاميذ ودرجاتهم وحضورهم',
              _presentation, 'presentation', (v) => _presentation = v),
          _settingToggle('بطاقات مدمجة', 'لتظهر أقسام أكثر على الشاشة',
              _compactHome, 'compactHome', (v) => _compactHome = v),
          _settingToggle('إظهار حصص اليوم', 'يعرض صفوف وحصص جدولي',
              _showDayCard, 'showDay', (v) => _showDayCard = v),
          _settingToggle('إظهار الاختصارات', 'الحضور والجرس والتخصيص',
              _showQuickActions, 'showQuick', (v) => _showQuickActions = v),
          _settingToggle('وصف البطاقات', 'نص مختصر تحت اسم كل تطبيق',
              _showCardDetails, 'showDescriptions',
              (v) => _showCardDetails = v),
          _settingToggle('زخرفة البطاقة الرئيسية', 'تدرج الألوان ورمز المدرسة',
              _showHeroDecoration, 'heroDecoration',
              (v) => _showHeroDecoration = v),
          _settingToggle('شريط التنقل السفلي', 'اختصارات للوصول إلى الصفحات',
              _showBottomNavigation, 'bottomNavigation',
              (v) => _showBottomNavigation = v),
          _settingToggle('تقليل الحركة', 'مناسب للأجهزة الأبطأ',
              _reduceMotion, 'motion', (v) => _reduceMotion = v),
          ListTile(
            title: const Text('تدوير زوايا البطاقات'),
            subtitle: Text('${_cardRadius.round()}'),
          ),
          Slider(
            value: _cardRadius,
            min: 8,
            max: 32,
            divisions: 12,
            onChanged: (v) => setState(() => _cardRadius = v),
            onChangeEnd: (v) => unawaited(_savePreference(
                _prefs.setDouble('${_prefix}cardRadius', v))),
          ),
          ListTile(title: const Text('تكبير النص في مدرستي'),
              trailing: Text('${(_textScale * 100).round()}%')),
          Slider(
            value: _textScale,
            min: .9,
            max: 1.2,
            divisions: 6,
            onChanged: (v) => setState(() => _textScale = v),
            onChangeEnd: (v) => unawaited(_savePreference(
                _prefs.setDouble('${_prefix}text', v))),
          ),
          TextButton.icon(
            onPressed: _resetAppearance,
            icon: const Icon(Icons.restore_rounded),
            label: const Text('إعادة ضبط المظهر فقط'),
          ),
        ]),
        const SizedBox(height: 10),
        _card('حماية التطبيق والبصمة والرمز', [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('قفل التطبيق بالرمز'),
            subtitle: const Text('رمز خاص من 4 إلى 8 أرقام يُحفظ بأمان'),
            value: _appLockEnabled,
            onChanged: (v) => v ? _enableAppLock() : _disableAppLock(),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('فتح بالبصمة'),
            subtitle: const Text('تحتاج رمز التطبيق أولاً وبصمة مسجلة في الجهاز'),
            value: _biometricUnlock,
            onChanged: _appLockEnabled ? _toggleBiometrics : null,
          ),
          if (_appLockEnabled) ...[
            ListTile(
              leading: const Icon(Icons.password),
              title: const Text('تغيير رمز قفل التطبيق'),
              onTap: _changeAppPin,
            ),
            ListTile(
              leading: const Icon(Icons.lock_clock_outlined),
              title: const Text('قفل التطبيق الآن'),
              onTap: () => setState(() => _appLocked = true),
            ),
          ],
          const Text('قفل التطبيق مختلف عن رمز المدير وصلاحياته.',
              style: TextStyle(fontSize: 11)),
        ]),
        const SizedBox(height: 10),
        _card('صلاحيات المدير وإعداداته', [
          if (!_admin)
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: const Text('الدخول إلى إعدادات المدير'),
              subtitle: const Text('خاص بمالك مستودع المناهج؛ يتطلب تفعيل حساب المالك'),
              onTap: _checking ? null : () => _authenticate(),
            )
          else ...[
            ListTile(
              leading: const Icon(Icons.lock_open_outlined),
              title: const Text('إنهاء جلسة المدير'),
              onTap: _lock,
            ),
            ListTile(
              title: const Text('مدة جلسة المدير'),
              trailing: DropdownButton<int>(
                value: _sessionMinutes,
                items: const [
                  DropdownMenuItem(value: 5, child: Text('٥ دقائق')),
                  DropdownMenuItem(value: 10, child: Text('١٠ دقائق')),
                  DropdownMenuItem(value: 15, child: Text('١٥ دقيقة')),
                  DropdownMenuItem(value: 30, child: Text('٣٠ دقيقة')),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  setState(() => _sessionMinutes = v);
                  _startSession();
                  unawaited(_savePreference(
                      _prefs.setInt('${_prefix}session', v)));
                },
              ),
            ),
            ListTile(
              title: const Text('اسم المدرسة في الرئيسية'),
              subtitle: Text(_school),
              onTap: () => _rename(context),
            ),
            ListTile(
              leading: const Icon(Icons.key_outlined),
              title: const Text('إضافة أو تغيير رمز المدير'),
              onTap: _setManagerPin,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('إعدادات المدير خاصة بمالك مستودع المناهج. '
                  'إدارة المناهج تتطلب تفويض مستودع GitHub الخاص بها.'),
            ),
            _tile(Section.manager, 'إدارة المناهج والنشر',
                () => _open(Section.manager)),
          ],
        ]),
        const SizedBox(height: 10),
        _card('الأذونات والتنبيهات', [
          ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: const Text('طلب إذن الإشعارات'),
            onTap: () => _device(DeviceService.requestNotifications),
          ),
          ListTile(
            leading: const Icon(Icons.access_time_outlined),
            title: const Text('إذن التنبيهات الدقيقة'),
            onTap: () => _device(() => DeviceService.openSettings('exact')),
          ),
          ListTile(
            leading: const Icon(Icons.vibration_outlined),
            title: const Text('إعدادات الاهتزاز'),
            onTap: () => _device(() => DeviceService.openSettings('vibration')),
          ),
          ListTile(
            leading: const Icon(Icons.battery_saver_outlined),
            title: const Text('إعدادات تحسين البطارية'),
            onTap: () => _device(() => DeviceService.openSettings('battery')),
          ),
        ]),
        const SizedBox(height: 10),
        _card('أدوات المدرسة', [
          for (final tool in SchoolTool.values)
            if (!_presentation || tool != SchoolTool.statistics)
              ListTile(leading: Icon(tool.icon), title: Text(tool.label), onTap: () => _openTool(tool)),
          if (!_presentation) ListTile(leading: const Icon(Icons.backup_outlined),
            title: const Text('نسخ سجل التلاميذ واستعادته'), onTap: () async {
              await _open(Section.records);
              if (mounted && _section == Section.records) _center.value = 'backup';
            }),
        ]),
        const SizedBox(height: 10),
        _card('معلومات التطبيق', [
          const ListTile(title: Text('النسخة'), trailing: Text(_version)),
          const ListTile(
            title: Text('خصوصية البيانات'),
            subtitle: Text('تخزن إعدادات الواجهة على الجهاز، ورموز القفل في مخزن مشفر. '
                'بيانات الجدول والسجل تبقى داخل التطبيقات ما لم تستخدم وظائف النشر أو المشاركة.'),
          ),
        ]),
        const SizedBox(height: 26),
      ],
    );
  }

  Future<void> _device(Future<void> Function() action) async {
    try {
      await action();
    } catch (_) {
      _message('تعذّر فتح إعداد الجهاز.');
    }
  }

  Future<void> _rename(BuildContext context) async {
    final name = await showDialog<String>(
      context: _dialogContext,
      builder: (context) => _SchoolNameDialog(initial: _school),
    );
    if (!mounted || !_admin || name == null || name.isEmpty) return;
    setState(() => _school = name);
    await _savePreference(_prefs.setString('${_prefix}school', name));
  }
}

class _SchoolNameDialog extends StatefulWidget {
  const _SchoolNameDialog({required this.initial});
  final String initial;
  @override
  State<_SchoolNameDialog> createState() => _SchoolNameDialogState();
}

class _SchoolNameDialogState extends State<_SchoolNameDialog> {
  late final _controller = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('اسم المدرسة'),
    content: TextField(controller: _controller, maxLength: 65, autofocus: true),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(
        onPressed: () => Navigator.pop(context, _controller.text.trim()),
        child: const Text('حفظ'),
      ),
    ],
  );
}
