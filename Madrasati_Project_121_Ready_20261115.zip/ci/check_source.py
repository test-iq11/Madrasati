"""Check the package boundaries, Android channels, and expected build inputs."""
from pathlib import Path
import re
from zipfile import ZipFile
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return (ROOT / name).read_text(encoding='utf-8')


pubspec = read('pubspec.yaml')
# Dependency regression: an unpublished secure-storage version once blocked all CI tests.
# Verify the root manifest, library module and already-pinned lockfile agree.
assert re.search(r'^  flutter_secure_storage: \^11\.2\.0\s*$', pubspec, re.M), \
    'Root pubspec.yaml must use published flutter_secure_storage ^11.2.0'
assert re.search(r'^  flutter_secure_storage: \^11\.2\.0\s*$',
                 read('modules/library/pubspec.yaml'), re.M), \
    'Library module must match the root secure storage constraint'
assert re.search(r'^  flutter_secure_storage:\n    dependency: "direct main"\n'
                 r'(?:.*\n){0,6}    version: "11\.2\.0"$',
                 read('pubspec.lock'), re.M), \
    'The root lockfile must pin flutter_secure_storage 11.2.0 as direct main'
assert 'version: 1.2.1+4' in pubspec
assert r"r'^version:\s*1\.2\.1\+4\s*$'" in read('.github/workflows/build-madrasati-android.yml')
ns = {'a': 'http://schemas.android.com/apk/res/android'}
manifest = ElementTree.parse(ROOT / 'android/app/src/main/AndroidManifest.xml')
permissions = {row.get('{' + ns['a'] + '}name') for row in manifest.findall('uses-permission')}
assert {'android.permission.CAMERA', 'android.permission.USE_BIOMETRIC',
        'android.permission.VIBRATE', 'android.permission.SCHEDULE_EXACT_ALARM'} <= permissions
# Regression guard: a missing Bundle import previously broke :app:compileReleaseJavaWithJavac.
sajli_activity = read('android/app/src/main/java/com/sajli/school/SajliActivity.java')
assert 'FlutterFragmentActivity' in sajli_activity
assert re.search(r'^import\s+android\.os\.Bundle\s*;', sajli_activity, re.M), \
    'SajliActivity must import android.os.Bundle for PrintDocumentAdapter.onLayout'
assert re.search(r'LayoutResultCallback\s+\w+,\s*Bundle\s+\w+', sajli_activity), \
    'Check the native PDF PrintDocumentAdapter signature'
assert 'MainActivity : SajliActivity' in read('android/app/src/main/kotlin/com/school/teacherbell/MainActivity.kt')
assert 'com.school.teacherbell/device' in read('android/app/src/main/kotlin/com/school/teacherbell/MainActivity.kt')
assert '"sajli/files"' in read('android/app/src/main/java/com/sajli/school/SajliActivity.java')
with ZipFile(ROOT / 'android/gradle/wrapper/gradle-wrapper.jar') as wrapper:
    assert 'org/gradle/wrapper/GradleWrapperMain.class' in wrapper.namelist()
for module in ('jadwali', 'scanner', 'library'):
    assert 'file_picker: 13.3.2' in read(f'modules/{module}/pubspec.yaml')
    assert all('FilePicker.platform' not in f.read_text() for f in (ROOT / 'modules' / module / 'lib').rglob('*.dart'))
assert 'share_plus: 13.1.0' in read('modules/scanner/pubspec.yaml')
assert 'excel_plus:' in read('modules/library/pubspec.yaml')
assert '\n  excel:' not in read('modules/library/pubspec.yaml')
for asset in ('UI-Regular.ttf', 'UI-Bold.ttf', 'UI-Latin.ttf', 'Arabic-Regular.ttf', 'Report-Regular.ttf'):
    assert (ROOT / 'modules/jadwali/assets/fonts' / asset).stat().st_size > 1000
for path in (
    'modules/jadwali/test/unscheduled_reason_1312_test.dart',
    'modules/sajli/test/records_test.dart',
    'android/app/src/test/kotlin/com/school/teacherbell/BellVibrationTest.kt',
    'modules/library/assets/library_seed.json',
    'modules/scanner/assets/demo/sample_front.jpg',
):
    assert (ROOT / path).is_file(), path
for module in ('jadwali', 'bell', 'sajli', 'scanner', 'library'):
    assert f'path: modules/{module}' in pubspec
print('Project, module assets, native Android bridges, and dependency declarations checked.')

# Keep the Android toolchain aligned with the pinned Flutter release.
assert 'gradle-9.3.1-bin.zip' in read('android/gradle/wrapper/gradle-wrapper.properties')
assert 'id "com.android.application" version "9.1.1"' in read('android/settings.gradle')
assert 'android.builtInKotlin=false' in read('android/gradle.properties')
assert 'android.newDsl=false' in read('android/gradle.properties')
workflow = read('.github/workflows/build-madrasati-android.yml')
assert "FLUTTER_VERSION: '3.50.0'" in workflow
assert '--android-skip-build-dependency-validation' not in workflow
# CI must use the unit-test variant registered by AGP 9 (not a nonexistent release task).
assert ':app:testReleaseUnitTest' not in workflow, 'AGP 9 does not create this task by default'
assert ':app:testDebugUnitTest' in workflow
assert 'TEST-*.xml' in workflow and 'Android JUnit:' in workflow
for name in ('BellSchedulerTest.kt', 'BellVibrationTest.kt'):
    test_path = ROOT / 'android/app/src/test/kotlin/com/school/teacherbell' / name
    assert '@Test' in test_path.read_text(encoding='utf-8'), f'{name} has no tests'
# The workflow and source project must both avoid Maven Central as first resolver.
mirror = 'https://maven-central-eu.storage-download.googleapis.com/maven2/'
for gradle in ('android/settings.gradle', 'android/build.gradle'):
    gradle_source = read(gradle)
    assert gradle_source.index(mirror) < gradle_source.index('mavenCentral()'), gradle
    assert 'google()' in gradle_source and 'mavenCentral()' in gradle_source
# Gradle basic cache needs *.gradle* in repository root; this project is ZIP-only.
# Use the standard GitHub Actions cache keyed from the ZIP in the repo root.
assert 'uses: actions/cache@v4' in workflow
assert "hashFiles('*.zip')" in workflow
assert 'uses: gradle/actions/setup-gradle@v6' not in workflow
assert 'Configure Maven Central mirror in extracted source' in workflow
print('Google-hosted Maven mirror and ZIP-safe Gradle dependency cache checked.')
print('Pinned Android toolchain and Flutter compatibility flags checked.')

# UI feature and release metadata regression guards.
main = read('lib/main.dart')
assert 'return MosaicHome(' in main
assert 'Widget _bottomNav()' in main
assert 'Widget _appLockScreen(' in main
assert 'MadrasatiPinStore' in main
assert 'فتح بالبصمة' in main
assert 'ألوان بطاقات التطبيقات' in main
assert (ROOT / 'test/mosaic_home_test.dart').is_file()
assert (ROOT / 'modules/sajli/test/student_name_navigation_test.dart').is_file()
assert "studentProfile(context, s);" in read('modules/sajli/lib/main.dart')
assert r"r'^version:\s*1\.2\.1\+4\s*$'" in workflow, 'CI and pubspec version mismatch'
assert "versionCode='4' versionName='1.2.1'" in workflow
print('Mosaic, Sajli name-tap, privacy lock and release versions checked.')

# Visual and behavioral regressions: approved RTL mosaic and student-grade entry.
assert 'tileHeight' in read('lib/mosaic_home.dart')
assert 'mosaic-${entry.title}' in read('lib/mosaic_home.dart')
assert 'DayCards(' in read('lib/main.dart')
assert 'showDialog<String>' in read('modules/sajli/lib/main.dart')
assert 'useRootNavigator: true' in read('modules/sajli/lib/main.dart')
assert 'student-sheet-save-grade' in read('modules/sajli/lib/student_sheet.dart')
assert (ROOT / 'test/day_cards_test.dart').is_file()
assert (ROOT / 'modules/sajli/test/student_name_navigation_test.dart').is_file()
print('Approved visual layout and real grade-entry flow checked.')

# Previous Sajli regression: the student grade sheet must preserve the original
# profile title and delete/undo path in addition to its new direct grade editor.
sheet = read('modules/sajli/lib/student_sheet.dart')
assert "Text('ملف التلميذ'" in sheet
assert "Text('حذف التلميذ'" in sheet
assert "ValueKey('student-sheet-save-grade')" in sheet
assert "ValueKey('student-sheet-close')" in sheet
assert "ValueKey('student-sheet-delete')" in sheet
assert 'showDialog<String>' in read('modules/sajli/lib/main.dart')
assert 'useRootNavigator: true' in read('modules/sajli/lib/main.dart')
assert 'sajli-profile-regression.log' in workflow
print('Sajli grade-editor, nested navigator, delete and restore regressions guarded.')
