import 'dart:math' as math;

import 'package:flutter/material.dart';

const _white = Colors.white;
const _heroText = Color(0xffdaf0e2);
const _clockColors = <int, (int, int, int)>{
  0xff103e32: (0xffb37563, 0xffd5a18a, 0xfffff0dc),
  0xff184a69: (0xff112941, 0xff245078, 0xffa5e9ff),
  0xff513774: (0xff2a2045, 0xff503779, 0xffedcaff),
  0xff734023: (0xff38261d, 0xff6a4228, 0xffffdb97),
  0xff712f48: (0xff391f31, 0xff71405a, 0xffffc9e3),
  0xff165655: (0xff113233, 0xff1c5b5b, 0xffacf1e3),
};

Color bellSignal(Color color) =>
    Color(_clockColors[color.toARGB32()]?.$3 ?? 0xffc7f684);

LinearGradient bellGradient(Color color) {
  final matched = _clockColors[color.toARGB32()];
  final base = color.computeLuminance() > .22
      ? Color.lerp(color, Colors.black, .34)!
      : color;
  return LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: matched == null
        ? [base, Color.lerp(base, const Color(0xff8ebba8), .17)!]
        : [Color(matched.$1), Color(matched.$2)],
  );
}

class BellBadge extends StatelessWidget {
  const BellBadge({
    super.key,
    required this.icon,
    required this.background,
    required this.foreground,
    this.size = 42,
  });

  final IconData icon;
  final Color background, foreground;
  final double size;

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    decoration: BoxDecoration(
      color: background,
      borderRadius: BorderRadius.circular(14),
    ),
    child: Icon(icon, size: 20, color: foreground),
  );
}

class BellHero extends StatelessWidget {
  const BellHero({
    super.key,
    required this.color,
    required this.status,
    required this.clockLabel,
    required this.day,
    required this.title,
    required this.detail,
    required this.value,
    required this.unit,
    required this.dialLabel,
    required this.progress,
    required this.hours,
    required this.nextTitle,
    required this.nextTime,
    required this.onClock,
  });

  final Color color;
  final String status, clockLabel, day, title, detail, value, unit, dialLabel;
  final String hours, nextTitle, nextTime;
  final double progress;
  final VoidCallback onClock;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final mobile = width <= 720;
    final dial = width <= 350 ? 110.0 : (width * .34).clamp(119.0, 191.0);
    final signal = bellSignal(color);
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: bellGradient(color),
        borderRadius: BorderRadius.circular(mobile ? 23 : 27),
        boxShadow: const [
          BoxShadow(
            color: Color(0x2b0c2826),
            blurRadius: 28,
            offset: Offset(0, 14),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(mobile ? 23 : 27),
        child: CustomPaint(
          painter: const _HeroDots(),
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              mobile ? 13 : 20,
              mobile ? 13 : 18,
              mobile ? 13 : 20,
              0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Wrap(
                  alignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 7,
                  runSpacing: 4,
                  children: [
                    _pill(
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.circle, size: 7, color: signal),
                          const SizedBox(width: 7),
                          Text(
                            status,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Semantics(
                      button: true,
                      label: 'فتح تجربة ساعة الدوام',
                      child: InkWell(
                        key: const ValueKey('clock-simulation'),
                        onTap: onClock,
                        borderRadius: BorderRadius.circular(99),
                        child: _pill(
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.schedule,
                                size: 14,
                                color: _heroText,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                clockLabel,
                                style: const TextStyle(
                                  color: _heroText,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: mobile ? 10 : 13),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              day,
                              style: const TextStyle(
                                color: _heroText,
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: width <= 350
                                    ? 22
                                    : (width * .062).clamp(25.0, 44.0),
                                height: 1.23,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              detail,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Color(0xffedf6ed),
                                fontSize: 12.3,
                                height: 1.5,
                              ),
                            ),
                            if (hours.isNotEmpty) ...[
                              const SizedBox(height: 8),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.calendar_today_outlined,
                                    size: 13,
                                    color: _heroText,
                                  ),
                                  const SizedBox(width: 5),
                                  Flexible(
                                    child: Text(
                                      hours,
                                      textDirection: TextDirection.ltr,
                                      style: const TextStyle(
                                        color: _heroText,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                      SizedBox(width: mobile ? 8 : 13),
                      SizedBox.square(
                        dimension: dial,
                        child: CustomPaint(
                          painter: _ClockDial(progress, signal),
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                              ),
                              child: FittedBox(
                                fit: BoxFit.scaleDown,
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      dialLabel,
                                      style: const TextStyle(
                                        color: _heroText,
                                        fontSize: 9.5,
                                      ),
                                    ),
                                    Text(
                                      value,
                                      key: const ValueKey('clock-countdown'),
                                      textDirection: TextDirection.ltr,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: (width * .06).clamp(
                                          22.0,
                                          35.0,
                                        ),
                                        fontWeight: FontWeight.w800,
                                        height: 1.15,
                                        fontFeatures: const [
                                          FontFeature.tabularFigures(),
                                        ],
                                      ),
                                    ),
                                    if (unit.isNotEmpty)
                                      Text(
                                        unit,
                                        style: TextStyle(
                                          color: signal,
                                          fontSize: 9,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(
                  height: 1,
                  thickness: 1,
                  color: Color(0x35ffffff),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: mobile ? 8 : 11),
                  child: Row(
                    children: [
                      Icon(Icons.arrow_back, size: 18, color: signal),
                      const SizedBox(width: 7),
                      Text(
                        'التالية',
                        style: TextStyle(
                          color: signal,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          nextTitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                      ),
                      if (nextTime.isNotEmpty)
                        Text(
                          nextTime,
                          textDirection: TextDirection.ltr,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _pill(Widget child) => DecoratedBox(
    decoration: BoxDecoration(
      color: const Color(0x15ffffff),
      border: Border.all(color: const Color(0x34ffffff)),
      borderRadius: BorderRadius.circular(99),
    ),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      child: child,
    ),
  );
}

class _HeroDots extends CustomPainter {
  const _HeroDots();
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint();
    for (double x = 12; x < size.width * .63; x += 18) {
      paint.color = Colors.white.withValues(
        alpha: .14 * (1 - x / (size.width * .63)),
      );
      for (double y = 9; y < size.height; y += 18) {
        canvas.drawCircle(Offset(x, y), 1, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _HeroDots oldDelegate) => false;
}

class _ClockDial extends CustomPainter {
  const _ClockDial(this.progress, this.signal);
  final double progress;
  final Color signal;
  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 120;
    final center = size.center(Offset.zero);
    final paint = Paint()
      ..strokeWidth = 1.45 * scale
      ..color = const Color(0x57ffffff);
    for (var tick = 0; tick < 60; tick++) {
      final angle = tick * math.pi / 30;
      final direction = Offset(math.cos(angle), math.sin(angle));
      canvas.drawLine(
        center + direction * (56 * scale),
        center + direction * (57.5 * scale),
        paint,
      );
    }
    final radius = 49 * scale;
    canvas.drawCircle(center, radius, Paint()..color = const Color(0x2b071b16));
    paint
      ..style = PaintingStyle.stroke
      ..color = const Color(0x2affffff)
      ..strokeWidth = 4 * scale;
    canvas.drawCircle(center, radius, paint);
    if (progress > 0) {
      paint
        ..color = signal
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 4.5 * scale;
      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        -math.pi / 2,
        progress.clamp(0.0, 1.0) * math.pi * 2,
        false,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ClockDial oldDelegate) =>
      progress != oldDelegate.progress || signal != oldDelegate.signal;
}

class HeroColorTile extends StatelessWidget {
  const HeroColorTile({
    super.key,
    required this.color,
    required this.name,
    required this.selected,
    required this.accent,
    required this.onTap,
  });
  final Color color, accent;
  final String name;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Semantics(
    selected: selected,
    button: true,
    label: 'لون البطاقة الرئيسية $name',
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        width: 68,
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? accent : accent.withValues(alpha: .2),
            width: selected ? 2 : 1,
          ),
        ),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              height: 33,
              padding: const EdgeInsets.symmetric(horizontal: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                gradient: bellGradient(color),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(
                    selected
                        ? Icons.check_rounded
                        : Icons.horizontal_rule_rounded,
                    color: _white,
                    size: 14,
                  ),
                  const Icon(
                    Icons.circle_outlined,
                    color: Color(0xb3ffffff),
                    size: 12,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 4),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(name, style: const TextStyle(fontSize: 10)),
            ),
          ],
        ),
      ),
    ),
  );
}
