import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:teacher_bell/bell_design.dart';
import 'package:teacher_bell/domain.dart';
import 'package:teacher_bell/main.dart';
import 'package:teacher_bell/lesson_tile.dart';
import 'package:teacher_bell/platform_service.dart';

void main() {
  testWidgets('hero swatch changes only the hero and is saved', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final initial = PlannerState()..accentIndex = 2;
    final channel =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    channel.setMockMethodCallHandler(DeviceService.channel, (call) async {
      if (call.method == 'status') {
        return <String, Object>{};
      }
      if (call.method == 'logs') {
        return <Object>[];
      }
      return null;
    });
    addTearDown(
      () => channel.setMockMethodCallHandler(DeviceService.channel, null),
    );
    await tester.pumpWidget(TeacherBellApp(initialState: initial));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الإعدادات'));
    await tester.pumpAndSettle();
    const blue = 0xff184a69;
    final tile = find.byKey(const ValueKey('hero-color-$blue'));
    expect(tile, findsOneWidget);
    await tester.ensureVisible(tile);
    await tester.pumpAndSettle();
    await tester.tap(tile);
    await tester.pumpAndSettle();
    await tester.tap(find.text('الرئيسية'));
    await tester.pumpAndSettle();
    expect(
      tester.widget<BellHero>(find.byType(BellHero)).color,
      const Color(blue),
    );
    final restored = await DeviceService.load();
    expect(restored.heroColor, blue);
    expect(restored.accentIndex, 2);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('vibration preset sends the same saved waveform parameters', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    Object? payload;
    final channel =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    channel.setMockMethodCallHandler(DeviceService.channel, (call) async {
      switch (call.method) {
        case 'status':
          return <String, Object>{'vibrator': true};
        case 'logs':
          return <Object>[];
        case 'testVibration':
          payload = call.arguments;
          return true;
        default:
          return null;
      }
    });
    addTearDown(
      () => channel.setMockMethodCallHandler(DeviceService.channel, null),
    );
    await tester.pumpWidget(TeacherBellApp(initialState: PlannerState()));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('إعدادات الهزاز'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('متكرر · 6'));
    await tester.pumpAndSettle();
    final button = find.text('تجربة النمط');
    await tester.ensureVisible(button);
    await tester.pumpAndSettle();
    await tester.tap(button);
    await tester.pumpAndSettle();
    expect(payload, {'count': 6, 'pulse': 190, 'gap': 140});
    final restored = await DeviceService.load();
    expect(restored.vibration.toJson(), payload);
    await tester.pump(const Duration(seconds: 3));
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('lesson editor saves its own count through the schedule', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    SharedPreferences.setMockInitialValues({});
    final channel =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    channel.setMockMethodCallHandler(DeviceService.channel, (call) async {
      if (call.method == 'status') {
        return <String, Object>{};
      }
      if (call.method == 'logs') {
        return <Object>[];
      }
      return null;
    });
    addTearDown(
      () => channel.setMockMethodCallHandler(DeviceService.channel, null),
    );
    final initial = PlannerState();
    final day = dayIndex(DateTime.now());
    initial.work[day] = true;
    initial.week[day][0] = initial.week[day][0].copyWith(
      subject: 'الرياضيات',
      grade: grades[0],
      mode: 'vibration',
      enabled: true,
    );
    await tester.pumpWidget(TeacherBellApp(initialState: initial));
    await tester.pumpAndSettle();
    await tester.tap(find.text('الحصص'));
    await tester.pumpAndSettle();
    final lesson = find.widgetWithText(LessonTile, 'الرياضيات');
    await tester.ensureVisible(lesson);
    await tester.tap(lesson);
    await tester.pumpAndSettle();
    final control = find.byKey(const ValueKey('lesson-vibration-0'));
    await tester.ensureVisible(control);
    await tester.pumpAndSettle();
    await tester.tap(control);
    await tester.pumpAndSettle();
    final option = find.text('6 هزات').last;
    await tester.ensureVisible(option);
    await tester.pumpAndSettle();
    await tester.tap(option);
    await tester.pumpAndSettle();
    final save = find.text('حفظ الحصة');
    await tester.ensureVisible(save);
    await tester.pumpAndSettle();
    await tester.tap(save);
    await tester.pumpAndSettle();
    final restored = await DeviceService.load();
    expect(restored.week[day][0].vibrationCount, 6);
    expect(restored.vibration.count, 3);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });

  test('vibration count and lesson color survive serialization', () {
    final state = PlannerState()
      ..vibration = const VibrationProfile(count: 6, pulse: 190, gap: 140);
    state.week[0][0] = state.week[0][0].copyWith(
      mode: 'vibration',
      vibrationCount: 12,
      color: 0xff9267b6,
    );
    final restored = state.clone();
    final lesson = restored.week[0][0];
    expect(lesson.vibrates, isTrue);
    expect(lesson.color, 0xff9267b6);
    expect(restored.vibrationFor(lesson).toJson(), {
      'count': 12,
      'pulse': 190,
      'gap': 140,
    });
    expect(restored.vibrationFor(restored.week[0][1]).count, 6);
    final old = PlannerState.fromJson(state.toJson()..remove('vibration'));
    expect(old.vibration.count, 3);
  });
}
