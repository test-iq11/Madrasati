import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:teacher_bell/bell_design.dart';
import 'package:teacher_bell/domain.dart';
import 'package:teacher_bell/main.dart';

void main() {
  testWidgets('Flutter clock draws its dial and previews a running lesson', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    var wallTime = DateTime(2026, 11, 8, 9, 7);
    await tester.pumpWidget(
      TeacherBellApp(
        initialState: PlannerState(),
        platformEnabled: false,
        readTime: () => wallTime,
      ),
    );
    await tester.pumpAndSettle();
    expect(find.byType(AndroidView), findsNothing);
    expect(find.byType(BellHero), findsOneWidget);
    expect(tester.getSize(find.byType(BellHero)).width, 364);
    await tester.tap(find.byKey(const ValueKey('clock-simulation')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('حصة جارية'));
    await tester.pumpAndSettle();
    expect(find.text('الحصة الجارية'), findsOneWidget);
    final countdown = find.byKey(const ValueKey('clock-countdown'));
    final value = tester.widget<Text>(countdown).data;
    expect(value, matches(RegExp(r'^\d{2}:\d{2}$')));
    wallTime = wallTime.add(const Duration(seconds: 2));
    await tester.pump(const Duration(seconds: 2));
    expect(tester.widget<Text>(countdown).data, isNot(value));
    expect(tester.takeException(), isNull);

    await tester.tap(find.text('الحصص'));
    await tester.pumpAndSettle();
    expect(find.byType(SliverPersistentHeader), findsOneWidget);
    expect(find.text('08:00'), findsOneWidget);
    expect(find.text('فاصل · 5 د'), findsWidgets);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });
}
