import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart' as flutter;
import 'package:material_ui/material_ui.dart';
import 'package:sajli/main.dart';
import 'package:sajli/records.dart';

void main() {
  testWidgets('tapping student name opens real profile, not blank page',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final folder = Directory.systemTemp.createTempSync('sajli-name-test-');
    addTearDown(() => folder.deleteSync(recursive: true));
    final records = Records.decode(File('assets/demo.json').readAsStringSync());
    final classId = records.activeClasses.first['id'].toString();
    final pupil = records.students(classId).first;
    final id = pupil['id'].toString();
    final name = pupil['name'].toString();
    await tester.pumpWidget(SajliApp(
      records: records,
      file: File('${folder.path}/sajli.json'),
    ));
    await tester.pumpAndSettle();
    final studentName = find.byKey(ValueKey('student-name-$id'));
    await tester.ensureVisible(studentName);
    await tester.pumpAndSettle();
    expect(studentName.hitTestable(), findsOneWidget);
    await tester.tap(studentName);
    await tester.pumpAndSettle();
    expect(find.text('حفظ الدرجة'), findsOneWidget);
    expect(find.byKey(const ValueKey('student-sheet-name')), findsOneWidget);
    expect(find.byKey(const ValueKey('student-sheet-grade-input')), findsOneWidget);
    expect(find.text(name), findsWidgets);
    expect(find.text('تعديل'), findsOneWidget);
    expect(find.byTooltip('حذف التلميذ'), findsOneWidget);
    final deleteRect = tester.getRect(find.byKey(const ValueKey('student-sheet-delete')));
    expect(deleteRect.top, greaterThanOrEqualTo(0));
    expect(deleteRect.bottom, lessThanOrEqualTo(844));
    // A valid grade must be saved to the underlying real student records.
    final course = records.subjects(classId).first;
    final term = records.periods.first['key'].toString();
    final current = records.score(id, course, term);
    await tester.ensureVisible(find.byKey(const ValueKey('student-sheet-grade-input')));
    await tester.pumpAndSettle();
    await tester.enterText(find.byKey(const ValueKey('student-sheet-grade-input')), '83');
    await tester.ensureVisible(find.byKey(const ValueKey('student-sheet-save-grade')));
    await tester.tap(find.byKey(const ValueKey('student-sheet-save-grade')));
    await tester.pumpAndSettle();
    expect(records.score(id, course, term), 83);
    expect(tester.takeException(), isNull);
    // Restore the fixture state in memory; the test uses an isolated temp file.
    records.setScore(id, course, term, current);
    await tester.ensureVisible(studentName);
    await tester.pumpAndSettle();
    expect(studentName.hitTestable(), findsOneWidget);
    await tester.tap(studentName);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.tap(find.byKey(const ValueKey('student-sheet-close')));
    await tester.pumpAndSettle();
    expect(find.text('كشف الدرجات'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('student sheet is visible over a nested Flutter app shell',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final folder = Directory.systemTemp.createTempSync('sajli-nested-test-');
    addTearDown(() => folder.deleteSync(recursive: true));
    final records = Records.decode(File('assets/demo.json').readAsStringSync());
    final classId = records.activeClasses.first['id'].toString();
    final id = records.students(classId).first['id'].toString();
    await tester.pumpWidget(flutter.MaterialApp(
      home: flutter.Scaffold(
        body: flutter.IndexedStack(index: 0, children: [
          SajliApp(records: records, file: File('${folder.path}/sajli.json')),
          const flutter.SizedBox.shrink(),
        ]),
      ),
    ));
    await tester.pumpAndSettle();
    final nameButton = find.byKey(ValueKey('student-name-$id'));
    await tester.ensureVisible(nameButton);
    await tester.pumpAndSettle();
    expect(nameButton.hitTestable(), findsOneWidget);
    await tester.tap(nameButton);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('student-sheet-name')), findsOneWidget);
    expect(find.byKey(const ValueKey('student-sheet-grade-input')), findsOneWidget);
    expect(find.text('حفظ الدرجة'), findsOneWidget);
    expect(find.byKey(const ValueKey('student-sheet-subject')), findsOneWidget);
    expect(find.byKey(const ValueKey('student-sheet-period')), findsOneWidget);
    final deleteButton = find.byKey(const ValueKey('student-sheet-delete'));
    expect(deleteButton, findsOneWidget);
    expect(tester.getRect(deleteButton).bottom, lessThanOrEqualTo(844));
    expect(tester.takeException(), isNull);
  });
}
