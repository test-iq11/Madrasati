import 'package:flutter/material.dart';

class WorkspaceCard extends Card {
  const WorkspaceCard({super.key,super.child,super.margin,super.color,super.shape,
    super.elevation,super.clipBehavior,super.surfaceTintColor,
    this.accent=const Color(0xff176d77)});
  final Color accent;

  @override
  Widget build(BuildContext context){
    final scheme=Theme.of(context).colorScheme;
    final base=color??scheme.surface;
    final outline=shape??RoundedRectangleBorder(borderRadius:BorderRadius.circular(22),
      side:BorderSide(color:Color.alphaBlend(accent.withValues(alpha:.12),scheme.outlineVariant)));
    return Padding(padding:margin??const EdgeInsets.symmetric(vertical:5,horizontal:2),
      child:Material(color:base,shape:outline,clipBehavior:clipBehavior??Clip.antiAlias,
        elevation:elevation??1,shadowColor:accent.withValues(alpha:.24),
        child:Ink(decoration:BoxDecoration(gradient:LinearGradient(
          begin:Alignment.topRight,end:Alignment.bottomLeft,
          colors:[Color.alphaBlend(accent.withValues(alpha:.075),base),base])),
          child:child)));
  }
}
