import 'package:flutter/material.dart';

/// Native counterpart of the HTML hero, with real data supplied by each module.
/// Uses layout primitives only, so it also works in Sajli's material_ui tree.
class UnifiedHero extends StatelessWidget {
  const UnifiedHero({super.key, required this.title, required this.description,
    required this.icon, required this.first, required this.last,
    this.school = 'مدرستي', this.chips = const [], this.actions = const [],
    this.art = true, this.minHeight = 221, this.radius = 25});
  final String title, description, school;
  final IconData icon;
  final Color first, last;
  final List<(IconData, String)> chips;
  final List<Widget> actions;
  final bool art;
  final double minHeight, radius;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, constraints) {
    final wide = constraints.maxWidth >= 650;
    final artSize = wide ? 128.0 : constraints.maxWidth <= 370 ? 68.0 : 85.0;
    return Container(
      constraints: BoxConstraints(minHeight: minHeight),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [last, first]),
        boxShadow: [BoxShadow(color: first.withValues(alpha: .17), blurRadius: 34,
          offset: const Offset(0, 14))]),
      child: Stack(children: [
        if (art) ...[
          for (final size in [300.0, 358.0, 420.0, 488.0])
            Positioned(left: 55-size/2, top: -5-size/2, child: Container(
              width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: .10))))),
          Positioned(right: -125, bottom: -140, child: Container(width: 245, height: 245,
            decoration: BoxDecoration(shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: .09)))),
        ],
        Padding(padding: EdgeInsets.fromLTRB(wide ? 29 : 19, wide ? 26 : 21,
          wide ? 29 : 19, wide ? 23 : 19), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min,
          children: [
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min, children: [
                _chip(Icons.auto_awesome_outlined, '$school • مساحة تعليمية مترابطة', pill: true),
                const SizedBox(height: 12),
                Text(title, style: TextStyle(color: Colors.white, fontSize: wide ? 34 : 25,
                  height: 1.35, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(description, style: TextStyle(color: Colors.white.withValues(alpha: .88),
                  fontSize: wide ? 13 : 11, height: 1.9)),
              ])),
              if (art) ...[
                const SizedBox(width: 12),
                Transform.rotate(angle: -.14, child: Container(width: artSize, height: artSize,
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .12),
                    borderRadius: BorderRadius.circular(wide ? 34 : 23),
                    border: Border.all(color: Colors.white.withValues(alpha: .24))),
                  child: Icon(icon, color: Colors.white, size: artSize * .51))),
              ],
            ]),
            if (chips.isNotEmpty) ...[const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 7, children: [for (final chip in chips) _chip(chip.$1, chip.$2)])],
            if (actions.isNotEmpty) ...[const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 6, children: actions)],
          ],
        )),
      ]),
    );
  });

  Widget _chip(IconData icon, String value, {bool pill = false}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .13),
      borderRadius: BorderRadius.circular(pill ? 99 : 11),
      border: Border.all(color: Colors.white.withValues(alpha: .24))),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 13, color: Colors.white), const SizedBox(width: 5),
      Flexible(child: Text(value, maxLines: 2, overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700))),
    ]));
}

/// Replaces Material's oval navigation indicator with the HTML rounded item.
class UnifiedNavigation extends StatelessWidget {
  const UnifiedNavigation({super.key, required this.items, required this.index,
    required this.onSelect, required this.accent, this.navigationKey});
  final List<(IconData, String)> items;
  final int index;
  final ValueChanged<int>? onSelect;
  final Color accent;
  final Key? navigationKey;
  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final surface = dark ? const Color(0xff131c26) : Colors.white;
    final ink = dark ? Color.lerp(accent, Colors.white, .48)! : accent;
    return SafeArea(top: false, minimum: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: Align(heightFactor: 1, child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 570),
        child: Container(key: navigationKey, padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(20),
            border: Border.all(color: dark ? const Color(0xff2b3b49) : const Color(0xffe5ebf2)),
            boxShadow: const [BoxShadow(color: Color(0x231a3956), blurRadius: 28, offset: Offset(0, 8))]),
          child: Row(children: [for (var i = 0; i < items.length; i++) Expanded(
            child: Semantics(button: true, selected: i == index,
              child: Material(color: i == index ? (dark ? const Color(0xff20313e) :
                Color.alphaBlend(accent.withValues(alpha: .10), Colors.white)) : surface,
                borderRadius: BorderRadius.circular(13), child: InkWell(
                  borderRadius: BorderRadius.circular(13),
                  onTap: onSelect == null ? null : () => onSelect!(i),
                  child: Padding(padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(items[i].$1, size: 20, color: i == index ? ink :
                        dark ? const Color(0xffa6b8c9) : const Color(0xff718298)),
                      const SizedBox(height: 2),
                      Text(items[i].$2, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                          color: i == index ? ink : dark ? const Color(0xffa6b8c9) : const Color(0xff718298))),
                    ])),
                ))),
          )]),
        ),
      )),
    );
  }
}
