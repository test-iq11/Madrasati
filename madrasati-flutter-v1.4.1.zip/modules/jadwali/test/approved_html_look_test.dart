import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/core/html_dashboard_hero.dart';

void main() {
  testWidgets('approved HTML banner has repair and timetable; settings and notifications live in the hero',
      (tester) async {
    var repaired = 0;
    var opened = 0;
    var settings = 0;
    var notifications = 0;
    tester.view.physicalSize = const Size(320, 740);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(
      theme: ThemeData(useMaterial3: true),
      home: Scaffold(body: SingleChildScrollView(
        child: HtmlDashboardHero(
          onRepair: () => repaired++,
          onTimetable: () => opened++,
          onSettings: () => settings++,
          onNotifications: () => notifications++,
        ),
      )),
    ));
    expect(find.byKey(const ValueKey('html-dashboard-hero')), findsOneWidget);
    final hero = find.byKey(const ValueKey('html-dashboard-hero'));
    for (final key in ['top-settings', 'top-notifications']) {
      final action = find.descendant(of: hero, matching: find.byKey(ValueKey(key)));
      expect(action, findsOneWidget);
      await tester.ensureVisible(action);
      await tester.tap(action);
      await tester.pump();
    }
    expect(settings, 1);
    expect(notifications, 1);
    await tester.ensureVisible(find.text('استكشف الإصلاح الذكي'));
    await tester.tap(find.text('استكشف الإصلاح الذكي'));
    await tester.pump();
    expect(repaired, 1);
    expect(find.byKey(const ValueKey('customize-school-card')), findsNothing);
    await tester.ensureVisible(find.text('فتح الجدول الدراسي'));
    await tester.tap(find.text('فتح الجدول الدراسي'));
    await tester.pump();
    expect(opened, 1);
    expect(tester.takeException(), isNull);
  });
}
