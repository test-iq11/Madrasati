import 'package:flutter/material.dart';

/// Thin, scalable line artwork for the school-statistics tiles.
/// The same painter is used for both the visible icon and its quiet watermark.
/// Material glyphs use fixed outlines, so changing IconTheme can't thin them.
class SchoolStatLineIcon extends StatelessWidget {
  const SchoolStatLineIcon({
    required this.label,
    this.size = 32,
    this.opacity = 1,
    this.lineWidth = 1.65,
    super.key,
  });

  final String label;
  final double size;
  final double opacity;
  /// Stroke width in a normalized 48x48 coordinate system.
  final double lineWidth;

  @override
  Widget build(BuildContext context) => SizedBox.square(
    dimension: size,
    child: CustomPaint(
      painter: _SchoolStatPainter(
        label: label,
        color: Colors.white.withValues(alpha: opacity),
        lineWidth: lineWidth,
      ),
    ),
  );
}

class _SchoolStatPainter extends CustomPainter {
  const _SchoolStatPainter({
    required this.label,
    required this.color,
    required this.lineWidth,
  });

  final String label;
  final Color color;
  final double lineWidth;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 48, size.height / 48);
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = lineWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true;
    void line(double x1, double y1, double x2, double y2) =>
        canvas.drawLine(Offset(x1, y1), Offset(x2, y2), p);
    void circle(double x, double y, double r) =>
        canvas.drawCircle(Offset(x, y), r, p);
    void path(List<Offset> points, {bool close = false}) {
      if (points.isEmpty) return;
      final shape = Path()..moveTo(points.first.dx, points.first.dy);
      for (final point in points.skip(1)) {
        shape.lineTo(point.dx, point.dy);
      }
      if (close) shape.close();
      canvas.drawPath(shape, p);
    }
    void people() {
      circle(19, 17, 5.2);
      circle(33.5, 18.5, 4.0);
      final first = Path()
        ..moveTo(8, 37)
        ..cubicTo(8, 27, 12, 25.5, 19, 25.5)
        ..cubicTo(26, 25.5, 30, 27, 30, 37);
      canvas.drawPath(first, p);
      final second = Path()
        ..moveTo(32.5, 27.5)
        ..cubicTo(39, 28, 41, 32, 41, 37);
      canvas.drawPath(second, p);
    }
    void calendar() {
      path([const Offset(10, 13), const Offset(38, 13),
        const Offset(38, 39), const Offset(10, 39)], close: true);
      line(10, 20, 38, 20);
      line(17, 9, 17, 17);
      line(31, 9, 31, 17);
      path([const Offset(18, 29), const Offset(22, 33), const Offset(31, 25)]);
    }
    switch (label) {
      case 'عدد التلاميذ':
        people();
      case 'الصفوف والشعب':
        path([const Offset(5, 20), const Offset(24, 11),
          const Offset(43, 20), const Offset(24, 29)], close: true);
        line(12, 24.5, 12, 33);
        final brim = Path()
          ..moveTo(12, 33)
          ..quadraticBezierTo(24, 42, 36, 33)
          ..lineTo(36, 24.5);
        canvas.drawPath(brim, p);
        line(43, 20, 43, 33);
        circle(43, 35, 2);
      case 'حاضر':
        circle(24, 24, 17);
        path([const Offset(15, 24), const Offset(21, 30), const Offset(34, 18)]);
      case 'غائب':
        circle(21, 16, 5.5);
        final person = Path()
          ..moveTo(8, 35)
          ..cubicTo(9, 25, 14, 24, 21, 24)
          ..cubicTo(27, 24, 31, 27, 33, 33);
        canvas.drawPath(person, p);
        line(9, 9, 40, 40);
      case 'متأخر':
        circle(24, 24, 17);
        line(24, 14, 24, 25);
        line(24, 25, 32, 30);
      case 'بعذر':
        path([const Offset(24, 6), const Offset(39, 12),
          const Offset(37, 30), const Offset(24, 41),
          const Offset(11, 30), const Offset(9, 12)], close: true);
        path([const Offset(16, 24), const Offset(22, 30), const Offset(33, 19)]);
      case 'غير مسجّل':
        calendar();
      default:
        circle(24, 24, 16);
        line(24, 15, 24, 26);
        circle(24, 33, 1.2);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _SchoolStatPainter old) =>
      old.label != label || old.color != color || old.lineWidth != lineWidth;
}
