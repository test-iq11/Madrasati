import 'package:flutter/material.dart';
import 'data.dart';

const editorBlue = Color(0xff2860aa);
Color editorTone(BuildContext c) => Theme.of(c).brightness == Brightness.dark ? const Color(0xffadc6ff) : editorBlue;
Color editorWash(BuildContext c) => Theme.of(c).brightness == Brightness.dark ? const Color(0xff304367) : const Color(0xffe6efff);

/// In the same RTL reading order as the final HTML reference.
const editorElementKinds = <(String,String,String)>[
 ('نص منسق','Aa','text'), ('قطعة','¶','text'), ('شعر','❝','text'),
 ('آية أو حديث','۞','text'), ('خيارات متعددة','☑','text'), ('صح أو خطأ','×/✓','text'),
 ('مطابقة','↔','text'), ('معادلة رياضية','∑','formula'), ('معادلة كيميائية','⚗','formula'),
 ('جدول','▦','table'), ('رسم','△','draw'), ('صورة','▧','image'),
 ('شبكة صور','▥','imageGrid'), ('فقرات بأعمدة','▤','text'), ('مساحة إجابة','⋯','text'),
 ('عنوان قسم','§','text'), ('فاصل صفحة','↵','pageBreak'), ('تعريف','≔','text'),
 ('مثال محلول','✓','text'), ('نموذج الإجابة','✔','text'),
];

Widget editorButton(BuildContext c,String label,IconData icon,VoidCallback? tap,{bool compact=false}) => OutlinedButton(
 key: ValueKey('editor-button-$label'), onPressed:tap,
 style:OutlinedButton.styleFrom(backgroundColor:editorWash(c),foregroundColor:editorTone(c),disabledBackgroundColor:editorWash(c),side:BorderSide(color:editorTone(c).withAlpha(28)),padding:EdgeInsets.symmetric(horizontal:compact?6:8,vertical:9),minimumSize:const Size(0,36),tapTargetSize:MaterialTapTargetSize.shrinkWrap,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12))),
 child:Row(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:16),const SizedBox(width:5),Flexible(child:Text(label,style:const TextStyle(fontSize:11.5),textAlign:TextAlign.center))]));

Widget editorCard(BuildContext c,Widget child,{bool question=false,bool nested=false})=>Container(
 margin:const EdgeInsets.only(bottom:12),decoration:BoxDecoration(color:question?editorTone(c):Colors.transparent,borderRadius:BorderRadius.circular(22)),padding:EdgeInsets.only(right:question?4:0),child:Container(padding:EdgeInsets.all(nested?10:15),
 decoration:BoxDecoration(color:nested?Theme.of(c).scaffoldBackgroundColor:Theme.of(c).cardColor,borderRadius:BorderRadius.circular(question?20:24),border:Border.all(color:Theme.of(c).dividerColor),boxShadow:const [BoxShadow(color:Color(0x090b1630),blurRadius:12,offset:Offset(0,4))]),
 child:child));

Future<T?> editorSheet<T>(BuildContext context,String title,Widget Function(BuildContext) body)=>showModalBottomSheet<T>(context:context,isScrollControlled:true,useSafeArea:true,backgroundColor:Theme.of(context).cardColor,shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(29))),clipBehavior:Clip.antiAlias,builder:(c)=>Padding(padding:EdgeInsets.only(bottom:MediaQuery.viewInsetsOf(c).bottom),child:ConstrainedBox(constraints:BoxConstraints(maxHeight:MediaQuery.sizeOf(c).height*.94),child:Column(mainAxisSize:MainAxisSize.min,children:[Padding(padding:const EdgeInsets.fromLTRB(19,18,19,12),child:Row(children:[Expanded(child:Text(title,style:TextStyle(fontSize:19,fontWeight:FontWeight.w700,color:accentForSheet(c)))),OutlinedButton(style:OutlinedButton.styleFrom(minimumSize:const Size(40,40),padding:EdgeInsets.zero,side:BorderSide(color:Theme.of(c).dividerColor),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(15))),onPressed:()=>Navigator.pop(c),child:const Icon(Icons.close,size:18))])),Flexible(child:SingleChildScrollView(padding:const EdgeInsets.fromLTRB(19,0,19,18),child:body(c)))]))));
Color accentForSheet(BuildContext c)=>Theme.of(c).brightness==Brightness.dark?const Color(0xffadc6ff):const Color(0xff465bb6);

Future<int?> showElementPicker(BuildContext c)=>editorSheet<int>(c,'إضافة عنصر إلى المحتوى',(sheet)=>GridView.builder(key:const ValueKey('element-picker-grid'),padding:EdgeInsets.zero,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:6,mainAxisSpacing:6,childAspectRatio:1.43),itemCount:editorElementKinds.length,itemBuilder:(ctx,i){final k=editorElementKinds[i];return Material(color:Theme.of(ctx).scaffoldBackgroundColor,borderRadius:BorderRadius.circular(13),child:InkWell(key:ValueKey('element-picker-$i'),borderRadius:BorderRadius.circular(13),onTap:()=>Navigator.pop(sheet,i),child:Container(padding:const EdgeInsets.all(4),decoration:BoxDecoration(border:Border.all(color:Theme.of(ctx).dividerColor),borderRadius:BorderRadius.circular(13)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Flexible(child:FittedBox(fit:BoxFit.scaleDown,child:Text(k.$2,style:TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:accentForSheet(ctx))))),const SizedBox(height:4),Flexible(child:Text(k.$1,textAlign:TextAlign.center,style:const TextStyle(fontSize:11),maxLines:2))]))));}));

class QuestionTextInput extends StatefulWidget {
 const QuestionTextInput({super.key,required this.q,required this.word,required this.onText,required this.onFormat});
 final Item q;final String word;final ValueChanged<String> onText;final void Function(String,dynamic) onFormat;
 @override State<QuestionTextInput> createState()=>_QuestionTextInputState();
}
class _QuestionTextInputState extends State<QuestionTextInput>{
 late final TextEditingController controller=TextEditingController(text:str(widget.q,'text'));
 @override void dispose(){controller.dispose();super.dispose();}
 void insert(String s){final t=controller.text,sel=controller.selection;final a=sel.isValid?sel.start:t.length,b=sel.isValid?sel.end:t.length;controller.value=TextEditingValue(text:t.replaceRange(a,b,s),selection:TextSelection.collapsed(offset:a+s.length));widget.onText(controller.text);}
 Future<void> diacritics()async{final s=await editorSheet<String>(context,'التشكيل',(c)=>Wrap(spacing:8,runSpacing:8,children:[for(final d in ['َ','ِ','ُ','ّ','ْ','ً','ٍ','ٌ'])OutlinedButton(onPressed:()=>Navigator.pop(c,d),child:Text('◌$d',style:const TextStyle(fontSize:25)))]));if(s!=null&&mounted)insert(s);}
 Widget chip(String label,VoidCallback tap,{bool selected=false})=>OutlinedButton(onPressed:tap,style:OutlinedButton.styleFrom(backgroundColor:selected?editorWash(context):Theme.of(context).cardColor,foregroundColor:selected?editorTone(context):Theme.of(context).colorScheme.onSurface,padding:const EdgeInsets.symmetric(horizontal:7,vertical:5),minimumSize:const Size(0,31),tapTargetSize:MaterialTapTargetSize.shrinkWrap,side:BorderSide(color:Theme.of(context).dividerColor),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(8))),child:Text(label,style:const TextStyle(fontSize:10.5)));
 @override Widget build(BuildContext c)=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:[chip('غامق',()=>widget.onFormat('bold',widget.q['bold']!=true),selected:widget.q['bold']==true),const SizedBox(width:4),chip('خط تحته',()=>widget.onFormat('underline',widget.q['underline']!=true),selected:widget.q['underline']==true),const SizedBox(width:4),chip('تشكيل',diacritics),const SizedBox(width:4),chip('فراغ',()=>insert(' ............ ')),const SizedBox(width:4),chip('عربي / English',()=>widget.onFormat('language',str(widget.q,'language')=='English'?'عربي':'English'),selected:str(widget.q,'language')=='English')])),const SizedBox(height:6),TextField(key:ValueKey('question-text-${widget.q['id']}'),controller:controller,onChanged:widget.onText,minLines:3,maxLines:9,textDirection:str(widget.q,'language')=='English'?TextDirection.ltr:TextDirection.rtl,style:TextStyle(fontWeight:widget.q['bold']==true?FontWeight.bold:FontWeight.normal,decoration:widget.q['underline']==true?TextDecoration.underline:TextDecoration.none,color:widget.q['ink'] is int?Color(widget.q['ink'] as int):null),decoration:InputDecoration(hintText:'اكتب نص ${widget.word} هنا...',alignLabelWithHint:true))]);
}

Future<T?> editorToolPage<T>(BuildContext c,Widget child)=>showModalBottomSheet<T>(context:c,isScrollControlled:true,useSafeArea:true,backgroundColor:Theme.of(c).cardColor,shape:const RoundedRectangleBorder(borderRadius:BorderRadius.vertical(top:Radius.circular(29))),clipBehavior:Clip.antiAlias,builder:(_)=>FractionallySizedBox(heightFactor:.94,child:child));
Widget scienceTiles(BuildContext c,List<String> titles,List<String> glyphs,ValueChanged<int> tap)=>GridView.builder(shrinkWrap:true,padding:EdgeInsets.zero,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:3,crossAxisSpacing:6,mainAxisSpacing:6,childAspectRatio:1.45),itemCount:titles.length,itemBuilder:(ctx,i)=>Material(color:Theme.of(c).scaffoldBackgroundColor,borderRadius:BorderRadius.circular(13),child:InkWell(onTap:()=>tap(i),borderRadius:BorderRadius.circular(13),child:Container(decoration:BoxDecoration(borderRadius:BorderRadius.circular(13),border:Border.all(color:Theme.of(c).dividerColor)),padding:const EdgeInsets.all(4),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Flexible(child:FittedBox(fit:BoxFit.scaleDown,child:Text(glyphs[i],style:TextStyle(color:accentForSheet(c),fontSize:23,fontWeight:FontWeight.bold)))),const SizedBox(height:4),Flexible(child:Text(titles[i],maxLines:2,textAlign:TextAlign.center,style:const TextStyle(fontSize:11)))])))));
