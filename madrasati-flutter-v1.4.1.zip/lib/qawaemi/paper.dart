import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'model.dart';

const mm=96/25.4;
Size paperSize(Map<String,String> v){final a3=v['size']=='A3', land=v['orientation']=='landscape';final w=(a3?277:190)*mm,h=(a3?400:277)*mm;return Size(land?h:w,land?w:h);}
const elementNames={'bism':'البسملة','logo':'شعار الجمهورية','director':'المديرية','schoolLabel':'إدارة مدرسة','school':'اسم المدرسة','exam':'عنوان الامتحان','year':'العام الدراسي','round':'الدور','grade':'الصف','subject':'المادة','date':'التاريخ','section':'الشعبة','teacher':'معلم المادة','principal':'مدير المدرسة','stat0':'المشتركون','stat1':'الممتحنون','stat2':'الناجحون','stat3':'الراسبون','stat4':'المكملون','stat5':'نسبة النجاح'};
class PaperLayout {
 final PaperPage page; final Size size; late final List<double> xs,ys; late final double bodyTop,rowHeight,footerTop,pad;
 late final Map<String,Rect> elements;
 PaperLayout(this.page):size=paperSize(page.v){
  final v=page.v;pad=setting(v,'pad',4,2,12)*mm;
  final weights=List<double>.generate(page.t.cols,(i)=>setting(v,'width|${page.t.id}|$i',page.t.weights[i],.3,12));final sum=weights.reduce((a,b)=>a+b);
  xs=[size.width-pad];for(final w in weights){xs.add(xs.last-(size.width-2*pad)*w/sum);}
  final hf=setting(v,'headingFont',11,7,18);final heights=List<double>.filled(page.t.h,math.max(20.0,hf*1.8));
  for(final cell in page.t.cells){if(cell.label.isEmpty)continue;final cw=xs[cell.x]-xs[cell.x+cell.span];final tp=TextPainter(text:TextSpan(text:ar(cell.label),style:TextStyle(fontSize:hf,fontWeight:FontWeight.bold)),textDirection:TextDirection.rtl)..layout(maxWidth:cell.dir.isEmpty?math.max(1.0,cw-4):double.infinity);final have=heights.skip(cell.y).take(cell.rs).fold<double>(0,(a,b)=>a+b);final need=(cell.dir.isEmpty?tp.height:tp.width)+8;tp.dispose();if(need>have)heights[cell.y+cell.rs-1]+=need-have;}
  final logo=setting(v,'logoSize',16,9,30)*mm;final col=(size.width-2*pad)/3;final line=math.max(18.0,setting(v,'headerFont',13,8,20)*1.6);final y=pad+26+logo+6;
  elements={'bism':Rect.fromLTWH(pad,pad,size.width-2*pad,24),'logo':Rect.fromCenter(center:Offset(size.width/2,pad+26+logo/2),width:logo,height:logo)};
  const groups=[['director','schoolLabel','school'],['exam','year','round'],['grade','subject','date','section']];for(var g=0;g<groups.length;g++){for(var i=0;i<groups[g].length;i++){if(groups[g][i]=='section'&&!page.blank&&page.field('section').isEmpty)continue;elements[groups[g][i]]=Rect.fromLTWH(size.width-pad-(g+1)*col,y+i*line,col,line);}}
  ys=[y+(page.blank||page.field('section').isNotEmpty?4:3)*line+8];for(final h in heights){ys.add(ys.last+h);}bodyTop=ys.last;
  footerTop=size.height-pad-64-(page.pages>1?16:0);rowHeight=math.max(1.0,(footerTop-8-bodyTop)/(page.end-page.start));
  final sw=(size.width-2*pad)/page.statistics.length;for(var i=0;i<page.statistics.length;i++){final id=i==page.statistics.length-1?'stat5':'stat$i';elements[id]=Rect.fromLTWH(size.width-pad-(i+1)*sw,footerTop,sw,22);}
  elements['teacher']=Rect.fromLTWH(size.width/2,footerTop+25,size.width/2-pad,23);elements['principal']=Rect.fromLTWH(pad,footerTop+25,size.width/2-pad,23);
 }
 Rect elementRect(String key){final r=elements[key]!;final parts=(positionValue(page.v,page.t.id,key)??'0,0').split(',');final dx=double.tryParse(parts.first)??0,dy=parts.length>1?double.tryParse(parts[1])??0:0;final w=r.width;final h=r.height; // normalized displacement, independent of paper orientation
 // Allow moving a centered single line horizontally, while keeping its anchor on the page.
 final moved=r.shift(Offset(dx*size.width,dy*size.height));final cx=moved.center.dx.clamp(pad/2,size.width-pad/2).toDouble();final cy=moved.center.dy.clamp(h/2,size.height-h/2).toDouble();return Rect.fromCenter(center:Offset(cx,cy),width:w,height:h);}
 Rect headerRect(Cell c)=>Rect.fromLTRB(xs[c.x+c.span],ys[c.y],xs[c.x],ys[c.y+c.rs]);
 Rect rowRect(int r,int c)=>Rect.fromLTRB(xs[c+1],bodyTop+(r-page.start)*rowHeight,xs[c],bodyTop+(r-page.start+1)*rowHeight);
 (int,int)? hit(Offset p){if(p.dy<bodyTop||p.dy>=bodyTop+(page.end-page.start)*rowHeight)return null;final r=page.start+((p.dy-bodyTop)/rowHeight).floor();for(int c=1;c<page.t.cols;c++){if(p.dx>=xs[c+1]&&p.dx<=xs[c])return (r,c);}return null;}
}
class PaperPainter extends CustomPainter {
 final PaperPage page;final ui.Image logo;final ui.Image? stamp;final String? selectedElement; final PaperLayout layout;
 PaperPainter(this.page,this.logo,{this.stamp,this.selectedElement}):layout=PaperLayout(page);
 Color get base=>Color(page.v['paperTheme']=='custom'?(int.tryParse(en(page.v['paperColor']??'#427d70').replaceFirst('#',''),radix:16)??0x427d70)|0xff000000:palette[page.v['paperTheme']]??palette['mono']!);
 bool active(String k)=>page.v['paperTheme']!='mono'&&page.v[k]=='on';
 double get strength=>setting(page.v,'colorStrength',18,5,40)/100;
 Color shade(double factor)=>Color.lerp(Colors.white,base,factor)!;
 // Fix the exported PDF alignment: tight paragraph width, not natural glyph width.
 void text(Canvas canvas,String s,Rect box,{double font=11,bool bold=false,TextAlign align=TextAlign.center,bool vertical=false,bool reverse=false,Color color=const Color(0xff111111)}){
  if(s.isEmpty||box.width<2||box.height<2)return;final width=vertical?box.height:box.width,height=vertical?box.width:box.height;var f=font;final available=math.max(1.0,width-3);
  TextPainter make()=>TextPainter(text:TextSpan(text:ar(s),style:TextStyle(color:color,fontSize:f,fontWeight:bold?FontWeight.bold:FontWeight.normal,height:1.10)),textDirection:TextDirection.rtl,textAlign:align)..layout(minWidth:available,maxWidth:available);
  var p=make();while(p.height>height-1&&f>5){p.dispose();f-=.5;p=make();}canvas.save();canvas.clipRect(box);if(vertical){canvas.translate(box.center.dx,box.center.dy);canvas.rotate(reverse?math.pi/2:-math.pi/2);canvas.translate(-width/2,-height/2);}else{canvas.translate(box.left,box.top);}p.paint(canvas,Offset(1.5,(height-p.height)/2));canvas.restore();p.dispose();
 }
 @override void paint(Canvas canvas,Size actual){final s=layout.size,v=page.v;canvas.save();canvas.scale(actual.width/s.width,actual.height/s.height);final p=layout.pad;final edge=active('colorFrame')?base:Colors.black;final grid=active('colorFrame')?shade(.83):const Color(0xff222222);final border=Paint()..color=grid..style=PaintingStyle.stroke..strokeWidth=setting(v,'lineWidth',.85,.3,3);canvas.drawRect(Offset.zero&s,Paint()..color=Colors.white);canvas.drawRect(Rect.fromLTWH(1,1,s.width-2,s.height-2),Paint()..color=edge..style=PaintingStyle.stroke..strokeWidth=setting(v,'frameWidth',2,.5,5));
  final hf=setting(v,'headerFont',13,8,20),ff=setting(v,'footerFont',12,7,18),cf=setting(v,'cellFont',11,7,18),tf=setting(v,'headingFont',11,7,18);
  void element(String key,String value,{double? font,TextAlign align=TextAlign.center}){if(layout.elements.containsKey(key))text(canvas,value,layout.elementRect(key),font:font??hf,bold:true,align:align);}
  element('bism','بسم الله الرحمن الرحيم',font:hf+4);canvas.drawImageRect(logo,Rect.fromLTWH(0,0,logo.width.toDouble(),logo.height.toDouble()),layout.elementRect('logo'),Paint()..filterQuality=FilterQuality.high);
  element('director',page.field('director'),align:TextAlign.right);element('schoolLabel','إدارة مدرسة',align:TextAlign.right);element('school',page.school,align:TextAlign.right);
  element('exam','قائمة امتحان ${page.field('exam')}');element('year','للعام الدراسي ${page.field('year')}');element('round','الدور (${page.field('round')})');element('grade','الصف / ${page.t.sourceGrade}',align:TextAlign.left);element('subject','المادة / ${page.t.sourceSubject}',align:TextAlign.left);element('date','التاريخ / ${page.dateText}',align:TextAlign.left);if(page.blank||page.field('section').isNotEmpty)element('section','الشعبة / ${page.blank?'........':page.field('section')}',align:TextAlign.left);
  for(final c in page.t.cells){final r=layout.headerRect(c);canvas.drawRect(r,Paint()..color=active('colorHead')?shade(strength):Colors.white);canvas.drawRect(r,border);text(canvas,c.label,r.deflate(1),font:tf,bold:true,vertical:c.dir.isNotEmpty,reverse:c.dir=='tbRl');}
  for(int i=page.start;i<page.end;i++){for(int j=0;j<page.t.cols;j++){final r=layout.rowRect(i,j);if(active('colorRows')&&i.isOdd)canvas.drawRect(r,Paint()..color=shade(strength*.48));canvas.drawRect(r,border);text(canvas,page.value(i,j),r.deflate(1),font:cf,align:j==0?TextAlign.center:v['bodyAlign']=='right'?TextAlign.right:TextAlign.center);}}
  final foot=layout.footerTop;if(active('colorFoot'))canvas.drawRect(Rect.fromLTWH(p,foot,s.width-2*p,48),Paint()..color=shade(strength*.55));for(int i=0;i<page.statistics.length;i++){element(i==page.statistics.length-1?'stat5':'stat$i',page.statistics[i],font:ff);}element('teacher','${page.t.general?'مرشد الصف':'معلم المادة'} / ${page.teacher}',font:ff);element('principal','مدير المدرسة / ${page.principal}',font:ff);
  if(page.pages>1)text(canvas,'صفحة ${ar(page.index+1)} من ${ar(page.pages)}',Rect.fromLTWH(p,foot+50,s.width-2*p,16),font:10);
  final opacity=setting(v,'waterOpacity',12,2,80)/100;final cy=v['waterPosition']=='bottom'?foot-65:s.height/2;final water=Rect.fromCenter(center:Offset(s.width/2,cy),width:s.width*.65,height:70);if((v['watermark']??'').isNotEmpty)text(canvas,v['watermark']!,water,font:32,bold:true,color:Colors.black.withAlpha((255*opacity).round()));if(stamp!=null){final image=stamp!;final target=Rect.fromCenter(center:Offset(s.width*.75,cy),width:90,height:90);canvas.drawImageRect(image,Rect.fromLTWH(0,0,image.width.toDouble(),image.height.toDouble()),target,Paint()..color=Colors.white.withAlpha((255*opacity).round()));}
  if(selectedElement!=null&&layout.elements.containsKey(selectedElement)){canvas.drawRect(layout.elementRect(selectedElement!),Paint()..color=const Color(0xff1b9d81)..style=PaintingStyle.stroke..strokeWidth=1.8);}
  canvas.restore();}
 @override bool shouldRepaint(covariant PaperPainter oldDelegate)=>true;
}

List<PaperPage> fittedPages(Template t,Map<String,String> v,Map<String,String> edits,{bool blank=false}) {
 final initial=makePages(t,v,edits,blank:blank);if(v['autoFit']!='on')return initial;final l=PaperLayout(initial.first);final available=l.footerTop-8-l.bodyTop;final minRow=setting(v,'rowMin',16,10,40);final cap=(available/minRow).floor().clamp(1,200).toInt();return makePages(t,v,edits,blank:blank,capacity:cap);
}
