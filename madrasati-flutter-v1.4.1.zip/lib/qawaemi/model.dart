import 'dart:math' as math;

String ar(Object? value) => (value ?? '').toString().replaceAllMapped(RegExp(r'[0-9]'), (m) => '٠١٢٣٤٥٦٧٨٩'[int.parse(m[0]!)]);
String en(String value) => value.replaceAllMapped(RegExp(r'[٠-٩]'), (m) => '٠١٢٣٤٥٦٧٨٩'.indexOf(m[0]!).toString());
const grades = ['الأول','الثاني','الثالث','الرابع','الخامس','السادس'];
const stats = ['المشتركون','الممتحنون','الناجحون','الراسبون','المكملون'];
const palette = {'inkSaver':0xff777777,'mono':0xff222222,'sage':0xff39775e,'blue':0xff386b9b,'lavender':0xff785c9b,'sand':0xffa07b35,'rose':0xffa95c70,'custom':0xff427d70};
const paletteNames = {'inkSaver':'اقتصادي للحبر','mono':'أبيض وأسود (رسمي)','sage':'أخضر هادئ','blue':'أزرق سماوي','lavender':'بنفسجي ناعم','sand':'ذهبي رملي','rose':'وردي هادئ','custom':'لون مخصص'};
String norm(String s) => const {'اول':'الأول','الاول':'الأول','سادس':'السادس','عربي':'اللغة العربية','الاسلامية':'التربية الإسلامية','اللغة الانكليزية':'اللغة الإنجليزية','رياضيات':'الرياضيات','علوم':'العلوم','اجتماعيات':'الاجتماعيات','تربية رياضية':'التربية الرياضية'}[s] ?? s;
class Cell {
  final String label, dir; final int x,y,span,rs;
  Cell(Map<String,dynamic> j):label=j['label'] as String,dir=j['dir'] as String,x=j['x'] as int,y=j['y'] as int,span=j['span'] as int,rs=j['rs'] as int;
}
class Template {
  final String grade,subject,sourceGrade,sourceSubject; final int cols,h,sourceRows; final List<Cell> cells;
  Template(Map<String,dynamic> j):grade=norm(j['g'] as String),subject=norm(j['m'] as String),sourceGrade=j['sourceG'] as String,sourceSubject=j['sourceM'] as String,cols=j['cols'] as int,h=j['h'] as int,sourceRows=j['sourceRows'] as int,cells=(j['cells'] as List).map((e)=>Cell(Map<String,dynamic>.from(e as Map))).toList();
  String get id => '$grade|$subject';
  bool get general => subject=='النتائج العامة';
  int get nameCol => cells.firstWhere((c)=>c.label.contains('اسم التلميذ')||c.label.contains('اسم الطالب'),orElse:()=>cells[math.min(2,cells.length-1)]).x;
  List<double> get weights => List<double>.generate(cols, (i) {
    final labels = cells
        .where((c) => i >= c.x && i < c.x + c.span && c.label.isNotEmpty)
        .map((c) => c.label)
        .toList();
    final last = labels.isEmpty ? '' : labels.last.replaceAll('ـ', '').trim();
    if (i == 0) return 0.57;
    if (i == nameCol) return cols > 11 ? 4.4 : 4.8;
    if (i == 1 && nameCol == 2) return 1.3;
    if (labels.join(' ').contains('ملاحظ')) return 2.65;
    if (RegExp(r'^(كتابة|كتابتا|كتابه)$').hasMatch(last)) return 2.25;
    return 1.0;
  });
}
Map<String,String> defaults() => {'grade':grades.first,'subject':'التربية الإسلامية','section':'','exam':'نصف السنة','date':DateTime.now().toIso8601String().substring(0,10),'year':'٢٠٢٦ / ٢٠٢٧','round':'الأول','school':'','director':'','teacher':'','principal':'','count':'٢٨','size':'A4','orientation':'portrait','names':'','paperTheme':'mono','paperColor':'#427d70','colorHead':'on','colorFrame':'on','colorRows':'off','colorFoot':'off','colorStrength':'18','pad':'4','logoSize':'16','headerFont':'13','headingFont':'11','cellFont':'11','footerFont':'12','lineWidth':'0.85','frameWidth':'2','rowMin':'16','autoFit':'on','bodyAlign':'center','watermark':'','waterOpacity':'12','waterPosition':'center',for(int i=0;i<5;i++)'st$i':''};
String listKey(Map<String,String> v)=>['grade','section','subject','exam','date','year','round'].map((k)=>v[k]??'').join('|');
String rosterKey(Map<String,String> v)=>'${v['year']}|${v['grade']}|${v['section']}';
String dayName(String d){final date=DateTime.tryParse(d);return date==null?'':const ['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'][date.weekday-1];}
class PaperPage {
  final Template t; final Map<String,String> v,edits; final bool blank; final int start,end,index,pages; final List<String> names;
  PaperPage(this.t,this.v,this.edits,this.blank,this.start,this.end,this.index,this.pages,this.names);
  String field(String k)=>blank&&(['section','date','teacher','names'].contains(k)||k.startsWith('st'))?'':v[k]??'';
  String cellKey(int row,int col)=>'${listKey(v)}|$row|$col';
  String value(int row,int col){if(col==0)return ar(row+1);if(blank)return '';final line=row<names.length?names[row]:'';final split=line.indexOf('|');final fallback=col==t.nameCol?(split<0?line:line.substring(split+1).trim()):col==t.nameCol-1&&split>=0?line.substring(0,split).trim():'';return ar(edits[cellKey(row,col)]??fallback);}
  String get dateText=>field('date').isEmpty?'.... / .... / ........':'${ar(field('date').replaceAll('-','/'))} ${dayName(field('date'))}';
  String get school=>field('school').isEmpty?'................':field('school');
  String get teacher=>field('teacher').isEmpty?'................':field('teacher');
  String get principal=>field('principal').isEmpty?'................':field('principal');
  String get gradeText=>t.sourceGrade+(field('section').isEmpty?'':' / ${field('section')}');
  List<String> get statistics {final result=<String>[];for(int i=0;i<stats.length;i++){if(i==4&&!t.general)continue;result.add('${stats[i]} / ${field('st$i').isEmpty?'.....':ar(field('st$i'))}');}final a=double.tryParse(en(field('st1'))),b=double.tryParse(en(field('st2')));result.add('نسبة النجاح / ${a!=null&&b!=null&&a>0?ar((100*b/a).toStringAsFixed(1))+'٪':'.....'}');return result;}
}
List<PaperPage> makePages(Template t,Map<String,String> v,Map<String,String> edits,{bool blank=false,int? capacity}){final names=blank?<String>[]:(v['names']??'').split('\n').map((s)=>s.trim()).where((s)=>s.isNotEmpty).toList();final count=(int.tryParse(en(v['count']??''))??28).clamp(1,200).toInt();final total=math.max(count,names.length);final cap=capacity??((v['orientation']=='landscape'?20:30)+(v['size']=='A3'?15:0));final pages=(total/cap).ceil();return List.generate(pages,(i)=>PaperPage(t,Map.of(v),Map.of(edits),blank,i*cap,math.min(total,(i+1)*cap),i,pages,names));}

// Layout overrides are keyed by template, not by the selected grade of a batch.
String positionKey(String element,{String? template})=>template==null?'pos|$element':'pos|$template|$element';
String? positionValue(Map<String,String> values,String template,String element)=>values[positionKey(element,template:template)]??values[positionKey(element)];
void setPosition(Map<String,String> values,String template,String element,String offset,{required bool all}){
 if(all){values.removeWhere((k,_)=>k.startsWith('pos|')&&k.endsWith('|$element'));values[positionKey(element)]=offset;}else{values[positionKey(element,template:template)]=offset;}
}
double setting(Map<String,String> v,String key,double fallback,double low,double high)=>(double.tryParse(en(v[key]??''))??fallback).clamp(low,high).toDouble();
