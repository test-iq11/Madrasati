import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
class PickedSchoolFile { const PickedSchoolFile(this.name,this.bytes,this.path); final String name; final Uint8List? bytes; final String? path; String? get extension=>name.contains('.')?name.split('.').last:null; }
class PickedSchoolFiles { const PickedSchoolFiles(this.files); final List<PickedSchoolFile> files; }
Future<PickedSchoolFiles?> pickLegacyFiles({required FileType type,List<String>? allowedExtensions,bool withData=false}) async { final f=await FilePicker.pickFile(type:type,allowedExtensions:allowedExtensions); if(f==null)return null; return PickedSchoolFiles([PickedSchoolFile(f.name,withData?await f.readAsBytes():null,f.path)]); }
