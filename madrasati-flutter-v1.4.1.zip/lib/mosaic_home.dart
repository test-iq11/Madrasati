import 'package:madrasati_cards/unified_visuals.dart';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:madrasati_cards/card_size.dart';

/// A native Flutter translation of the approved Madrasati HTML homepage.
/// All entry points are callbacks: no mock student or curriculum data is shown.
class MosaicEntry {
  const MosaicEntry({
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.onTap,
    this.section,
  });
  final String? section;
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
}

class MosaicHero extends StatelessWidget {
  const MosaicHero({
    required this.school,
    required this.accent,
    required this.rounded,
    required this.compact,
    required this.showDecoration,
    this.onExplore,
    this.lessons = '—',
    this.progress = '—',
    this.tasks = '—',
    super.key,
  });
  final String school;
  final Color accent;
  final double rounded;
  final bool compact, showDecoration;
  final VoidCallback? onExplore;
  final String lessons, progress, tasks;

  @override
  Widget build(BuildContext context) {
    return UnifiedHero(
      title: 'مدرستك، بنظام واحد',
      description: 'جدولك وحضور تلاميذك وتنبيهاتك وكتبك ومستنداتك، جميعها في تجربة عربية هادئة ومتناسقة.',
      icon: Icons.school_outlined, school: school,
      first: accent == const Color(0xff087c77) ? const Color(0xff066d71) : accent,
      last: const Color(0xff264b73), art: showDecoration,
      radius: rounded + 5, minHeight: compact ? 180 : 221,
      chips: [(Icons.calendar_today_outlined, 'حصص اليوم: $lessons'),
        (Icons.task_alt_outlined, 'مهام: $tasks'), (Icons.auto_awesome_outlined, '٦ أقسام مترابطة'),
        (Icons.donut_large_outlined, 'إنجاز المنهج: $progress')],
    );
  }

}

class MosaicHome extends StatelessWidget {
  const MosaicHome({
    required this.school,
    this.banner,
    this.center,
    required this.entries,
    required this.day,
    required this.accent,
    required this.compact,
    required this.rounded,
    required this.showDescriptions,
    required this.showDay,
    required this.showShortcuts,
    required this.showDecoration,
    required this.quickAttendance,
    required this.quickBell,
    required this.quickSettings,
    this.onSearch,
    this.onCenter,
    this.onStudent,
    this.onClassroom,
    this.onCurriculum,
    this.metrics,
    this.onAnalytics,
    this.onSchedule,
    super.key,
  });

  final Widget? banner, center, metrics;
  final String school;
  final List<MosaicEntry> entries;
  final Widget day;
  final Color accent;
  final bool compact;
  final double rounded;
  final bool showDescriptions, showDay, showShortcuts, showDecoration;
  final VoidCallback quickAttendance, quickBell, quickSettings;
  final VoidCallback? onSearch, onCenter, onStudent, onClassroom,
      onCurriculum, onAnalytics, onSchedule;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final muted = scheme.onSurfaceVariant;
    return LayoutBuilder(builder: (context, limits) {
      final outerPadding = limits.maxWidth >= 700 ? 27.0 : 15.0;
      final gridWidth = math.min(1030.0, limits.maxWidth - outerPadding * 2);
      const gap = 12.0;
      // Unified HTML: 158px cards and a 126px full-width last card.
      final tileHeight = compact ? 136.0 : 158.0;
      if (entries.length < 4) {
        return const Center(child: Text('الأقسام غير مكتملة'));
      }
      return ListView(
        key: const PageStorageKey('mosaic-home'),
        padding: EdgeInsets.fromLTRB(outerPadding, 15, outerPadding, 114),
        children: [
          Center(child: SizedBox(width: gridWidth,
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              banner ?? MosaicHero(school: school, accent: accent, rounded: rounded,
                compact: compact, showDecoration: showDecoration, onExplore: onCenter),
              const SizedBox(height: 14),
              _sectionTitle(context, Icons.grid_view_rounded, 'أقسام التطبيق',
                'ادخل لأي قسم واستخدم أدواته الكاملة',
                trailing: banner == null && onSearch != null ? IconButton(
                  key: const ValueKey('modern-global-search'), tooltip: 'البحث الشامل',
                  icon: const Icon(Icons.search_outlined), onPressed: onSearch) : null),
              const SizedBox(height: 13),
              // All six work sections have equal, full-size tiles.
              for (final row in [for(var i=0;i<entries.length;i+=2) [i,if(i+1<entries.length)i+1]]) ...[
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (final i in row) ...[
                    if (i != row.first) const SizedBox(width: gap),
                    Expanded(child: _tile(context, entries[i], tileHeight,
                        i, horizontal: row.length == 1)),
                  ],
                ]),
                const SizedBox(height: gap),
              ],
              if (showDay) ...[
                const SizedBox(height: 12),
                _sectionTitle(context, Icons.schedule_outlined, 'حصص اليوم',
                  'ترتيب واضح ليومك الدراسي',
                  trailing: TextButton(onPressed: onSchedule,
                    child: Text('الجدول الكامل', style: TextStyle(color: accent,
                      fontSize: 11, fontWeight: FontWeight.w900)))),
                const SizedBox(height: 12),
                day,
              ],
              if(metrics!=null)...[_sectionTitle(context,Icons.bar_chart_outlined,'نبض المدرسة','مؤشرات من سجلي المدرسي'),metrics!],
              if (showShortcuts) ...[
                const SizedBox(height: 23),
                _sectionTitle(context, Icons.bolt_rounded, 'اختصارات يومك', 'خطوات مباشرة للأعمال المتكررة'),
                const SizedBox(height: 11),
                Row(children: [
                  Expanded(child: _shortcut(context, 'تسجيل الحضور', Icons.fact_check_outlined,
                    const Color(0xffe9f7f1), const Color(0xff16866c), quickAttendance)),
                  const SizedBox(width: 9),
                  Expanded(child: _shortcut(context, 'ملف التلميذ', Icons.person_outline,
                    const Color(0xfff0e9fa), const Color(0xff815abd), onStudent)),
                  const SizedBox(width: 9),
                  Expanded(child: _shortcut(context, 'الجرس', Icons.notifications_outlined,
                    const Color(0xfffff0e2), const Color(0xffb9844b), quickBell)),
                ]),
              ],
              const SizedBox(height: 24),
              _sectionTitle(context, Icons.auto_awesome_rounded, 'مساحة أكثر ذكاءً',
                'أدوات تكمل يومك الدراسي'),
              const SizedBox(height: 12),
              Material(
                color: dark ? const Color(0xff204036) : const Color(0xffe9f8f2),
                borderRadius: BorderRadius.circular(22),
                child: InkWell(
                  key: const ValueKey('modern-teacher-center'),
                  onTap: onCenter,
                  borderRadius: BorderRadius.circular(22),
                  child: Padding(padding: const EdgeInsets.all(20), child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('مركز المعلم الذكي', style: TextStyle(fontSize: 10,
                        fontWeight: FontWeight.w900, color: dark ? const Color(0xff9de6bd) : const Color(0xff3d947d))),
                      const SizedBox(height: 8),
                      Text('كل تفاصيل يومك، في مكان واحد.',
                        style: TextStyle(fontSize: 16, color: dark ? Colors.white : const Color(0xff114d45),
                          fontWeight: FontWeight.w900, height: 1.6)),
                      const SizedBox(height: 8),
                      Text('مهامك، التلاميذ، والمواد الدراسية',
                        style: TextStyle(color: muted, fontSize: 10)),
                      const SizedBox(height: 9),
                      Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        decoration: BoxDecoration(color: const Color(0xff0c7861),
                          borderRadius: BorderRadius.circular(9)),
                        child: const Row(mainAxisSize: MainAxisSize.min, children: [
                          Text('فتح المركز', style: TextStyle(color: Colors.white,
                            fontSize: 10, fontWeight: FontWeight.w800)),
                          SizedBox(width: 5),
                          Icon(Icons.arrow_back_rounded, size: 13, color: Colors.white),
                        ])),
                    ])),
                    const SizedBox(width: 8),
                    Container(width: 81, height: 81, alignment: Alignment.center,
                      decoration: BoxDecoration(shape: BoxShape.circle,
                        color: dark ? const Color(0xff1b4337) : const Color(0xffdef6ea),
                        border: Border.all(color: const Color(0xff1aa685), width: 8)),
                      child: Icon(Icons.school_outlined,
                        color: dark ? const Color(0xff8bdec2) : const Color(0xff14725e), size: 30)),
                  ])),
                ),
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _spotlight(context, 'ملف التلميذ',
                  'درجاته وحضوره ومستمسكاته في صفحة واحدة',
                  Icons.person_outline, const Color(0xff7b55b9), onStudent)),
                const SizedBox(width: 9),
                Expanded(child: _spotlight(context, 'متابعة الصف',
                  'المؤشرات والتلاميذ والإجراءات اليومية',
                  Icons.groups_outlined, const Color(0xff137f75), onClassroom)),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _spotlight(context, 'إنجاز المنهج',
                  'راقب تقدم كل مادة ببساطة',
                  Icons.donut_large_rounded, const Color(0xff3676c1), onCurriculum)),
                const SizedBox(width: 9),
                Expanded(child: _spotlight(context, 'إحصاءات المدرسة',
                  'أرقام واضحة تساعدك على المتابعة',
                  Icons.bar_chart_rounded, const Color(0xffb77639), onAnalytics)),
              ]),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: onSearch,
                icon: const Icon(Icons.arrow_back_rounded, size: 17),
                label: const Text('اكتشف المزيد عبر البحث الشامل'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: accent,
                  minimumSize: const Size.fromHeight(46),
                  side: BorderSide(color: accent.withValues(alpha: .25)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
              ),
              if (center != null) ...[const SizedBox(height: 15), center!],
              const SizedBox(height: 17),
              Text('مدرستي · أدواتك المدرسية في مكان واحد',
                textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 10)),
            ]),
          )),
        ],
      );
    });
  }

  Widget _sectionTitle(BuildContext context, IconData icon, String title, String subtitle,
      {Widget? trailing}) {
    final scheme = Theme.of(context).colorScheme;
    return Row(children: [
      Container(width: 39, height: 39,
        decoration: BoxDecoration(color: const Color(0xffe8f5f0),
          border: Border.all(color: const Color(0xffd8ede5)),
          borderRadius: BorderRadius.circular(13)),
        child: Icon(icon, color: const Color(0xff087b62), size: 20)),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(fontSize: 18, color: scheme.onSurface,
          fontWeight: FontWeight.w900)),
        Text(subtitle, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 10)),
      ])),
      if (trailing != null) trailing,
    ]);
  }

  Widget _tile(BuildContext context, MosaicEntry entry, double height, int index,
      {bool horizontal = false}) {
    const gradients = [
      (Color(0xff176d77), Color(0xff4a9a92)),
      (Color(0xff665789), Color(0xff9788b1)),
      (Color(0xffb37563), Color(0xffd5a18a)),
      (Color(0xff326a9a), Color(0xff70a5bb)),
      (Color(0xff285c49), Color(0xff4b9474)),
      (Color(0xff514ba7), Color(0xff8a75ce)),
    ];
    final pair = gradients[index % gradients.length];
    final base = entry.color;
    final last = base == pair.$1 ? pair.$2 : Color.lerp(base, Colors.white, .28)!;
    final tile = Material(color: Colors.transparent,
      borderRadius: BorderRadius.circular(rounded + 3), clipBehavior: Clip.antiAlias,
      child: Ink(decoration: BoxDecoration(gradient: LinearGradient(
        begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [base, last])),
        child: InkWell(key: ValueKey('mosaic-${entry.title}'), onTap: entry.onTap,
          child: SizedBox(height: height, child: Stack(children: [
            if (showDecoration) for (final size in [150.0, 190.0, 240.0])
              Positioned(left: 30-size/2, top: 30-size/2, child: Container(width: size, height: size,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withValues(alpha: .12))))),
            Padding(padding: const EdgeInsets.all(15), child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Icon(entry.icon, size: 27, color: Colors.white),
                  const Icon(Icons.arrow_back, size: 17, color: Colors.white),
                ]),
                const Spacer(),
                Text(entry.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800, height: 1.25)),
                if (showDescriptions) ...[const SizedBox(height: 5), Text(entry.description,
                  maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xfff1f5f7), fontSize: 11, height: 1.5))],
              ],
            )),
          ])),
        )),
    );
    final shadowed = DecoratedBox(decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(rounded + 3),
      boxShadow: [BoxShadow(color: base.withValues(alpha: .13), blurRadius: 25, offset: const Offset(0, 15))]), child: tile);
    return entry.section == null || entry.section == 'qawaemi' || entry.section == 'asilati' ? shadowed : SectionCard('tile-${entry.section}', child: shadowed);
  }

  Widget _shortcut(BuildContext context, String title, IconData icon,
      Color light, Color foreground, VoidCallback? onTap) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18),
        child: Container(height: 108,
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 12),
          decoration: BoxDecoration(border: Border.all(color: scheme.outlineVariant.withValues(alpha: .60)),
            borderRadius: BorderRadius.circular(18)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(width: 40, height: 40,
              decoration: BoxDecoration(color: dark ? foreground.withValues(alpha: .22) : light,
                borderRadius: BorderRadius.circular(13)),
              child: Icon(icon, color: foreground, size: 22)),
            const SizedBox(height: 8),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: scheme.onSurface, fontSize: 10,
                fontWeight: FontWeight.w900)),
          ]),
        )),
    );
  }

  Widget _spotlight(BuildContext context, String title, String description,
      IconData icon, Color tone, VoidCallback? onTap) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(color: scheme.surface, borderRadius: BorderRadius.circular(20),
      child: InkWell(
        key: ValueKey('modern-spotlight-$title'),
        onTap: onTap, borderRadius: BorderRadius.circular(20),
        child: Container(
          constraints: const BoxConstraints(minHeight: 137),
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
            border: Border.all(color: scheme.outlineVariant.withValues(alpha: .7))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 39, height: 39,
              decoration: BoxDecoration(color: tone.withValues(alpha: dark ? .23 : .12),
                borderRadius: BorderRadius.circular(13)),
              child: Icon(icon, color: tone, size: 20)),
            const SizedBox(height: 8),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: scheme.onSurface,
                fontWeight: FontWeight.w900, fontSize: 12)),
            const SizedBox(height: 3),
            Text(description, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 10, height: 1.5)),
          ]),
        )),
    );
  }
}
