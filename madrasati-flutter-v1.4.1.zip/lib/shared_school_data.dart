import 'package:flutter/foundation.dart';
class SchoolSelection { const SchoolSelection({required this.school,required this.grade,required this.section,required this.subject,required this.year,required this.students}); final String school,grade,section,subject,year; final List<Map<String,String>> students; }
class SchoolExchange extends ValueNotifier<SchoolSelection?> { SchoolExchange():super(null); }
