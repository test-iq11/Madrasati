Arabic PDF font is fetched by tool/prepare_android.sh.
