#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/.."
mkdir -p assets/asilati/fonts
fetch() { local url="$1" name="$2"; if [[ ! -s "assets/asilati/fonts/$name" ]]; then curl -fL --retry 1 --max-time 20 "$url" -o "assets/asilati/fonts/$name.tmp" && mv "assets/asilati/fonts/$name.tmp" "assets/asilati/fonts/$name" || { rm -f "assets/asilati/fonts/$name.tmp"; echo "Optional font unavailable: $name; bundled Arabic fallback remains available."; }; fi; }
fetch 'https://raw.githubusercontent.com/notofonts/noto-fonts/main/hinted/ttf/NotoNaskhArabic/NotoNaskhArabic-Regular.ttf' NotoNaskhArabic-Regular.ttf
fetch 'https://raw.githubusercontent.com/notofonts/noto-fonts/main/LICENSE' OFL-Noto.txt
for spec in 'amiri/Amiri-Regular.ttf' 'cairo/Cairo-Regular.ttf' 'tajawal/Tajawal-Regular.ttf' 'almarai/Almarai-Regular.ttf' 'alexandria/Alexandria-Regular.ttf' 'notosansarabic/NotoSansArabic-Regular.ttf'; do
  fetch "https://raw.githubusercontent.com/google/fonts/main/ofl/$spec" "${spec##*/}"
done
