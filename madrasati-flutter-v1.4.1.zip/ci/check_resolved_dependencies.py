"""Validate the actual lockfile after pub get, never the inherited input lock."""
from pathlib import Path
import re
lock = Path('pubspec.lock').read_text()
for package in ('xml', 'flutter_math_fork', 'flutter_svg', 'vector_graphics_compiler'):
    match = re.search(r'^  '+package+r':\n(?:(?:    .*|)\n)*?    version: "([^"\n]+)"', lock, re.M)
    assert match, f'Not resolved: {package}'
    version = match.group(1)
    print(f'{package}: {version}')
    if package == 'xml':
        parts = tuple(map(int, version.split('.')))
        assert (6, 6, 1) <= parts <= (7, 0, 1), version
