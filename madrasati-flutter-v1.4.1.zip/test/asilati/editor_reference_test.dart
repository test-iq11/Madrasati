import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/asilati/data.dart';
import 'package:madrasati/asilati/editor_widgets.dart';
import 'package:madrasati/asilati/exams.dart';
import 'package:madrasati/asilati/ui.dart';
import 'package:madrasati/asilati/pdf_service.dart';

void main(){
 const expected=['نص منسق','قطعة','شعر','آية أو حديث','خيارات متعددة','صح أو خطأ','مطابقة','معادلة رياضية','معادلة كيميائية','جدول','رسم','صورة','شبكة صور','فقرات بأعمدة','مساحة إجابة','عنوان قسم','فاصل صفحة','تعريف','مثال محلول','نموذج الإجابة'];
 test('HTML reference element order has 20 unique destinations',(){expect(editorElementKinds.map((e)=>e.$1).toList(),expected);expect(expected.toSet(),hasLength(20));});
 test('marks and required alternatives',(){final q=question();q['children']=[question()..['mark']=7,question()..['mark']=8,question()..['mark']=12];q['required']=2;expect(questionMark(q),15);expect(examMark(exam()..['required']=1,[q,question()]),15);q['layout']='متسلسلة داخل السطر';expect(canInlineChildren(q,items(q['children'])),isTrue);});
 for(final size in [const Size(320,640),const Size(360,760),const Size(412,850)]){
 testWidgets('reference picker grid and editor controls at $size',(tester)async{
  tester.view.devicePixelRatio=1;tester.view.physicalSize=size;
  addTearDown(tester.view.resetPhysicalSize);addTearDown(tester.view.resetDevicePixelRatio);
  final store=Store(File('${Directory.systemTemp.path}/muallim-reference-${size.width}.json'));
  final doc=exam();final q=items(doc['questions']).first;q['mark']=20;doc['questions']=[q];
  await tester.pumpWidget(MaterialApp(locale:const Locale('ar'),supportedLocales:const [Locale('ar'),Locale('en')],localizationsDelegates:GlobalMaterialLocalizations.delegates,theme:appTheme(false),home:ExamEditor(store,doc)));
  await tester.pumpAndSettle();expect(tester.takeException(),isNull);
  expect(find.byType(NavigationBar),findsOneWidget);expect(find.text('مجموع الدرجات المحسوبة'),findsOneWidget);
  expect(find.text('سؤال 1'),findsOneWidget);expect(find.text('20 د'),findsOneWidget);expect(find.byKey(ValueKey('${q['id']}:quick-mark:0')),findsOneWidget);expect(find.text('إضافة نقطة'),findsOneWidget);
  final openPicker=find.byKey(const ValueKey('editor-button-إضافة عنصر'));
  await tester.ensureVisible(openPicker);await tester.pumpAndSettle();await tester.tap(openPicker);await tester.pumpAndSettle();
  final grid=find.byKey(const ValueKey('element-picker-grid'));expect(grid,findsOneWidget);
  final delegate=tester.widget<GridView>(grid).gridDelegate as SliverGridDelegateWithFixedCrossAxisCount;expect(delegate.crossAxisCount,3);
  expect(find.byKey(const ValueKey('element-picker-0')),findsOneWidget);expect(find.byKey(const ValueKey('element-picker-19')),findsOneWidget);
  for(int i=0;i<expected.length;i++)expect(find.descendant(of:grid,matching:find.text(expected[i])),findsOneWidget);
  expect(tester.takeException(),isNull);
  await tester.ensureVisible(find.byKey(const ValueKey('element-picker-0')));await tester.tap(find.byKey(const ValueKey('element-picker-0')));await tester.pumpAndSettle();
  expect(find.text('نص منسق'),findsOneWidget);expect(find.text('نوع العنصر'),findsNothing);
  await tester.enterText(find.widgetWithText(TextFormField,'المحتوى'),'نص تجريبي');FocusManager.instance.primaryFocus?.unfocus();await tester.pumpAndSettle();
  final insert=find.text('حفظ وإدراج');await tester.ensureVisible(insert);await tester.tap(insert);await tester.pumpAndSettle();
  expect(find.text('نص تجريبي'),findsOneWidget);expect(tester.takeException(),isNull);
 });
 }
}
