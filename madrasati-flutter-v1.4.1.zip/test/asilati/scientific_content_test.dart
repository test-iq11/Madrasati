import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/asilati/data.dart';
import 'package:madrasati/asilati/exams.dart';
import 'package:madrasati/asilati/science_patterns.dart';
import 'package:madrasati/asilati/science_drawing.dart';
import 'package:madrasati/asilati/content_elements.dart';
import 'package:madrasati/asilati/pdf_service.dart';
import 'package:madrasati/asilati/word_service.dart';
void main(){TestWidgetsFlutterBinding.ensureInitialized();
 test('all preview shape types and structured patterns',(){expect(shapeNames,hasLength(14));expect(patternNames,hasLength(12));expect(contentKinds,hasLength(13));expect(pattern(0,['x','y']),r'\frac{x}{y}');expect(pattern(2,['3','x']),r'\sqrt[3]{x}');});
 test('answer-only content and correct answers stay out of student output',(){final b={'kind':'خيارات متعددة','text':'اختر','options':'أ\nب','correct':'2'};expect(elementText(b),isNot(contains('الإجابة:')));expect(elementText(b,answers:true),contains('الإجابة: 2'));expect(elementText({'kind':'نموذج الإجابة','text':'حل'}),isEmpty);});
 test('print options affect labels, paper dimensions and signatures',(){final e=exam()..addAll({'size':'Letter','fontSize':15.0,'signaturePosition':'الوسط','digitStyle':'إنجليزية 123','partNumber':'A, B, C'});expect(examFontSize(e),15);expect(outputLabel(e,question(),0,1),'A /');expect(outputLabel(e,question(),1,0),contains('2'));expect(examWord(e),isNotEmpty);});
 test('recovered models retain structured equations and choices',()async{final t=await loadTemplates();int images=0,choices=0;void visit(Item q){for(final b in items(q['elements'])){for(final r in items(b['runs'])){if(str(r,'image').isNotEmpty)images++;}if(str(b,'kind')=='خيارات متعددة')choices++;}for(final c in items(q['children']))visit(c);}for(final e in t)for(final q in items(e['questions']))visit(q);expect(images,greaterThan(60));expect(choices,10);});
}
