import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/asilati/data.dart';
void main(){
 test('Arabic and Persian digits are accepted',(){expect(score('٨٥'),85);expect(score('۹۰'),90);});
 test('invalid nested question marks are rejected',(){final d=Store.empty();final e=exam();(e['questions'] as List).first['mark']='bad';d['exams']=[e];expect(()=>Store.validate(d),throwsFormatException);});
 test('ragged tables are rejected',(){final d=Store.empty();d['elements']=[{'id':'table1','type':'table','rows':[['a','b'],['c']]}];expect(()=>Store.validate(d),throwsFormatException);});
 test('valid exam and schedule backup round trip',(){final d=Store.empty();d['exams']=[exam()];d['schedule']=[{'id':'0:1','day':0,'period':1}];expect(Store.validate(d)['exams'],hasLength(1));});
 test('monthly mean and grade boundaries',(){expect(average(80,90),85);expect(score('120'),100);expect(score('-5'),0);});
 test('exam and questions are independent',(){final a=exam(),b=exam();expect(a['id'],isNot(b['id']));expect(items(a['questions']).length,1);});
 test('backup schema rejects invalid versions',(){expect(()=>Store.validate({'version':2}),throwsFormatException);expect(Store.validate(Store.empty())['version'],1);});
 test('save, replace and remove persistent records',()async{final dir=await Directory.systemTemp.createTemp();try{final s=Store(File('${dir.path}/test.json'));final e=exam();await s.put('exams',e);expect(await s.file.exists(),isTrue);e['title']='عنوان جديد';await s.put('exams',e);expect(s.list('exams').length,1);expect(s.list('exams').first['title'],'عنوان جديد');await s.remove('exams',e['id'] as String);expect(s.list('exams'),isEmpty);}finally{await dir.delete(recursive:true);}});
}
