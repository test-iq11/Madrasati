import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/mosaic_home.dart';

void main() {
  testWidgets('mosaic provides six real tappable entry cards', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final opened = <String>[];
    final entries = [
      for (final title in ['جدولي', 'سجلّي', 'جرس المعلم', 'المناهج','قوائمي','أسئلتي'])
        MosaicEntry(
          title: title,
          section: title,
          description: 'وصف $title',
          icon: Icons.school_outlined,
          color: const Color(0xff276b59),
          onTap: () => opened.add(title),
        ),
    ];
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: MosaicHome(
          school: 'مدرستي',
          entries: entries,
          day: const Text('جدول اليوم التجريبي'),
          accent: const Color(0xff276b59),
          compact: false,
          rounded: 20,
          showDescriptions: true,
          showDay: false,
          showShortcuts: false,
          showDecoration: true,
          quickAttendance: () {},
          quickBell: () {},
          quickSettings: () {},
        ),
      ),
    ));
    await tester.pumpAndSettle();
    expect(find.text('أقسام التطبيق'), findsOneWidget);
    expect(find.text('جدولي'), findsOneWidget);
    expect(find.text('سجلّي'), findsOneWidget);
    expect(find.text('جرس المعلم'), findsOneWidget);
    final sizeSchedule = tester.getSize(find.byKey(const ValueKey('mosaic-جدولي')));
    final sizeRecords = tester.getSize(find.byKey(const ValueKey('mosaic-سجلّي')));
    final sizeBell = tester.getSize(find.byKey(const ValueKey('mosaic-جرس المعلم')));
    final sizeBooks = tester.getSize(find.byKey(const ValueKey('mosaic-المناهج')));
    expect(sizeSchedule, sizeRecords);
    expect(sizeRecords, sizeBell);
    expect(sizeBell, sizeBooks);
    expect(sizeSchedule.height, 158); // Approved mobile HTML tile height.
    await tester.tap(find.text('سجلّي'));
    expect(opened, ['سجلّي']);
    final questions=find.byKey(const ValueKey('mosaic-أسئلتي'));
    await tester.dragUntilVisible(questions,find.byType(ListView),const Offset(0,-180),maxIteration:20);
    await tester.pumpAndSettle();
    expect(questions.hitTestable(),findsOneWidget);
    await tester.tap(questions);
    expect(opened,['سجلّي','أسئلتي']);
    expect(tester.takeException(), isNull);
  });
}
