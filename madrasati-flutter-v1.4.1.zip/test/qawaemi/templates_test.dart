import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/qawaemi/model.dart';
import 'package:madrasati/qawaemi/paper.dart';
import 'package:madrasati/qawaemi/exports.dart';
import 'package:archive/archive.dart';
import 'package:image/image.dart' as img;

void main(){TestWidgetsFlutterBinding.ensureInitialized();final raw=jsonDecode(File('assets/qawaemi/templates.json').readAsStringSync()) as List;final templates=raw.map((e)=>Template(Map<String,dynamic>.from(e as Map))).toList();
 test('all 51 source templates, merged headers and vertical labels preserved',(){expect(templates.length,51);expect(templates.map((t)=>t.id).toSet().length,51);expect(templates.expand((t)=>t.cells).where((c)=>c.dir.isNotEmpty&&c.label.isNotEmpty).length,235);for(final t in templates){final occupied=<String>{};for(final c in t.cells){for(int y=c.y;y<c.y+c.rs;y++){for(int x=c.x;x<c.x+c.span;x++){expect(occupied.add('$x,$y'),true,reason:t.id);}}}expect(occupied.length,t.cols*t.h);}});
 test('column widths are positive doubles for all original templates',(){for(final t in templates){final w=t.weights;expect(w.length,t.cols,reason:t.id);expect(w.first,0.57);expect(w[t.nameCol],t.cols>11?4.4:4.8);expect(w.every((x)=>x.isFinite&&x>0),true,reason:t.id);}});
 test('single list updates metadata, uses Arabic digits and names',(){final v=defaults()..addAll({'date':'2027-01-20','section':'أ','year':'٢٠٢٦ / ٢٠٢٧','names':'اسم تجريبي','teacher':'معلم','principal':'مدير','st1':'١٠','st2':'٨'});final q=makePages(templates.first,v,{}).first;expect(q.dateText,contains('٢٠٢٧/٠١/٢٠'));expect(q.value(0,q.t.nameCol),'اسم تجريبي');expect(q.value(0,0),'١');expect(q.statistics.last,contains('٨٠.٠'));expect(q.principal,'مدير');});
 test('all templates in batch blank except shared metadata',(){final v=defaults()..addAll({'names':'اسم تجريبي','section':'أ','teacher':'معلم','school':'مدرسة','principal':'مدير','st0':'١٢'});final pages=templates.expand((t)=>makePages(t,v,{},blank:true)).toList();expect(pages.length,51);for(final q in pages){expect(q.field('section'),'');expect(q.field('date'),'');expect(q.value(0,q.t.nameCol),'');expect(q.field('teacher'),'');expect(q.field('st0'),'');expect(q.principal,'مدير');expect(q.school,'مدرسة');}});
 test('pagination preserves rows, layout fits within paper',(){for(final size in ['A4','A3']){for(final orientation in ['portrait','landscape']){final v=defaults()..addAll({'size':size,'orientation':orientation,'count':'٦٧'});for(final t in templates){final pages=makePages(t,v,{});expect(pages.first.start,0);expect(pages.last.end,67);for(final q in pages){final l=PaperLayout(q);expect(l.rowHeight,greaterThan(1));expect(l.bodyTop+(q.end-q.start)*l.rowHeight,lessThan(l.footerTop));}}}}});
 test('Office files are actual OpenXML ZIP packages',(){final q=makePages(templates.first,defaults(),{});final doc=ZipDecoder().decodeBytes(makeDocx(q));final xls=ZipDecoder().decodeBytes(makeXlsx(q));expect(doc.files.any((f)=>f.name=='word/document.xml'),true);expect(xls.files.any((f)=>f.name=='xl/worksheets/sheet1.xml'),true);});
 test('independent current-template and global positions',(){final v=defaults();final a=templates.first.id,b=templates.last.id;setPosition(v,a,'grade','0.05,0.02',all:false);expect(positionValue(v,a,'grade'),'0.05,0.02');expect(positionValue(v,b,'grade'),isNull);expect(positionValue(v,a,'subject'),isNull);setPosition(v,a,'grade','0.01,0.03',all:true);expect(positionValue(v,a,'grade'),'0.01,0.03');expect(positionValue(v,b,'grade'),'0.01,0.03');setPosition(v,a,'grade','0.02,0.04',all:false);expect(positionValue(v,b,'grade'),'0.01,0.03');});
 test('centered header and independent element rectangles',(){final v=defaults();final t=templates.first;final base=PaperLayout(makePages(t,v,{}).first);expect(base.elementRect('bism').center.dx,closeTo(base.size.width/2,.001));expect(base.elementRect('logo').center.dx,closeTo(base.size.width/2,.001));setPosition(v,t.id,'grade','0.01,0.01',all:false);final moved=PaperLayout(makePages(t,v,{}).first);expect(moved.elementRect('subject'),base.elementRect('subject'));expect(moved.elementRect('grade').center.dy,closeTo(base.elementRect('grade').center.dy+base.size.height*.01,.001));});
 test('roster registration numbers and names stay in separate cells',(){final t=templates.first;final v=defaults()..['names']='١٢٣ | اسم تجريبي';final q=makePages(t,v,{}).first;expect(q.value(0,t.nameCol),'اسم تجريبي');expect(q.value(0,t.nameCol-1),'١٢٣');});
 test('PNG decoder reads bundled logo and launcher icon', () {
   for (final path in ['assets/qawaemi/logo.png', 'assets/qawaemi/app_icon.png']) {
     final decoded = img.decodePng(File(path).readAsBytesSync());
     expect(decoded, isNotNull, reason: path);
     expect(decoded!.width, greaterThan(0));
   }
 });
}
