import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/qawaemi/main.dart' as app;

void main(){
 testWidgets('searchable choice sheet selects and returns chosen value',(tester) async {
  String value='الرياضيات';
  await tester.pumpWidget(MaterialApp(home:Scaffold(body:StatefulBuilder(builder:(context,change)=>app.choiceField<String>(context,'المادة',['الرياضيات','العلوم','اللغة العربية'],value,(x)=>change(()=>value=x))))));
  await tester.tap(find.text('الرياضيات'));
  await tester.pumpAndSettle();
  expect(find.text('اختر المادة'),findsOneWidget);
  await tester.enterText(find.byType(TextField),'العربية');
  await tester.pumpAndSettle();
  expect(find.text('اللغة العربية'),findsOneWidget);
  expect(find.text('العلوم'),findsNothing);
  await tester.tap(find.text('اللغة العربية'));
  await tester.pumpAndSettle();
  expect(value,'اللغة العربية');
 });
}
