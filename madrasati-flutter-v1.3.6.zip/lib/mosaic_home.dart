import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:madrasati_cards/card_size.dart';

/// A native Flutter translation of the approved Madrasati HTML homepage.
/// All entry points are callbacks: no mock student or curriculum data is shown.
class MosaicEntry {
  const MosaicEntry({
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.onTap,
    this.section,
  });
  final String? section;
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
}

class MosaicHero extends StatelessWidget {
  const MosaicHero({
    required this.school,
    required this.accent,
    required this.rounded,
    required this.compact,
    required this.showDecoration,
    this.onExplore,
    this.lessons = '—',
    this.progress = '—',
    this.tasks = '—',
    super.key,
  });
  final String school;
  final Color accent;
  final double rounded;
  final bool compact, showDecoration;
  final VoidCallback? onExplore;
  final String lessons, progress, tasks;

  @override
  Widget build(BuildContext context) {
    final minHeight = compact ? 170.0 : 205.0;
    return ClipRRect(
      borderRadius: BorderRadius.circular(rounded + 9),
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: AlignmentDirectional.topStart,
            end: AlignmentDirectional.bottomEnd,
            colors: [
              Color.lerp(accent, const Color(0xff052c36), .63)!,
              accent,
              Color.lerp(accent, const Color(0xff08b38c), .28)!,
            ],
          ),
          boxShadow: [BoxShadow(color: accent.withValues(alpha: .20), blurRadius: 28, offset: const Offset(0, 11))],
        ),
        child: Stack(children: [
          if (showDecoration) ...[
            PositionedDirectional(
              top: -150, end: -90,
              child: Container(width: 295, height: 295,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withValues(alpha: .09), width: 1.5)),
              ),
            ),
            PositionedDirectional(
              top: -110, end: -50,
              child: Container(width: 213, height: 213,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withValues(alpha: .09), width: 24)),
              ),
            ),
            PositionedDirectional(
              bottom: 30, start: -90,
              child: Container(width: 184, height: 184,
                decoration: BoxDecoration(shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: .055)),
              ),
            ),
          ],
          Column(mainAxisSize: MainAxisSize.min, children: [
            ConstrainedBox(
              constraints: BoxConstraints(minHeight: minHeight),
              child: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(compact ? 16 : 20, 23, 12, 18),
                child: Row(children: [
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      DecoratedBox(
                        decoration: BoxDecoration(color: Colors.white.withValues(alpha: .13),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: Colors.white.withValues(alpha: .19))),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(Icons.circle, size: 7, color: Color(0xff80f8ba)),
                            SizedBox(width: 5),
                            Flexible(child: Text('منصتك المدرسية في مكان واحد',
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w800))),
                          ]),
                        ),
                      ),
                      const SizedBox(height: 11),
                      Text(school, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: Colors.white, fontSize: compact ? 31 : 36,
                          fontWeight: FontWeight.w900, height: 1.35)),
                      const SizedBox(height: 3),
                      if (!compact) const Text('يوم دراسي أهدأ، وتنظيم أذكى.\nكل أدواتك بلمسة واحدة.',
                        style: TextStyle(color: Color(0xffdef7ed), fontSize: 11, height: 1.65)),
                      const SizedBox(height: 13),
                      Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(11),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(11),
                          onTap: onExplore,
                          child: const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              Text('استكشف مركز المعلم', style: TextStyle(
                                fontSize: 10, color: Color(0xff076b59), fontWeight: FontWeight.w900)),
                              SizedBox(width: 6), Icon(Icons.arrow_back_rounded, color: Color(0xff076b59), size: 15),
                            ]),
                          ),
                        ),
                      ),
                    ],
                  )),
                  if (showDecoration) ...[
                    const SizedBox(width: 6),
                    SizedBox(width: 104, height: 140,
                      child: Stack(alignment: Alignment.center, children: [
                        Container(width: 104, height: 104,
                          decoration: BoxDecoration(shape: BoxShape.circle,
                            color: Colors.white.withValues(alpha: .085),
                            border: Border.all(color: Colors.white.withValues(alpha: .18)))),
                        Transform.rotate(angle: -.10, child: Container(
                          height: 76, width: 80,
                          decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: Colors.white.withValues(alpha: .26), width: 1.3)),
                          child: const Icon(Icons.school_rounded, color: Colors.white, size: 49))),
                        const Positioned(top: 9, right: 8,
                          child: Icon(Icons.auto_awesome_rounded, color: Color(0xffbeffe9), size: 23)),
                        const Positioned(bottom: 8, left: 8,
                          child: Icon(Icons.check_circle_rounded, color: Color(0xffd3fff0), size: 19)),
                      ]),
                    ),
                  ],
                ]),
              ),
            ),
            Container(
              height: 47,
              decoration: BoxDecoration(
                color: const Color(0xff043f42).withValues(alpha: .22),
                border: Border(top: BorderSide(color: Colors.white.withValues(alpha: .13)))),
              child: Row(children: [
                Expanded(child: _heroStat(Icons.calendar_today_outlined, 'حصص اليوم', lessons)),
                Container(width: 1, height: 18, color: Colors.white.withValues(alpha: .18)),
                Expanded(child: _heroStat(Icons.donut_large_rounded, 'إنجاز المنهج', progress)),
                Container(width: 1, height: 18, color: Colors.white.withValues(alpha: .18)),
                Expanded(child: _heroStat(Icons.task_alt_rounded, 'مهام', tasks)),
              ]),
            ),
          ]),
        ]),
      ),
    );
  }

  Widget _heroStat(IconData icon, String title, String value) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: const Color(0xffd8fff3), size: 12),
      const SizedBox(width: 3),
      Flexible(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Color(0xffd8fff3), fontSize: 8))),
      const SizedBox(width: 4),
      Text(value, maxLines: 1, style: const TextStyle(color: Colors.white,
        fontWeight: FontWeight.w900, fontSize: 10)),
    ]),
  );
}

class MosaicHome extends StatelessWidget {
  const MosaicHome({
    required this.school,
    this.banner,
    this.center,
    required this.entries,
    required this.day,
    required this.accent,
    required this.compact,
    required this.rounded,
    required this.showDescriptions,
    required this.showDay,
    required this.showShortcuts,
    required this.showDecoration,
    required this.quickAttendance,
    required this.quickBell,
    required this.quickSettings,
    this.onSearch,
    this.onCenter,
    this.onStudent,
    this.onClassroom,
    this.onCurriculum,
    this.onAnalytics,
    this.onSchedule,
    super.key,
  });

  final Widget? banner, center;
  final String school;
  final List<MosaicEntry> entries;
  final Widget day;
  final Color accent;
  final bool compact;
  final double rounded;
  final bool showDescriptions, showDay, showShortcuts, showDecoration;
  final VoidCallback quickAttendance, quickBell, quickSettings;
  final VoidCallback? onSearch, onCenter, onStudent, onClassroom,
      onCurriculum, onAnalytics, onSchedule;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final ink = scheme.onSurface;
    final muted = scheme.onSurfaceVariant;
    return LayoutBuilder(builder: (context, limits) {
      final outerPadding = limits.maxWidth >= 700 ? 20.0 : 13.0;
      final gridWidth = math.min(870.0, limits.maxWidth - outerPadding * 2);
      const gap = 12.0;
      final tileHeight = compact ? 156.0 : 191.0;
      final fifthHeight = compact ? 98.0 : 124.0;
      if (entries.length < 5) {
        return const Center(child: Text('الأقسام غير مكتملة'));
      }
      return ListView(
        key: const PageStorageKey('mosaic-home'),
        padding: EdgeInsets.fromLTRB(outerPadding, 15, outerPadding, 114),
        children: [
          Center(child: SizedBox(width: gridWidth,
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              banner ?? MosaicHero(school: school, accent: accent, rounded: rounded,
                compact: compact, showDecoration: showDecoration, onExplore: onCenter),
              const SizedBox(height: 14),
              Material(
                color: scheme.surface,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(19),
                  side: BorderSide(color: scheme.outlineVariant.withValues(alpha: .65))),
                child: InkWell(
                  key: const ValueKey('modern-global-search'),
                  borderRadius: BorderRadius.circular(19),
                  onTap: onSearch,
                  child: Padding(padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                    child: Row(children: [
                      Container(width: 42, height: 42,
                        decoration: BoxDecoration(color: dark ? const Color(0xff20473d) : const Color(0xffe8f5f0),
                          borderRadius: BorderRadius.circular(14)),
                        child: const Icon(Icons.search_rounded, size: 24, color: Color(0xff14836a))),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('تبحث عن شيء؟', style: TextStyle(color: ink, fontSize: 13,
                          fontWeight: FontWeight.w900)),
                        const SizedBox(height: 2),
                        Text('تلميذ، مادة، كتاب، أو حصة...', maxLines: 1,
                          style: TextStyle(color: muted, fontSize: 10)),
                      ])),
                      Icon(Icons.arrow_back_rounded, color: muted, size: 19),
                    ]),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              _sectionTitle(context, Icons.grid_view_rounded, 'تطبيقات مدرستي',
                'اختر ما تريد إنجازه', trailing: Text('05 تطبيقات',
                  style: TextStyle(fontSize: 11, color: muted, fontWeight: FontWeight.w800))),
              const SizedBox(height: 13),
              // The first four tiles have identical dimensions, the fifth is full-width.
              for (final row in [[0, 1], [2, 3], [4]]) ...[
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  for (final i in row) ...[
                    if (i != row.first) const SizedBox(width: gap),
                    Expanded(child: _tile(context, entries[i], row.length == 1 ? fifthHeight : tileHeight,
                        i, horizontal: row.length == 1)),
                  ],
                ]),
                const SizedBox(height: gap),
              ],
              if (showDay) ...[
                const SizedBox(height: 12),
                _sectionTitle(context, Icons.schedule_outlined, 'حصص اليوم',
                  'ترتيب واضح ليومك الدراسي',
                  trailing: TextButton(onPressed: onSchedule,
                    child: Text('الجدول الكامل', style: TextStyle(color: accent,
                      fontSize: 11, fontWeight: FontWeight.w900)))),
                const SizedBox(height: 12),
                day,
              ],
              if (showShortcuts) ...[
                const SizedBox(height: 23),
                _sectionTitle(context, Icons.bolt_rounded, 'أنجزها بسرعة', 'إجراءات تحتاجها كل يوم'),
                const SizedBox(height: 11),
                Row(children: [
                  Expanded(child: _shortcut(context, 'تسجيل الحضور', Icons.fact_check_outlined,
                    const Color(0xffe9f7f1), const Color(0xff16866c), quickAttendance)),
                  const SizedBox(width: 9),
                  Expanded(child: _shortcut(context, 'ملف التلميذ', Icons.person_outline,
                    const Color(0xfff0e9fa), const Color(0xff815abd), onStudent)),
                  const SizedBox(width: 9),
                  Expanded(child: _shortcut(context, 'الجرس', Icons.notifications_outlined,
                    const Color(0xfffff0e2), const Color(0xffb9844b), quickBell)),
                ]),
              ],
              const SizedBox(height: 24),
              _sectionTitle(context, Icons.auto_awesome_rounded, 'مساحة أكثر ذكاءً',
                'أدوات تكمل يومك الدراسي'),
              const SizedBox(height: 12),
              Material(
                color: dark ? const Color(0xff204036) : const Color(0xffe9f8f2),
                borderRadius: BorderRadius.circular(22),
                child: InkWell(
                  key: const ValueKey('modern-teacher-center'),
                  onTap: onCenter,
                  borderRadius: BorderRadius.circular(22),
                  child: Padding(padding: const EdgeInsets.all(20), child: Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('مركز المعلم الذكي', style: TextStyle(fontSize: 10,
                        fontWeight: FontWeight.w900, color: dark ? const Color(0xff9de6bd) : const Color(0xff3d947d))),
                      const SizedBox(height: 8),
                      Text('كل تفاصيل يومك، في مكان واحد.',
                        style: TextStyle(fontSize: 16, color: dark ? Colors.white : const Color(0xff114d45),
                          fontWeight: FontWeight.w900, height: 1.6)),
                      const SizedBox(height: 8),
                      Text('مهامك، التلاميذ، والمواد الدراسية',
                        style: TextStyle(color: muted, fontSize: 10)),
                      const SizedBox(height: 9),
                      Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                        decoration: BoxDecoration(color: const Color(0xff0c7861),
                          borderRadius: BorderRadius.circular(9)),
                        child: const Row(mainAxisSize: MainAxisSize.min, children: [
                          Text('فتح المركز', style: TextStyle(color: Colors.white,
                            fontSize: 10, fontWeight: FontWeight.w800)),
                          SizedBox(width: 5),
                          Icon(Icons.arrow_back_rounded, size: 13, color: Colors.white),
                        ])),
                    ])),
                    const SizedBox(width: 8),
                    Container(width: 81, height: 81, alignment: Alignment.center,
                      decoration: BoxDecoration(shape: BoxShape.circle,
                        color: dark ? const Color(0xff1b4337) : const Color(0xffdef6ea),
                        border: Border.all(color: const Color(0xff1aa685), width: 8)),
                      child: Icon(Icons.school_outlined,
                        color: dark ? const Color(0xff8bdec2) : const Color(0xff14725e), size: 30)),
                  ])),
                ),
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _spotlight(context, 'ملف التلميذ',
                  'درجاته وحضوره ومستمسكاته في صفحة واحدة',
                  Icons.person_outline, const Color(0xff7b55b9), onStudent)),
                const SizedBox(width: 9),
                Expanded(child: _spotlight(context, 'متابعة الصف',
                  'المؤشرات والتلاميذ والإجراءات اليومية',
                  Icons.groups_outlined, const Color(0xff137f75), onClassroom)),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _spotlight(context, 'إنجاز المنهج',
                  'راقب تقدم كل مادة ببساطة',
                  Icons.donut_large_rounded, const Color(0xff3676c1), onCurriculum)),
                const SizedBox(width: 9),
                Expanded(child: _spotlight(context, 'إحصاءات المدرسة',
                  'أرقام واضحة تساعدك على المتابعة',
                  Icons.bar_chart_rounded, const Color(0xffb77639), onAnalytics)),
              ]),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: onSearch,
                icon: const Icon(Icons.arrow_back_rounded, size: 17),
                label: const Text('اكتشف المزيد عبر البحث الشامل'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: accent,
                  minimumSize: const Size.fromHeight(46),
                  side: BorderSide(color: accent.withValues(alpha: .25)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
              ),
              if (center != null) ...[const SizedBox(height: 15), center!],
              const SizedBox(height: 17),
              Text('مدرستي · أدواتك المدرسية في مكان واحد',
                textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 10)),
            ]),
          )),
        ],
      );
    });
  }

  Widget _sectionTitle(BuildContext context, IconData icon, String title, String subtitle,
      {Widget? trailing}) {
    final scheme = Theme.of(context).colorScheme;
    return Row(children: [
      Container(width: 39, height: 39,
        decoration: BoxDecoration(color: const Color(0xffe8f5f0),
          border: Border.all(color: const Color(0xffd8ede5)),
          borderRadius: BorderRadius.circular(13)),
        child: Icon(icon, color: const Color(0xff087b62), size: 20)),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(fontSize: 18, color: scheme.onSurface,
          fontWeight: FontWeight.w900)),
        Text(subtitle, style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 10)),
      ])),
      if (trailing != null) trailing,
    ]);
  }

  Widget _tile(BuildContext context, MosaicEntry entry, double height, int index,
      {bool horizontal = false}) {
    const kicker = ['نظّم يومك', 'تابع صفّك', 'ابقَ مستعداً', 'تعلّم بسهولة', 'وثائقك بأمان'];
    final base = entry.color;
    final gradient = LinearGradient(
      begin: AlignmentDirectional.topStart,
      end: AlignmentDirectional.bottomEnd,
      colors: [Color.lerp(base, Colors.white, .09)!, Color.lerp(base, const Color(0xff091e34), .18)!],
    );
    final icon = Container(
      width: horizontal ? 64 : 47,
      height: horizontal ? 64 : 47,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .18),
        border: Border.all(color: Colors.white.withValues(alpha: .24)),
        borderRadius: BorderRadius.circular(horizontal ? 20 : 17)),
      child: Icon(entry.icon, size: horizontal ? 32 : 27, color: Colors.white),
    );
    final labels = Column(crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min, children: [
        Text(kicker[index], maxLines: 1,
          style: const TextStyle(color: Color(0xffe9f6ff), fontSize: 10)),
        const SizedBox(height: 3),
        Text(entry.title, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(color: Colors.white, fontSize: horizontal ? 22 : 20,
            fontWeight: FontWeight.w900, height: 1.35)),
        if (showDescriptions) ...[
          const SizedBox(height: 4),
          Text(entry.description, maxLines: horizontal ? 1 : 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Color(0xffedf5fa), fontSize: 10, height: 1.5)),
        ],
      ]);
    final tile = Material(
      borderRadius: BorderRadius.circular(rounded + 5),
      clipBehavior: Clip.antiAlias,
      child: Ink(
        decoration: BoxDecoration(gradient: gradient,
          borderRadius: BorderRadius.circular(rounded + 5),
          boxShadow: [BoxShadow(color: base.withValues(alpha: .18),
            blurRadius: 18, offset: const Offset(0, 8))]),
        child: InkWell(
          key: ValueKey('mosaic-${entry.title}'),
          onTap: entry.onTap,
          child: SizedBox(height: height, child: Stack(children: [
            PositionedDirectional(
              start: -24, bottom: -18,
              child: Icon(entry.icon, size: 132,
                color: Colors.white.withValues(alpha: .075)),
            ),
            Padding(padding: EdgeInsets.all(horizontal ? 18 : 15), child:
              horizontal
                ? Row(children: [
                    icon, const SizedBox(width: 15),
                    Expanded(child: labels),
                    Container(width: 30, height: 30, alignment: Alignment.center,
                      decoration: BoxDecoration(shape: BoxShape.circle,
                        border: Border.all(color: Colors.white.withValues(alpha: .40))),
                      child: const Icon(Icons.arrow_back_rounded,
                        color: Colors.white, size: 17)),
                  ])
                : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [icon, Text('${index + 1}'.padLeft(2, '0'),
                        style: TextStyle(color: Colors.white.withValues(alpha: .67),
                          letterSpacing: 1, fontSize: 11))]),
                    const Spacer(),
                    labels,
                    const SizedBox(height: 5),
                  ]),
            ),
          ])),
        ),
      ),
    );
    return entry.section == null ? tile : SectionCard('tile-${entry.section}', child: tile);
  }

  Widget _shortcut(BuildContext context, String title, IconData icon,
      Color light, Color foreground, VoidCallback? onTap) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: scheme.surface,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18),
        child: Container(height: 108,
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 12),
          decoration: BoxDecoration(border: Border.all(color: scheme.outlineVariant.withValues(alpha: .60)),
            borderRadius: BorderRadius.circular(18)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(width: 40, height: 40,
              decoration: BoxDecoration(color: dark ? foreground.withValues(alpha: .22) : light,
                borderRadius: BorderRadius.circular(13)),
              child: Icon(icon, color: foreground, size: 22)),
            const SizedBox(height: 8),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: scheme.onSurface, fontSize: 10,
                fontWeight: FontWeight.w900)),
          ]),
        )),
    );
  }

  Widget _spotlight(BuildContext context, String title, String description,
      IconData icon, Color tone, VoidCallback? onTap) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(color: scheme.surface, borderRadius: BorderRadius.circular(20),
      child: InkWell(
        key: ValueKey('modern-spotlight-$title'),
        onTap: onTap, borderRadius: BorderRadius.circular(20),
        child: Container(
          constraints: const BoxConstraints(minHeight: 137),
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20),
            border: Border.all(color: scheme.outlineVariant.withValues(alpha: .7))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 39, height: 39,
              decoration: BoxDecoration(color: tone.withValues(alpha: dark ? .23 : .12),
                borderRadius: BorderRadius.circular(13)),
              child: Icon(icon, color: tone, size: 20)),
            const SizedBox(height: 8),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: scheme.onSurface,
                fontWeight: FontWeight.w900, fontSize: 12)),
            const SizedBox(height: 3),
            Text(description, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 10, height: 1.5)),
          ]),
        )),
    );
  }
}
