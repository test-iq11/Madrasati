import 'package:teacher_bell/domain.dart' as bell;

DateTime baghdadDate() {
  final date = DateTime.now().toUtc().add(const Duration(hours: 3));
  return DateTime(date.year, date.month, date.day);
}

class SchoolDay {
  const SchoolDay(this.sections, this.lessons, this.section, this.date);
  final List<Map<String, Object?>> sections, lessons;
  final Map<String, Object?>? section;
  final DateTime date;

  int? get sectionId => section?['id'] as int?;
  String get grade => section?['grade_name']?.toString() ?? '';
  String get sectionLabel => '$grade · ${section?['section_name'] ?? ''}';
  String get dayName => bell.weekdays[bell.dayIndex(date)];

  static SchoolDay select(
    List<Map<String, Object?>> sections,
    List<Map<String, Object?>> entries,
    int? selected,
    DateTime date,
  ) {
    final section =
        sections.where((row) => row['id'] == selected).firstOrNull ??
        sections.firstOrNull;
    final day = bell.weekdays[bell.dayIndex(date)];
    final lessons = section == null
        ? <Map<String, Object?>>[]
        : [
            for (final entry in entries)
              if (entry['section_id'] == section['id'] &&
                  entry['day_name'] == day)
                entry,
          ];
    return SchoolDay(sections, lessons, section, date);
  }

  List<bell.Lesson>? toBellLessons() {
    final result = <bell.Lesson>[];
    for (final row in lessons) {
      final start = _minutes(row['start_time']);
      final end = _minutes(row['end_time']);
      final subject = row['subject_name']?.toString().trim() ?? '';
      if (start == null ||
          end == null ||
          start >= end ||
          subject.isEmpty ||
          (result.isNotEmpty && result.last.end > start))
        return null;
      result.add(
        bell.Lesson(
          id: 'madrasati-${row['id']}',
          subject: subject == 'الإنجليزية' ? 'اللغة الإنكليزية' : subject,
          grade: grade,
          start: start,
          end: end,
          enabled: true,
          section: row['section_name']?.toString() ?? '',
          place: row['room_name']?.toString() ?? '',
        ),
      );
    }
    return result;
  }
}

int? _minutes(Object? value) {
  final fields = value?.toString().split(':');
  if (fields == null || fields.length != 2) return null;
  final hour = int.tryParse(fields[0]);
  final minute = int.tryParse(fields[1]);
  if (hour == null ||
      minute == null ||
      hour < 0 ||
      hour > 23 ||
      minute < 0 ||
      minute > 59)
    return null;
  return hour * 60 + minute;
}
