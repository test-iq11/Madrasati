import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:iraqi_school_library_dual/admin/admin_library_app.dart';
import 'package:iraqi_school_library_dual/user/user_library_app.dart';
import 'package:iraqi_school_timetable/app/app.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:local_auth/local_auth.dart';
import 'package:mustamsakati/main.dart';
import 'package:sajli/main.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:teacher_bell/domain.dart' as bell;
import 'package:teacher_bell/main.dart' as bell_ui;
import 'package:teacher_bell/platform_service.dart';

import 'school_day.dart';

const _prefix = 'madrasati.';
const _version = '1.0.0';

enum Section {
  today('اليوم', Icons.home_outlined, 0xff276b59),
  schedule('الجدول', Icons.calendar_month_outlined, 0xff2b5779),
  records('سجلّي', Icons.fact_check_outlined, 0xff57417c),
  notifications('الجرس', Icons.notifications_outlined, 0xff745124),
  scanner('المسح', Icons.document_scanner_outlined, 0xff295f65),
  library('المناهج', Icons.menu_book_outlined, 0xff3a5484),
  settings('الإعدادات', Icons.tune, 0xff376167),
  manager('إدارة المناهج', Icons.admin_panel_settings_outlined, 0xff57417c);

  const Section(this.label, this.icon, this.tone);
  final String label;
  final IconData icon;
  final int tone;
}

const _mainSections = [
  Section.today,
  Section.schedule,
  Section.records,
  Section.notifications,
  Section.scanner,
  Section.library,
];
const _protectable = [
  Section.schedule,
  Section.records,
  Section.scanner,
  Section.library,
];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final preferences = await SharedPreferences.getInstance();
  runApp(Madrasati(preferences: preferences));
}

class Madrasati extends StatefulWidget {
  const Madrasati({required this.preferences, super.key});
  final SharedPreferences preferences;

  @override
  State<Madrasati> createState() => _MadrasatiState();
}

class _MadrasatiState extends State<Madrasati> with WidgetsBindingObserver {
  final _bell = GlobalKey<bell_ui.TeacherBellAppState>();
  final _attendance = ValueNotifier<({String grade, DateTime date})?>(null);
  final _books = ValueNotifier<String?>(null);
  final _auth = LocalAuthentication();
  final _database = DatabaseService.instance;
  final _visited = <Section>{Section.today};
  final _messenger = GlobalKey<ScaffoldMessengerState>();
  late final Future<SajliApp> _records = loadSajli(attendance: _attendance);

  late ThemeMode _mode;
  late bool _reduceMotion;
  late double _textScale;
  late bool _largeCard;
  late Color _accent;
  late String _school;
  late int _sessionMinutes;
  late Set<String> _locked;
  late DateTime _date;
  late Future<SchoolDay> _schoolDay;
  Timer? _sessionTimer;
  DateTime? _sessionExpiry;
  bool _admin = false;
  bool _checking = false;
  bool _transferring = false;
  Section _section = Section.today;
  int? _sectionId;

  SharedPreferences get _prefs => widget.preferences;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _mode = ThemeMode.values.firstWhere(
      (mode) => mode.name == _prefs.getString('${_prefix}theme'),
      orElse: () => ThemeMode.system,
    );
    _school = _prefs.getString('${_prefix}school') ?? 'مدرستي';
    _reduceMotion = _prefs.getBool('${_prefix}motion') ?? false;
    _textScale = (_prefs.getDouble('${_prefix}text') ?? 1)
        .clamp(.9, 1.2)
        .toDouble();
    _largeCard = _prefs.getBool('${_prefix}largeCard') ?? false;
    _accent = Color(_prefs.getInt('${_prefix}accent') ?? 0xff276b59);
    _sessionMinutes = _prefs.getInt('${_prefix}session') ?? 5;
    _locked = (_prefs.getStringList('${_prefix}protected') ?? []).toSet();
    _sectionId = _prefs.getInt('${_prefix}section');
    _date = baghdadDate();
    _schoolDay = _loadDay();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sessionTimer?.cancel();
    _attendance.dispose();
    _books.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_admin &&
        (state == AppLifecycleState.detached ||
            (state == AppLifecycleState.resumed &&
                _sessionExpiry?.isAfter(DateTime.now()) == false))) {
      _lock();
    }
  }

  Future<SchoolDay> _loadDay() async {
    final sections = await _database.sectionsDetailed();
    final entries = await _database.entriesDetailed();
    return SchoolDay.select(sections, entries, _sectionId, _date);
  }

  void _message(String text) {
    _messenger.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _savePreference(Future<bool> write) async {
    try {
      if (!await write) _message('تعذّر حفظ التفضيل على الجهاز.');
    } catch (_) {
      _message('تعذّر حفظ التفضيل على الجهاز.');
    }
  }

  void _lock() {
    _sessionTimer?.cancel();
    _sessionExpiry = null;
    if (!mounted) return;
    setState(() {
      _admin = false;
      _visited.remove(Section.manager);
      _visited.removeWhere((section) => _locked.contains(section.name));
      if (_section == Section.manager || _locked.contains(_section.name)) {
        _section = Section.settings;
      }
    });
  }

  void _startSession() {
    _sessionTimer?.cancel();
    final duration = Duration(minutes: _sessionMinutes);
    _sessionExpiry = DateTime.now().add(duration);
    _sessionTimer = Timer(duration, _lock);
  }

  Future<bool> _authenticate() async {
    if (_admin) return true;
    if (_checking) return false;
    setState(() => _checking = true);
    try {
      final granted = await _auth.authenticate(
        localizedReason: 'أكّد هويتك لفتح إدارة مدرستي على هذا الجهاز',
      );
      if (!mounted || !granted) return false;
      setState(() => _admin = true);
      _startSession();
      return true;
    } catch (_) {
      _message('تعذّر التحقق. فعّل قفل شاشة الجهاز ثم أعد المحاولة.');
      return false;
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  Future<void> _open(Section section) async {
    if (section == Section.manager || _locked.contains(section.name)) {
      if (!await _authenticate()) return;
    }
    if (!mounted) return;
    if (section == _section) {
      if (section == Section.today) setState(() => _schoolDay = _loadDay());
      return;
    }
    setState(() {
      if (section == Section.today) _schoolDay = _loadDay();
      _section = section;
      _visited.add(section);
    });
  }

  Future<void> _updateProtection(Section section, bool locked) async {
    if (!_admin) return;
    final updated = {..._locked};
    if (locked) {
      updated.add(section.name);
    } else {
      updated.remove(section.name);
    }
    try {
      if (!await _prefs.setStringList(
        '${_prefix}protected',
        updated.toList(),
      )) {
        throw StateError('settings');
      }
      if (mounted) setState(() => _locked = updated);
    } catch (_) {
      _message('تعذّر حفظ سياسة الصلاحيات.');
    }
  }

  Future<void> _openAttendance(SchoolDay day) async {
    if (day.grade.isEmpty) return;
    await _open(Section.records);
    if (_section == Section.records) {
      _attendance.value = null;
      _attendance.value = (grade: day.grade, date: day.date);
    }
  }

  Future<void> _openBooks(SchoolDay day) async {
    if (day.grade.isEmpty) return;
    await _open(Section.library);
    if (_section == Section.library) {
      _books.value = null;
      _books.value = day.grade;
    }
  }

  Future<void> _transfer(BuildContext context, SchoolDay day) async {
    if (_transferring || day.lessons.isEmpty) return;
    final entries = day.toBellLessons();
    if (entries == null) {
      _message('أوقات الحصص متداخلة أو ناقصة. راجعها في الجدول.');
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تهيئة جرس الحصص'),
        content: Text(
          'نقل ${entries.length} حصص من ${day.sectionLabel} ليوم ${day.dayName} وتحديث جدول الجرس الأسبوعي لهذا اليوم؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تطبيق'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    if (_locked.contains(Section.schedule.name) && !_admin) {
      _message('انتهت جلسة المدير. افتح الجدول وأعد المحاولة.');
      return;
    }
    setState(() => _transferring = true);
    try {
      await _open(Section.notifications);
      await WidgetsBinding.instance.endOfFrame;
      if (!mounted) return;
      final saved = await _bell.currentState?.importSchoolDay(
        bell.dayIndex(day.date),
        entries,
      );
      _message(
        saved == true
            ? 'تم نقل الحصص إلى جدول الجرس.'
            : 'تعذّر نقل الحصص إلى الجرس.',
      );
    } catch (_) {
      _message('تعذّر حفظ حصص الجرس.');
    } finally {
      if (mounted) setState(() => _transferring = false);
    }
  }

  ThemeData _theme(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(
      seedColor: _accent,
      brightness: brightness,
    );
    return ThemeData(
      colorScheme: scheme,
      useMaterial3: true,
      fontFamily: 'NotoSansArabic',
      scaffoldBackgroundColor: brightness == Brightness.dark
          ? const Color(0xff101820)
          : const Color(0xfff1f6f8),
      cardTheme: CardThemeData(
        color: brightness == Brightness.dark
            ? const Color(0xff1a2834)
            : Colors.white,
        margin: EdgeInsets.zero,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: _school,
    debugShowCheckedModeBanner: false,
    locale: const Locale('ar', 'IQ'),
    supportedLocales: const [Locale('ar', 'IQ'), Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: _theme(Brightness.light),
    darkTheme: _theme(Brightness.dark),
    themeMode: _mode,
    themeAnimationDuration: _reduceMotion
        ? Duration.zero
        : const Duration(milliseconds: 180),
    scaffoldMessengerKey: _messenger,
    builder: (context, child) {
      final media = MediaQuery.of(context);
      return MediaQuery(
        data: media.copyWith(
          disableAnimations: _reduceMotion || media.disableAnimations,
          textScaler: TextScaler.linear(
            media.textScaler.scale(14) / 14 * _textScale,
          ),
        ),
        child: child!,
      );
    },
    home: Builder(builder: _shell),
  );

  Widget _shell(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Column(
        children: [
          _header(context),
          Expanded(
            child: IndexedStack(
              index: _section.index,
              children: [
                for (final section in Section.values)
                  KeyedSubtree(
                    key: ValueKey(section),
                    child: _visited.contains(section)
                        ? TickerMode(
                            enabled: _section == section,
                            child: _page(context, section),
                          )
                        : const SizedBox.shrink(),
                  ),
              ],
            ),
          ),
        ],
      ),
    ),
  );

  Widget _header(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dark = scheme.brightness == Brightness.dark;
    return Material(
      color: scheme.surface,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(12, 5, 6, 1),
            child: Row(
              children: [
                Icon(Icons.school_outlined, color: scheme.primary),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _school,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                IconButton(
                  tooltip: 'إعدادات مدرستي',
                  onPressed: () => _open(Section.settings),
                  icon: const Icon(Icons.settings_outlined),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(7, 0, 7, 7),
            child: Row(
              children: [
                for (final section in _mainSections)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 2),
                      child: _tab(section, scheme, dark),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tab(Section section, ColorScheme scheme, bool dark) {
    final selected = _section == section;
    final base = Color(section.tone);
    final fill = Color.alphaBlend(
      base.withValues(alpha: selected ? .24 : .12),
      scheme.surface,
    );
    final ink = dark ? Color.lerp(base, Colors.white, .65)! : base;
    return Semantics(
      selected: selected,
      button: true,
      child: Tooltip(
        message: section.label,
        child: Material(
          color: fill,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(
              color: selected ? ink : ink.withValues(alpha: .25),
            ),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => _open(section),
            child: SizedBox(
              height: 47,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(section.icon, size: 18, color: ink),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      section.label,
                      style: TextStyle(
                        color: ink,
                        fontWeight: FontWeight.w700,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _page(BuildContext context, Section section) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return switch (section) {
      Section.today => _today(context),
      Section.schedule => TimetableApp(darkOverride: dark),
      Section.records => FutureBuilder<SajliApp>(
        future: _records,
        builder: (context, snapshot) {
          if (snapshot.hasError)
            return const Center(child: Text('تعذّر فتح بيانات سجلّي.'));
          if (!snapshot.hasData)
            return const Center(child: CircularProgressIndicator());
          final source = snapshot.data!;
          return SajliApp(
            records: source.records,
            file: source.file,
            darkOverride: dark,
            attendance: _attendance,
          );
        },
      ),
      Section.notifications => bell_ui.TeacherBellApp(
        key: _bell,
        darkOverride: dark,
      ),
      Section.scanner => MustamsakatiApp(darkOverride: dark),
      Section.library => IraqiLibraryUserApp(
        darkOverride: dark,
        openGrade: _books,
      ),
      Section.settings => _settings(context),
      Section.manager =>
        _admin ? IraqiLibraryAdminApp(dark: dark) : const SizedBox.shrink(),
    };
  }

  Widget _today(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ListView(
      key: const PageStorageKey('today'),
      padding: const EdgeInsets.all(14),
      children: [
        Container(
          padding: EdgeInsets.all(_largeCard ? 25 : 18),
          decoration: BoxDecoration(
            color: scheme.primaryContainer,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: scheme.outlineVariant),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _school,
                      style: TextStyle(
                        color: scheme.onPrimaryContainer,
                        fontSize: 27,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'جدول الحصص والحضور والجرس في يوم دراسي واحد',
                      style: TextStyle(color: scheme.onPrimaryContainer),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.school_outlined,
                color: scheme.onPrimaryContainer,
                size: 48,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (_locked.contains(Section.schedule.name) && !_admin)
          _card('جدول اليوم المختار', [
            _tile(
              Section.schedule,
              'فتح الجدول المحمي',
              () => _open(Section.schedule),
            ),
          ])
        else
          FutureBuilder<SchoolDay>(
            future: _schoolDay,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return _card('جدول اليوم المختار', [
                  const Text('تعذّر قراءة بيانات الجدول.'),
                  TextButton(
                    onPressed: () => _open(Section.today),
                    child: const Text('إعادة المحاولة'),
                  ),
                ]);
              }
              if (!snapshot.hasData)
                return const Center(child: LinearProgressIndicator());
              final day = snapshot.data!;
              return Column(
                children: [
                  _card('جدول اليوم المختار', [
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        if (day.sections.isNotEmpty)
                          DropdownButton<int>(
                            value: day.sectionId,
                            items: [
                              for (final item in day.sections)
                                DropdownMenuItem(
                                  value: item['id'] as int,
                                  child: Text(
                                    '${item['grade_name']} · ${item['section_name']}',
                                  ),
                                ),
                            ],
                            onChanged: (id) {
                              if (id == null) return;
                              setState(() {
                                _sectionId = id;
                                _schoolDay = _loadDay();
                              });
                              unawaited(
                                _savePreference(
                                  _prefs.setInt('${_prefix}section', id),
                                ),
                              );
                            },
                          ),
                        OutlinedButton.icon(
                          icon: const Icon(Icons.today_outlined),
                          label: Text(day.dayName),
                          onPressed: () async {
                            final selected = await showDatePicker(
                              context: context,
                              initialDate: _date,
                              firstDate: DateTime(2020),
                              lastDate: DateTime(2100),
                            );
                            if (mounted && selected != null)
                              setState(() {
                                _date = selected;
                                _schoolDay = _loadDay();
                              });
                          },
                        ),
                      ],
                    ),
                    if (day.lessons.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 8),
                        child: Text(
                          'لا توجد حصص معتمدة لهذا الصف واليوم. أعد الجدول من قسم الجدول.',
                        ),
                      ),
                    for (final lesson in day.lessons.take(4))
                      Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: ListTile(
                          dense: true,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          tileColor: scheme.surfaceContainerHighest,
                          title: Text(lesson['subject_name']?.toString() ?? ''),
                          trailing: Text(
                            lesson['teacher_name']?.toString() ?? '',
                          ),
                        ),
                      ),
                    Wrap(
                      spacing: 6,
                      children: [
                        TextButton.icon(
                          onPressed: () => _open(Section.schedule),
                          icon: const Icon(Icons.calendar_month_outlined),
                          label: const Text('فتح الجدول'),
                        ),
                        TextButton.icon(
                          onPressed: day.lessons.isEmpty || _transferring
                              ? null
                              : () => _transfer(context, day),
                          icon: const Icon(Icons.notifications_outlined),
                          label: const Text('تهيئة الجرس'),
                        ),
                      ],
                    ),
                  ]),
                  const SizedBox(height: 10),
                  _card('مهام الصف', [
                    _tile(
                      Section.records,
                      'تسجيل الحضور',
                      () => _openAttendance(day),
                    ),
                    _tile(Section.library, 'كتب الصف', () => _openBooks(day)),
                    _tile(
                      Section.scanner,
                      'مسح بطاقة طالب',
                      () => _open(Section.scanner),
                    ),
                  ]),
                ],
              );
            },
          ),
        const SizedBox(height: 12),
        _card('أقسام مدرستي', [
          for (final section in _mainSections.skip(1))
            _tile(section, section.label, () => _open(section)),
        ]),
      ],
    );
  }

  Widget _card(String title, List<Widget> children) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17),
          ),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    ),
  );

  Widget _tile(Section section, String label, VoidCallback onTap) => Builder(
    builder: (context) {
      final scheme = Theme.of(context).colorScheme;
      final base = Color(section.tone);
      final ink = scheme.brightness == Brightness.dark
          ? Color.lerp(base, Colors.white, .68)!
          : base;
      return Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: ListTile(
          dense: true,
          leading: Icon(section.icon, color: ink),
          title: Text(label, style: TextStyle(color: ink)),
          trailing: Icon(Icons.chevron_left, color: ink),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(color: ink.withValues(alpha: .21)),
          ),
          tileColor: Color.alphaBlend(
            base.withValues(alpha: .09),
            scheme.surface,
          ),
          onTap: onTap,
        ),
      );
    },
  );

  Widget _settings(BuildContext context) {
    final themeLabels = {
      ThemeMode.system: 'حسب الجهاز',
      ThemeMode.light: 'فاتح',
      ThemeMode.dark: 'ليلي',
    };
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        _card('المظهر العام', [
          ListTile(
            title: const Text('مظهر التطبيق'),
            subtitle: const Text('يُطبّق على جميع الأقسام'),
            trailing: DropdownButton<ThemeMode>(
              value: _mode,
              items: [
                for (final entry in themeLabels.entries)
                  DropdownMenuItem(value: entry.key, child: Text(entry.value)),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() => _mode = value);
                unawaited(
                  _savePreference(
                    _prefs.setString('${_prefix}theme', value.name),
                  ),
                );
              },
            ),
          ),
          const ListTile(title: Text('لون واجهة مدرستي')),
          Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              for (final swatch in const [
                ('أخضر', 0xff276b59),
                ('أزرق', 0xff2b5779),
                ('بنفسجي', 0xff57417c),
                ('نحاسي', 0xff745124),
              ])
                ChoiceChip(
                  selected: _accent.toARGB32() == swatch.$2,
                  avatar: CircleAvatar(backgroundColor: Color(swatch.$2)),
                  label: Text(swatch.$1),
                  onSelected: (_) {
                    setState(() => _accent = Color(swatch.$2));
                    unawaited(
                      _savePreference(
                        _prefs.setInt('${_prefix}accent', swatch.$2),
                      ),
                    );
                  },
                ),
            ],
          ),
          SwitchListTile(
            title: const Text('تقليل الحركة'),
            value: _reduceMotion,
            onChanged: (value) {
              setState(() => _reduceMotion = value);
              unawaited(
                _savePreference(_prefs.setBool('${_prefix}motion', value)),
              );
            },
          ),
          SwitchListTile(
            title: const Text('تكبير البطاقة الرئيسية'),
            value: _largeCard,
            onChanged: (value) {
              setState(() => _largeCard = value);
              unawaited(
                _savePreference(_prefs.setBool('${_prefix}largeCard', value)),
              );
            },
          ),
          ListTile(
            title: const Text('حجم النص ‎'),
            trailing: Text('${(_textScale * 100).round()}%'),
          ),
          Slider(
            value: _textScale,
            min: .9,
            max: 1.2,
            divisions: 6,
            onChanged: (value) => setState(() => _textScale = value),
            onChangeEnd: (value) => unawaited(
              _savePreference(_prefs.setDouble('${_prefix}text', value)),
            ),
          ),
        ]),
        const SizedBox(height: 9),
        _card('الإدارة والصلاحيات', [
          if (!_admin)
            ListTile(
              leading: const Icon(Icons.lock_outline),
              title: const Text('فتح جلسة المدير'),
              subtitle: const Text('ببصمة الهاتف أو رمز قفله'),
              onTap: _checking ? null : _authenticate,
            )
          else ...[
            ListTile(
              leading: const Icon(Icons.lock_open),
              title: const Text('قفل جلسة المدير'),
              onTap: _lock,
            ),
            ListTile(
              title: const Text('مدة جلسة المدير'),
              trailing: DropdownButton<int>(
                value: _sessionMinutes,
                items: const [
                  DropdownMenuItem(value: 5, child: Text('٥ دقائق')),
                  DropdownMenuItem(value: 10, child: Text('١٠ دقائق')),
                  DropdownMenuItem(value: 15, child: Text('١٥ دقيقة')),
                ],
                onChanged: (value) {
                  if (value == null) return;
                  setState(() => _sessionMinutes = value);
                  _startSession();
                  unawaited(
                    _savePreference(_prefs.setInt('${_prefix}session', value)),
                  );
                },
              ),
            ),
            ListTile(
              title: const Text('اسم المدرسة في الواجهة'),
              subtitle: Text(_school),
              onTap: () => _rename(context),
            ),
            for (final section in _protectable)
              SwitchListTile(
                title: Text('قفل قسم ${section.label}'),
                subtitle: const Text('يتطلب فتحه جلسة مدير'),
                value: _locked.contains(section.name),
                onChanged: (value) => _updateProtection(section, value),
              ),
            _tile(
              Section.manager,
              'إدارة المناهج والنشر',
              () => _open(Section.manager),
            ),
          ],
        ]),
        const SizedBox(height: 9),
        _card('تنبيهات الجهاز', [
          ListTile(
            title: const Text('طلب إذن الإشعارات'),
            leading: const Icon(Icons.notifications_active_outlined),
            onTap: () => _device(DeviceService.requestNotifications),
          ),
          ListTile(
            title: const Text('فتح صلاحية التنبيه الدقيق'),
            onTap: () => _device(() => DeviceService.openSettings('exact')),
          ),
          ListTile(
            title: const Text('فتح إعدادات الاهتزاز'),
            onTap: () => _device(() => DeviceService.openSettings('vibration')),
          ),
          const ListTile(title: Text('إصدار مدرستي'), trailing: Text(_version)),
        ]),
      ],
    );
  }

  Future<void> _device(Future<void> Function() action) async {
    try {
      await action();
    } catch (_) {
      _message('تعذّر فتح إعداد الجهاز.');
    }
  }

  Future<void> _rename(BuildContext context) async {
    final name = await showDialog<String>(
      context: context,
      builder: (context) => _SchoolNameDialog(initial: _school),
    );
    if (!mounted || !_admin || name == null || name.isEmpty) return;
    setState(() => _school = name);
    await _savePreference(_prefs.setString('${_prefix}school', name));
  }
}

class _SchoolNameDialog extends StatefulWidget {
  const _SchoolNameDialog({required this.initial});
  final String initial;
  @override
  State<_SchoolNameDialog> createState() => _SchoolNameDialogState();
}

class _SchoolNameDialogState extends State<_SchoolNameDialog> {
  late final _controller = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('اسم المدرسة'),
    content: TextField(controller: _controller, maxLength: 65, autofocus: true),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(
        onPressed: () => Navigator.pop(context, _controller.text.trim()),
        child: const Text('حفظ'),
      ),
    ],
  );
}
