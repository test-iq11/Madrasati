"""Check the package boundaries, Android channels, and expected build inputs."""
from pathlib import Path
import re
from zipfile import ZipFile
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return (ROOT / name).read_text(encoding='utf-8')


pubspec = read('pubspec.yaml')
assert 'version: 1.0.0+1' in pubspec
ns = {'a': 'http://schemas.android.com/apk/res/android'}
manifest = ElementTree.parse(ROOT / 'android/app/src/main/AndroidManifest.xml')
permissions = {row.get('{' + ns['a'] + '}name') for row in manifest.findall('uses-permission')}
assert {'android.permission.CAMERA', 'android.permission.USE_BIOMETRIC',
        'android.permission.VIBRATE', 'android.permission.SCHEDULE_EXACT_ALARM'} <= permissions
# Regression guard: a missing Bundle import previously broke :app:compileReleaseJavaWithJavac.
sajli_activity = read('android/app/src/main/java/com/sajli/school/SajliActivity.java')
assert 'FlutterFragmentActivity' in sajli_activity
assert re.search(r'^import\s+android\.os\.Bundle\s*;', sajli_activity, re.M), \
    'SajliActivity must import android.os.Bundle for PrintDocumentAdapter.onLayout'
assert re.search(r'LayoutResultCallback\s+\w+,\s*Bundle\s+\w+', sajli_activity), \
    'Check the native PDF PrintDocumentAdapter signature'
assert 'MainActivity : SajliActivity' in read('android/app/src/main/kotlin/com/school/teacherbell/MainActivity.kt')
assert 'com.school.teacherbell/device' in read('android/app/src/main/kotlin/com/school/teacherbell/MainActivity.kt')
assert '"sajli/files"' in read('android/app/src/main/java/com/sajli/school/SajliActivity.java')
with ZipFile(ROOT / 'android/gradle/wrapper/gradle-wrapper.jar') as wrapper:
    assert 'org/gradle/wrapper/GradleWrapperMain.class' in wrapper.namelist()
for module in ('jadwali', 'scanner', 'library'):
    assert 'file_picker: 13.3.2' in read(f'modules/{module}/pubspec.yaml')
    assert all('FilePicker.platform' not in f.read_text() for f in (ROOT / 'modules' / module / 'lib').rglob('*.dart'))
assert 'share_plus: 13.1.0' in read('modules/scanner/pubspec.yaml')
assert 'excel_plus:' in read('modules/library/pubspec.yaml')
assert '\n  excel:' not in read('modules/library/pubspec.yaml')
for asset in ('UI-Regular.ttf', 'UI-Bold.ttf', 'UI-Latin.ttf', 'Arabic-Regular.ttf', 'Report-Regular.ttf'):
    assert (ROOT / 'modules/jadwali/assets/fonts' / asset).stat().st_size > 1000
for path in (
    'modules/jadwali/test/unscheduled_reason_1312_test.dart',
    'modules/sajli/test/records_test.dart',
    'android/app/src/test/kotlin/com/school/teacherbell/BellVibrationTest.kt',
    'modules/library/assets/library_seed.json',
    'modules/scanner/assets/demo/sample_front.jpg',
):
    assert (ROOT / path).is_file(), path
for module in ('jadwali', 'bell', 'sajli', 'scanner', 'library'):
    assert f'path: modules/{module}' in pubspec
print('Project, module assets, native Android bridges, and dependency declarations checked.')

# Keep the Android toolchain aligned with the pinned Flutter release.
assert 'gradle-9.3.1-bin.zip' in read('android/gradle/wrapper/gradle-wrapper.properties')
assert 'id "com.android.application" version "9.1.1"' in read('android/settings.gradle')
assert 'android.builtInKotlin=false' in read('android/gradle.properties')
assert 'android.newDsl=false' in read('android/gradle.properties')
workflow = read('.github/workflows/build-madrasati-android.yml')
assert "FLUTTER_VERSION: '3.50.0'" in workflow
assert '--android-skip-build-dependency-validation' not in workflow
print('Pinned Android toolchain and Flutter compatibility flags checked.')
