import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

typedef SaveFileDialog = Future<String?> Function({
  required String dialogTitle,
  required String fileName,
  required List<String> allowedExtensions,
  required Uint8List bytes,
});

/// Save the export through the platform picker or a caller-supplied dialog.
class FileSaveService {
  FileSaveService({SaveFileDialog? dialog, bool? writeSelectedPath})
    : _dialog = dialog ?? _showDialog,
      _writeSelectedPath = writeSelectedPath ?? false;

  final SaveFileDialog _dialog;
  final bool _writeSelectedPath;

  static Future<String?> _showDialog({
    required String dialogTitle,
    required String fileName,
    required List<String> allowedExtensions,
    required Uint8List bytes,
  }) async {
    final uri = await FilePicker.saveFile(
      dialogTitle: dialogTitle,
      fileName: fileName,
      bytes: bytes,
    );
    if (uri == null) return null;
    return uri.scheme == 'file' ? uri.toFilePath() : uri.toString();
  }

  Future<String?> saveBytes({
    required String dialogTitle,
    required String fileName,
    required List<String> allowedExtensions,
    required Uint8List bytes,
  }) async {
    final path = await _dialog(
      dialogTitle: dialogTitle,
      fileName: fileName,
      allowedExtensions: allowedExtensions,
      bytes: bytes,
    );
    if (path == null) return null;
    if (_writeSelectedPath) await File(path).writeAsBytes(bytes, flush: true);
    return path;
  }
}
