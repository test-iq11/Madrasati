import '../services/lesson_swap_service.dart';

import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart' as desktop_sqlite;
import 'package:path_provider/path_provider.dart';

import '../services/teacher_assignment_policy.dart';
import '../services/school_timetable_policy.dart';
import '../services/conflict_detection_service.dart';

/// مصدر البيانات المحلي الوحيد للتطبيق. جميع البيانات المدرسية تحفظ في SQLite.
class DatabaseService {
  DatabaseService._() : _factory = null, _directory = null;

  /// Explicit storage is useful for isolated databases and migration checks.
  DatabaseService.withStorage({
    required DatabaseFactory factory,
    required String directory,
  }) : _factory = factory,
       _directory = directory;

  final DatabaseFactory? _factory;
  final String? _directory;
  static final DatabaseService instance = DatabaseService._();
  Database? _database;
  Map<String, Object?>? _manualUndo;
  bool get canUndoManualEdit => _manualUndo != null;

  static const int schemaVersion = 10;
  static const Set<String> _allowedTables = {
    'academic_years',
    'school_settings',
    'stages',
    'grades',
    'sections',
    'subjects',
    'teachers',
    'teacher_subjects',
    'teacher_grades',
    'teacher_subject_grades',
    'school_days',
    'time_slots',
    'subject_blocked_slots',
    'teacher_availability',
    'section_subject_requirements',
    'rooms',
    'timetable_versions',
    'timetable_entries',
    'audit_log',
  };

  /// Public regression guard: only known schema tables may be queried by name.
  static bool isAllowedTableName(String table) =>
      _allowedTables.contains(table);

  static const List<String> backupTables = [
    'academic_years',
    'school_settings',
    'stages',
    'grades',
    'sections',
    'subjects',
    'teachers',
    'teacher_subjects',
    'teacher_grades',
    'teacher_subject_grades',
    'school_days',
    'time_slots',
    'subject_blocked_slots',
    'teacher_availability',
    'section_subject_requirements',
    'rooms',
    'timetable_versions',
    'timetable_entries',
    'audit_log',
  ];

  Future<Database> get database async {
    if (_database != null) return _database!;
    final desktop = Platform.isWindows || Platform.isLinux;
    if (_factory == null && desktop) desktop_sqlite.sqfliteFfiInit();
    final factory =
        _factory ??
        (desktop ? desktop_sqlite.databaseFactoryFfi : databaseFactory);
    // Keep desktop data outside the extracted application folder, so replacing
    // or moving the executable cannot discard the school's database.
    final base =
        _directory ??
        (desktop
            ? p.join((await getApplicationSupportDirectory()).path, 'databases')
            : await factory.getDatabasesPath());
    await Directory(base).create(recursive: true);
    _database = await factory.openDatabase(
      p.join(base, 'iraqi_school_timetable.db'),
      options: OpenDatabaseOptions(
        version: schemaVersion,
        onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
        onCreate: _createSchema,
        // Safety net for databases created by earlier builds whose version was
        // already advanced although one of the newer tables was missing.
        onOpen: (db) async {
          // Existing installations occasionally report a newer version despite
          // missing one of the compatibility tables/columns. Repair by schema,
          // not only by the SQLite version number, and never drop user data.
          await _ensureCompatibilityTables(db);
          await _ensureGradeDayLimits(db);
          await _ensureTimetableEntryGradeColumns(db);
          await db.transaction(_ensureTeacherAvailabilityScope);
        },
        onUpgrade: (db, oldVersion, newVersion) async {
          // These operations are idempotent, so they also repair interrupted or
          // previously mis-versioned upgrades without CREATE TABLE conflicts.
          await _ensureCompatibilityTables(db);
          await _ensureGradeDayLimits(db);
          await _ensureTimetableEntryGradeColumns(db);
          await _ensureTeacherAvailabilityScope(db);
          // Seven is not a normal daily limit anymore. Sixth-grade Sunday is a
          // separate automatic exception evaluated from actual weekly demand.
          await db.execute(
            'UPDATE grades SET max_daily_lessons=6 WHERE max_daily_lessons>6',
          );
          await db.execute(
            'UPDATE sections SET max_daily_lessons=6 WHERE max_daily_lessons>6',
          );
        },
      ),
    );
    return _database!;
  }

  /// Close the handle before replacing storage or reopening it in a new session.
  Future<void> close() async {
    final current = _database;
    _database = null;
    await current?.close();
  }

  Future<void> _ensureCompatibilityTables(DatabaseExecutor db) async {
    final subjectColumns = await db.rawQuery('PRAGMA table_info(subjects)');
    if (subjectColumns.isNotEmpty &&
        !subjectColumns.any((row) => row['name'] == 'morning_priority')) {
      await db.execute(
        'ALTER TABLE subjects ADD COLUMN morning_priority INTEGER NOT NULL DEFAULT 1 CHECK (morning_priority BETWEEN 1 AND 3)',
      );
    }
    await db.execute('''CREATE TABLE IF NOT EXISTS teacher_grades (
      teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
      grade_id INTEGER NOT NULL REFERENCES grades(id) ON DELETE CASCADE,
      PRIMARY KEY(teacher_id, grade_id)
    )''');
    await db.execute('''CREATE TABLE IF NOT EXISTS subject_blocked_slots (
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      slot_id INTEGER NOT NULL REFERENCES time_slots(id) ON DELETE CASCADE,
      PRIMARY KEY(subject_id, slot_id)
    )''');
    await db.execute('''CREATE TABLE IF NOT EXISTS teacher_subject_grades (
      teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      grade_id INTEGER NOT NULL,
      PRIMARY KEY(teacher_id, subject_id, grade_id)
    )''');
  }

  /// Backward-compatible daily limits, owned by each grade and copied to its
  /// sections. JSON keys are actual school_days IDs (not weekday positions).
  /// Existing school files keep all records; empty JSON means legacy defaults.
  Future<void> _ensureGradeDayLimits(DatabaseExecutor db) async {
    for (final table in ['grades', 'sections']) {
      final columns = await db.rawQuery('PRAGMA table_info($table)');
      if (!columns.any((row) => row['name'] == 'daily_limits_json')) {
        await db.execute(
          "ALTER TABLE $table ADD COLUMN daily_limits_json TEXT NOT NULL DEFAULT '{}'",
        );
      }
    }
    // A newly added section inherits the per-day plan of its parent grade.
    // Explicit values from an imported backup remain untouched.
    await db.execute('''CREATE TRIGGER IF NOT EXISTS inherit_grade_daily_limits
      AFTER INSERT ON sections
      WHEN NEW.daily_limits_json = '{}'
      BEGIN
        UPDATE sections SET daily_limits_json = COALESCE(
          (SELECT daily_limits_json FROM grades WHERE id = NEW.grade_id), '{}')
        WHERE id = NEW.id;
      END''');
  }

  /// Persist each weekday independently and propagate to all existing sections
  /// of the grade in one transaction. No timetable is rewritten implicitly.
  Future<void> updateGradeDayLimits(int gradeId, Map<int, int> values) async {
    final db = await database;
    await db.transaction((txn) async {
      final grade = await txn.query('grades',
          columns: ['id', 'daily_limits_json'], where: 'id=?', whereArgs: [gradeId], limit: 1);
      if (grade.isEmpty) throw StateError('الصف المطلوب غير موجود');
      final days = await txn.query('school_days', columns: ['id']);
      final validDayIds = days.map((day) => day['id'] as int).toSet();
      if (values.keys.any((id) => !validDayIds.contains(id)) ||
          values.values.any((limit) => limit < 0 || limit > 7)) {
        throw ArgumentError('اليوم أو عدد الحصص غير صالح (0 إلى 7)');
      }
      // The editor submits active days only. Preserve overrides for disabled
      // days, and support changing a single weekday without resetting others.
      final merged = <String, int>{};
      for (final day in days) {
        final saved = SchoolTimetablePolicy.configuredDayLimit(
            section: grade.single, day: day);
        if (saved != null) merged['${day['id']}'] = saved;
      }
      for (final entry in values.entries) {
        merged[entry.key.toString()] = entry.value;
      }
      final json = jsonEncode(merged);
      await txn.update('grades', {'daily_limits_json': json},
          where: 'id=?', whereArgs: [gradeId]);
      await txn.update('sections', {'daily_limits_json': json},
          where: 'grade_id=?', whereArgs: [gradeId]);
      await txn.insert('audit_log', {
        'action': 'تعديل الحصص اليومية لكل يوم',
        'entity': 'grades', 'entity_id': gradeId,
        'details': json, 'created_at': DateTime.now().toIso8601String(),
      });
    });
  }

  /// Existing bans remain global. A row may optionally target one grade and/or
  /// one subject; deleting a scoped ban must never remove a broader rule.
  Future<void> _ensureTeacherAvailabilityScope(DatabaseExecutor db) async {
    final columns = await db.rawQuery(
      'PRAGMA table_info(teacher_availability)',
    );
    if (columns.isEmpty) return;
    final names = columns.map((row) => row['name']).toSet();
    if (!names.contains('grade_id') || !names.contains('subject_id')) {
      await db.execute('''CREATE TABLE teacher_availability_scoped (
        teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
        day_id INTEGER NOT NULL REFERENCES school_days(id) ON DELETE CASCADE,
        slot_id INTEGER NOT NULL REFERENCES time_slots(id) ON DELETE CASCADE,
        is_available INTEGER NOT NULL DEFAULT 1,
        grade_id INTEGER REFERENCES grades(id) ON DELETE CASCADE,
        subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE
      )''');
      await db.execute('''INSERT INTO teacher_availability_scoped
        (teacher_id, day_id, slot_id, is_available, grade_id, subject_id)
        SELECT teacher_id, day_id, slot_id, is_available,
          ${names.contains('grade_id') ? 'grade_id' : 'NULL'},
          ${names.contains('subject_id') ? 'subject_id' : 'NULL'}
        FROM teacher_availability''');
      await db.execute('DROP TABLE teacher_availability');
      await db.execute(
        'ALTER TABLE teacher_availability_scoped RENAME TO teacher_availability',
      );
    }
    await db.execute(
      '''CREATE UNIQUE INDEX IF NOT EXISTS teacher_availability_scope
      ON teacher_availability (teacher_id, day_id, slot_id,
        IFNULL(grade_id, 0), IFNULL(subject_id, 0))''',
    );
  }

  Future<void> _ensureTimetableEntryGradeColumns(DatabaseExecutor db) async {
    final tables = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='timetable_entries'",
    );
    if (tables.isEmpty) return;
    final columns = await db.rawQuery('PRAGMA table_info(timetable_entries)');
    final names = columns.map((row) => row['name']?.toString()).toSet();
    if (!names.contains('grade_id')) {
      await db.execute(
        'ALTER TABLE timetable_entries ADD COLUMN grade_id INTEGER',
      );
    }
    if (!names.contains('grade_name')) {
      await db.execute(
        'ALTER TABLE timetable_entries ADD COLUMN grade_name TEXT',
      );
    }
    if (!names.contains('is_locked')) {
      await db.execute(
        'ALTER TABLE timetable_entries ADD COLUMN is_locked INTEGER NOT NULL DEFAULT 0 CHECK (is_locked IN (0, 1))',
      );
    }
  }

  Future<void> _createSchema(Database db, int version) async {
    final statements = <String>[
      '''CREATE TABLE academic_years (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        is_active INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )''',
      '''CREATE TABLE school_settings (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        school_name TEXT NOT NULL DEFAULT 'مدرستي',
        directorate TEXT NOT NULL DEFAULT '',
        stage TEXT NOT NULL DEFAULT 'الابتدائية',
        default_lesson_minutes INTEGER NOT NULL DEFAULT 45,
        allow_unqualified_teacher INTEGER NOT NULL DEFAULT 0
      )''',
      '''CREATE TABLE stages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        position INTEGER NOT NULL DEFAULT 0
      )''',
      '''CREATE TABLE grades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        stage_id INTEGER NOT NULL REFERENCES stages(id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        max_daily_lessons INTEGER NOT NULL DEFAULT 6,
        daily_limits_json TEXT NOT NULL DEFAULT '{}',
        position INTEGER NOT NULL DEFAULT 0,
        UNIQUE(stage_id, name)
      )''',
      '''CREATE TABLE sections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        grade_id INTEGER NOT NULL REFERENCES grades(id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        max_daily_lessons INTEGER NOT NULL DEFAULT 6,
        daily_limits_json TEXT NOT NULL DEFAULT '{}',
        UNIQUE(grade_id, name)
      )''',
      '''CREATE TABLE subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        code TEXT NOT NULL DEFAULT '',
        color INTEGER NOT NULL DEFAULT 4280391411,
        max_daily_lessons INTEGER NOT NULL DEFAULT 2,
        allow_same_day INTEGER NOT NULL DEFAULT 0,
        morning_priority INTEGER NOT NULL DEFAULT 1 CHECK (morning_priority BETWEEN 1 AND 3)
      )''',
      '''CREATE TABLE teachers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        code TEXT NOT NULL DEFAULT '',
        weekly_load INTEGER NOT NULL DEFAULT 24,
        max_daily_lessons INTEGER NOT NULL DEFAULT 6,
        max_consecutive_lessons INTEGER NOT NULL DEFAULT 4,
        notes TEXT NOT NULL DEFAULT ''
      )''',
      '''CREATE TABLE teacher_subjects (
        teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        PRIMARY KEY(teacher_id, subject_id)
      )''',
      '''CREATE TABLE teacher_grades (
        teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
        grade_id INTEGER NOT NULL REFERENCES grades(id) ON DELETE CASCADE,
        PRIMARY KEY(teacher_id, grade_id)
      )''',
      '''CREATE TABLE teacher_subject_grades (
        teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        grade_id INTEGER NOT NULL,
        PRIMARY KEY(teacher_id, subject_id, grade_id)
      )''',
      '''CREATE TABLE school_days (
        id INTEGER PRIMARY KEY,
        position INTEGER NOT NULL,
        name TEXT NOT NULL UNIQUE,
        is_active INTEGER NOT NULL DEFAULT 1
      )''',
      '''CREATE TABLE time_slots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        start_time TEXT NOT NULL,
        end_time TEXT NOT NULL,
        kind TEXT NOT NULL DEFAULT 'lesson',
        position INTEGER NOT NULL DEFAULT 0,
        is_available INTEGER NOT NULL DEFAULT 1
      )''',
      '''CREATE TABLE subject_blocked_slots (
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        slot_id INTEGER NOT NULL REFERENCES time_slots(id) ON DELETE CASCADE,
        PRIMARY KEY(subject_id, slot_id)
      )''',
      '''CREATE TABLE teacher_availability (
        teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
        day_id INTEGER NOT NULL REFERENCES school_days(id) ON DELETE CASCADE,
        slot_id INTEGER NOT NULL REFERENCES time_slots(id) ON DELETE CASCADE,
        is_available INTEGER NOT NULL DEFAULT 1,
        grade_id INTEGER REFERENCES grades(id) ON DELETE CASCADE,
        subject_id INTEGER REFERENCES subjects(id) ON DELETE CASCADE
      )''',
      '''CREATE UNIQUE INDEX teacher_availability_scope ON teacher_availability
        (teacher_id, day_id, slot_id, IFNULL(grade_id, 0), IFNULL(subject_id, 0))''',
      '''CREATE TABLE section_subject_requirements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        weekly_lessons INTEGER NOT NULL DEFAULT 0,
        max_daily_lessons INTEGER NOT NULL DEFAULT 2,
        allow_same_day INTEGER NOT NULL DEFAULT 0,
        UNIQUE(section_id, subject_id)
      )''',
      '''CREATE TABLE rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        kind TEXT NOT NULL DEFAULT 'قاعة'
      )''',
      '''CREATE TABLE timetable_versions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        academic_year_id INTEGER NOT NULL REFERENCES academic_years(id) ON DELETE RESTRICT,
        name TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'مسودة',
        notes TEXT NOT NULL DEFAULT '',
        is_active INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        approved_at TEXT
      )''',
      '''CREATE TABLE timetable_entries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        version_id INTEGER NOT NULL REFERENCES timetable_versions(id) ON DELETE CASCADE,
        section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE RESTRICT,
        subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
        teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
        room_id INTEGER REFERENCES rooms(id) ON DELETE SET NULL,
        day_id INTEGER NOT NULL REFERENCES school_days(id) ON DELETE RESTRICT,
        slot_id INTEGER NOT NULL REFERENCES time_slots(id) ON DELETE RESTRICT,
        grade_id INTEGER,
        grade_name TEXT,
        is_locked INTEGER NOT NULL DEFAULT 0 CHECK (is_locked IN (0, 1)),
        created_at TEXT NOT NULL,
        UNIQUE(version_id, section_id, day_id, slot_id)
      )''',
      '''CREATE TABLE audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        entity TEXT NOT NULL,
        entity_id INTEGER,
        details TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )''',
      'CREATE INDEX idx_entries_version_day_slot ON timetable_entries(version_id, day_id, slot_id)',
      'CREATE INDEX idx_entries_section ON timetable_entries(section_id, version_id)',
      'CREATE INDEX idx_entries_teacher ON timetable_entries(teacher_id, version_id)',
      'CREATE INDEX idx_requirements_section ON section_subject_requirements(section_id)',
    ];
    for (final sql in statements) {
      await db.execute(sql);
    }
    await _seedInitialData(db);
  }

  Future<void> _seedInitialData(DatabaseExecutor db) async {
    final now = DateTime.now().toIso8601String();
    await db.insert('school_settings', {
      'id': 1,
      'school_name': 'مدرستي',
      'directorate': '',
      'stage': 'الابتدائية',
      'default_lesson_minutes': 45,
      'allow_unqualified_teacher': 0,
    });
    final yearId = await db.insert('academic_years', {
      'name': '${DateTime.now().year}-${DateTime.now().year + 1}',
      'is_active': 1,
      'created_at': now,
    });
    final stageId = await db.insert('stages', {
      'name': 'الابتدائية',
      'position': 0,
    });
    const gradeNames = [
      'الأول الابتدائي',
      'الثاني الابتدائي',
      'الثالث الابتدائي',
      'الرابع الابتدائي',
      'الخامس الابتدائي',
      'السادس الابتدائي',
    ];
    for (var i = 0; i < gradeNames.length; i++) {
      await db.insert('grades', {
        'stage_id': stageId,
        'name': gradeNames[i],
        'position': i,
        'max_daily_lessons': 6,
        // Distinct editable quotas for each weekday. 6th grade Sunday has
        // seven configured periods, used only when weekly demand needs it.
        'daily_limits_json': jsonEncode({
          for (var dayIndex = 1; dayIndex <= 5; dayIndex++)
            '$dayIndex': i == 5 && dayIndex == 1 ? 7 : 6,
        }),
      });
    }
    const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];
    for (var i = 0; i < days.length; i++) {
      await db.insert('school_days', {
        'id': i + 1,
        'position': i,
        'name': days[i],
        'is_active': 1,
      });
    }
    const slots = [
      ['الحصة الأولى', '08:00', '08:45', 'lesson'],
      ['الحصة الثانية', '08:50', '09:30', 'lesson'],
      ['الحصة الثالثة', '09:35', '10:10', 'lesson'],
      ['الحصة الرابعة', '10:20', '11:00', 'lesson'],
      ['الحصة الخامسة', '11:05', '11:45', 'lesson'],
      ['الحصة السادسة', '11:50', '12:30', 'lesson'],
      ['الحصة السابعة', '12:35', '13:15', 'lesson'],
    ];
    for (var i = 0; i < slots.length; i++) {
      await db.insert('time_slots', {
        'name': slots[i][0],
        'start_time': slots[i][1],
        'end_time': slots[i][2],
        'kind': slots[i][3],
        'position': i,
        'is_available': 1,
      });
    }
    const subjects = [
      'التربية الإسلامية',
      'اللغة العربية',
      'اللغة الإنجليزية',
      'الرياضيات',
      'العلوم',
      'الاجتماعيات',
      'التربية الفنية',
      'التربية الرياضية',
      'الحاسوب',
    ];
    for (var i = 0; i < subjects.length; i++) {
      await db.insert('subjects', {
        'name': subjects[i],
        'code': '',
        'color': 4280391411,
        'max_daily_lessons': 2,
        'allow_same_day': 0,
      });
    }
    final versionId = await db.insert('timetable_versions', {
      'academic_year_id': yearId,
      'name': 'الجدول الأولي',
      'status': 'مسودة',
      'notes': 'نسخة أولية فارغة أنشئت عند إعداد التطبيق',
      'is_active': 1,
      'created_at': now,
      'updated_at': now,
    });
    await db.insert('audit_log', {
      'action': 'إنشاء',
      'entity': 'timetable_version',
      'entity_id': versionId,
      'details': 'إنشاء النسخة الأولية',
      'created_at': now,
    });
  }

  Future<List<Map<String, Object?>>> rows(
    String table, {
    String? orderBy,
  }) async {
    if (!isAllowedTableName(table))
      throw ArgumentError('اسم جدول غير مسموح: $table');
    return (await database).query(table, orderBy: orderBy);
  }

  Future<List<Map<String, Object?>>> sectionsDetailed() async =>
      (await database).rawQuery('''
    SELECT s.id, s.name AS section_name, s.grade_id, s.max_daily_lessons,
           s.daily_limits_json, g.position AS grade_position,
           g.name AS grade_name, g.stage_id, st.name AS stage_name,
           (SELECT COUNT(*) FROM section_subject_requirements r WHERE r.section_id=s.id) AS requirements_count,
           (SELECT COALESCE(SUM(weekly_lessons),0) FROM section_subject_requirements r WHERE r.section_id=s.id) AS required_lessons
    FROM sections s JOIN grades g ON g.id=s.grade_id JOIN stages st ON st.id=g.stage_id
    ORDER BY st.position, g.position, g.id, s.name
  ''');

  /// Persist the ordinary daily cap for a grade and all its sections together.
  /// Kept outside the widget so database behavior can be tested using real
  /// SQLite without depending on testWidgets' simulated clock.
  Future<void> updateGradeDailyLimit(int gradeId, int normalLimit) async {
    if (normalLimit < 1 || normalLimit > 6) {
      throw RangeError.range(normalLimit, 1, 6, 'normalLimit');
    }
    final db = await database;
    await db.transaction((txn) async {
      final grades = await txn.query('grades',
          columns: ['id'], where: 'id=?', whereArgs: [gradeId], limit: 1);
      if (grades.isEmpty) {
        throw StateError('الصف المطلوب غير موجود');
      }
      await txn.update('grades', {'max_daily_lessons': normalLimit, 'daily_limits_json': '{}'},
          where: 'id=?', whereArgs: [gradeId]);
      await txn.update('sections', {'max_daily_lessons': normalLimit, 'daily_limits_json': '{}'},
          where: 'grade_id=?', whereArgs: [gradeId]);
      await txn.insert('audit_log', {
        'action': 'تعديل الحد اليومي للصف',
        'entity': 'grades',
        'entity_id': gradeId,
        'details': 'عدد الحصص المعتاد: $normalLimit',
        'created_at': DateTime.now().toIso8601String(),
      });
    });
  }

  Future<List<Map<String, Object?>>> gradesDetailed() async =>
      (await database).rawQuery('''
    SELECT g.*, st.name AS stage_name FROM grades g JOIN stages st ON st.id=g.stage_id
    ORDER BY st.position, g.position, g.name
  ''');

  Future<List<Map<String, Object?>>> entriesDetailed({
    int? versionId,
    int? sectionId,
  }) async {
    final yearVersion =
        versionId ?? await activeVersionId(await activeYearId());
    if (yearVersion == null) return [];
    final where = <String>[];
    final args = <Object?>[yearVersion];
    if (sectionId != null) {
      where.add('e.section_id = ?');
      args.add(sectionId);
    }
    return (await database).rawQuery('''
      -- لا تستخدم e.* هنا: جدول الحصص يحتفظ بنسخة قديمة من grade_id/grade_name،
      -- بينما صف الشعبة الحالي هو المرجع الصحيح. أسماء الأعمدة منفصلة لتجنب تكرار المفاتيح.
      SELECT e.id, e.version_id, e.section_id, e.subject_id, e.teacher_id, e.room_id,
             e.day_id, e.slot_id, e.grade_id AS stored_grade_id, e.grade_name AS stored_grade_name,
             e.created_at, e.is_locked,
             s.name AS subject_name, t.name AS teacher_name, sec.name AS section_name,
             sec.grade_id AS grade_id, sec.grade_id AS section_grade_id,
             g.name AS grade_name, g.name AS section_grade_name,
             d.name AS day_name, d.position AS day_position,
             ts.name AS slot_name, ts.start_time, ts.end_time, ts.position AS slot_position,
             r.name AS room_name, v.name AS version_name, v.status AS version_status
      FROM timetable_entries e
      JOIN subjects s ON s.id=e.subject_id
      LEFT JOIN teachers t ON t.id=e.teacher_id
      JOIN sections sec ON sec.id=e.section_id
      JOIN grades g ON g.id=sec.grade_id
      JOIN school_days d ON d.id=e.day_id
      JOIN time_slots ts ON ts.id=e.slot_id
      LEFT JOIN rooms r ON r.id=e.room_id
      JOIN timetable_versions v ON v.id=e.version_id
      WHERE e.version_id = ? ${where.isEmpty ? '' : 'AND ${where.join(' AND ')}'}
      ORDER BY d.position, ts.position, g.position, sec.name
    ''', args);
  }

  Future<List<Map<String, Object?>>> requirementsDetailed({
    int? sectionId,
  }) async {
    final args = <Object?>[];
    var clause = '';
    if (sectionId != null) {
      clause = 'WHERE r.section_id=?';
      args.add(sectionId);
    }
    return (await database).rawQuery('''
      SELECT r.*, sec.name AS section_name, sec.grade_id AS grade_id, sec.max_daily_lessons AS section_max_daily_lessons,
             g.name AS grade_name, st.name AS stage_name, sub.name AS subject_name
      FROM section_subject_requirements r
      JOIN sections sec ON sec.id=r.section_id
      JOIN grades g ON g.id=sec.grade_id
      JOIN stages st ON st.id=g.stage_id
      JOIN subjects sub ON sub.id=r.subject_id $clause
      ORDER BY g.position, sec.name, sub.name
    ''', args);
  }

  Future<int?> activeYearId() async {
    final result = await (await database).query(
      'academic_years',
      where: 'is_active=1',
      limit: 1,
    );
    if (result.isEmpty) return null;
    return result.first['id'] as int;
  }

  Future<Map<String, Object?>?> activeYear() async {
    final result = await (await database).query(
      'academic_years',
      where: 'is_active=1',
      limit: 1,
    );
    return result.isEmpty ? null : result.first;
  }

  Future<void> setActiveYear(int id) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.update('academic_years', {'is_active': 0});
      await txn.update(
        'academic_years',
        {'is_active': 1},
        where: 'id=?',
        whereArgs: [id],
      );
      final existing = await txn.query(
        'timetable_versions',
        where: 'academic_year_id=? AND is_active=1',
        whereArgs: [id],
        limit: 1,
      );
      if (existing.isEmpty) {
        final now = DateTime.now().toIso8601String();
        await txn.insert('timetable_versions', {
          'academic_year_id': id,
          'name': 'الجدول الأولي',
          'status': 'مسودة',
          'notes': '',
          'is_active': 1,
          'created_at': now,
          'updated_at': now,
        });
      }
    });
  }

  Future<int?> activeVersionId(int? yearId) async {
    if (yearId == null) return null;
    final result = await (await database).query(
      'timetable_versions',
      columns: ['id'],
      where: 'academic_year_id=? AND is_active=1',
      whereArgs: [yearId],
      limit: 1,
    );
    return result.isEmpty ? null : result.first['id'] as int;
  }

  Future<int> add(String table, Map<String, Object?> values) async {
    final db = await database;
    // Validation and insert must share a transaction; otherwise the permission
    // data could change between the check and the write.
    final id = await db.transaction((txn) async {
      if (table == 'timetable_entries') {
        await _validateTeacherAssignments(txn, [values]);
        await _validateSeventhLessonPolicy(txn, [values]);
      }
      return txn.insert(
        table,
        values,
        conflictAlgorithm: ConflictAlgorithm.abort,
      );
    });
    await log('إضافة', table, id, 'إضافة سجل جديد');
    return id;
  }

  Future<int> edit(String table, int id, Map<String, Object?> values) async {
    final db = await database;
    final count = await db.transaction((txn) async {
      if (table == 'timetable_entries') {
        final current = await txn.query(
          'timetable_entries',
          where: 'id=?',
          whereArgs: [id],
          limit: 1,
        );
        if (current.isEmpty)
          throw StateError('الحصة المطلوب تعديلها غير موجودة.');
        // Merge inside the same transaction to protect partial updates too.
        final merged = Map<String, Object?>.from(current.first)..addAll(values);
        await _validateTeacherAssignments(txn, [merged]);
        await _validateSeventhLessonPolicy(txn, [merged]);
      } else if (table == 'timetable_versions' && values['status'] == 'معتمد') {
        // Final guard for approval, even if called outside the UI.
        final entries = await txn.query(
          'timetable_entries',
          where: 'version_id=?',
          whereArgs: [id],
        );
        await _validateTeacherAssignments(txn, entries);
      }
      return txn.update(table, values, where: 'id=?', whereArgs: [id]);
    });
    if (count > 0) await log('تعديل', table, id, jsonEncode(values));
    return count;
  }

  /// يمنع تخزين إسناد جديد ما لم يكن المعلم مؤهلاً للمادة ومسموحاً له بالصف
  /// المرتبط بالشعبة فعلياً. لا يعتمد على grade_id الذي يرسله نموذج الواجهة.
  Future<void> _validateTeacherAssignments(
    DatabaseExecutor executor,
    List<Map<String, Object?>> entries,
  ) async {
    final assignedEntries = entries
        .where((entry) => entry['teacher_id'] != null)
        .toList();
    if (assignedEntries.isEmpty) return;

    final qualifications = (await executor.query('teacher_subjects'))
        .map((row) => Map<String, Object?>.from(row))
        .toList();
    final legacyGrades = (await executor.query('teacher_grades'))
        .map((row) => Map<String, Object?>.from(row))
        .toList();
    final subjectGrades = (await executor.query('teacher_subject_grades'))
        .map((row) => Map<String, Object?>.from(row))
        .toList();
    final sections = await executor.rawQuery('''
      SELECT sec.id AS section_id, sec.grade_id AS grade_id, sec.name AS section_name,
             g.name AS grade_name
      FROM sections sec LEFT JOIN grades g ON g.id=sec.grade_id
    ''');
    final teacherRows = await executor.query(
      'teachers',
      columns: ['id', 'name'],
    );
    final subjectRows = await executor.query(
      'subjects',
      columns: ['id', 'name'],
    );
    int intOf(Object? value) {
      if (value is int) return value;
      if (value is num) return value.toInt();
      return int.tryParse('$value') ?? 0;
    }

    final sectionById = <int, Map<String, Object?>>{
      for (final row in sections)
        intOf(row['section_id']): Map<String, Object?>.from(row),
    };
    final teacherNameById = <int, String>{
      for (final row in teacherRows) intOf(row['id']): '${row['name'] ?? ''}',
    };
    final subjectNameById = <int, String>{
      for (final row in subjectRows) intOf(row['id']): '${row['name'] ?? ''}',
    };
    final policy = TeacherAssignmentPolicy(
      qualifications: qualifications,
      teacherGrades: legacyGrades,
      teacherSubjectGrades: subjectGrades,
    );

    for (final entry in assignedEntries) {
      final teacherId = intOf(entry['teacher_id']);
      final subjectId = intOf(entry['subject_id']);
      final sectionId = intOf(entry['section_id']);
      final section = sectionById[sectionId];
      if (teacherId <= 0) {
        throw StateError('رقم المعلم غير صالح؛ لم يتم حفظ الحصة.');
      }
      if (section == null) {
        throw StateError('الشعبة رقم $sectionId غير موجودة؛ لم يتم حفظ الحصة.');
      }
      final gradeId = intOf(section['grade_id']);
      final message = policy.violation(
        teacherId: teacherId,
        subjectId: subjectId,
        gradeId: gradeId,
        teacherName: teacherNameById[teacherId],
        subjectName: subjectNameById[subjectId],
        gradeName: '${section['grade_name'] ?? ''}',
        sectionName: '${section['section_name'] ?? sectionId}',
      );
      if (message != null) {
        throw StateError('$message لم يتم حفظ أي تغيير.');
      }
    }
  }

  Future<int> remove(String table, int id) async {
    final count = await (await database).delete(
      table,
      where: 'id=?',
      whereArgs: [id],
    );
    if (count > 0) await log('حذف', table, id, 'حذف سجل');
    return count;
  }

  /// Delete an archived timetable version and its entries while protecting the
  /// active version. The audit event survives the cascade deletion.
  Future<void> deleteArchivedVersion(int versionId) async {
    final db = await database;
    await db.transaction((txn) async {
      final result = await txn.query(
        'timetable_versions',
        where: 'id=?',
        whereArgs: [versionId],
        limit: 1,
      );
      if (result.isEmpty)
        throw StateError('النسخة المؤرشفة غير موجودة أو حُذفت مسبقاً.');
      final version = result.first;
      if ((version['is_active'] as num? ?? 0) == 1) {
        throw StateError(
          'لا يمكن حذف النسخة النشطة. اجعل نسخة أخرى نشطة أولاً.',
        );
      }
      final entryCount =
          Sqflite.firstIntValue(
            await txn.rawQuery(
              'SELECT COUNT(*) FROM timetable_entries WHERE version_id=?',
              [versionId],
            ),
          ) ??
          0;
      final deleted = await txn.delete(
        'timetable_versions',
        where: 'id=? AND is_active=0',
        whereArgs: [versionId],
      );
      if (deleted != 1)
        throw StateError('لم تُحذف النسخة؛ ربما أصبحت نشطة في أثناء العملية.');
      await txn.insert('audit_log', {
        'action': 'حذف نسخة مؤرشفة',
        'entity': 'timetable_versions',
        'entity_id': versionId,
        'details':
            'حذف النسخة «${version['name']}» مع $entryCount حصة تابعة لها.',
        'created_at': DateTime.now().toIso8601String(),
      });
    });
  }

  Future<void> log(
    String action,
    String entity,
    int? id,
    String details,
  ) async {
    await (await database).insert('audit_log', {
      'action': action,
      'entity': entity,
      'entity_id': id,
      'details': details,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<Map<String, Object?>> getSettings() async {
    final result = await (await database).query(
      'school_settings',
      where: 'id=1',
      limit: 1,
    );
    return result.isEmpty ? {'school_name': 'مدرستي'} : result.first;
  }

  Future<void> saveSettings(Map<String, Object?> values) async {
    await (await database).update('school_settings', values, where: 'id=1');
    await log('تعديل', 'school_settings', 1, jsonEncode(values));
  }

  Future<List<int>> qualifiedTeacherIds(int subjectId) async {
    final data = await (await database).query(
      'teacher_subjects',
      columns: ['teacher_id'],
      where: 'subject_id=?',
      whereArgs: [subjectId],
    );
    return data.map((e) => e['teacher_id'] as int).toList();
  }

  /// ينسخ النسخة المعتمدة إلى نسخة عمل قبل أول تعديل، حتى تبقى المعتمدة ثابتة.
  Future<int?> ensureEditableActiveVersion(int yearId) async {
    return (await database).transaction((txn) => _editableVersion(txn, yearId));
  }

  Future<int?> _editableVersion(DatabaseExecutor txn, int yearId) async {
    final versions = await txn.query(
      'timetable_versions',
      where: 'academic_year_id=? AND is_active=1',
      whereArgs: [yearId],
      limit: 1,
    );
    if (versions.isEmpty) return null;
    final active = versions.first;
    if (active['status'] != 'معتمد') return active['id'] as int;
    final oldEntries = await txn.query(
      'timetable_entries',
      where: 'version_id=?',
      whereArgs: [active['id']],
    );
    // لا ننسخ إسنادات معتمدة مخالفة إلى نسخة عمل جديدة. إذا كانت النسخة
    // القديمة تحتوي إسناداً غير مسموح، تبقى محفوظة ويُوجّه المستخدم إلى صفحة
    // فحص التعارضات لإنشاء نسخة مصححة بدلاً من نشر المخالفة في نسخة جديدة.
    await _validateTeacherAssignments(txn, oldEntries);
    final now = DateTime.now().toIso8601String();
    final newId = await txn.insert('timetable_versions', {
      'academic_year_id': yearId,
      'name': 'تعديلات على ${active['name']}',
      'status': 'قيد التعديل',
      'notes':
          'نسخة عمل مشتقة تلقائياً من النسخة المعتمدة رقم ${active['id']}.',
      'is_active': 0,
      'created_at': now,
      'updated_at': now,
    });
    for (final old in oldEntries) {
      final row = Map<String, Object?>.from(old);
      row.remove('id');
      row.remove('version_id');
      row.remove('created_at');
      await txn.insert('timetable_entries', {
        ...row,
        'version_id': newId,
        'created_at': now,
      });
    }
    await txn.update(
      'timetable_versions',
      {'is_active': 0},
      where: 'id=?',
      whereArgs: [active['id']],
    );
    await txn.update(
      'timetable_versions',
      {'is_active': 1},
      where: 'id=?',
      whereArgs: [newId],
    );
    await txn.insert('audit_log', {
      'action': 'إنشاء نسخة عمل',
      'entity': 'timetable_versions',
      'entity_id': newId,
      'details': 'نسخ النسخة المعتمدة رقم ${active['id']} قبل التعديل',
      'created_at': now,
    });
    return newId;
  }

  Future<Map<String, Object?>> _swapData(
    DatabaseExecutor txn,
    int versionId,
  ) async => {
    'entries': await txn.query(
      'timetable_entries',
      where: 'version_id=?',
      whereArgs: [versionId],
    ),
    'sections': await txn.rawQuery(
      'SELECT s.*, g.name AS grade_name, g.position AS grade_position FROM sections s JOIN grades g ON g.id=s.grade_id',
    ),
    'requirements': await txn.query('section_subject_requirements'),
    'subjects': await txn.query('subjects'),
    'teachers': await txn.query('teachers'),
    'qualifications': await txn.query('teacher_subjects'),
    'teacherGrades': await txn.query('teacher_grades'),
    'teacherSubjectGrades': await txn.query('teacher_subject_grades'),
    'days': await txn.query('school_days'),
    'slots': await txn.query('time_slots'),
    'subjectBlockedSlots': await txn.query('subject_blocked_slots'),
    'availability': await txn.query('teacher_availability'),
  };

  /// Read, validate, clone an approved version if needed, and swap atomically.
  Future<void> swapLessons({
    required int yearId,
    required Map<String, Object?> first,
    required Map<String, Object?> second,
  }) async {
    final db = await database;
    final token = await db.transaction((txn) async {
      final versions = await txn.query(
        'timetable_versions',
        where: 'academic_year_id=? AND is_active=1',
        whereArgs: [yearId],
      );
      if (versions.length != 1 ||
          versions.single['id'] != first['version_id'] ||
          first['version_id'] != second['version_id']) {
        throw StateError(
          'تغيرت النسخة النشطة؛ حدّث الجدول وأعد اختيار الحصتين.',
        );
      }
      final version = versions.single['id'] as int;
      final data = await _swapData(txn, version);
      final entries = (data['entries'] as List).cast<Map<String, Object?>>();
      for (final expected in [first, second]) {
        final current = entries
            .where((r) => r['id'] == expected['id'])
            .toList();
        if (current.length != 1 ||
            LessonSwapService.identity.any(
              (k) => current.single[k] != expected[k],
            )) {
          throw StateError('تغيرت إحدى الحصتين؛ حدّث الجدول وأعد الاختيار.');
        }
      }
      final reason = const LessonSwapService().validate(data, first, second);
      if (reason != null) throw StateError(reason);
      final editable = (await _editableVersion(txn, yearId))!;
      final originals = <Map<String, Object?>>[];
      final after = <Map<String, Object?>>[];
      for (final pair in [(first, second), (second, first)]) {
        final current = (await txn.query(
          'timetable_entries',
          where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?',
          whereArgs: [
            editable,
            pair.$1['section_id'],
            pair.$1['day_id'],
            pair.$1['slot_id'],
          ],
        )).single;
        originals.add(Map.from(current));
        after.add({
          ...current,
          for (final key in LessonSwapService.payload) key: pair.$2[key],
        });
      }
      await _validateTeacherAssignments(txn, after);
      await _validateSeventhLessonPolicy(txn, after);
      for (final row in after) {
        await txn.update(
          'timetable_entries',
          {for (final k in LessonSwapService.payload) k: row[k]},
          where: 'id=?',
          whereArgs: [row['id']],
        );
      }
      final stamp = DateTime.now().toIso8601String();
      await txn.update(
        'timetable_versions',
        {'status': 'قيد التعديل', 'updated_at': stamp},
        where: 'id=?',
        whereArgs: [editable],
      );
      await txn.insert('audit_log', {
        'action': 'تبديل حصتين',
        'entity': 'timetable_versions',
        'entity_id': editable,
        'details': jsonEncode({'before': originals, 'after': after}),
        'created_at': stamp,
      });
      return <String, Object?>{
        'beforeRows': originals,
        'afterRows': after,
        'stamp': stamp,
      };
    });
    _manualUndo = token;
  }

  /// The seventh lesson is restricted to sixth grade on Sunday and is allowed
  /// only when weekly demand exceeds six lessons per active school day. This
  /// database-transaction guard prevents UI paths from bypassing the policy.
  Future<void> _validateSeventhLessonPolicy(
    DatabaseExecutor txn,
    List<Map<String, Object?>> candidateEntries,
  ) async {
    if (candidateEntries.isEmpty) return;
    final lessonSlots = await txn.query(
      'time_slots',
      columns: ['id', 'position'],
      where: 'kind=? AND is_available=?',
      whereArgs: ['lesson', 1],
      orderBy: 'position ASC',
    );
    if (lessonSlots.isEmpty) return;
    final rankBySlotId = <int, int>{
      for (var index = 0; index < lessonSlots.length; index++)
        _dbInt(lessonSlots[index]['id']): index,
    };
    final activeDays = await txn.query(
      'school_days',
      columns: ['id', 'name', 'position', 'is_active'],
      where: 'is_active=1',
      orderBy: 'position ASC',
    );
    for (final entry in candidateEntries) {
      final slotId = _dbInt(entry['slot_id']);
      final rank = rankBySlotId[slotId];
      if (rank == null) continue;
      if (rank > 6) {
        throw StateError(
          'لا يسمح بإضافة حصة ثامنة أو بعدها؛ الحد الأقصى سبع حصص في اليوم.',
        );
      }
      final sectionId = _dbInt(entry['section_id']);
      // Existing invalid seventh-period rows are not grandfathered: they must be
      // moved to an allowed cell or deleted before they can be saved/approved.
      final sectionRows = await txn.rawQuery(
        'SELECT s.max_daily_lessons, s.daily_limits_json, g.name AS grade_name, g.position AS grade_position '
        'FROM sections s INNER JOIN grades g ON g.id=s.grade_id WHERE s.id=? LIMIT 1',
        [sectionId],
      );
      final section = sectionRows.isEmpty
          ? <String, Object?>{'max_daily_lessons': 6}
          : Map<String, Object?>.from(sectionRows.first);
      final dayRows = await txn.query(
        'school_days',
        columns: ['id', 'name', 'position', 'is_active'],
        where: 'id=?',
        whereArgs: [_dbInt(entry['day_id'])],
        limit: 1,
      );
      final required =
          Sqflite.firstIntValue(
            await txn.rawQuery(
              'SELECT COALESCE(SUM(weekly_lessons),0) FROM section_subject_requirements WHERE section_id=?',
              [sectionId],
            ),
          ) ??
          0;
      final allowedLimit = dayRows.isEmpty ? 0 :
          SchoolTimetablePolicy.dailyLimit(
            section: section, day: dayRows.first,
            activeDays: activeDays, lessonSlots: lessonSlots,
            weeklyDemand: required,
          );
      if (rank >= allowedLimit) {
        throw StateError(
          'الحصة رقم ${rank + 1} خارج العدد المخصص لهذا الصف واليوم. '
          'الحد الحالي $allowedLimit؛ عدّله من إعداد الجدول > '
          'الحصص المخصصة لكل صف أو اختر فترة أخرى.',
        );
      }
    }
  }

  int _dbInt(Object? value, {int fallback = 0}) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }

  Future<void> saveEntry(Map<String, Object?> values, {int? entryId}) async {
    final db = await database;
    final undo = await db.transaction((txn) async {
      Map<String, Object?>? before;
      Map<String, Object?> toValidate = Map<String, Object?>.from(values);
      if (entryId != null) {
        final current = await txn.query(
          'timetable_entries',
          where: 'id=?',
          whereArgs: [entryId],
          limit: 1,
        );
        if (current.isEmpty)
          throw StateError(
            'الحصة المطلوب تعديلها غير موجودة؛ لم يتم حفظ أي تغيير.',
          );
        before = Map<String, Object?>.from(current.first);
        // Validate the merged row, not only the fields supplied by a caller. This
        // closes the partial-update bypass where teacher_id could be omitted.
        if (_dbInt(current.first['is_locked']) == 1 &&
            [
              'section_id',
              'subject_id',
              'teacher_id',
              'day_id',
              'slot_id',
              'room_id',
            ].any(
              (key) =>
                  values.containsKey(key) && values[key] != current.first[key],
            )) {
          throw StateError('الحصة مثبتة. أزل القفل عنها قبل تغييرها.');
        }
        toValidate = Map<String, Object?>.from(current.first)..addAll(values);
      }
      await _validateTeacherAssignments(txn, [toValidate]);
      await _validateSeventhLessonPolicy(txn, [toValidate]);
      if (entryId == null) {
        await txn.insert(
          'timetable_entries',
          values,
          conflictAlgorithm: ConflictAlgorithm.abort,
        );
      } else {
        final updated = await txn.update(
          'timetable_entries',
          values,
          where: 'id=?',
          whereArgs: [entryId],
        );
        if (updated != 1)
          throw StateError('تعذر تحديث الحصة المطلوبة؛ لم يتم حفظ أي تغيير.');
      }
      final stamp = DateTime.now().toIso8601String();
      await txn.update(
        'timetable_versions',
        {'status': 'قيد التعديل', 'updated_at': stamp},
        where: 'id=?',
        whereArgs: [toValidate['version_id']],
      );
      return before == null
          ? null
          : <String, Object?>{
              'before': before,
              'after': (await txn.query(
                'timetable_entries',
                where: 'id=?',
                whereArgs: [entryId],
              )).single,
              'stamp': stamp,
            };
    });
    _manualUndo = undo;
    await log(
      entryId == null ? 'إضافة حصة' : 'تعديل حصة',
      'timetable_entries',
      entryId,
      jsonEncode(values),
    );
  }

  Future<void> setEntryLock({
    required int yearId,
    required int sectionId,
    required int dayId,
    required int slotId,
    required bool locked,
  }) async {
    final versionId = await ensureEditableActiveVersion(yearId);
    if (versionId == null) throw StateError('لا توجد نسخة نشطة قابلة للتعديل.');
    final db = await database;
    final undo = await db.transaction((txn) async {
      final versions = await txn.query(
        'timetable_versions',
        where: 'id=? AND academic_year_id=? AND is_active=1',
        whereArgs: [versionId, yearId],
      );
      if (versions.isEmpty || versions.first['status'] == 'معتمد') {
        throw StateError('تغيرت النسخة النشطة؛ حدّث الجدول وأعد المحاولة.');
      }
      final originals = await txn.query(
        'timetable_entries',
        where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?',
        whereArgs: [versionId, sectionId, dayId, slotId],
      );
      if (originals.length != 1) throw StateError('الحصة غير موجودة.');
      final count = await txn.update(
        'timetable_entries',
        {'is_locked': locked ? 1 : 0},
        where: 'version_id=? AND section_id=? AND day_id=? AND slot_id=?',
        whereArgs: [versionId, sectionId, dayId, slotId],
      );
      if (count != 1)
        throw StateError('تعذر العثور على الحصة المطلوب تثبيتها.');
      final now = DateTime.now().toIso8601String();
      await txn.update(
        'timetable_versions',
        {'updated_at': now},
        where: 'id=?',
        whereArgs: [versionId],
      );
      await txn.insert('audit_log', {
        'action': locked ? 'تثبيت حصة' : 'إزالة تثبيت حصة',
        'entity': 'timetable_versions',
        'entity_id': versionId,
        'details': jsonEncode({
          'section_id': sectionId,
          'day_id': dayId,
          'slot_id': slotId,
        }),
        'created_at': now,
      });
      return <String, Object?>{
        'before': Map<String, Object?>.from(originals.single),
        'after': {...originals.single, 'is_locked': locked ? 1 : 0},
        'stamp': now,
      };
    });
    _manualUndo = undo;
  }

  Future<void> undoLastManualEdit() async {
    final token = _manualUndo;
    if (token == null) throw StateError('لا يوجد تعديل قابل للتراجع.');
    final beforeRows = token['beforeRows'] == null
        ? [Map<String, Object?>.from(token['before'] as Map)]
        : (token['beforeRows'] as List).cast<Map<String, Object?>>();
    final afterRows = token['afterRows'] == null
        ? [Map<String, Object?>.from(token['after'] as Map)]
        : (token['afterRows'] as List).cast<Map<String, Object?>>();
    final before = beforeRows.first;
    final after = afterRows.first;
    final db = await database;
    await db.transaction((txn) async {
      final versions = await txn.query(
        'timetable_versions',
        where: 'id=? AND is_active=1',
        whereArgs: [after['version_id']],
      );
      if (versions.length != 1 ||
          versions.single['updated_at'] != token['stamp']) {
        throw StateError('تغير الجدول بعد هذا التعديل؛ لم يُنفّذ التراجع.');
      }
      for (final expected in afterRows) {
        final current = await txn.query(
          'timetable_entries',
          where: 'id=?',
          whereArgs: [expected['id']],
        );
        if (current.length != 1 ||
            expected.keys.any((k) => current.single[k] != expected[k])) {
          throw StateError('تغيرت الحصة بعد التعديل؛ لم يُنفّذ التراجع.');
        }
      }
      final board = await txn.query(
        'timetable_entries',
        where: 'version_id=?',
        whereArgs: [after['version_id']],
      );
      final proposed = [
        for (final row in board)
          beforeRows.where((r) => r['id'] == row['id']).firstOrNull ?? row,
      ];
      Future<List<ConflictIssue>> scan(List<Map<String, Object?>> rows) async =>
          const ConflictDetectionService().scan(
            entries: rows,
            sections: await txn.rawQuery(
              'SELECT s.*, g.name AS grade_name FROM sections s JOIN grades g ON g.id=s.grade_id',
            ),
            requirements: await txn.query('section_subject_requirements'),
            teachers: await txn.query('teachers'),
            qualifications: await txn.query('teacher_subjects'),
            teacherGrades: await txn.query('teacher_grades'),
            teacherSubjectGrades: await txn.query('teacher_subject_grades'),
            days: await txn.query('school_days'),
            slots: await txn.query('time_slots'),
            subjectBlockedSlots: await txn.query('subject_blocked_slots'),
            teacherAvailability: await txn.query('teacher_availability'),
          );
      String issueKey(ConflictIssue i) =>
          '${i.type}:${i.message}:${i.sectionId}:${i.teacherId}:${i.subjectId}:${i.dayId}:${i.slotId}';
      final baseline = (await scan(board)).map(issueKey).toSet();
      final newIssues = (await scan(proposed)).where(
        (i) =>
            i.type != 'تكرار توقيت المادة في أيام متتالية' &&
            !baseline.contains(issueKey(i)),
      );
      if (newIssues.isNotEmpty)
        throw StateError(
          'التراجع يخالف الشروط الحالية: ${newIssues.first.message}',
        );
      await _validateTeacherAssignments(txn, beforeRows);
      await _validateSeventhLessonPolicy(txn, beforeRows);
      for (final row in beforeRows) {
        await txn.update(
          'timetable_entries',
          row,
          where: 'id=?',
          whereArgs: [row['id']],
        );
      }
      final now = DateTime.now().toIso8601String();
      await txn.update(
        'timetable_versions',
        {'updated_at': now},
        where: 'id=?',
        whereArgs: [before['version_id']],
      );
      await txn.insert('audit_log', {
        'action': 'التراجع عن تعديل حصة',
        'entity': 'timetable_entries',
        'entity_id': before['id'],
        'details': 'استعادة آخر تعديل يدوي بعد فحص الشروط',
        'created_at': now,
      });
    });
    if (identical(_manualUndo, token)) _manualUndo = null;
  }

  /// يحفظ نتيجة الجدولة كنسخة جديدة ولا يمس النسخة القديمة.
  Future<int> saveAsNewVersion({
    required int yearId,
    required String name,
    required List<Map<String, Object?>> entries,
    String notes = 'نتيجة الجدولة التلقائية',
    bool activate = true,
    bool requireComplete = false,
    int? expectedActiveVersionId,
    List<Map<String, Object?>>? expectedOriginalEntries,
    bool validateRelativeConflicts = false,
  }) async {
    final db = await database;
    final now = DateTime.now().toIso8601String();
    return db.transaction((txn) async {
      // Optimistic lock: do not activate a repair based on a stale timetable.
      if (expectedActiveVersionId != null) {
        final active = await txn.query(
          'timetable_versions', columns: ['id'],
          where: 'academic_year_id=? AND is_active=1', whereArgs: [yearId],
        );
        if (active.length != 1 || active.single['id'] != expectedActiveVersionId) {
          throw StateError('تغيرت النسخة النشطة أثناء المعاينة؛ أعد حساب البدائل.');
        }
        if (expectedOriginalEntries != null) {
          final actual = await txn.query('timetable_entries',
            where: 'version_id=?', whereArgs: [expectedActiveVersionId],
            orderBy: 'id');
          final expected = expectedOriginalEntries.toList()
            ..sort((a, b) => (a['id'] as int).compareTo(b['id'] as int));
          const keys = ['id', 'section_id', 'subject_id', 'teacher_id',
            'room_id', 'day_id', 'slot_id', 'is_locked'];
          if (actual.length != expected.length ||
              List.generate(actual.length, (i) => i).any((i) =>
                keys.any((key) => actual[i][key] != expected[i][key]))) {
            throw StateError('تغيرت حصص الجدول أو الأقفال أثناء المعاينة؛ أعد الفحص دون حفظ.');
          }
        }
      }
      if (validateRelativeConflicts) {
        if (expectedActiveVersionId == null || expectedOriginalEntries == null) {
          throw StateError('يلزم تحديد النسخة الأصلية للإصلاح الآمن.');
        }
        final original = await txn.query('timetable_entries',
          where: 'version_id=?', whereArgs: [expectedActiveVersionId]);
        // Pins always retain their exact payload and cell.
        const pinnedKeys = ['section_id','subject_id','teacher_id',
          'room_id','day_id','slot_id'];
        if (!original.where((e) => e['is_locked'] == 1).every((pin) =>
          entries.any((entry) => pinnedKeys.every((key) => pin[key] == entry[key])))) {
          throw StateError('الحل يمس حصة مقفلة؛ لم يُحفظ.');
        }
        final sections = await txn.rawQuery(
          'SELECT s.*, g.name AS grade_name FROM sections s JOIN grades g ON g.id=s.grade_id');
        final requirements = await txn.query('section_subject_requirements');
        final teachers = await txn.query('teachers');
        final qualifications = await txn.query('teacher_subjects');
        final teacherGrades = await txn.query('teacher_grades');
        final teacherSubjectGrades = await txn.query('teacher_subject_grades');
        final days = await txn.query('school_days');
        final slots = await txn.query('time_slots');
        final blockedSlots = await txn.query('subject_blocked_slots');
        final availability = await txn.query('teacher_availability');
        List<ConflictIssue> inspect(List<Map<String, Object?>> board) =>
            const ConflictDetectionService().scan(
              entries: board, sections: sections, requirements: requirements,
              teachers: teachers, qualifications: qualifications,
              teacherGrades: teacherGrades, teacherSubjectGrades: teacherSubjectGrades,
              days: days, slots: slots, subjectBlockedSlots: blockedSlots,
              teacherAvailability: availability,
            );
        Map<String, int> count(List<ConflictIssue> issues) {
          final counts = <String, int>{};
          for (final issue in issues) {
            final key = '${issue.type}|${issue.sectionId}|${issue.teacherId}|${issue.subjectId}|${issue.dayId}|${issue.slotId}';
            counts[key] = (counts[key] ?? 0) + 1;
          }
          return counts;
        }
        final beforeIssues = inspect(original);
        final afterIssues = inspect(entries);
        final before = count(beforeIssues.where((i) => i.severity == 'خطأ مانع').toList());
        final after = count(afterIssues.where((i) => i.severity == 'خطأ مانع').toList());
        final beforeTotal = before.values.fold<int>(0, (a,b) => a+b);
        final afterTotal = after.values.fold<int>(0, (a,b) => a+b);
        if (afterTotal >= beforeTotal || after.entries.any((e) => e.value > (before[e.key] ?? 0))) {
          throw StateError('أُعيد فحص القيود داخل قاعدة البيانات؛ الحل لا يقلل التعارضات دون إضافة تعارض جديد. لم يُحفظ.');
        }
        // Warnings about limits and lesson patterns may not worsen either.
        bool protectedWarning(ConflictIssue i) => i.severity == 'تحذير' &&
            i.type != 'تكرار توقيت المادة في أيام متتالية';
        final oldWarnings = count(beforeIssues.where(protectedWarning).toList());
        final newWarnings = count(afterIssues.where(protectedWarning).toList());
        if (newWarnings.entries.any((e) => e.value > (oldWarnings[e.key] ?? 0))) {
          throw StateError('الإصلاح يضيف تحذيراً جديداً في النصاب أو توزيع الحصص؛ لم يُحفظ.');
        }
      }
      if (requireComplete) {
        final active = await txn.query(
          'timetable_versions',
          columns: ['id'],
          where: 'academic_year_id=? AND is_active=1',
          whereArgs: [yearId],
        );
        if (expectedActiveVersionId != null &&
            (active.length != 1 ||
                active.single['id'] != expectedActiveVersionId)) {
          throw StateError('تغير الجدول النشط أثناء البحث؛ لم يُستبدل الجدول.');
        }
        final issues = const ConflictDetectionService()
            .scan(
              entries: entries,
              sections: await txn.rawQuery(
                'SELECT s.*, g.name AS grade_name FROM sections s JOIN grades g ON g.id=s.grade_id',
              ),
              requirements: await txn.query('section_subject_requirements'),
              teachers: await txn.query('teachers'),
              qualifications: await txn.query('teacher_subjects'),
              teacherGrades: await txn.query('teacher_grades'),
              teacherSubjectGrades: await txn.query('teacher_subject_grades'),
              days: await txn.query('school_days'),
              slots: await txn.query('time_slots'),
              subjectBlockedSlots: await txn.query('subject_blocked_slots'),
              teacherAvailability: await txn.query('teacher_availability'),
            )
            .where(
              (issue) => issue.type != 'تكرار توقيت المادة في أيام متتالية',
            )
            .toList();
        if (issues.isNotEmpty) {
          throw StateError(
            'لم يُستبدل الجدول لأن الفحص وقت الحفظ وجد: ${issues.take(5).map((i) => i.message).join('\n')}',
          );
        }
        if (active.isNotEmpty) {
          final pins = await txn.query(
            'timetable_entries',
            where: 'version_id=? AND is_locked=1',
            whereArgs: [active.first['id']],
          );
          if (!pins.every(
            (pin) => entries.any(
              (entry) => [
                'section_id',
                'subject_id',
                'teacher_id',
                'day_id',
                'slot_id',
                'room_id',
              ].every((key) => pin[key] == entry[key]),
            ),
          )) {
            throw StateError(
              'تغير تثبيت الحصص أثناء البحث؛ لم يُستبدل الجدول.',
            );
          }
        }
      }
      // افحص كامل الحزمة قبل إنشاء النسخة حتى لا يبقى نصف حفظ إذا وُجد إسناد مخالف.
      await _validateTeacherAssignments(txn, entries);
      await _validateSeventhLessonPolicy(txn, entries);
      final versionId = await txn.insert('timetable_versions', {
        'academic_year_id': yearId,
        'name': name,
        'status': 'مسودة',
        'notes': notes,
        'is_active': 0,
        'created_at': now,
        'updated_at': now,
      });
      for (final entry in entries) {
        await txn.insert('timetable_entries', {
          ...entry,
          'version_id': versionId,
          'created_at': now,
        });
      }
      // A partial draft must never replace the currently active timetable.
      // Only an explicitly approved full-result workflow should request activation.
      if (activate) {
        await txn.update(
          'timetable_versions',
          {'is_active': 0},
          where: 'academic_year_id=?',
          whereArgs: [yearId],
        );
        await txn.update(
          'timetable_versions',
          {'is_active': 1},
          where: 'id=?',
          whereArgs: [versionId],
        );
      }
      await txn.insert('audit_log', {
        'action': 'إنشاء نسخة',
        'entity': 'timetable_versions',
        'entity_id': versionId,
        'details':
            '${activate ? 'تفعيل' : 'حفظ كمسودة غير نشطة'} $name بعد إنشاء ${entries.length} حصة',
        'created_at': now,
      });
      return versionId;
    });
  }

  Future<Map<String, Object?>> summary() async {
    final db = await database;
    final yearId = await activeYearId();
    final versionId = await activeVersionId(yearId);
    final result = <String, Object?>{};
    for (final item in [
      ['grades', 'عدد الصفوف'],
      ['sections', 'عدد الشعب'],
      ['subjects', 'عدد المواد'],
      ['teachers', 'عدد المعلمين'],
    ]) {
      final count =
          Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM ${item[0]}'),
          ) ??
          0;
      result[item[1]] = count;
    }
    final required =
        Sqflite.firstIntValue(
          await db.rawQuery(
            'SELECT COALESCE(SUM(weekly_lessons),0) FROM section_subject_requirements',
          ),
        ) ??
        0;
    final distributed = versionId == null
        ? 0
        : (Sqflite.firstIntValue(
                await db.rawQuery(
                  'SELECT COUNT(*) FROM timetable_entries WHERE version_id=?',
                  [versionId],
                ),
              ) ??
              0);
    result['الحصص المطلوبة'] = required;
    result['الحصص الموزعة'] = distributed;
    result['الحصص المتبقية'] = (required - distributed) < 0
        ? 0
        : required - distributed;
    result['نسبة الاكتمال'] = required == 0
        ? 0.0
        : (distributed / required).clamp(0.0, 1.0);
    result['العام الدراسي'] = (await activeYear())?['name'] ?? 'غير محدد';
    result['version_id'] = versionId;
    return result;
  }

  Future<Map<String, Object?>> exportAll() async {
    final db = await database;
    final data = <String, Object?>{
      'format': 'iraqi_school_timetable_backup',
      'schema_version': schemaVersion,
      'exported_at': DateTime.now().toIso8601String(),
      'tables': <String, Object?>{},
    };
    final tables = data['tables'] as Map<String, Object?>;
    for (final table in backupTables) {
      tables[table] = await db.query(table);
    }
    return data;
  }

  Future<void> importAll(Map<String, Object?> backup) async {
    final sourceVersion = backup['schema_version'];
    if (backup['format'] != 'iraqi_school_timetable_backup' ||
        (sourceVersion != schemaVersion &&
            sourceVersion != 9 &&
            sourceVersion != 8 &&
            sourceVersion != 7 &&
            sourceVersion != 6 &&
            sourceVersion != 5 &&
            sourceVersion != 4 &&
            sourceVersion != 3 &&
            sourceVersion != 2 &&
            sourceVersion != 1) ||
        backup['tables'] is! Map) {
      throw const FormatException(
        'ملف النسخة الاحتياطية غير معروف أو غير متوافق مع إصدار قاعدة البيانات.',
      );
    }
    final source = (backup['tables'] as Map).cast<String, dynamic>();
    const newTables = {
      'teacher_grades',
      'subject_blocked_slots',
      'teacher_subject_grades',
    };
    for (final table in backupTables) {
      if (source[table] is! List) {
        if ((sourceVersion == 1 ||
                sourceVersion == 2 ||
                sourceVersion == 3 ||
                sourceVersion == 4) &&
            newTables.contains(table)) {
          source[table] = <Object?>[];
        } else {
          throw FormatException('الجدول $table مفقود من النسخة الاحتياطية.');
        }
      }
    }
    final db = await database;
    // جميع خطوات الاستعادة داخل معاملة واحدة: إما استعادة كاملة أو تراجع كامل.
    await db.transaction((txn) async {
      for (final table in backupTables.reversed) {
        await txn.delete(table);
      }
      for (final table in backupTables) {
        final records = (source[table] as List).cast<Map>();
        for (final record in records) {
          await txn.insert(
            table,
            record.cast<String, Object?>(),
            conflictAlgorithm: ConflictAlgorithm.abort,
          );
        }
      }
      // Backups from older versions may contain the former normal limit of 7.
      // Normalize it after restore; the sixth-grade Sunday exception is computed
      // from actual weekly demand, not from a stored daily limit of seven.
      await txn.execute(
        'UPDATE grades SET max_daily_lessons=6 WHERE max_daily_lessons>6',
      );
      await txn.execute(
        'UPDATE sections SET max_daily_lessons=6 WHERE max_daily_lessons>6',
      );
    });
  }
}
