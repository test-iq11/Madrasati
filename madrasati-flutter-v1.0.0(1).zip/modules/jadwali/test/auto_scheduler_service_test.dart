import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_timetable/services/auto_scheduler_service.dart';

void main() {
  test('لا يعتبر اكتمال عدد الحصص اكتمالاً عند وجود مشكلة في تغطية الأيام', () {
    final result = SchedulerResult(
      placements: <Map<String, Object?>>[
        for (var i = 0; i < 6; i++)
          <String, Object?>{
            'section_id': 1,
            'subject_id': 2,
            'teacher_id': 4,
            'day_id': i == 5 ? 4 : i + 1,
            'slot_id': i + 1,
          },
      ],
      unscheduled: const <String>[],
      requestedCount: 6,
      exploredNodes: 20,
      searchLimitReached: false,
      dailySpreadIssues: const <String>[
        'الصف الخامس الابتدائي، الشعبة أ، مادة الرياضيات: يوم الخميس بلا حصة.',
      ],
    );

    expect(result.placements, hasLength(6));
    expect(result.unscheduled, isEmpty);
    expect(result.complete, isFalse,
        reason: 'عدد الحصص وحده لا يكفي إذا كانت تغطية أيام الدوام غير مستوفاة');
  });

  const scheduler = AutoSchedulerService(nodeLimit: 5000);

  test('يفضل اختلاف فترة المادة بين يومين متتاليين عند وجود بدائل', () {
    final result = const AutoSchedulerService(nodeLimit: 20000).generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'اللغة العربية', 'weekly_lessons': 2, 'max_daily_lessons': 2, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم العربية', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 4},
      ],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.complete, isTrue);
    final sunday = result.placements.singleWhere((p) => p['day_id'] == 1);
    final monday = result.placements.singleWhere((p) => p['day_id'] == 2);
    expect(sunday['slot_id'], isNot(monday['slot_id']));
  });

  test('يوازن حصص الشعبة على أيام الأسبوع بدلاً من تكديسها في اليوم الأول', () {
    final result = const AutoSchedulerService(nodeLimit: 10000).generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 4},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'العربية', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 1, 'subject_id': 3, 'subject_name': 'الرياضيات', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم العربية', 'weekly_load': 10, 'max_daily_lessons': 4, 'max_consecutive_lessons': 0},
        {'id': 6, 'name': 'معلم الرياضيات', 'weekly_load': 10, 'max_daily_lessons': 4, 'max_consecutive_lessons': 0},
      ],
      qualifications: [
        {'teacher_id': 5, 'subject_id': 2},
        {'teacher_id': 6, 'subject_id': 3},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements.map((placement) => placement['day_id']).toSet(), hasLength(2));
  });

  test('يوزع حصتين على يومين دون تكرار المادة في اليوم نفسه', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'grade_id': 1, 'section_name': 'أ', 'max_daily_lessons': 6}],
      requirements: [{'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 2, 'max_daily_lessons': 2, 'allow_same_day': 0}],
      teachers: [{'id': 5, 'name': 'معلم الرياضيات', 'weekly_load': 20, 'max_daily_lessons': 5, 'max_consecutive_lessons': 4}],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}, {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1}],
      slots: [{'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1}],
    );
    expect(result.complete, isTrue);
    expect(result.placements, hasLength(2));
    expect(result.placements.map((e) => e['day_id']).toSet(), hasLength(2));
    expect(result.placements.map((e) => e['teacher_id']).toSet(), equals({5}));
  });


  test('يوزّع المعلم المؤهل تلقائياً على أكثر من شعبة دون تعارض زمني', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 2, 'grade_name': 'الثاني', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 2, 'max_daily_lessons': 2, 'allow_same_day': 0},
        {'section_id': 2, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 2, 'max_daily_lessons': 2, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم الرياضيات', 'weekly_load': 4, 'max_daily_lessons': 2, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.complete, isTrue);
    expect(result.placements, hasLength(4));
    expect(result.placements.map((e) => e['teacher_id']).toSet(), equals({5}));
    expect(result.placements.map((e) => e['section_id']).toSet(), equals({1, 2}));
    final teacherCells = result.placements.map((e) => '${e['teacher_id']}:${e['day_id']}:${e['slot_id']}').toList();
    expect(teacherCells.toSet().length, teacherCells.length);
  });

  test('لا يدّعي اكتمال الجدول عندما لا يوجد معلم مؤهل', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'section_name': 'أ'}],
      requirements: [{'section_id': 1, 'subject_id': 2, 'subject_name': 'العلوم', 'weekly_lessons': 1}],
      teachers: [{'id': 5, 'name': 'معلم'}],
      qualifications: [],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [{'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1}],
    );
    expect(result.complete, isFalse);
    expect(result.placements, isEmpty);
    expect(result.unscheduled, isNotEmpty);
  });
  test('يشرح عند تجاوز متطلبات الشعبة عدد الخانات المتاحة ويولد التوزيع الممكن', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'stage_name': 'الابتدائية', 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 1},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 4, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 1, 'subject_id': 3, 'subject_name': 'العلوم', 'weekly_lessons': 4, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم مؤهل', 'weekly_load': 10, 'max_daily_lessons': 1, 'max_consecutive_lessons': 0},
        {'id': 6, 'name': 'معلم ثانٍ', 'weekly_load': 10, 'max_daily_lessons': 1, 'max_consecutive_lessons': 0},
      ],
      qualifications: [
        {'teacher_id': 5, 'subject_id': 2},
        {'teacher_id': 6, 'subject_id': 3},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.placements, hasLength(5));
    expect(result.complete, isFalse);
    expect(result.unscheduled.any((item) => item.contains('الصف الأول الابتدائي') && item.contains('المتاح 5 خانة')), isTrue);
  });
  test('يحترم صفوف المعلم ويعيد استخدام المعلم عبر الصفوف المسموح بها', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 101, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 102, 'grade_name': 'الثاني', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 1},
        {'section_id': 2, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 1},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم الصف الأول', 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0},
        {'id': 6, 'name': 'معلم الصف الثاني', 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}, {'teacher_id': 6, 'subject_id': 2}],
      teacherGrades: [{'teacher_id': 5, 'grade_id': 101}, {'teacher_id': 6, 'grade_id': 102}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.complete, isTrue);
    expect(result.placements.where((e) => e['section_id'] == 1).single['teacher_id'], 5);
    expect(result.placements.where((e) => e['section_id'] == 2).single['teacher_id'], 6);
  });


  test('يحدد الصفوف المسموحة لكل مادة بشكل مستقل للمعلم نفسه', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 101, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 102, 'grade_name': 'الثاني', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 3, 'grade_id': 103, 'grade_name': 'الثالث', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الإنكليزية', 'weekly_lessons': 1},
        {'section_id': 2, 'subject_id': 2, 'subject_name': 'الإنكليزية', 'weekly_lessons': 1},
        {'section_id': 3, 'subject_id': 2, 'subject_name': 'الإنكليزية', 'weekly_lessons': 1},
      ],
      teachers: [{'id': 5, 'name': 'جليل', 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0}],
      qualifications: [{'teacher_id': 5, 'subject_id': 2}],
      teacherSubjectGrades: [
        {'teacher_id': 5, 'subject_id': 2, 'grade_id': 101},
        {'teacher_id': 5, 'subject_id': 2, 'grade_id': 102},
      ],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
        {'id': 3, 'name': 'الثالثة', 'position': 2, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.placements, hasLength(2));
    expect(result.placements.map((p) => p['section_id']).toSet(), equals({1, 2}));
    expect(result.unscheduled, isNotEmpty);
  });

  test('لا يمنح المعلم صلاحية ضمنية لصف مادة عند وجود قواعد حديثة', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 5},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 10, 'subject_name': 'العلوم', 'weekly_lessons': 1},
      ],
      teachers: [
        {'id': 7, 'name': 'معلم غير مضبوط الصفوف', 'weekly_load': 5, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 7, 'subject_id': 10}],
      // وجود قاعدة حديثة لزوج آخر يجب أن يمنع اعتبار غياب القاعدة إذناً عاماً.
      teacherSubjectGrades: [{'teacher_id': 9, 'subject_id': 11, 'grade_id': 1}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [{'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1}],
    );

    expect(result.placements, isEmpty);
    expect(result.complete, isFalse);
    expect(result.unscheduled.single, contains('لا يوجد معلم مسموح له'));
  });

  test('لا يضع مادة في فترة حظرها المستخدم', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 5}],
      requirements: [{'section_id': 1, 'subject_id': 2, 'subject_name': 'الأخلاقية', 'weekly_lessons': 1}],
      teachers: [{'id': 7, 'name': 'معلم المادة', 'weekly_load': 5, 'max_daily_lessons': 5}],
      qualifications: [{'teacher_id': 7, 'subject_id': 2}],
      subjectBlockedSlots: [{'subject_id': 2, 'slot_id': 2}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements.single['slot_id'], 1);
  });


  test('حارس نهائي يمنع إسناد العربية لطالب في الرابع مع السماح له بالرياضيات في الرابع', () {
    final result = scheduler.generate(
      sections: [
        {'id': 6, 'grade_id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 9, 'grade_id': 4, 'grade_name': 'الرابع الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 6, 'subject_id': 2, 'subject_name': 'اللغة العربية', 'weekly_lessons': 1},
        {'section_id': 9, 'subject_id': 2, 'subject_name': 'اللغة العربية', 'weekly_lessons': 1},
        {'section_id': 9, 'subject_id': 4, 'subject_name': 'الرياضيات', 'weekly_lessons': 1},
      ],
      teachers: [
        {'id': 4, 'name': 'طالب', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
        {'id': 5, 'name': 'معلم عربي للرابع', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
      ],
      qualifications: [
        {'teacher_id': 4, 'subject_id': 2},
        {'teacher_id': 4, 'subject_id': 4},
        {'teacher_id': 5, 'subject_id': 2},
      ],
      teacherSubjectGrades: [
        {'teacher_id': 4, 'subject_id': 2, 'grade_id': 1},
        {'teacher_id': 4, 'subject_id': 4, 'grade_id': 3},
        {'teacher_id': 4, 'subject_id': 4, 'grade_id': 4},
        {'teacher_id': 5, 'subject_id': 2, 'grade_id': 4},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.placements.any((p) => p['teacher_id'] == 4 && p['subject_id'] == 2 && p['section_id'] == 9), isFalse);
    expect(result.placements.any((p) => p['teacher_id'] == 4 && p['subject_id'] == 2 && p['section_id'] == 6), isTrue);
    expect(result.placements.any((p) => p['teacher_id'] == 4 && p['subject_id'] == 4 && p['section_id'] == 9), isTrue);
  });


  test('يتجاوز الطلب المستحيل حسابياً ويجدول الممكن مع تفسير الحصة المتبقية', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        {'id': 1, 'grade_id': 6, 'grade_name': 'السادس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 7},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'اللغة العربية', 'weekly_lessons': 6, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 4, 'name': 'طالب', 'weekly_load': 6, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 4, 'subject_id': 2}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    // One lesson per day over five days can only yield five lessons. The
    // scheduler must not waste its search limit trying to force all six.
    expect(result.placements, hasLength(5));
    expect(result.complete, isFalse);
    expect(result.unscheduled, hasLength(1));
    expect(result.unscheduled.single, contains('يسمح بحد أقصى 5 حصة أسبوعياً'));
    expect(result.unscheduled.single, contains('المتبقي 1'));
  });


  test('يكمل ست حصص عربية خلال خمسة أيام بوضع الحصة الإضافية في السادسة دون تعارض', () {
    final result = const AutoSchedulerService(nodeLimit: 20000).generate(
      sections: [
        {'id': 1, 'grade_id': 6, 'grade_name': 'السادس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'اللغة العربية', 'weekly_lessons': 6, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 4, 'name': 'معلم العربية', 'weekly_load': 8, 'max_daily_lessons': 6, 'max_consecutive_lessons': 6},
      ],
      qualifications: [{'teacher_id': 4, 'subject_id': 2}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        for (var i = 1; i <= 6; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements, hasLength(6));
    expect(result.placements.map((p) => p['day_id']).toSet(), equals({1, 2, 3, 4, 5}),
        reason: 'المادة التي تتجاوز خمس حصص يجب أن تظهر مرة واحدة على الأقل في كل يوم دوام');
    final byDay = <int, List<Map<String, Object?>>>{};
    for (final placement in result.placements) {
      (byDay[placement['day_id'] as int] ??= <Map<String, Object?>>[]).add(placement);
    }
    final repeatedDays = byDay.entries.where((entry) => entry.value.length == 2).toList();
    expect(repeatedDays, hasLength(1));
    expect(repeatedDays.single.value.map((entry) => entry['slot_id']).toSet().contains(6), isTrue,
        reason: 'الحصة الإضافية يجب أن تكون في الفترة السادسة');
    expect(result.placements.map((p) => '${p['section_id']}:${p['day_id']}:${p['slot_id']}').toSet(), hasLength(6));
    expect(result.placements.map((p) => '${p['teacher_id']}:${p['day_id']}:${p['slot_id']}').toSet(), hasLength(6));
  });

  test('خمس حصص أسبوعياً يجب أن تظهر مرة واحدة على الأقل في كل يوم دوام', () {
    final result = const AutoSchedulerService(nodeLimit: 10000).generate(
      sections: [
        {'id': 1, 'grade_id': 5, 'grade_name': 'الخامس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 8, 'subject_name': 'الرياضيات', 'weekly_lessons': 5, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 3, 'name': 'معلم الرياضيات', 'weekly_load': 8, 'max_daily_lessons': 6, 'max_consecutive_lessons': 6},
      ],
      qualifications: [{'teacher_id': 3, 'subject_id': 8}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        for (var i = 1; i <= 6; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements, hasLength(5));
    expect(result.placements.map((p) => p['day_id']).toSet(), equals({1, 2, 3, 4, 5}));
    expect(result.dailySpreadIssues, isEmpty);
    expect(result.placements.every((p) => p['slot_id'] != 7), isTrue);
  });

  test('يعطي أولوية لتغطية مادة 5 حصص يومياً عندما تتجاوز متطلبات الشعبة السعة', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        {'id': 1, 'grade_id': 5, 'grade_name': 'الخامس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 1},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 5, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 1, 'subject_id': 3, 'subject_name': 'اللغة العربية', 'weekly_lessons': 5, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 1, 'subject_id': 4, 'subject_name': 'العلوم', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 2, 'name': 'معلم الرياضيات', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
        {'id': 3, 'name': 'معلم العربية', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
        {'id': 4, 'name': 'معلم العلوم', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
      ],
      qualifications: [
        {'teacher_id': 2, 'subject_id': 2},
        {'teacher_id': 3, 'subject_id': 3},
        {'teacher_id': 4, 'subject_id': 4},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الحصة الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    final mathLessons = result.placements.where((p) => p['subject_id'] == 2).toList();
    expect(mathLessons, hasLength(5));
    expect(mathLessons.map((p) => p['day_id']).toSet(), equals({1, 2, 3, 4, 5}));
    expect(result.complete, isFalse, reason: 'التغطية لا تبرر إخفاء نقص بقية المتطلبات عندما تتجاوز السعة');
  });

  test('لا يستخدم الحصة السابعة ما دام يمكن تلبية المتطلب دونها', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 7}],
      requirements: [{'section_id': 1, 'subject_id': 1, 'subject_name': 'العربية', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0}],
      teachers: [{'id': 1, 'name': 'معلم', 'weekly_load': 5, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0}],
      qualifications: [{'teacher_id': 1, 'subject_id': 1}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        for (var i = 1; i <= 7; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements.single['slot_id'], isNot(7));
  });

  test('يسمح بالحصة السابعة للصف السادس يوم الأحد عند تجاوز سعة ست حصص', () {
    final requirements = [
      for (var i = 1; i <= 7; i++)
        {'section_id': 1, 'subject_id': i, 'subject_name': 'المادة $i', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
    ];
    final result = scheduler.generate(
      sections: [{'id': 1, 'grade_id': 6, 'grade_name': 'السادس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 6}],
      requirements: requirements,
      teachers: [
        for (var i = 1; i <= 7; i++)
          {'id': i, 'name': 'معلم $i', 'weekly_load': 1, 'max_daily_lessons': 1, 'max_consecutive_lessons': 0},
      ],
      qualifications: [for (var i = 1; i <= 7; i++) {'teacher_id': i, 'subject_id': i}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [
        for (var i = 1; i <= 7; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );
    expect(result.complete, isTrue);
    expect(result.placements, hasLength(7));
    expect(result.placements.any((entry) => entry['slot_id'] == 7), isTrue);
  });

  test('يمنع الحصة السابعة عن الصفوف غير السادس حتى يوم الأحد', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'grade_id': 1, 'grade_name': 'الأول الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 7}],
      requirements: [
        for (var i = 1; i <= 7; i++)
          {'section_id': 1, 'subject_id': i, 'subject_name': 'المادة $i', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        for (var i = 1; i <= 7; i++)
          {'id': i, 'name': 'معلم $i', 'weekly_load': 1, 'max_daily_lessons': 1, 'max_consecutive_lessons': 0},
      ],
      qualifications: [for (var i = 1; i <= 7; i++) {'teacher_id': i, 'subject_id': i}],
      days: [{'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1}],
      slots: [for (var i = 1; i <= 7; i++) {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1}],
    );
    expect(result.placements.any((entry) => entry['slot_id'] == 7), isFalse);
    expect(result.complete, isFalse);
  });

  test('يمنع الحصة السابعة عن الصف السادس في غير يوم الأحد', () {
    final result = scheduler.generate(
      sections: [{'id': 1, 'grade_id': 6, 'grade_name': 'السادس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 7}],
      requirements: [
        for (var i = 1; i <= 7; i++)
          {'section_id': 1, 'subject_id': i, 'subject_name': 'المادة $i', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        for (var i = 1; i <= 7; i++)
          {'id': i, 'name': 'معلم $i', 'weekly_load': 1, 'max_daily_lessons': 1, 'max_consecutive_lessons': 0},
      ],
      qualifications: [for (var i = 1; i <= 7; i++) {'teacher_id': i, 'subject_id': i}],
      days: [{'id': 2, 'name': 'الاثنين', 'position': 0, 'is_active': 1}],
      slots: [for (var i = 1; i <= 7; i++) {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1}],
    );
    expect(result.placements.any((entry) => entry['slot_id'] == 7), isFalse);
    expect(result.complete, isFalse);
  });

  test('يحافظ على الحصص الصالحة في المسودة عند تعذر تغطية يوم واحد لمادة كثيفة', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        {'id': 1, 'grade_id': 6, 'grade_name': 'السادس الابتدائي', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 2, 'subject_name': 'الرياضيات', 'weekly_lessons': 6, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 4, 'name': 'معلم الرياضيات', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 6},
      ],
      qualifications: [{'teacher_id': 4, 'subject_id': 2}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        for (var i = 1; i <= 6; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
      ],
      teacherAvailability: [
        for (var i = 1; i <= 6; i++)
          {'teacher_id': 4, 'day_id': 5, 'slot_id': i, 'is_available': 0},
      ],
    );
    expect(result.complete, isFalse);
    expect(result.placements, isNotEmpty,
        reason: 'يجب الاحتفاظ بالحصص السليمة في المسودة بدلاً من حذف المادة كاملة عند تعذر تغطية يوم واحد');
    expect(result.placements.every((p) => p['subject_id'] == 2), isTrue);
  });

  test('يفضل تدوير توقيت المادة بين الأيام ولا يكرر العربية في الحصة الأولى يومين متتاليين', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 20, 'subject_name': 'اللغة العربية', 'weekly_lessons': 2, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم العربية', 'weekly_load': 10, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 5, 'subject_id': 20}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
      ],
      slots: [
        {'id': 1, 'name': 'الأولى', 'position': 0, 'kind': 'lesson', 'is_available': 1},
        {'id': 2, 'name': 'الثانية', 'position': 1, 'kind': 'lesson', 'is_available': 1},
        {'id': 3, 'name': 'الثالثة', 'position': 2, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.complete, isTrue);
    expect(result.placements, hasLength(2));
    final firstDay = result.placements.singleWhere((row) => row['day_id'] == 1);
    final secondDay = result.placements.singleWhere((row) => row['day_id'] == 2);
    expect(firstDay['slot_id'], 1, reason: 'ينبغي أن تبقى أفضلية الحصة الأولى يوم الأحد في هذا المثال المباشر');
    expect(secondDay['slot_id'], isNot(1), reason: 'لا تكرر العربية في الحصة الأولى يوم الاثنين إذا كانت فترة بديلة متاحة');
  });

  test('يوزع خمس حصص للمادة عبر أيام الأسبوع على فترات متنوعة قدر الإمكان', () {
    final result = scheduler.generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 1, 'subject_name': 'اللغة العربية', 'weekly_lessons': 5, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم العربية', 'weekly_load': 10, 'max_daily_lessons': 5, 'max_consecutive_lessons': 0},
      ],
      qualifications: [{'teacher_id': 5, 'subject_id': 1}],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
        {'id': 2, 'name': 'الاثنين', 'position': 1, 'is_active': 1},
        {'id': 3, 'name': 'الثلاثاء', 'position': 2, 'is_active': 1},
        {'id': 4, 'name': 'الأربعاء', 'position': 3, 'is_active': 1},
        {'id': 5, 'name': 'الخميس', 'position': 4, 'is_active': 1},
      ],
      slots: [
        for (var i = 1; i <= 6; i++)
          {'id': i, 'name': 'الحصة $i', 'position': i - 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.complete, isTrue);
    expect(result.placements, hasLength(5));
    final periodByDay = {for (final row in result.placements) row['day_id']: row['slot_id']};
    for (var day = 1; day < 5; day++) {
      expect(periodByDay[day], isNot(periodByDay[day + 1]));
    }
    expect(periodByDay.values.toSet().length, greaterThanOrEqualTo(4));
  });

  test('لا يسمح بتضارب المعلم في الحصة الخامسة حتى لو تعذر إكمال جميع الحصص', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 5},
        {'id': 2, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'ب', 'max_daily_lessons': 5},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 10, 'subject_name': 'الرياضيات', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 2, 'subject_id': 11, 'subject_name': 'العلوم', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم المواد', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
      ],
      qualifications: [
        {'teacher_id': 5, 'subject_id': 10},
        {'teacher_id': 5, 'subject_id': 11},
      ],
      subjectBlockedSlots: [
        for (var slot = 1; slot <= 4; slot++) {'subject_id': 10, 'slot_id': slot},
        for (var slot = 1; slot <= 4; slot++) {'subject_id': 11, 'slot_id': slot},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
      ],
      slots: [
        for (var slot = 1; slot <= 5; slot++)
          {'id': slot, 'name': 'الحصة $slot', 'position': slot - 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    expect(result.placements, hasLength(1));
    expect(result.complete, isFalse);
    expect(result.placements.every((p) => p['slot_id'] == 5), isTrue);
  });

  test('يرفض التوزيع المتزامن للمعلم على ثلاث شعب في السادسة ويعيد نتيجة جزئية آمنة', () {
    final result = const AutoSchedulerService(nodeLimit: 5000).generate(
      sections: [
        {'id': 1, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'أ', 'max_daily_lessons': 6},
        {'id': 2, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'ب', 'max_daily_lessons': 6},
        {'id': 3, 'grade_id': 1, 'grade_name': 'الأول', 'section_name': 'ج', 'max_daily_lessons': 6},
      ],
      requirements: [
        {'section_id': 1, 'subject_id': 10, 'subject_name': 'الرياضيات', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 2, 'subject_id': 11, 'subject_name': 'العلوم', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
        {'section_id': 3, 'subject_id': 12, 'subject_name': 'التربية الفنية', 'weekly_lessons': 1, 'max_daily_lessons': 1, 'allow_same_day': 0},
      ],
      teachers: [
        {'id': 5, 'name': 'معلم المواد', 'weekly_load': 10, 'max_daily_lessons': 6, 'max_consecutive_lessons': 0},
      ],
      qualifications: [
        {'teacher_id': 5, 'subject_id': 10},
        {'teacher_id': 5, 'subject_id': 11},
        {'teacher_id': 5, 'subject_id': 12},
      ],
      subjectBlockedSlots: [
        for (var subject = 10; subject <= 12; subject++)
          for (var slot = 1; slot <= 5; slot++) {'subject_id': subject, 'slot_id': slot},
      ],
      days: [
        {'id': 1, 'name': 'الأحد', 'position': 0, 'is_active': 1},
      ],
      slots: [
        for (var slot = 1; slot <= 6; slot++)
          {'id': slot, 'name': 'الحصة $slot', 'position': slot - 1, 'kind': 'lesson', 'is_available': 1},
      ],
    );

    // There is only one available time slot and one qualified teacher.
    // The scheduler must not claim completion by double-booking the teacher.
    expect(result.requestedCount, 3);
    expect(result.complete, isFalse);
    expect(result.placements, hasLength(1));
    expect(result.unscheduled, isNotEmpty);
    expect(result.placements.every((p) => p['teacher_id'] == 5 && p['day_id'] == 1 && p['slot_id'] == 6), isTrue);
    final teacherTimeKeys = result.placements
        .map((p) => '${p['teacher_id']}:${p['day_id']}:${p['slot_id']}')
        .toList();
    expect(teacherTimeKeys.toSet().length, teacherTimeKeys.length,
        reason: 'لا يجوز إسناد المعلم لأكثر من شعبة في الوقت نفسه حتى في السادسة');
  });

}


// Regression guard for the bounded CSP search: a tiny configured budget must
// not be silently expanded to the historical 120k/180k search.
