class ReportSection {
  const ReportSection(this.title, this.headings, this.rows);
  final String title;
  final List<String> headings;
  final List<List<String>> rows;
}

class SchoolReport {
  const SchoolReport({
    required this.title,
    required this.school,
    required this.details,
    required this.sections,
    required this.landscape,
    this.note = '',
    this.teacher = '',
    this.director = '',
  });
  final String title, school, details, note, teacher, director;
  bool get hasSignatures => teacher.isNotEmpty || director.isNotEmpty;
  final List<ReportSection> sections;
  final bool landscape;
  double get width => landscape ? 1123 : 794;
  double get height => landscape ? 794 : 1123;
}
