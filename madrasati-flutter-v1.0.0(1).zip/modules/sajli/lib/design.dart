import 'dart:math' as math;

import 'package:material_ui/material_ui.dart';

const sajliPalettes = {
  'توتي': Color(0xff573d91),
  'أخضر': Color(0xff285f53),
  'وردي': Color(0xff833f5c),
  'نيلي': Color(0xff3f5686),
  'نحاسي': Color(0xff805129),
};

Color contrastInk(Color background) => background.computeLuminance() > 0.179
    ? const Color(0xff17121c)
    : Colors.white;

class SajliHero extends StatelessWidget {
  const SajliHero({
    super.key,
    required this.school,
    required this.title,
    required this.hint,
    required this.accent,
    required this.icon,
    required this.height,
    this.art = true,
    this.chart = false,
  });
  final String school, title, hint;
  final Color accent;
  final IconData icon;
  final double height;
  final bool art, chart;

  @override
  Widget build(BuildContext context) {
    final ink = contrastInk(accent);
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 600;
        final showArt = art && constraints.maxWidth >= 290;
        return Container(
          constraints: BoxConstraints(minHeight: height + (wide ? 20 : 0)),
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(
            color: accent,
            borderRadius: BorderRadius.circular(wide ? 24 : 18),
          ),
          child: Stack(
            alignment: AlignmentDirectional.centerStart,
            children: [
              if (showArt)
                PositionedDirectional(
                  end: 0,
                  top: 0,
                  bottom: 0,
                  width: wide ? constraints.maxWidth * .30 : 111,
                  child: ExcludeSemantics(
                    child: _HeroArt(icon: icon, chart: chart),
                  ),
                ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(
                  wide ? 27 : 14,
                  18,
                  showArt ? (wide ? constraints.maxWidth * .31 : 114) : 14,
                  18,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.school_outlined, color: ink, size: 15),
                        const SizedBox(width: 5),
                        Flexible(
                          child: Text(
                            school,
                            style: TextStyle(
                              color: ink,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      title,
                      style: TextStyle(
                        color: ink,
                        fontSize: wide ? 40 : 28,
                        height: 1.35,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      hint,
                      style: TextStyle(
                        color: ink,
                        fontSize: wide ? 13 : 11,
                        height: 1.65,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _HeroArt extends StatelessWidget {
  const _HeroArt({required this.icon, required this.chart});
  final IconData icon;
  final bool chart;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final large = constraints.maxWidth >= 150;
      final scale = large ? 1.05 : .64;
      return ClipRect(
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned.fill(child: CustomPaint(painter: _Rings(scale))),
            Transform.translate(
              offset: Offset(-25 * scale, -50 * scale),
              child: Align(
                alignment: Alignment.center,
                child: Icon(
                  Icons.auto_awesome,
                  color: const Color(0xfff5cf8a),
                  size: 19 * scale,
                ),
              ),
            ),
            Transform.rotate(
              angle: -math.pi / 15,
              child: Container(
                width: 127 * scale,
                height: 92 * scale,
                padding: EdgeInsets.all(11 * scale),
                decoration: BoxDecoration(
                  color: const Color(0xfff5edf9),
                  borderRadius: BorderRadius.circular(15 * scale),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x38201637),
                      blurRadius: 22,
                      offset: Offset(0, 9),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _line(34 * scale, 7 * scale, const Color(0xff7959ab)),
                    SizedBox(height: 6 * scale),
                    _line(55 * scale, 5 * scale, const Color(0xffcfbde5)),
                    SizedBox(height: 4 * scale),
                    _line(45 * scale, 5 * scale, const Color(0xffcfbde5)),
                    Expanded(
                      child: chart
                          ? Directionality(
                              textDirection: TextDirection.ltr,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  _line(
                                    15 * scale,
                                    14 * scale,
                                    const Color(0xffb89bdc),
                                  ),
                                  _line(
                                    15 * scale,
                                    26 * scale,
                                    const Color(0xffdba8bc),
                                  ),
                                  _line(
                                    15 * scale,
                                    20 * scale,
                                    const Color(0xffb89bdc),
                                  ),
                                  _line(
                                    15 * scale,
                                    35 * scale,
                                    const Color(0xff71539e),
                                  ),
                                ],
                              ),
                            )
                          : Center(
                              child: Icon(
                                icon,
                                size: 27 * scale,
                                color: const Color(0xff573d91),
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
            Transform.translate(
              offset: Offset(44 * scale, 32 * scale),
              child: Transform.rotate(
                angle: math.pi / 18,
                child: Container(
                  width: 38 * scale,
                  height: 38 * scale,
                  decoration: BoxDecoration(
                    color: const Color(0xfff0cb82),
                    borderRadius: BorderRadius.circular(11 * scale),
                  ),
                  child: Icon(
                    Icons.check,
                    size: 23 * scale,
                    color: const Color(0xff4f3514),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    },
  );

  Widget _line(double width, double height, Color color) => Container(
    width: width,
    height: height,
    decoration: BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(4),
    ),
  );
}

class _Rings extends CustomPainter {
  const _Rings(this.scale);
  final double scale;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0x38ffffff)
      ..style = PaintingStyle.stroke;
    final center = size.center(Offset.zero);
    canvas.drawCircle(center, 97 * scale, paint);
    canvas.drawCircle(center, 119 * scale, paint);
  }

  @override
  bool shouldRepaint(_Rings oldDelegate) => oldDelegate.scale != scale;
}
