import 'dart:convert';

typedef Json = Map<String, dynamic>;

Json object(Object? value) =>
    value is Map ? Map<String, dynamic>.from(value) : {};

String asciiDigits(String value) => value
    .replaceAllMapped(RegExp('[٠-٩۰-۹]'), (m) {
      final code = m[0]!.codeUnitAt(0);
      return (code - (code >= 0x06f0 ? 0x06f0 : 0x0660)).toString();
    })
    .replaceAll('٫', '.');

String arabicDigits(String value) => value
    .replaceAllMapped(RegExp(r'[0-9]'), (match) {
      return String.fromCharCode(0x0660 + int.parse(match[0]!));
    })
    .replaceAllMapped(RegExp(r'([٠-٩])\.(?=[٠-٩])'), (match) => '${match[1]}٫');

const studentGenders = {'male': 'ذكر', 'female': 'أنثى', 'unknown': 'غير محدد'};

String studentGender(Json row) {
  final value = row['gender']?.toString() ?? '';
  return studentGenders.containsKey(value) ? value : 'unknown';
}

String _arabicNameKey(Object? name) => (name?.toString() ?? '')
    .trim()
    .replaceAll(RegExp(r'[ـً-ٰٟ]'), '')
    .replaceAll(RegExp('[أإآٱ]'), 'ا')
    .replaceAll('ؤ', 'و')
    .replaceAll(RegExp('[ئى]'), 'ي')
    .replaceAll('ة', 'ه')
    .replaceAll(RegExp(r'\s+'), ' ')
    .toLowerCase();

bool _move<T>(List<T> rows, int index, int offset) {
  final next = index + offset;
  if (index < 0 ||
      index >= rows.length ||
      next < 0 ||
      next >= rows.length ||
      offset == 0) {
    return false;
  }
  rows.insert(next, rows.removeAt(index));
  return true;
}

String numText(num n) =>
    n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(1);
String dayKey(DateTime d) => d.toIso8601String().substring(0, 10);
const monthNames = [
  'كانون الثاني',
  'شباط',
  'آذار',
  'نيسان',
  'أيار',
  'حزيران',
  'تموز',
  'آب',
  'أيلول',
  'تشرين الأول',
  'تشرين الثاني',
  'كانون الأول',
];
const attendanceLabels = {
  'present': 'حاضر',
  'absent': 'غائب',
  'excused': 'بعذر',
  'late': 'متأخر',
};
const gradeLabels = {'score': 'درجة', 'absent': 'غائب', 'exempt': 'معفى'};
const groups = ['الفصل الأول', 'نصف السنة', 'الفصل الثاني', 'الامتحان النهائي'];

class RemovedStudent {
  const RemovedStudent(this._student, this._index, this._direct, this._daily);
  final Json _student;
  final int _index;
  final Json _direct;
  final Map<String, Json> _daily;
}

class Records {
  Records(this.data);

  factory Records.decode(String text) {
    final data = object(jsonDecode(text));
    if (data['classes'] is! List ||
        data['students'] is! List ||
        data['grades'] is! Map ||
        data['attendance'] is! Map) {
      throw const FormatException('بنية النسخة الاحتياطية غير صالحة');
    }
    final records = Records(data);
    final classIds = <String>{};
    for (final row in records.classes) {
      if (row['id'] == null ||
          row['name'] is! String ||
          !classIds.add(row['id'].toString())) {
        throw const FormatException('صف غير صالح أو مكرر');
      }
    }
    final studentIds = <String>{};
    for (final row in records.people) {
      if (row['id'] == null ||
          row['name'] is! String ||
          !classIds.contains(row['classId'].toString()) ||
          !studentIds.add(row['id'].toString())) {
        throw const FormatException('بيانات التلاميذ غير صالحة');
      }
    }
    if (data['subjects'] is! List || data['periods'] is! List) {
      throw const FormatException('بيانات المواد أو الفترات غير صالحة');
    }
    return records;
  }

  final Json data;
  List<Json> list(String key) =>
      (data[key] as List? ?? []).map(object).toList();
  List<Json> get classes => list('classes');
  List<Json> get activeClasses =>
      classes.where((r) => r['archived'] != true).toList();
  List<Json> get people => list('students');
  List<Json> get periods => list('periods');
  List<String> get courses =>
      (data['subjects'] as List? ?? []).map((e) => e.toString()).toList();
  List<String> subjects(String classId) =>
      (object(data['classSubjects'])[classId] as List?)
          ?.map((e) => e.toString())
          .toList() ??
      courses;
  bool manualStudentOrder(String classId) =>
      object(data['studentOrdering'])[classId] == 'manual';

  void alphabeticalStudentOrder(String classId) {
    final settings = object(data['studentOrdering'])..remove(classId);
    data['studentOrdering'] = settings;
  }

  List<Json> students(String classId) {
    final rows = people
        .where(
          (r) => r['classId'].toString() == classId && r['archived'] != true,
        )
        .toList();
    if (manualStudentOrder(classId)) return rows;
    final indexed = rows.indexed.toList();
    const rank = {'male': 0, 'female': 1, 'unknown': 2};
    indexed.sort((a, b) {
      final byGender = rank[studentGender(a.$2)]!.compareTo(
        rank[studentGender(b.$2)]!,
      );
      if (byGender != 0) return byGender;
      final byName = _arabicNameKey(a.$2['name'])
          .compareTo(_arabicNameKey(b.$2['name']));
      return byName == 0 ? a.$1.compareTo(b.$1) : byName;
    });
    return indexed.map((entry) => entry.$2).toList();
  }

  bool moveStudent(String classId, String id, int offset) {
    final ordered = students(classId);
    if (!_move(
      ordered,
      ordered.indexWhere((s) => s['id'].toString() == id),
      offset,
    ))
      return false;
    final iterator = ordered.iterator;
    data['students'] = people.map((row) {
      if (row['classId'].toString() != classId || row['archived'] == true)
        return row;
      iterator.moveNext();
      return iterator.current;
    }).toList();
    data['studentOrdering'] = {
      ...object(data['studentOrdering']),
      classId: 'manual',
    };
    return true;
  }

  bool moveClass(String id, int offset) {
    final rows = classes;
    if (!_move(rows, rows.indexWhere((c) => c['id'].toString() == id), offset))
      return false;
    data['classes'] = rows;
    return true;
  }

  bool deleteClass(String id) {
    final rows = classes;
    if (!rows.any((c) => c['id'].toString() == id)) return false;
    final roster = people;
    final removed = roster
        .where((s) => s['classId'].toString() == id)
        .map((s) => s['id'].toString())
        .toSet();
    data['classes'] = rows.where((c) => c['id'].toString() != id).toList();
    data['students'] = roster
        .where((s) => !removed.contains(s['id'].toString()))
        .toList();
    for (final key in ['studentOrdering', 'classSubjects']) {
      data[key] = object(data[key])..remove(id);
    }
    for (final key in ['grades', 'gradeStates']) {
      data[key] = object(data[key])
        ..removeWhere((id, _) => removed.contains(id));
    }
    for (final key in ['attendance', 'attNotes']) {
      data[key] = object(data[key]).map(
        (date, day) => MapEntry(
          date,
          object(day)..removeWhere((id, _) => removed.contains(id)),
        ),
      );
    }
    return true;
  }

  bool changeSubject(String classId, String current, String? replacement) {
    final rows = subjects(classId);
    final index = rows.indexOf(current);
    if (index < 0 || (replacement != null && rows.contains(replacement)))
      return false;
    final ids = people
        .where((s) => s['classId'].toString() == classId)
        .map((s) => s['id'].toString())
        .toSet();
    if (replacement != null && courses.contains(replacement)) {
      final newMaximum = maximum(replacement);
      if (ids.any(
        (id) => object(object(object(data['grades'])[id])[current]).values
            .any((value) => (num.tryParse(value.toString()) ?? 0) > newMaximum),
      )) {
        throw const FormatException(
          'هناك درجات أعلى من الحد الأقصى للمادة المطلوبة',
        );
      }
    }
    final scoped = {
      for (final row in classes)
        row['id'].toString(): subjects(row['id'].toString()),
    };
    if (replacement == null) {
      rows.removeAt(index);
    } else {
      rows[index] = replacement;
      if (!courses.contains(replacement)) {
        data['gradeMax'] = {
          ...object(data['gradeMax']),
          replacement: maximum(current),
        };
        data['subjects'] = [...courses, replacement];
      }
    }
    data['classSubjects'] = {...scoped, classId: rows};
    for (final key in ['grades', 'gradeStates']) {
      final root = object(data[key]);
      for (final id in ids) {
        if (!root.containsKey(id)) continue;
        final person = object(root[id]);
        final entries = person.remove(current);
        if (replacement != null && entries != null)
          person[replacement] = entries;
        root[id] = person;
      }
      data[key] = root;
    }
    if (!object(data['classSubjects']).values
        .any((list) => list is List && list.contains(current))) {
      data['subjects'] = courses.where((name) => name != current).toList();
      data['gradeMax'] = object(data['gradeMax'])..remove(current);
    }
    return true;
  }

  void addSubject(String classId, String name) {
    final rows = subjects(classId);
    if (rows.contains(name)) return;
    data['classSubjects'] = {
      for (final row in classes)
        row['id'].toString(): subjects(row['id'].toString()),
      classId: [...rows, name],
    };
    if (!courses.contains(name)) data['subjects'] = [...courses, name];
  }

  bool moveSubject(String classId, String name, int offset) {
    final rows = subjects(classId);
    if (!_move(rows, rows.indexOf(name), offset)) return false;
    data['classSubjects'] = {...object(data['classSubjects']), classId: rows};
    return true;
  }

  bool movePeriod(String key, int offset) {
    final rows = periods;
    if (!_move(rows, rows.indexWhere((p) => p['key'] == key), offset))
      return false;
    data['periods'] = rows;
    return true;
  }

  bool deletePeriod(String key) {
    final rows = periods;
    if (!rows.any((p) => p['key'] == key)) return false;
    data['periods'] = rows.where((p) => p['key'] != key).toList();
    for (final field in ['grades', 'gradeStates']) {
      data[field] = object(data[field]).map(
        (id, subjects) => MapEntry(
          id,
          object(
            subjects,
          ).map((name, values) => MapEntry(name, object(values)..remove(key))),
        ),
      );
    }
    return true;
  }

  RemovedStudent? deleteStudent(String id) {
    final students = people;
    final index = students.indexWhere(
      (student) => student['id'].toString() == id,
    );
    if (index == -1) return null;
    final student = students.removeAt(index);
    final direct = <String, dynamic>{};
    for (final key in ['grades', 'gradeStates']) {
      final root = object(data[key]);
      if (root.containsKey(id)) {
        direct[key] = root.remove(id);
        data[key] = root;
      }
    }
    final daily = <String, Json>{};
    for (final key in ['attendance', 'attNotes']) {
      final root = object(data[key]);
      final removed = <String, dynamic>{};
      for (final day in root.keys.toList()) {
        final row = object(root[day]);
        if (row.containsKey(id)) {
          removed[day] = row.remove(id);
          root[day] = row;
        }
      }
      if (removed.isNotEmpty) {
        daily[key] = removed;
        data[key] = root;
      }
    }
    data['students'] = students;
    return RemovedStudent(student, index, direct, daily);
  }

  bool restoreStudent(RemovedStudent removal) {
    final id = removal._student['id'].toString();
    if (!classes.any(
      (row) => row['id'].toString() == removal._student['classId'].toString(),
    ))
      return false;
    final students = people;
    if (students.any((student) => student['id'].toString() == id)) return false;
    final index = removal._index > students.length
        ? students.length
        : removal._index;
    students.insert(index, removal._student);
    data['students'] = students;
    for (final entry in removal._direct.entries) {
      data[entry.key] = {...object(data[entry.key]), id: entry.value};
    }
    for (final entry in removal._daily.entries) {
      final root = object(data[entry.key]);
      for (final day in entry.value.entries) {
        root[day.key] = {...object(root[day.key]), id: day.value};
      }
      data[entry.key] = root;
    }
    return true;
  }

  String className(String id) =>
      classes
          .where((r) => r['id'].toString() == id)
          .firstOrNull?['name']
          ?.toString() ??
      '';
  String get school => data['school']?.toString() ?? '';
  String get teacher => data['teacher']?.toString() ?? '';
  String get director => data['director']?.toString() ?? '';
  String get year => data['year']?.toString() ?? '';
  num maximum(String subject) {
    final value = object(data['gradeMax'])[subject];
    return value is num && value.isFinite && value > 0 ? value : 100;
  }

  Object? _lookup(String key, String id, String subject, String period) =>
      object(object(object(data[key])[id])[subject])[period];

  String gradeStatus(String id, String subject, String period) {
    final status = _lookup('gradeStates', id, subject, period)?.toString();
    return gradeLabels.containsKey(status) ? status! : 'score';
  }

  num? score(String id, String subject, String period) {
    if (gradeStatus(id, subject, period) != 'score') return null;
    final value = num.tryParse(
      _lookup('grades', id, subject, period).toString(),
    );
    return value != null &&
            value.isFinite &&
            value >= 0 &&
            value <= maximum(subject)
        ? value
        : null;
  }

  String gradeText(String id, String subject, String period) {
    final status = gradeStatus(id, subject, period);
    final value = score(id, subject, period);
    return status != 'score'
        ? gradeLabels[status]!
        : value == null
        ? '—'
        : numText(value);
  }

  void _put(
    String key,
    String id,
    String subject,
    String period,
    Object? value,
  ) {
    final root = object(data[key]);
    final person = object(root[id]);
    final course = object(person[subject]);
    course[period] = value;
    person[subject] = course;
    root[id] = person;
    data[key] = root;
  }

  void setScore(String id, String subject, String period, num? value) {
    if (value != null &&
        (!value.isFinite || value < 0 || value > maximum(subject))) {
      throw const FormatException('الدرجة خارج النطاق');
    }
    _put('grades', id, subject, period, value);
  }

  void setGradeStatus(
    String id,
    String subject,
    String period,
    String status,
  ) => _put('gradeStates', id, subject, period, status);

  Json attendance(String day) => object(object(data['attendance'])[day]);
  void setAttendance(String day, String id, String status) {
    final root = object(data['attendance']);
    final row = attendance(day);
    if (status.isEmpty) {
      row.remove(id);
    } else {
      row[id] = status;
    }
    root[day] = row;
    data['attendance'] = root;
  }

  Map<String, int> attendanceSummary(String id, String month) {
    final result = <String, int>{for (final k in attendanceLabels.keys) k: 0};
    for (final entry in object(data['attendance']).entries) {
      if (!entry.key.startsWith('$month-')) continue;
      final status = object(entry.value)[id]?.toString();
      if (result.containsKey(status)) result[status!] = result[status]! + 1;
    }
    return result;
  }

  num rounded(num n) => switch (data['rounding']) {
    'floor' => n.floor(),
    'decimal' => (n * 10).round() / 10,
    _ => n.round(),
  };

  num? weighted(List<num?> values, List<num> weights) {
    var sum = 0.0;
    var total = 0.0;
    for (var i = 0; i < values.length; i++) {
      final weight = weights[i];
      if (weight <= 0) continue;
      final value = values[i];
      if (value == null) return null;
      sum += (value * weight).toDouble();
      total += weight.toDouble();
    }
    return total == 0 ? null : rounded(sum / total);
  }

  ({num? first, num? mid, num? second, num? effort, num? exam, num? finalGrade})
  annual(String id, String subject) {
    List<num?> group(String label) => periods
        .where((p) => p['section'] == label)
        .map((p) => score(id, subject, p['key'].toString()))
        .toList();
    num? mean(String label) {
      final values = group(label);
      return weighted(values, List<num>.filled(values.length, 1));
    }

    final first = mean(groups[0]);
    final mid = group(groups[1]).firstOrNull;
    final second = mean(groups[2]);
    final exam = group(groups[3]).firstOrNull;
    final calc = object(data['calc']);
    num weight(String k) => calc[k] is num ? calc[k] as num : 1;
    final effort = weighted(
      [first, mid, second],
      [weight('f1'), weight('mid'), weight('f2')],
    );
    return (
      first: first,
      mid: mid,
      second: second,
      effort: effort,
      exam: exam,
      finalGrade: weighted([effort, exam], [weight('sai'), weight('exam')]),
    );
  }

  List<({String period, double? percent, int count})> trend(
    String id,
    String classId,
  ) {
    return periods.where((p) => p['section'] != groups.last).map((p) {
      final period = p['key'].toString();
      final values = subjects(classId)
          .map((s) {
            final value = score(id, s, period);
            return value == null ? null : value / maximum(s) * 100;
          })
          .whereType<double>()
          .toList();
      return (
        period: period,
        percent: values.isEmpty
            ? null
            : values.reduce((a, b) => a + b) / values.length,
        count: values.length,
      );
    }).toList();
  }
}
