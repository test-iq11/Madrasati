import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:sajli/records.dart';
import 'package:sajli/report_data.dart';

void main() {
  test(
    'card is scoped to one student and honors selected fields and month',
    () {
      final records = Records.decode(
        File('assets/demo.json').readAsStringSync(),
      );
      final classId = records.activeClasses.first['id'].toString();
      final people = records.students(classId);
      final id = people.first['id'].toString();
      final other = people[1]['id'].toString();
      final subject = records.subjects(classId).first;
      final period = records.periods.first['key'].toString();
      records.setScore(id, subject, period, 0);
      records.setAttendance('2026-11-01', id, 'excused');
      records.setAttendance('2026-11-01', other, 'absent');
      records.setAttendance('2026-10-01', id, 'absent');
      final report = prepareReport(
        records: records,
        kind: ReportKind.parent,
        classId: classId,
        subject: subject,
        period: period,
        month: DateTime(2026, 11),
        studentId: id,
        landscape: false,
        fields: {ParentField.grades, ParentField.attendance},
        note: 'ملاحظة مخفية',
      );
      expect(report.sections, hasLength(2));
      expect(report.sections.first.rows.first[1], '0');
      expect(report.sections.last.rows.single, ['0', '0', '1', '0']);
      expect(report.note, isEmpty);
      expect(report.details, contains(people.first['name']));
      expect(report.details, isNot(contains(people[1]['name'])));
      expect(report.landscape, isFalse);
    },
  );

  test('weighted calculation respects absence and zero weight', () {
    final records = Records.decode(File('assets/demo.json').readAsStringSync());
    expect(records.weighted([0, 80], [1, 1]), 40);
    expect(records.weighted([null, 80], [1, 1]), isNull);
    expect(records.weighted([null, 80], [0, 1]), 80);
    expect(asciiDigits('٧٥٫٥'), '75.5');
  });
  test('deleting and undoing a pupil round trips legacy records and preserves other edits', () {
    final records = Records.decode(File('assets/demo.json').readAsStringSync());
    final pupil = records.people.first;
    final id = pupil['id'].toString();
    final other = records.people[1]['id'].toString();
    final subject = records.courses.first;
    final period = records.periods.first['key'].toString();
    records.setGradeStatus(id, subject, period, 'exempt');
    records.setAttendance('2026-11-01', id, 'excused');
    records.data['attNotes'] = {
      '2026-11-01': {id: 'ملاحظة', other: 'موجود'},
    };
    final removed = records.deleteStudent(id)!;
    expect(records.people.any((p) => p['id'] == pupil['id']), isFalse);
    expect(records.gradeStatus(id, subject, period), 'score');
    expect(records.attendance('2026-11-01')[id], isNull);
    expect(object(object(records.data['attNotes'])['2026-11-01']), {
      other: 'موجود',
    });
    expect(records.deleteStudent(id), isNull);
    records.setAttendance('2026-11-01', other, 'present');
    expect(records.restoreStudent(removed), isTrue);
    expect(records.restoreStudent(removed), isFalse);
    expect(records.people.first, pupil);
    expect(records.gradeStatus(id, subject, period), 'exempt');
    expect(records.attendance('2026-11-01'), {id: 'excused', other: 'present'});
    expect(object(object(records.data['attNotes'])['2026-11-01']), {
      id: 'ملاحظة',
      other: 'موجود',
    });
    final reloaded = Records.decode(jsonEncode(records.data));
    expect(reloaded.people.first, pupil);
    expect(reloaded.gradeStatus(id, subject, period), 'exempt');
    expect(reloaded.attendance('2026-11-01')[id], 'excused');
  });
}
