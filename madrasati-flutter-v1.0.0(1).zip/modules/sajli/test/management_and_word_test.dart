import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:sajli/office.dart';
import 'package:sajli/records.dart';
import 'package:sajli/report_data.dart';

Records fixture() => Records({
  'classes': [
    {'id': 'a', 'name': 'الأول'},
    {'id': 'b', 'name': 'الثاني'},
  ],
  'students': [
    {'id': '1', 'classId': 'a', 'name': 'زَيْنَب', 'gender': 'female'},
    {'id': '2', 'classId': 'a', 'name': 'محمّد', 'gender': 'male'},
    {'id': '3', 'classId': 'a', 'name': 'إبراهيم', 'gender': 'male'},
    {'id': '4', 'classId': 'a', 'name': 'أسماء', 'gender': 'female'},
    {'id': '5', 'classId': 'a', 'name': 'اسم قديم'},
    {'id': '6', 'classId': 'b', 'name': 'علي'},
    {'id': '7', 'classId': 'a', 'name': 'مؤرشف', 'archived': true},
  ],
  'subjects': ['رياضيات', 'علوم'],
  'periods': [
    {'key': 'شهر 1', 'section': 'الفصل الأول'},
    {'key': 'شهر 2', 'section': 'الفصل الأول'},
  ],
  'grades': <String, dynamic>{},
  'attendance': <String, dynamic>{},
  'teacher': 'علي',
  'director': 'حيدر',
  'school': 'مدرسة 1',
});

void main() {
  test('grouped alphabetical ordering and persistent manual reordering', () {
    final r = fixture();
    List<Object?> ids(Records records) =>
        records.students('a').map((row) => row['id']).toList();
    expect(ids(r), ['3', '2', '4', '1', '5']);
    expect(r.moveStudent('a', '1', -1), isTrue);
    expect(ids(Records.decode(jsonEncode(r.data))), ['3', '2', '1', '4', '5']);
    r.alphabeticalStudentOrder('a');
    expect(ids(r), ['3', '2', '4', '1', '5']);
  });

  test('scoped course edits and class deletion preserve other classes', () {
    final r = fixture();
    r.setScore('2', 'رياضيات', 'شهر 1', 92);
    r.setGradeStatus('3', 'رياضيات', 'شهر 1', 'absent');
    r.setScore('6', 'رياضيات', 'شهر 2', 71);
    r.setAttendance('2026-11-15', '7', 'absent');
    r.setAttendance('2026-11-15', '6', 'present');

    expect(r.changeSubject('a', 'رياضيات', 'الحساب'), isTrue);
    expect(r.score('2', 'الحساب', 'شهر 1'), 92);
    expect(r.gradeStatus('3', 'الحساب', 'شهر 1'), 'absent');
    expect(r.score('6', 'رياضيات', 'شهر 2'), 71);
    expect(r.moveSubject('a', 'الحساب', 1), isTrue);
    expect(r.subjects('a'), ['علوم', 'الحساب']);
    expect(r.changeSubject('a', 'علوم', null), isTrue);
    expect(r.subjects('b'), ['رياضيات', 'علوم']);
    expect(r.moveClass('a', 1), isTrue);
    expect(r.classes.map((row) => row['id']), ['b', 'a']);
    expect(r.deleteClass('a'), isTrue);
    expect(r.people.map((row) => row['id']), ['6']);
    expect(r.score('2', 'الحساب', 'شهر 1'), isNull);
    expect(r.attendance('2026-11-15'), {'6': 'present'});
    expect(r.deleteClass('b'), isTrue);
    expect(Records.decode(jsonEncode(r.data)).people, isEmpty);
  });

  test('period removal clears only that evaluation from score and status', () {
    final r = fixture();
    expect(r.movePeriod('شهر 1', 1), isTrue);
    expect(r.periods.first['key'], 'شهر 2');
    r.setScore('2', 'علوم', 'شهر 1', 62);
    r.setGradeStatus('3', 'علوم', 'شهر 1', 'absent');
    r.setScore('2', 'علوم', 'شهر 2', 71);
    expect(r.deletePeriod('شهر 1'), isTrue);
    expect(r.score('2', 'علوم', 'شهر 1'), isNull);
    expect(r.gradeStatus('3', 'علوم', 'شهر 1'), 'score');
    expect(r.score('2', 'علوم', 'شهر 2'), 71);
    expect(r.deletePeriod('شهر 2'), isTrue);
    expect(Records.decode(jsonEncode(r.data)).periods, isEmpty);
  });

  test(
    'Word preserves RTL and uses Arabic numerals and a real page footer',
    () {
      final r = fixture();
      r.setScore('2', 'رياضيات', 'شهر 1', 94.5);
      final report = prepareReport(
        records: r,
        kind: ReportKind.monthly,
        classId: 'a',
        subject: 'رياضيات',
        period: 'شهر 1',
        month: DateTime(2026, 11),
        studentId: '',
        landscape: false,
        fields: {},
        note: '',
      );
      final doc = utf8.decode(wordReport(report), allowMalformed: true);
      expect(doc, contains('٩٤٫٥'));
      expect(doc, contains('شهر ١'));
      expect(doc, contains('<w:bidiVisual/>'));
      expect(doc, contains('<w:footerReference'));
      expect(doc, contains('اسم المعلم: علي'));
      expect(doc, contains('مدير المدرسة: حيدر'));
      final excel = utf8.decode(excelReport(report), allowMalformed: true);
      expect(excel, contains('<v>94.5</v>'));
      final sample = Platform.environment['SAJLI_TEST_DOCX'];
      if (sample != null) File(sample).writeAsBytesSync(wordReport(report));
    },
  );
}
