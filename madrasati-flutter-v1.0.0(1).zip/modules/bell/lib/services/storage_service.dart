import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/lesson_settings.dart';

class StorageService {
  static const _lessonsKey = 'teacher_bell.lessons.v1';
  static const _daysKey = 'teacher_bell.work_days.v1';
  static const _enabledKey = 'teacher_bell.notifications_enabled.v1';
  static const _profilesKey = 'teacher_bell.schedule_profiles.v2';
  static const _dayProfilesKey = 'teacher_bell.day_profiles.v2';
  static const _soundKey = 'teacher_bell.bell_sound.v1';
  static const _darkModeKey = 'teacher_bell.dark_mode.v1';
  static const _announcementsEnabledKey =
      'teacher_bell.voice_announcements_enabled.v1';
  static const _announcementTextKey =
      'teacher_bell.voice_announcements_text.v1';
  static const _announcementVolumeKey =
      'teacher_bell.voice_announcements_volume.v1';

  Future<AppSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    final lessons = defaultLessons();
    final stored = prefs.getString(_lessonsKey);
    if (stored != null) {
      try {
        final values = jsonDecode(stored) as List<dynamic>;
        for (final value in values) {
          if (value is! Map) {
            continue;
          }
          final data = Map<String, dynamic>.from(value);
          final id = data['id'] as int?;
          final index = lessons.indexWhere((lesson) => lesson.id == id);
          if (index >= 0) {
            lessons[index] = lessons[index].applyJson(data);
          }
        }
      } catch (_) {
        // Recover from malformed preferences using the original fixed timetable.
      }
    }

    final savedDays = prefs.getStringList(_daysKey);
    final workDays = savedDays == null || savedDays.length != 7
        ? <bool>[true, true, true, true, true, false, false]
        : savedDays.map((value) => value == '1').toList();

    final profileDefaults = defaultScheduleProfiles();
    final savedProfiles = prefs.getString(_profilesKey);
    if (savedProfiles != null) {
      try {
        final values = jsonDecode(savedProfiles) as List<dynamic>;
        for (final value in values) {
          if (value is! Map) {
            continue;
          }
          final data = Map<String, dynamic>.from(value);
          final id = data['id'] as String?;
          final index = profileDefaults.indexWhere(
            (profile) => profile.id == id,
          );
          if (index >= 0) {
            profileDefaults[index] = ScheduleProfile.fromJson(
              data,
              profileDefaults[index],
            );
          }
        }
      } catch (_) {
        // Invalid profile data does not prevent the app from opening.
      }
    }

    final savedDayProfiles = prefs.getStringList(_dayProfilesKey);
    final knownProfileIds = profileDefaults
        .map((profile) => profile.id)
        .toSet();
    final dayProfileIds =
        savedDayProfiles == null || savedDayProfiles.length != 7
        ? List<String>.filled(7, 'morning')
        : savedDayProfiles
              .map((id) => knownProfileIds.contains(id) ? id : 'morning')
              .toList();

    final savedSound = prefs.getString(_soundKey);
    final sound = BellSound.values.firstWhere(
      (value) => value.name == savedSound,
      orElse: () => BellSound.classic,
    );

    return AppSettings(
      lessons: lessons,
      workDays: workDays,
      notificationsEnabled: prefs.getBool(_enabledKey) ?? false,
      profiles: profileDefaults,
      dayProfileIds: dayProfileIds,
      bellSound: sound,
      darkMode: prefs.getBool(_darkModeKey) ?? false,
      announcementsEnabled: prefs.getBool(_announcementsEnabledKey) ?? false,
      announcementText:
          prefs.getString(_announcementTextKey) ?? defaultAnnouncementText,
      announcementVolume: (prefs.getDouble(_announcementVolumeKey) ?? 0.8)
          .clamp(0.2, 1.0)
          .toDouble(),
    );
  }

  Future<void> save(AppSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _lessonsKey,
      jsonEncode(settings.lessons.map((lesson) => lesson.toJson()).toList()),
    );
    await prefs.setStringList(
      _daysKey,
      settings.workDays.map((enabled) => enabled ? '1' : '0').toList(),
    );
    await prefs.setBool(_enabledKey, settings.notificationsEnabled);
    await prefs.setString(
      _profilesKey,
      jsonEncode(settings.profiles.map((profile) => profile.toJson()).toList()),
    );
    await prefs.setStringList(_dayProfilesKey, settings.dayProfileIds);
    await prefs.setString(_soundKey, settings.bellSound.name);
    await prefs.setBool(_darkModeKey, settings.darkMode);
    await prefs.setBool(
      _announcementsEnabledKey,
      settings.announcementsEnabled,
    );
    await prefs.setString(_announcementTextKey, settings.announcementText);
    await prefs.setDouble(_announcementVolumeKey, settings.announcementVolume);
  }

  Future<void> reset() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_lessonsKey);
    await prefs.remove(_daysKey);
    await prefs.remove(_enabledKey);
    await prefs.remove(_profilesKey);
    await prefs.remove(_dayProfilesKey);
    await prefs.remove(_soundKey);
    await prefs.remove(_darkModeKey);
    await prefs.remove(_announcementsEnabledKey);
    await prefs.remove(_announcementTextKey);
    await prefs.remove(_announcementVolumeKey);
  }
}
