import 'package:flutter/material.dart';
import 'domain.dart';

class LessonTile extends StatelessWidget {
  const LessonTile({
    super.key,
    required this.lesson,
    required this.index,
    required this.color,
    required this.date,
    required this.now,
    required this.onTap,
    required this.onActions,
    this.dark = false,
    this.exception = false,
    this.vibrationCount = 3,
    this.compact = false,
    this.showTime = true,
    this.accent = const Color(0xff087451),
  });

  final Lesson lesson;
  final int index, vibrationCount;
  final Color color;
  final DateTime date, now;
  final VoidCallback onTap, onActions;
  final bool dark, exception, compact, showTime;
  final Color accent;

  bool currentLabel(DateTime date, DateTime now) =>
      lesson.enabled &&
      lesson.configured &&
      dayDate(date) == dayDate(now) &&
      !atMinute(date, lesson.start).isAfter(now) &&
      atMinute(date, lesson.end).isAfter(now);

  @override
  Widget build(BuildContext context) {
    final paper = dark ? const Color(0xff141414) : Colors.white;
    final ink = dark ? const Color(0xfff5f5f5) : const Color(0xff192f27);
    final muted = dark ? const Color(0xffbdbdbd) : const Color(0xff54685e);
    final title = lesson.subject.isEmpty ? 'حصة غير مضبوطة' : lesson.subject;
    final details = [
      if (lesson.grade.isNotEmpty) lesson.grade,
      if (lesson.section.isNotEmpty) 'شعبة ${lesson.section}',
      if (lesson.place.isNotEmpty) lesson.place,
      if (exception) 'استثناء يومي',
    ].join(' · ');
    final sameDay = dayDate(date) == dayDate(now);
    final done =
        lesson.enabled &&
        lesson.configured &&
        sameDay &&
        !atMinute(date, lesson.end).isAfter(now);
    final alert = !lesson.enabled
        ? 'متوقفة'
        : done
        ? 'انتهت'
        : currentLabel(date, now)
        ? 'الآن'
        : lesson.vibrates
        ? vibrationCountLabel(vibrationCount)
        : lesson.mode == 'sound'
        ? 'نغمة'
        : 'إشعار';
    final current = currentLabel(date, now);
    final label =
        '${index + 1}، $title، $details، ${clock(lesson.start)} إلى ${clock(lesson.end)}، $alert';
    return Opacity(
      opacity: lesson.enabled ? 1 : .72,
      child: Semantics(
        label: label,
        button: true,
        child: Material(
          color: done
              ? paper
              : Color.alphaBlend(
                  (current ? accent : color).withValues(
                    alpha: current ? .10 : .08,
                  ),
                  paper,
                ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: current
                  ? accent
                  : dark
                  ? const Color(0xff30453a)
                  : const Color(0xffdfe6dd),
            ),
          ),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: onTap,
            onLongPress: onActions,
            child: Container(
              constraints: BoxConstraints(minHeight: compact ? 49 : 60),
              decoration: BoxDecoration(
                border: BorderDirectional(
                  start: BorderSide(color: current ? accent : color, width: 3),
                ),
              ),
              padding: const EdgeInsetsDirectional.fromSTEB(7, 4, 4, 4),
              child: Row(
                children: [
                  Container(
                    width: compact ? 29 : 31,
                    height: compact ? 29 : 34,
                    decoration: BoxDecoration(
                      color: Color.alphaBlend(
                        color.withValues(alpha: .17),
                        paper,
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    alignment: Alignment.center,
                    child: done
                        ? Icon(Icons.check, size: 15, color: muted)
                        : Text(
                            '${index + 1}',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: ink,
                            ),
                          ),
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            color: ink,
                          ),
                        ),
                        Text(
                          details.isEmpty ? 'اختر المادة والصف' : details,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 10, color: muted),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 5),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '${clock(lesson.start)}–${clock(lesson.end)}',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: ink,
                        ),
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            current
                                ? Icons.schedule
                                : done
                                ? Icons.check
                                : lesson.vibrates
                                ? Icons.vibration
                                : lesson.mode == 'sound'
                                ? Icons.volume_up_outlined
                                : Icons.notifications_none,
                            size: 12,
                            color: muted,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            alert,
                            style: TextStyle(fontSize: 9, color: muted),
                          ),
                        ],
                      ),
                    ],
                  ),
                  if (!compact)
                    SizedBox(
                      width: 26,
                      child: IconButton(
                        tooltip: 'إجراءات الحصة ${index + 1}',
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(minHeight: 42),
                        onPressed: onActions,
                        icon: Icon(Icons.more_horiz, size: 15, color: muted),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
