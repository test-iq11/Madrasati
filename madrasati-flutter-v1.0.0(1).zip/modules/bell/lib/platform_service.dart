import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'domain.dart';
import 'services/storage_service.dart';

class DeviceService {
  static const channel = MethodChannel('com.school.teacherbell/device');
  static const stateKey = 'teacher_bell.planner.v3';
  static Future<Map<String, dynamic>> status() async =>
      Map<String, dynamic>.from(
        await channel.invokeMapMethod<String, dynamic>('status') ?? {},
      );
  static Future<void> sync(PlannerState state) async {
    await channel.invokeMethod<void>('sync', state.encode());
  }

  static Future<PlannerState> load() async {
    final prefs = await SharedPreferences.getInstance(),
        raw = prefs.getString(stateKey);
    if (raw != null) {
      try {
        return PlannerState.fromJson(
          Map<String, dynamic>.from(jsonDecode(raw) as Map),
        );
      } catch (_) {
        /* Keep the damaged value available rather than destroying it. */
      }
    }
    final old = await StorageService().load();
    final state = PlannerState();
    for (var d = 0; d < 7; d++) {
      final profile = old.profileForDay(d);
      state.week[d] = old.lessons.map((l) {
        final t = profile.timeFor(l.id);
        return Lesson(
          id: 'd${d}l${l.id}',
          subject: l.subjectLabel,
          grade: l.grade,
          start: t.startMinutes,
          end: t.endMinutes,
          enabled: l.enabled && l.isConfigured,
          mode: l.alertMode.name,
        );
      }).toList();
    }
    state.work = old.workDays;
    state.enabled = old.notificationsEnabled;
    state.dark = old.darkMode;
    state.tone = old.bellSound.name;
    state.speech = old.announcementsEnabled;
    state.speechText = old.announcementText;
    state.volume = old.announcementVolume;
    final migrated = state.toJson()..['version'] = 3;
    return PlannerState.fromJson(migrated);
  }

  static Future<void> save(PlannerState state) async {
    final prefs = await SharedPreferences.getInstance();
    if (!await prefs.setString(stateKey, state.encode())) {
      throw StateError('تعذر حفظ الإعدادات');
    }
  }

  static Future<Map<String, dynamic>?> pickTone() async {
    final value = await channel.invokeMapMethod<String, dynamic>('pickTone');
    return value == null ? null : Map<String, dynamic>.from(value);
  }

  static Future<void> testTone(PlannerState state) async {
    await channel.invokeMethod<void>('testTone', state.encode());
  }

  static Future<bool> testVibration(VibrationProfile profile) async =>
      await channel.invokeMethod<bool>('testVibration', profile.toJson()) ??
      false;

  static Future<void> stopVibration() =>
      channel.invokeMethod<void>('stopVibration');

  static Future<void> stopSound() async {
    await channel.invokeMethod<void>('stopSound');
  }

  static Future<void> speech(String text, double volume) async {
    await channel.invokeMethod<void>('speak', {'text': text, 'volume': volume});
  }

  static Future<void> requestNotifications() async {
    await channel.invokeMethod<void>('requestNotifications');
  }

  static Future<void> openSettings(String kind) async {
    await channel.invokeMethod<void>('openSettings', kind);
  }

  static Future<void> exportImage(Uint8List bytes) async {
    await channel.invokeMethod<void>('shareImage', bytes);
  }

  static Future<void> printSchedule(
    List<String> lines, {
    required bool landscape,
  }) => channel.invokeMethod<void>('printSchedule', {
    'lines': lines,
    'landscape': landscape,
  });

  static Future<List<Map<String, dynamic>>> logs() async {
    final rows = await channel.invokeListMethod<dynamic>('logs') ?? [];
    return rows.map((l) => Map<String, dynamic>.from(l as Map)).toList();
  }

  static Future<void> clearLogs() async {
    await channel.invokeMethod<void>('clearLogs');
  }

  static Future<void> resetNative() async {
    await channel.invokeMethod<void>('reset');
    await StorageService().reset();
  }
}
