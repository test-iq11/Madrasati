import 'dart:convert';

const appVersion = '6.1.1';
const weekdays = [
  'الأحد',
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
];
const subjects = [
  'التربية الإسلامية',
  'اللغة العربية',
  'اللغة الإنكليزية',
  'الرياضيات',
  'العلوم',
  'الاجتماعيات',
  'التربية الفنية',
  'التربية الرياضية',
  'الحاسوب',
];
const grades = [
  'الأول الابتدائي',
  'الثاني الابتدائي',
  'الثالث الابتدائي',
  'الرابع الابتدائي',
  'الخامس الابتدائي',
  'السادس الابتدائي',
];
const alertNames = {
  'notification': 'إشعار فقط',
  'vibration': 'إشعار + اهتزاز',
  'sound': 'إشعار + نغمة',
  'both': 'إشعار + اهتزاز + نغمة',
};
const defaultSpeech = 'حان موعد {lesson}. مادة {subject}، للصف {grade}.';
String clock(int minutes) =>
    '${(minutes ~/ 60).toString().padLeft(2, '0')}:${(minutes % 60).toString().padLeft(2, '0')}';
String dateKey(DateTime date) =>
    '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
int dayIndex(DateTime date) => date.weekday % 7;
DateTime dayDate(DateTime date, [int offset = 0]) =>
    DateTime(date.year, date.month, date.day + offset);
DateTime atMinute(DateTime date, int minute) =>
    DateTime(date.year, date.month, date.day, minute ~/ 60, minute % 60);
const originalStarts = [480, 530, 575, 620, 665, 710];
const originalEnds = [525, 570, 610, 660, 705, 750];

const defaultHeroColor = 0xff103e32;
String vibrationCountLabel(int count) => switch (count) {
  1 => 'هزة واحدة',
  2 => 'هزتان',
  <= 10 => '$count هزات',
  _ => '$count هزة',
};

class VibrationProfile {
  const VibrationProfile({this.count = 3, this.pulse = 240, this.gap = 160});

  final int count, pulse, gap;
  VibrationProfile copyWith({int? count, int? pulse, int? gap}) =>
      VibrationProfile(
        count: count ?? this.count,
        pulse: pulse ?? this.pulse,
        gap: gap ?? this.gap,
      );

  int get duration => count * pulse + (count - 1) * gap;
  Map<String, int> toJson() => {'count': count, 'pulse': pulse, 'gap': gap};

  factory VibrationProfile.fromJson(Object? value) {
    final json = value is Map ? value : const {};
    int read(String key, int fallback, int low, int high) {
      final value = json[key];
      return value is num && value.isFinite
          ? value.toInt().clamp(low, high)
          : fallback;
    }

    return VibrationProfile(
      count: read('count', 3, 1, 12),
      pulse: read('pulse', 240, 80, 700),
      gap: read('gap', 160, 70, 650),
    );
  }
}

class Lesson {
  const Lesson({
    required this.id,
    this.subject = '',
    this.grade = '',
    required this.start,
    required this.end,
    this.enabled = false,
    this.mode = 'notification',
    this.section = '',
    this.place = '',
    this.tone = 'global',
    this.toneUri = '',
    this.toneName = '',
    this.allowSpeech = true,
    this.vibrationCount = 0,
    this.color = 0,
  });
  final String id,
      subject,
      grade,
      mode,
      section,
      place,
      tone,
      toneUri,
      toneName;
  final bool allowSpeech;
  final int start, end, vibrationCount, color;
  final bool enabled;
  bool get vibrates => mode == 'vibration' || mode == 'both';
  bool get configured => subject.trim().isNotEmpty && grade.trim().isNotEmpty;
  bool get validTime => start >= 0 && end < 1440 && end > start;
  Lesson copyWith({
    String? id,
    int? vibrationCount,
    int? color,
    String? section,
    String? place,
    String? tone,
    String? toneUri,
    String? toneName,
    bool? allowSpeech,
    String? subject,
    String? grade,
    int? start,
    int? end,
    bool? enabled,
    String? mode,
  }) => Lesson(
    id: id ?? this.id,
    vibrationCount: vibrationCount ?? this.vibrationCount,
    color: color ?? this.color,
    section: section ?? this.section,
    place: place ?? this.place,
    tone: tone ?? this.tone,
    toneUri: toneUri ?? this.toneUri,
    toneName: toneName ?? this.toneName,
    allowSpeech: allowSpeech ?? this.allowSpeech,
    subject: subject ?? this.subject,
    grade: grade ?? this.grade,
    start: start ?? this.start,
    end: end ?? this.end,
    enabled: enabled ?? this.enabled,
    mode: mode ?? this.mode,
  );
  Map<String, dynamic> toJson() => {
    'id': id,
    'vibrationCount': vibrationCount,
    'color': color,
    'subject': subject,
    'grade': grade,
    'start': start,
    'end': end,
    'enabled': enabled,
    'mode': mode,
    'section': section,
    'place': place,
    'tone': tone,
    'toneUri': toneUri,
    'toneName': toneName,
    'allowSpeech': allowSpeech,
  };
  factory Lesson.fromJson(Map<String, dynamic> j) => Lesson(
    id: j['id']?.toString() ?? '',
    vibrationCount: ((j['vibrationCount'] as num?)?.toInt() ?? 0).clamp(0, 12),
    color: (j['color'] as num?)?.toInt() ?? 0,
    section: j['section'] as String? ?? '',
    place: j['place'] as String? ?? '',
    tone: j['tone'] as String? ?? 'global',
    toneUri: j['toneUri'] as String? ?? '',
    toneName: j['toneName'] as String? ?? '',
    allowSpeech: j['allowSpeech'] != false,
    subject: j['subject'] as String? ?? '',
    grade: j['grade'] as String? ?? '',
    start: (j['start'] as num?)?.toInt() ?? 480,
    end: (j['end'] as num?)?.toInt() ?? 525,
    enabled: j['enabled'] == true,
    mode: alertNames.containsKey(j['mode'])
        ? j['mode'] as String
        : 'notification',
  );
}

class DayOverride {
  DayOverride({this.closed = false, List<Lesson>? lessons})
    : lessons = lessons ?? [];
  final bool closed;
  final List<Lesson> lessons;
  Map<String, dynamic> toJson() => {
    'closed': closed,
    'lessons': lessons.map((l) => l.toJson()).toList(),
  };
  factory DayOverride.fromJson(Map<String, dynamic> j) => DayOverride(
    closed: j['closed'] == true,
    lessons: (j['lessons'] as List? ?? [])
        .map((v) => Lesson.fromJson(Map<String, dynamic>.from(v as Map)))
        .toList(),
  );
}

class Seasonal {
  const Seasonal({
    this.type = 'normal',
    this.from = '',
    this.until = '',
    this.start = 480,
    this.duration = 35,
    this.rest = 5,
  });
  final String type, from, until;
  final int start, duration, rest;
  bool active(String date) =>
      type != 'normal' &&
      from.isNotEmpty &&
      until.isNotEmpty &&
      date.compareTo(from) >= 0 &&
      date.compareTo(until) <= 0;
  Map<String, dynamic> toJson() => {
    'type': type,
    'from': from,
    'until': until,
    'start': start,
    'duration': duration,
    'rest': rest,
  };
  factory Seasonal.fromJson(Map<String, dynamic> j) => Seasonal(
    type: j['type'] as String? ?? 'normal',
    from: j['from'] as String? ?? '',
    until: j['until'] as String? ?? '',
    start: (j['start'] as num?)?.toInt() ?? 480,
    duration: (j['duration'] as num?)?.toInt() ?? 35,
    rest: (j['rest'] as num?)?.toInt() ?? 5,
  );
}

class PlannerState {
  PlannerState()
    : week = List.generate(
        7,
        (d) => List.generate(
          6,
          (i) => Lesson(
            id: 'd${d}l${i + 1}',
            start: originalStarts[i],
            end: originalEnds[i],
          ),
        ),
      );
  List<List<Lesson>> week;
  List<bool> work = [true, true, true, true, true, false, false];
  bool enabled = false,
      dark = false,
      large = false,
      speech = false,
      endAlert = false;
  bool focus = false, landscape = false;
  int textSize = 0, reportDay = -1;
  int reminder = 0, heroColor = defaultHeroColor, accentIndex = 0;
  VibrationProfile vibration = const VibrationProfile();
  VibrationProfile vibrationFor(Lesson lesson) => lesson.vibrationCount == 0
      ? vibration
      : vibration.copyWith(count: lesson.vibrationCount);
  double volume = .8;
  String tone = 'classic',
      toneUri = '',
      toneName = '',
      speechText = defaultSpeech,
      vacationUntil = '';
  Seasonal seasonal = const Seasonal();
  Map<String, DayOverride> exceptions = {};
  Map<String, int> cardColors = {};
  bool vacation(DateTime date) =>
      vacationUntil.isNotEmpty && dateKey(date).compareTo(vacationUntil) <= 0;
  List<Lesson> effective(DateTime date, {bool configuredOnly = true}) {
    final key = dateKey(date), override = exceptions[key];
    if (override?.closed == true) {
      return [];
    }
    if (override == null && !work[dayIndex(date)]) {
      return [];
    }
    var list = List<Lesson>.of(override?.lessons ?? week[dayIndex(date)]);
    if (override == null && seasonal.active(key)) {
      list = [
        for (var i = 0; i < list.length; i++)
          list[i].copyWith(
            start: seasonal.start + i * (seasonal.duration + seasonal.rest),
            end:
                seasonal.start +
                i * (seasonal.duration + seasonal.rest) +
                seasonal.duration,
          ),
      ];
    }
    list =
        list
            .where(
              (l) =>
                  l.validTime &&
                  (!configuredOnly || (l.enabled && l.configured)),
            )
            .toList()
          ..sort((a, b) => a.start.compareTo(b.start));
    return list;
  }

  ({Lesson lesson, DateTime at})? next(DateTime now) {
    DateTime first = dayDate(now);
    if (vacation(now)) {
      final end = DateTime.tryParse(vacationUntil);
      if (end != null) {
        first = dayDate(end, 1);
      }
    }
    for (var offset = 0; offset < 370; offset++) {
      final date = dayDate(first, offset);
      if (vacation(date)) {
        continue;
      }
      for (final lesson in effective(date)) {
        final at = atMinute(date, lesson.start);
        if (at.isAfter(now)) {
          return (lesson: lesson, at: at);
        }
      }
    }
    return null;
  }

  String announcement(Lesson lesson, int index) => speechText
      .replaceAll('{lesson}', 'الدرس ${index + 1}')
      .replaceAll('{subject}', lesson.subject)
      .replaceAll('{grade}', lesson.grade);
  PlannerState clone() => PlannerState.fromJson(toJson());
  Map<String, dynamic> toJson() => {
    'version': 5,
    'accentIndex': accentIndex,
    'vibration': vibration.toJson(),
    'focus': focus,
    'landscape': landscape,
    'textSize': textSize,
    'reportDay': reportDay,
    'week': week.map((a) => a.map((l) => l.toJson()).toList()).toList(),
    'work': work,
    'enabled': enabled,
    'dark': dark,
    'large': large,
    'speech': speech,
    'endAlert': endAlert,
    'reminder': reminder,
    'heroColor': heroColor,
    'volume': volume,
    'tone': tone,
    'toneUri': toneUri,
    'toneName': toneName,
    'speechText': speechText,
    'vacationUntil': vacationUntil,
    'seasonal': seasonal.toJson(),
    'exceptions': exceptions.map((k, v) => MapEntry(k, v.toJson())),
    'cardColors': cardColors,
  };
  factory PlannerState.fromJson(Map<String, dynamic> j) {
    final s = PlannerState();
    final week = j['week'];
    if (week is List && week.length == 7) {
      s.week = week
          .map(
            (day) => (day as List)
                .map(
                  (l) => Lesson.fromJson(Map<String, dynamic>.from(l as Map)),
                )
                .toList(),
          )
          .toList();
    }
    if (j['work'] is List && (j['work'] as List).length == 7) {
      s.work = (j['work'] as List).map((v) => v == true).toList();
    }
    if ((j['version'] as num? ?? 3) < 4) {
      for (var d = 0; d < 7; d++) {
        if (s.week[d].length == 5) {
          s.week[d].add(Lesson(id: 'd${d}_migration6', start: 710, end: 750));
        }
      }
    }
    s.focus = j['focus'] == true;
    s.landscape = j['landscape'] == true;
    s.textSize =
        ((j['textSize'] as num?)?.toInt() ?? (j['large'] == true ? 1 : 0))
            .clamp(0, 2);
    s.reportDay = ((j['reportDay'] as num?)?.toInt() ?? -1).clamp(-1, 6);
    s.enabled = j['enabled'] == true;
    s.dark = j['dark'] == true;
    s.large = j['large'] == true;
    s.speech = j['speech'] == true;
    s.endAlert = j['endAlert'] == true;
    s.reminder = ((j['reminder'] as num?)?.toInt() ?? 0).clamp(0, 60);
    final oldHero = (j['heroColor'] as num?)?.toInt();
    s.heroColor = (j['version'] as num? ?? 3) < 5 && oldHero == 0xff173f39
        ? defaultHeroColor
        : oldHero ?? defaultHeroColor;
    s.accentIndex = ((j['accentIndex'] as num?)?.toInt() ?? 0).clamp(0, 3);
    s.vibration = VibrationProfile.fromJson(j['vibration']);
    s.volume = ((j['volume'] as num?)?.toDouble() ?? .8).clamp(0, 1);
    s.tone = j['tone'] as String? ?? 'classic';
    s.toneUri = j['toneUri'] as String? ?? '';
    s.toneName = j['toneName'] as String? ?? '';
    s.speechText = j['speechText'] as String? ?? defaultSpeech;
    s.vacationUntil = j['vacationUntil'] as String? ?? '';
    if (j['seasonal'] is Map) {
      s.seasonal = Seasonal.fromJson(
        Map<String, dynamic>.from(j['seasonal'] as Map),
      );
    }
    if (j['exceptions'] is Map) {
      s.exceptions = (j['exceptions'] as Map).map(
        (k, v) => MapEntry(
          k.toString(),
          DayOverride.fromJson(Map<String, dynamic>.from(v as Map)),
        ),
      );
    }
    if (j['cardColors'] is Map) {
      s.cardColors = (j['cardColors'] as Map).map(
        (k, v) => MapEntry(k.toString(), (v as num).toInt()),
      );
    }
    return s;
  }
  String encode() => jsonEncode(toJson());
}

class AuditIssue {
  const AuditIssue(this.day, this.index, this.message);
  final int day, index;
  final String message;
}

List<AuditIssue> audit(PlannerState state) {
  final result = <AuditIssue>[];
  for (var d = 0; d < 7; d++) {
    if (!state.work[d]) {
      continue;
    }
    final list = state.week[d];
    for (var i = 0; i < list.length; i++) {
      final l = list[i];
      if (!l.enabled) {
        continue;
      }
      if (!l.configured) {
        result.add(
          AuditIssue(
            d,
            i,
            '${weekdays[d]}: المادة أو الصف غير مكتمل في الحصة ${i + 1}.',
          ),
        );
      }
      if (!l.validTime) {
        result.add(
          AuditIssue(d, i, '${weekdays[d]}: وقت الحصة ${i + 1} غير صالح.'),
        );
      }
      for (var k = 0; k < i; k++) {
        final a = list[k];
        if (a.enabled && l.start < a.end && l.end > a.start) {
          result.add(
            AuditIssue(
              d,
              i,
              '${weekdays[d]}: تداخل بين الحصتين ${k + 1} و${i + 1}.',
            ),
          );
        }
      }
    }
  }
  return result;
}

List<Lesson>? proposeTimes(List<Lesson> source) {
  var previousEnd = 0;
  final result = <Lesson>[];
  for (final l in source) {
    if (!l.enabled) {
      result.add(l);
      continue;
    }
    final start = l.start < previousEnd ? previousEnd : l.start;
    final duration = (l.end - l.start).clamp(10, 180);
    if (start + duration >= 1440) {
      return null;
    }
    result.add(l.copyWith(start: start, end: start + duration));
    previousEnd = start + duration + 5;
  }
  return result;
}

/// Copies only after every selected destination has passed validation.
PlannerState copyLessonToDays(
  PlannerState state,
  Lesson source,
  Set<int> days,
) {
  if (days.isEmpty) {
    throw ArgumentError('اختر يومًا واحدًا على الأقل.');
  }
  for (final d in days) {
    if (d < 0 || d > 6) {
      throw ArgumentError('يوم غير صالح.');
    }
    if (source.enabled &&
        state.week[d].any(
          (l) => l.enabled && source.start < l.end && source.end > l.start,
        )) {
      throw ArgumentError('يتداخل وقت الحصة في ${weekdays[d]}.');
    }
  }
  final next = state.clone();
  for (final d in days) {
    next.week[d].add(
      source.copyWith(
        id: 'd${d}_${source.id}_${DateTime.now().microsecondsSinceEpoch}',
      ),
    );
    next.week[d].sort((a, b) => a.start.compareTo(b.start));
  }
  return next;
}

PlannerState delayDay(
  PlannerState state,
  DateTime date,
  int fromIndex,
  int minutes,
) {
  final list = state.effective(date, configuredOnly: false);
  if (minutes < 1 ||
      minutes > 180 ||
      fromIndex < 0 ||
      fromIndex >= list.length) {
    throw ArgumentError('راجع الحصة وعدد دقائق التأخير.');
  }
  final shifted = [
    for (var i = 0; i < list.length; i++)
      i < fromIndex
          ? list[i]
          : list[i].copyWith(
              start: list[i].start + minutes,
              end: list[i].end + minutes,
            ),
  ];
  if (shifted.any((l) => !l.validTime)) {
    throw ArgumentError('التأخير يتجاوز نهاية اليوم.');
  }
  final next = state.clone();
  next.exceptions[dateKey(date)] = DayOverride(lessons: shifted);
  return next;
}

PlannerState pauseLessonForDate(PlannerState state, DateTime date, String id) {
  final list = state.effective(date, configuredOnly: false);
  if (!list.any((l) => l.id == id)) {
    throw ArgumentError('الحصة غير موجودة في هذا التاريخ.');
  }
  final next = state.clone();
  next.exceptions[dateKey(date)] = DayOverride(
    lessons: [
      for (final l in list) l.id == id ? l.copyWith(enabled: false) : l,
    ],
  );
  return next;
}
