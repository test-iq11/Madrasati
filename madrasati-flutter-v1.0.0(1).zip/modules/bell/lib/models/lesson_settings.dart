import 'package:flutter/material.dart';

enum AlertMode { notification, vibration, sound, both }

enum BellSound { classic, soft, doubleBell }

extension AlertModeDetails on AlertMode {
  String get label => switch (this) {
    AlertMode.notification => 'إشعار فقط',
    AlertMode.vibration => 'إشعار + اهتزاز',
    AlertMode.sound => 'إشعار + نغمة',
    AlertMode.both => 'كل الخيارات: إشعار + اهتزاز + نغمة',
  };

  String get description => switch (this) {
    AlertMode.notification =>
      'يظهر إشعار الحصة بصمت، من دون طلب صوت أو اهتزاز من التطبيق.',
    AlertMode.vibration =>
      'يظهر الإشعار مع نمط اهتزاز، من دون نغمة خاصة بالتطبيق.',
    AlertMode.sound => 'يظهر الإشعار مع نغمة الجرس التي تختارها.',
    AlertMode.both => 'يظهر الإشعار وتعمل نغمة الجرس والاهتزاز معاً.',
  };

  IconData get icon => switch (this) {
    AlertMode.notification => Icons.notifications_none_rounded,
    AlertMode.vibration => Icons.vibration_rounded,
    AlertMode.sound => Icons.volume_up_rounded,
    AlertMode.both => Icons.notifications_active_rounded,
  };
}

extension BellSoundDetails on BellSound {
  String get label => switch (this) {
    BellSound.classic => 'الجرس الكلاسيكي',
    BellSound.soft => 'نغمة هادئة',
    BellSound.doubleBell => 'رنتان متتاليتان',
  };

  String get rawResource => switch (this) {
    BellSound.classic => 'bell_tone',
    BellSound.soft => 'soft_chime',
    BellSound.doubleBell => 'double_bell',
  };
}

class LessonTime {
  const LessonTime({
    required this.lessonId,
    required this.startHour,
    required this.startMinute,
    required this.endHour,
    required this.endMinute,
  });

  final int lessonId;
  final int startHour;
  final int startMinute;
  final int endHour;
  final int endMinute;

  int get startMinutes => startHour * 60 + startMinute;
  int get endMinutes => endHour * 60 + endMinute;
  bool get isValid =>
      startHour >= 0 &&
      startHour <= 23 &&
      endHour >= 0 &&
      endHour <= 23 &&
      startMinute >= 0 &&
      startMinute <= 59 &&
      endMinute >= 0 &&
      endMinute <= 59 &&
      endMinutes > startMinutes;

  String get startTime => _formatTime(startHour, startMinute);
  String get endTime => _formatTime(endHour, endMinute);

  static String _formatTime(int hour, int minute) =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  LessonTime copyWith({
    int? startHour,
    int? startMinute,
    int? endHour,
    int? endMinute,
  }) => LessonTime(
    lessonId: lessonId,
    startHour: startHour ?? this.startHour,
    startMinute: startMinute ?? this.startMinute,
    endHour: endHour ?? this.endHour,
    endMinute: endMinute ?? this.endMinute,
  );

  Map<String, dynamic> toJson() => {
    'lessonId': lessonId,
    'startHour': startHour,
    'startMinute': startMinute,
    'endHour': endHour,
    'endMinute': endMinute,
  };

  factory LessonTime.fromJson(Map<String, dynamic> json, LessonTime fallback) {
    int read(String key, int value) {
      final candidate = json[key];
      return candidate is int ? candidate : value;
    }

    final parsed = LessonTime(
      lessonId: read('lessonId', fallback.lessonId),
      startHour: read('startHour', fallback.startHour),
      startMinute: read('startMinute', fallback.startMinute),
      endHour: read('endHour', fallback.endHour),
      endMinute: read('endMinute', fallback.endMinute),
    );
    return parsed.isValid ? parsed : fallback;
  }
}

class ScheduleProfile {
  const ScheduleProfile({
    required this.id,
    required this.name,
    required this.description,
    required this.times,
  });

  final String id;
  final String name;
  final String description;
  final List<LessonTime> times;

  LessonTime timeFor(int lessonId) => times.firstWhere(
    (value) => value.lessonId == lessonId,
    orElse: () => defaultLessons()
        .firstWhere((lesson) => lesson.id == lessonId)
        .asLessonTime(),
  );

  ScheduleProfile withTime(LessonTime updated) => ScheduleProfile(
    id: id,
    name: name,
    description: description,
    times: [
      for (final time in times)
        if (time.lessonId == updated.lessonId) updated else time,
      if (!times.any((time) => time.lessonId == updated.lessonId)) updated,
    ],
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'description': description,
    'times': times.map((value) => value.toJson()).toList(),
  };

  factory ScheduleProfile.fromJson(
    Map<String, dynamic> json,
    ScheduleProfile fallback,
  ) {
    final source = json['times'];
    final sourceById = <int, Map<String, dynamic>>{};
    if (source is List) {
      for (final value in source) {
        if (value is Map) {
          final data = Map<String, dynamic>.from(value);
          final id = data['lessonId'];
          if (id is int) {
            sourceById[id] = data;
          }
        }
      }
    }
    return ScheduleProfile(
      id: fallback.id,
      name: fallback.name,
      description: fallback.description,
      times: fallback.times
          .map(
            (time) => LessonTime.fromJson(
              sourceById[time.lessonId] ?? const <String, dynamic>{},
              time,
            ),
          )
          .toList(),
    );
  }
}

class LessonSettings {
  const LessonSettings({
    required this.id,
    required this.title,
    required this.startHour,
    required this.startMinute,
    required this.endHour,
    required this.endMinute,
    required this.color,
    required this.icon,
    this.subject = '',
    this.customSubject = '',
    this.grade = '',
    this.enabled = false,
    this.alertMode = AlertMode.notification,
  });

  final int id;
  final String title;
  final int startHour;
  final int startMinute;
  final int endHour;
  final int endMinute;
  final Color color;
  final IconData icon;
  final String subject;
  final String customSubject;
  final String grade;
  final bool enabled;
  final AlertMode alertMode;

  String get subjectLabel =>
      subject == 'مادة أخرى' ? customSubject.trim() : subject;
  bool get isConfigured => subjectLabel.isNotEmpty && grade.isNotEmpty;
  String get startTime => _formatTime(startHour, startMinute);
  String get endTime => _formatTime(endHour, endMinute);
  String get alertLabel => alertMode.label;

  LessonTime asLessonTime() => LessonTime(
    lessonId: id,
    startHour: startHour,
    startMinute: startMinute,
    endHour: endHour,
    endMinute: endMinute,
  );

  LessonSettings withTime(LessonTime time) => copyWith(
    startHour: time.startHour,
    startMinute: time.startMinute,
    endHour: time.endHour,
    endMinute: time.endMinute,
  );

  static String _formatTime(int hour, int minute) =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  LessonSettings copyWith({
    String? subject,
    String? customSubject,
    String? grade,
    bool? enabled,
    AlertMode? alertMode,
    int? startHour,
    int? startMinute,
    int? endHour,
    int? endMinute,
  }) => LessonSettings(
    id: id,
    title: title,
    startHour: startHour ?? this.startHour,
    startMinute: startMinute ?? this.startMinute,
    endHour: endHour ?? this.endHour,
    endMinute: endMinute ?? this.endMinute,
    color: color,
    icon: icon,
    subject: subject ?? this.subject,
    customSubject: customSubject ?? this.customSubject,
    grade: grade ?? this.grade,
    enabled: enabled ?? this.enabled,
    alertMode: alertMode ?? this.alertMode,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'subject': subject,
    'customSubject': customSubject,
    'grade': grade,
    'enabled': enabled,
    'alertMode': alertMode.name,
    // Retained for compatibility with the original stored timetable.
    'startHour': startHour,
    'startMinute': startMinute,
    'endHour': endHour,
    'endMinute': endMinute,
  };

  LessonSettings applyJson(Map<String, dynamic> json) {
    final rawMode = json['alertMode'] as String? ?? AlertMode.notification.name;
    final mode = AlertMode.values.firstWhere(
      (value) => value.name == rawMode,
      orElse: () => AlertMode.notification,
    );
    int read(String key, int value) =>
        json[key] is int ? json[key] as int : value;
    return copyWith(
      subject: json['subject'] as String? ?? '',
      customSubject: json['customSubject'] as String? ?? '',
      grade: json['grade'] as String? ?? '',
      enabled: json['enabled'] as bool? ?? false,
      alertMode: mode,
      startHour: read('startHour', startHour),
      startMinute: read('startMinute', startMinute),
      endHour: read('endHour', endHour),
      endMinute: read('endMinute', endMinute),
    );
  }
}

class AppSettings {
  const AppSettings({
    required this.lessons,
    required this.workDays,
    required this.notificationsEnabled,
    required this.profiles,
    required this.dayProfileIds,
    required this.bellSound,
    required this.darkMode,
    required this.announcementsEnabled,
    required this.announcementText,
    required this.announcementVolume,
  });

  final List<LessonSettings> lessons;

  /// Display order is Sunday through Saturday.
  final List<bool> workDays;
  final bool notificationsEnabled;
  final List<ScheduleProfile> profiles;

  /// One profile ID per weekday, in Sunday-through-Saturday order.
  final List<String> dayProfileIds;
  final BellSound bellSound;
  final bool darkMode;
  final bool announcementsEnabled;
  final String announcementText;
  final double announcementVolume;

  ScheduleProfile profileForDay(int dayIndex) {
    final id = dayIndex >= 0 && dayIndex < dayProfileIds.length
        ? dayProfileIds[dayIndex]
        : 'morning';
    return profiles.firstWhere(
      (profile) => profile.id == id,
      orElse: () => profiles.first,
    );
  }

  AppSettings copyWith({
    List<LessonSettings>? lessons,
    List<bool>? workDays,
    bool? notificationsEnabled,
    List<ScheduleProfile>? profiles,
    List<String>? dayProfileIds,
    BellSound? bellSound,
    bool? darkMode,
    bool? announcementsEnabled,
    String? announcementText,
    double? announcementVolume,
  }) => AppSettings(
    lessons: lessons ?? this.lessons,
    workDays: workDays ?? this.workDays,
    notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
    profiles: profiles ?? this.profiles,
    dayProfileIds: dayProfileIds ?? this.dayProfileIds,
    bellSound: bellSound ?? this.bellSound,
    darkMode: darkMode ?? this.darkMode,
    announcementsEnabled: announcementsEnabled ?? this.announcementsEnabled,
    announcementText: announcementText ?? this.announcementText,
    announcementVolume: announcementVolume ?? this.announcementVolume,
  );
}

const List<String> schoolSubjects = [
  'التربية الإسلامية',
  'اللغة العربية',
  'اللغة الإنكليزية',
  'الرياضيات',
  'العلوم',
  'الاجتماعيات',
  'التربية الفنية',
  'التربية الرياضية',
  'الحاسوب',
  'مادة أخرى',
];

const List<String> schoolGrades = [
  'الأول الابتدائي',
  'الثاني الابتدائي',
  'الثالث الابتدائي',
  'الرابع الابتدائي',
  'الخامس الابتدائي',
  'السادس الابتدائي',
];

const List<String> arabicWeekdays = [
  'الأحد',
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
];

const defaultAnnouncementText =
    'حان موعد {lesson}. المادة {subject}. الصف {grade}.';

List<LessonSettings> defaultLessons() => List<LessonSettings>.of(const [
  LessonSettings(
    id: 1,
    title: 'الدرس الأول',
    startHour: 8,
    startMinute: 0,
    endHour: 8,
    endMinute: 45,
    color: Color(0xFF4778D8),
    icon: Icons.auto_stories_rounded,
  ),
  LessonSettings(
    id: 2,
    title: 'الدرس الثاني',
    startHour: 8,
    startMinute: 50,
    endHour: 9,
    endMinute: 30,
    color: Color(0xFF18A999),
    icon: Icons.science_rounded,
  ),
  LessonSettings(
    id: 3,
    title: 'الدرس الثالث',
    startHour: 9,
    startMinute: 35,
    endHour: 10,
    endMinute: 10,
    color: Color(0xFF8B69D4),
    icon: Icons.calculate_rounded,
  ),
  LessonSettings(
    id: 4,
    title: 'الدرس الرابع',
    startHour: 10,
    startMinute: 20,
    endHour: 11,
    endMinute: 0,
    color: Color(0xFFE79A43),
    icon: Icons.palette_rounded,
  ),
  LessonSettings(
    id: 5,
    title: 'الدرس الخامس',
    startHour: 11,
    startMinute: 5,
    endHour: 11,
    endMinute: 45,
    color: Color(0xFFE16984),
    icon: Icons.menu_book_rounded,
  ),
]);

List<ScheduleProfile> defaultScheduleProfiles() {
  final originalTimes = defaultLessons()
      .map((lesson) => lesson.asLessonTime())
      .toList();
  final eveningTimes = originalTimes.map((time) {
    int shifted(int minutes) {
      // Normalize a clock time into the 0..1439 minute range.
      return minutes % (24 * 60);
    }

    final start = shifted(time.startMinutes + 300);
    final end = shifted(time.endMinutes + 300);
    return LessonTime(
      lessonId: time.lessonId,
      startHour: start ~/ 60,
      startMinute: start % 60,
      endHour: end ~/ 60,
      endMinute: end % 60,
    );
  }).toList();
  const examStarts = [480, 540, 600, 660, 720];
  final examTimes = [
    for (var index = 0; index < originalTimes.length; index++)
      LessonTime(
        lessonId: originalTimes[index].lessonId,
        startHour: examStarts[index] ~/ 60,
        startMinute: examStarts[index] % 60,
        endHour: (examStarts[index] + 45) ~/ 60,
        endMinute: (examStarts[index] + 45) % 60,
      ),
  ];
  return [
    ScheduleProfile(
      id: 'morning',
      name: 'الصباحي',
      description: 'الجدول الأصلي المحدد للحصص الصباحية.',
      times: originalTimes,
    ),
    ScheduleProfile(
      id: 'evening',
      name: 'المسائي',
      description:
          'نموذج مسائي يبدأ بعد خمس ساعات من الجدول الصباحي؛ عدّله حسب مدرستك.',
      times: eveningTimes,
    ),
    ScheduleProfile(
      id: 'exam',
      name: 'الامتحانات',
      description: 'نموذج مبدئي بفواصل مختلفة، وجميع الأوقات قابلة للتعديل.',
      times: examTimes,
    ),
  ];
}
