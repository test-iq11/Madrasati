import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:teacher_bell/domain.dart';
import 'package:teacher_bell/main.dart';
import 'package:teacher_bell/lesson_tile.dart';

void main() {
  for (final width in [320.0, 360.0, 390.0]) {
    testWidgets(
      'phone width $width preserves main layout and keeps spoken reminder in settings',
      (tester) async {
        tester.view.physicalSize = Size(width, 900);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        final s = PlannerState()
          ..large = true
          ..speech = true;
        await tester.pumpWidget(
          TeacherBellApp(initialState: s, platformEnabled: false),
        );
        await tester.pumpAndSettle();
        expect(find.text('يوم دراسي موفّق'), findsNothing);
        expect(find.text('التذكير الصوتي المنطوق'), findsNothing);
        expect(tester.takeException(), isNull);
        await tester.tap(find.text('الإعدادات'));
        await tester.pumpAndSettle();
        expect(find.text('التذكير الصوتي المنطوق'), findsOneWidget);
        expect(find.text('إعادة ضبط التطبيق'), findsWidgets);
        expect(find.text('الإصدار $appVersion · Android'), findsOneWidget);
        expect(tester.takeException(), isNull);
        await tester.pumpWidget(const SizedBox());
      },
    );
  }
  for (final width in [320.0, 360.0, 390.0]) {
    for (final scale in [1.0, 1.28]) {
      testWidgets('compact lesson at $width and text scale $scale', (
        tester,
      ) async {
        tester.view.physicalSize = Size(width, 500);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        var actions = false;
        await tester.pumpWidget(
          MaterialApp(
            home: Directionality(
              textDirection: TextDirection.rtl,
              child: MediaQuery(
                data: MediaQueryData(
                  size: Size(width, 500),
                  textScaler: TextScaler.linear(scale),
                ),
                child: Scaffold(
                  body: Padding(
                    padding: const EdgeInsets.all(14),
                    child: LessonTile(
                      lesson: const Lesson(
                        id: 'a',
                        subject: 'اللغة العربية وآدابها',
                        grade: 'السادس الابتدائي',
                        section: 'ب',
                        place: 'القاعة الثالثة',
                        start: 480,
                        end: 525,
                        enabled: true,
                      ),
                      index: 0,
                      color: const Color(0xff237463),
                      date: DateTime(2026, 11, 8),
                      now: DateTime(2026, 11, 8, 8, 10),
                      onTap: () {},
                      onActions: () {
                        actions = true;
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
        expect(tester.getSize(find.byType(LessonTile)).height, lessThan(160));
        await tester.tap(find.byTooltip('إجراءات الحصة 1'));
        expect(actions, isTrue);
        await tester.pumpWidget(const SizedBox());
      });
    }
  }
}
