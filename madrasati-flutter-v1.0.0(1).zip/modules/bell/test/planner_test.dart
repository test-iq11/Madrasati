import 'package:flutter_test/flutter_test.dart';
import 'package:teacher_bell/domain.dart';

PlannerState configured() {
  final s = PlannerState();
  for (var d = 0; d < 7; d++) {
    s.week[d] = [
      Lesson(
        id: 'd$d',
        subject: 'العلوم',
        grade: grades[1],
        start: 480,
        end: 525,
        enabled: true,
        mode: 'both',
      ),
    ];
  }
  return s;
}

void main() {
  test('fresh app has six default times with speech and alerts disabled', () {
    final s = PlannerState();
    expect(s.week.first.map((l) => l.start), originalStarts);
    expect(s.week.first.map((l) => l.end), originalEnds);
    expect(s.speech, isFalse);
    expect(s.enabled, isFalse);
    expect(s.effective(DateTime(2026, 11, 8)), isEmpty);
  });
  test('each weekday retains its own subject', () {
    final s = configured();
    s.week[1][0] = s.week[1][0].copyWith(subject: 'الرياضيات');
    expect(s.effective(DateTime(2026, 11, 8)).single.subject, 'العلوم');
    expect(s.effective(DateTime(2026, 11, 9)).single.subject, 'الرياضيات');
  });
  test('date override changes one date without editing weekly data', () {
    final s = configured();
    s.exceptions['2026-11-08'] = DayOverride(
      lessons: [s.week[0][0].copyWith(start: 540, end: 580)],
    );
    expect(s.effective(DateTime(2026, 11, 8)).single.start, 540);
    expect(s.effective(DateTime(2026, 11, 15)).single.start, 480);
  });
  test('cancelled date schedules next active day', () {
    final s = configured();
    s.exceptions['2026-11-08'] = DayOverride(closed: true);
    expect(s.next(DateTime(2026, 11, 8, 7))!.at, DateTime(2026, 11, 9, 8));
  });
  test(
    'vacation is inclusive and next lesson resumes without reopening app',
    () {
      final s = configured()..vacationUntil = '2026-11-09';
      expect(s.vacation(DateTime(2026, 11, 9, 23, 59)), isTrue);
      expect(s.vacation(DateTime(2026, 11, 10)), isFalse);
      expect(s.next(DateTime(2026, 11, 8, 7))!.at, DateTime(2026, 11, 10, 8));
    },
  );
  test('seasonal timetable expires and exceptions take precedence', () {
    final s = configured()
      ..seasonal = const Seasonal(
        type: 'ramadan',
        from: '2026-11-08',
        until: '2026-11-09',
        start: 540,
        duration: 30,
        rest: 5,
      );
    expect(s.effective(DateTime(2026, 11, 8)).single.start, 540);
    expect(s.effective(DateTime(2026, 11, 10)).single.start, 480);
    s.exceptions['2026-11-08'] = DayOverride(
      lessons: [s.week[0][0].copyWith(start: 600, end: 645)],
    );
    expect(s.effective(DateTime(2026, 11, 8)).single.start, 600);
  });
  test(
    'unconfigured and disabled lessons never become scheduled candidates',
    () {
      final s = configured();
      s.week[0] = [
        s.week[0][0].copyWith(subject: ''),
        s.week[0][0].copyWith(enabled: false),
      ];
      expect(s.effective(DateTime(2026, 11, 8)), isEmpty);
    },
  );
  test('audit detects overlapping active lessons and incomplete grade', () {
    final s = configured();
    s.week[0].add(
      const Lesson(
        id: 'second',
        subject: 'الرياضيات',
        start: 510,
        end: 555,
        enabled: true,
      ),
    );
    expect(audit(s).where((e) => e.day == 0).length, 2);
  });
  test('repair preserves lessons and adds a five minute break', () {
    final a = [
      const Lesson(
        id: 'a',
        subject: 'أ',
        grade: 'صف',
        start: 480,
        end: 525,
        enabled: true,
      ),
      const Lesson(
        id: 'b',
        subject: 'ب',
        grade: 'صف',
        start: 510,
        end: 550,
        enabled: true,
      ),
    ];
    final p = proposeTimes(a)!;
    expect(p[0].start, 480);
    expect(p[1].start, 530);
    expect(p[1].end, 570);
    expect(p[1].subject, 'ب');
    expect(a[1].start, 510);
  });
  test('repair refuses to overflow the day', () {
    final a = [
      const Lesson(id: 'a', start: 1360, end: 1420, enabled: true),
      const Lesson(id: 'b', start: 1370, end: 1435, enabled: true),
    ];
    expect(proposeTimes(a), isNull);
  });
  test(
    'serialization preserves custom tone, palette, speech and extra lessons',
    () {
      final s = configured()
        ..tone = 'device'
        ..toneUri = 'content://com.school.teacherbell.files/tones/test.mp3'
        ..toneName = 'نغمتي'
        ..speech = true
        ..large = true
        ..reminder = 5;
      s.cardColors['العلوم'] = 0xff7860a5;
      s.week[0].add(const Lesson(id: 'extra', start: 700, end: 740));
      final copy = s.clone();
      expect(copy.toneUri, s.toneUri);
      expect(copy.cardColors, s.cardColors);
      expect(copy.speech, isTrue);
      expect(copy.large, isTrue);
      expect(copy.week[0].length, 2);
      copy.week[0].clear();
      expect(s.week[0].length, 2);
    },
  );
  test('six default lessons are safe and unconfigured', () {
    final s = PlannerState();
    expect(s.week.every((d) => d.length == 6), isTrue);
    expect(s.week[0][5].start, 710);
    expect(s.week[0][5].enabled, isFalse);
  });
  test(
    'v3 migration preserves edited five lessons and adds inactive sixth once',
    () {
      final s = PlannerState();
      for (var d = 0; d < 7; d++) {
        s.week[d] = s.week[d].take(5).toList();
      }
      s.week[0][0] = s.week[0][0].copyWith(subject: 'مادتي', start: 490);
      final raw = s.toJson()..['version'] = 3;
      final migrated = PlannerState.fromJson(raw);
      expect(migrated.week[0].length, 6);
      expect(migrated.week[0][0].subject, 'مادتي');
      expect(migrated.week[0][0].start, 490);
      expect(migrated.week[0].last.enabled, isFalse);
      migrated.week[0].removeLast();
      expect(migrated.clone().week[0].length, 5);
    },
  );
  test('lesson metadata and report preferences survive persistence', () {
    final s = configured()
      ..focus = true
      ..textSize = 2
      ..landscape = true
      ..reportDay = 3;
    s.week[0][0] = s.week[0][0].copyWith(
      section: 'ب',
      place: 'قاعة ٣',
      tone: 'device',
      toneUri: 'content://tone/1',
      toneName: 'مخصص',
      allowSpeech: false,
    );
    final copy = s.clone();
    expect(copy.week[0][0].toJson(), s.week[0][0].toJson());
    expect(copy.focus, isTrue);
    expect(copy.textSize, 2);
    expect(copy.landscape, isTrue);
    expect(copy.reportDay, 3);
  });
  test('copy validates all destinations before mutating any day', () {
    final s = configured();
    s.week[1].clear();
    var rejected = false;
    try {
      copyLessonToDays(s, s.week[0][0], {1, 2});
    } on ArgumentError {
      rejected = true;
    }
    expect(rejected, isTrue);
    expect(s.week[1], isEmpty);
    s.week[2].clear();
    final copied = copyLessonToDays(s, s.week[0][0].copyWith(section: 'ج'), {
      1,
      2,
    });
    expect(copied.week[1].single.section, 'ج');
    expect(copied.week[1].single.id == copied.week[2].single.id, isFalse);
    expect(s.week[1], isEmpty);
  });
  test('delay affects selected date and keeps prior lessons unchanged', () {
    final s = configured();
    s.week[0].add(s.week[0][0].copyWith(id: 'second', start: 530, end: 570));
    final shifted = delayDay(s, DateTime(2026, 11, 8), 1, 15);
    expect(shifted.effective(DateTime(2026, 11, 8))[0].start, 480);
    expect(shifted.effective(DateTime(2026, 11, 8))[1].start, 545);
    expect(shifted.effective(DateTime(2026, 11, 15))[1].start, 530);
    expect(s.exceptions.isEmpty, isTrue);
  });
  test('pause is restricted to one date and survives saving', () {
    final s = configured();
    final paused = pauseLessonForDate(s, DateTime(2026, 11, 8), 'd0').clone();
    expect(paused.effective(DateTime(2026, 11, 8)), isEmpty);
    expect(paused.effective(DateTime(2026, 11, 15)).single.enabled, isTrue);
    expect(s.week[0].single.enabled, isTrue);
  });
}
