import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/school_day.dart';

void main() {
  const sections = [
    {'id': 1, 'grade_name': 'السادس الابتدائي', 'section_name': 'أ'},
    {'id': 2, 'grade_name': 'السادس الابتدائي', 'section_name': 'ب'},
  ];
  Map<String, Object?> lesson(
    int id,
    int section,
    String day,
    String start,
    String end,
  ) => {
    'id': id,
    'section_id': section,
    'section_name': 'أ',
    'day_name': day,
    'subject_name': 'الرياضيات',
    'start_time': start,
    'end_time': end,
  };

  test(
    'loads only the selected section and day without dropping seventh lesson',
    () {
      final result = SchoolDay.select(
        sections,
        [
          lesson(99, 2, 'الأحد', '09:00', '09:45'),
          lesson(98, 1, 'الاثنين', '09:00', '09:45'),
          for (final (i, hour) in [7, 8, 9, 10, 11, 12, 13].indexed)
            lesson(
              i,
              1,
              'الأحد',
              '${hour.toString().padLeft(2, '0')}:00',
              '${hour.toString().padLeft(2, '0')}:45',
            ),
        ],
        1,
        DateTime(2026, 11, 15),
      );
      final bell = result.toBellLessons();
      expect(result.sectionId, 1);
      expect(result.dayName, 'الأحد');
      expect(bell, hasLength(7));
      expect(bell!.last.start, 780);
    },
  );

  test('refuses overlap and invalid minutes before touching the bell', () {
    final result = SchoolDay.select(
      sections,
      [
        lesson(1, 1, 'الأحد', '08:00', '08:45'),
        lesson(2, 1, 'الأحد', '08:30', '09:05'),
      ],
      1,
      DateTime(2026, 11, 15),
    );
    expect(result.toBellLessons(), isNull);
  });
}
