package com.school.teacherbell
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class BellSchedulerTest {
    @Before fun timezone(){TimeZone.setDefault(TimeZone.getTimeZone("Asia/Baghdad"))}
    private fun timestamp(s:String):Long=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(s)!!.time
    private fun config():JSONObject {
        val week=JSONArray()
        for(d in 0..6)week.put(JSONArray().put(JSONObject().put("id","d$d").put("subject","العلوم").put("grade","الثاني").put("start",480).put("end",525).put("enabled",true).put("mode","both")))
        return JSONObject().put("week",week).put("work",JSONArray(listOf(true,true,true,true,true,false,false))).put("enabled",true).put("exceptions",JSONObject()).put("seasonal",JSONObject().put("type","normal"))
    }
    @Test fun nextReminderIsBeforeStart(){val c=config().put("reminder",5);assertEquals(timestamp("2026-11-08 07:55"),BellScheduler.nextEvents(c,timestamp("2026-11-08 07:00")).first().getLong("at"))}
    @Test fun reminderDoesNotReplaceStart(){val c=config().put("reminder",5);assertEquals("start",BellScheduler.nextEvents(c,timestamp("2026-11-08 07:55")).first().getString("type"))}
    @Test fun endAlertIsScheduledAfterStart(){val c=config().put("endAlert",true);val next=BellScheduler.nextEvents(c,timestamp("2026-11-08 08:01")).first();assertEquals("end",next.getString("type"));assertEquals(timestamp("2026-11-08 08:45"),next.getLong("at"))}
    @Test fun cancellationAffectsOnlyOneDate(){val c=config();c.getJSONObject("exceptions").put("2026-11-08",JSONObject().put("closed",true));assertEquals(timestamp("2026-11-09 08:00"),BellScheduler.nextEvents(c,timestamp("2026-11-08 07:00")).first().getLong("at"))}
    @Test fun vacationResumesAutomatically(){val c=config().put("vacationUntil","2026-11-09");assertEquals(timestamp("2026-11-10 08:00"),BellScheduler.nextEvents(c,timestamp("2026-11-08 07:00")).first().getLong("at"))}
    @Test fun disabledConfigurationHasNoAlarms(){assertTrue(BellScheduler.nextEvents(config().put("enabled",false),timestamp("2026-11-08 07:00")).isEmpty())}
    @Test fun seasonalExpires(){val c=config().put("seasonal",JSONObject().put("type","ramadan").put("from","2026-11-08").put("until","2026-11-09").put("start",540).put("duration",30).put("rest",5));assertEquals(timestamp("2026-11-08 09:00"),BellScheduler.nextEvents(c,timestamp("2026-11-08 07:00")).first().getLong("at"));assertEquals(timestamp("2026-11-10 08:00"),BellScheduler.nextEvents(c,timestamp("2026-11-10 07:00")).first().getLong("at"))}
    @Test fun normalWeekContinuesBeyondFiniteHorizon(){val c=config();assertEquals(timestamp("2027-11-07 08:00"),BellScheduler.nextEvents(c,timestamp("2027-11-07 07:00")).first().getLong("at"))}

    @Test fun sixthLessonCanBeNextScheduledEvent() {
        val c=config()
        c.getJSONArray("week").getJSONArray(0).put(JSONObject().put("id","sixth").put("subject","الحاسوب").put("grade","السادس").put("start",710).put("end",750).put("enabled",true))
        val next=BellScheduler.nextEvents(c,timestamp("2026-11-08 11:00")).first()
        assertEquals("sixth",next.getJSONObject("lesson").getString("id"))
        assertEquals(timestamp("2026-11-08 11:50"),next.getLong("at"))
    }
    @Test fun customLessonFieldsReachNativeEvent() {
        val c=config()
        c.getJSONArray("week").getJSONArray(0).getJSONObject(0).put("section","ب").put("place","قاعة ٣").put("tone","device").put("toneUri","content://test/tone").put("allowSpeech",false)
        val l=BellScheduler.nextEvents(c,timestamp("2026-11-08 07:00")).first().getJSONObject("lesson")
        assertEquals("ب",l.getString("section"))
        assertEquals("قاعة ٣",l.getString("place"))
        assertEquals("content://test/tone",l.getString("toneUri"))
        assertFalse(l.getBoolean("allowSpeech"))
    }
}
