package com.school.teacherbell

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class BellVibrationTest {
    @Test fun threePulsesHaveAnInitialZeroAndTwoGaps() {
        val profile = BellVibration.from(JSONObject().put("count", 3).put("pulse", 240).put("gap", 160))
        assertArrayEquals(longArrayOf(0, 240, 160, 240, 160, 240), profile.timings())
    }

    @Test fun lessonCountOverridesGeneralCountAndKeepsTiming() {
        val general = JSONObject().put("count", 6).put("pulse", 190).put("gap", 140)
        val single = BellVibration.from(general, 1)
        assertArrayEquals(longArrayOf(0, 190), single.timings())
        assertNotEquals(single.channelSuffix, BellVibration.from(general).channelSuffix)
        val largest = BellVibration.from(general, 12)
        assertEquals(12, largest.timings().filterIndexed { index, _ -> index % 2 == 1 }.size)
        assertEquals(190L, largest.timings().last())
    }

    @Test fun oldConfigurationAndOutOfRangeValuesRemainUsable() {
        assertEquals(BellVibration(3, 240, 160), BellVibration.from(null))
        val invalid = JSONObject().put("count", 100).put("pulse", 4).put("gap", 900)
        assertEquals(BellVibration(12, 80, 650), BellVibration.from(invalid, -1))
    }

    @Test fun lockScreenTestUsesUpcomingLessonVibrationCountAndMode() {
        val lesson = JSONObject().put("id", "math").put("subject", "رياضيات")
            .put("grade", "الرابع").put("enabled", true).put("start", 480)
            .put("end", 525).put("mode", "both").put("vibrationCount", 8)
            .put("tone", "soft")
        val config = JSONObject().put("work", JSONArray(List(7) { true }))
            .put("week", JSONArray(List(7) { JSONArray().put(lesson) }))
        val selected = BellTestReceiver.testLesson(config, 0)
        assertEquals("clock_vibration_test", selected.getString("id"))
        assertEquals("both", selected.getString("mode"))
        assertEquals("soft", selected.getString("tone"))
        assertEquals(8, BellVibration.from(null, selected.optInt("vibrationCount")).count)
        assertEquals(false, selected.optBoolean("allowSpeech"))
        assertEquals("math", lesson.getString("id"))
    }

    @Test fun emptyScheduleStillOffersARealVibrationOnlyTest() {
        val selected = BellTestReceiver.testLesson(JSONObject(), 0)
        assertEquals("vibration", selected.getString("mode"))
        assertEquals(3, BellVibration.from(null, selected.optInt("vibrationCount")).count)
    }

}
