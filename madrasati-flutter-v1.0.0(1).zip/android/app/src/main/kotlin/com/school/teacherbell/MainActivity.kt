package com.school.teacherbell

import android.Manifest
import android.app.NotificationManager
import android.appwidget.AppWidgetManager
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.core.content.FileProvider
import com.sajli.school.SajliActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class MainActivity : SajliActivity() {
    private var pickResult: MethodChannel.Result? = null
    private var permissionResult: MethodChannel.Result? = null
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger,"com.school.teacherbell/device").setMethodCallHandler { call,result ->
            try {
                when(call.method) {
                    "status" -> result.success(BellScheduler.status(this))
                    "sync" -> { val raw=call.arguments as String;BellScheduler.sync(applicationContext,raw);if(!JSONObject(raw).optBoolean("speech")){BellAudio.stop();stopService(Intent(this,BellSpeechService::class.java))};result.success(null) }
                    "pickTone" -> {
                        if(pickResult!=null){result.error("busy","A picker is already open",null)}
                        else {pickResult=result;startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="audio/*";addCategory(Intent.CATEGORY_OPENABLE);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},4001)}
                    }
                    "requestNotifications" -> {
                        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                            if(permissionResult!=null)result.error("busy","Permission request pending",null)
                            else{permissionResult=result;requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),4002)}
                        }else result.success(true)
                    }
                    "openSettings" -> {openDeviceSettings(call.arguments as? String ?: "app");result.success(null)}
                    "testTone" -> {BellAudio.play(applicationContext,JSONObject(call.arguments as String));result.success(null)}
                    "testVibration" -> {
                        val profile = BellVibration.from(JSONObject(call.arguments as Map<*, *>))
                        val sent = BellVibration.play(this, profile)
                        BellScheduler.log(this, if (sent) "اختبار الهزاز · ${profile.count} هزات" else "اختبار الهزاز · لا يوجد هزاز متاح")
                        result.success(sent)
                    }
                    "stopVibration" -> { BellVibration.cancel(this); result.success(null) }
                    "stopSound" -> {BellAudio.stop();stopService(Intent(this,BellSpeechService::class.java));result.success(null)}
                    "speak" -> {val args=call.arguments as Map<*,*>;BellAudio.speak(applicationContext,args["text"].toString(),(args["volume"] as Number).toFloat());result.success(null)}
                    "logEdit" -> {
                        BellScheduler.log(this, call.arguments as String, "edit")
                        result.success(null)
                    }
                    "logs" -> {val raw=getSharedPreferences(BellScheduler.PREFS,MODE_PRIVATE).getString("logs","[]");val array=JSONArray(raw);result.success((0 until array.length()).map{val j=array.getJSONObject(it);mapOf("text" to j.optString("text"),"time" to j.optString("time"),"kind" to j.optString("kind", if (j.optString("text").contains("اختبار")) "test" else "alert"))})}
                    "clearLogs" -> {getSharedPreferences(BellScheduler.PREFS,MODE_PRIVATE).edit().remove("logs").apply();result.success(null)}
                    "scheduleTest" -> {result.success(BellTestReceiver.schedule(this,call.arguments as String))}
                    "cancelTest" -> {BellTestReceiver.cancel(this);result.success(null)}
                    "reset" -> {BellVibration.cancel(this);BellTestReceiver.cancel(this);BellScheduler.cancel(this);BellAudio.stop();stopService(Intent(this,BellSpeechService::class.java));(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancelAll();getSharedPreferences(BellScheduler.PREFS,MODE_PRIVATE).edit().clear().commit();File(filesDir,"tones").deleteRecursively();BellWidget.updateAll(this);result.success(null)}
                    "shareImage" -> {val bytes=call.arguments as ByteArray;val dir=File(cacheDir,"exports").apply{mkdirs()};dir.listFiles()?.forEach{it.delete()};val file=File(dir,"teacher_bell_weekly.png");file.writeBytes(bytes);val uri=FileProvider.getUriForFile(this,"$packageName.files",file);val intent=Intent(Intent.ACTION_SEND).apply{type="image/png";putExtra(Intent.EXTRA_STREAM,uri);clipData=ClipData.newRawUri("الجدول الأسبوعي",uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};startActivity(Intent.createChooser(intent,"مشاركة الجدول"));result.success(null)}
                    "printSchedule" -> {
                        val args = call.arguments as Map<*, *>
                        val lines = (args["lines"] as List<*>).filterIsInstance<String>()
                        BellPrint.open(this, "جرس المعلم · الجدول الأسبوعي", lines, args["landscape"] == true)
                        result.success(null)
                    }
                    "pinWidget" -> {val manager=AppWidgetManager.getInstance(this);if(Build.VERSION.SDK_INT>=26&&manager.isRequestPinAppWidgetSupported)result.success(manager.requestPinAppWidget(ComponentName(this,BellWidget::class.java),null,null))else result.success(false)}
                    else -> result.notImplemented()
                }
            }catch(error:Exception){if(call.method=="pickTone")pickResult=null;result.error("device_error",error.localizedMessage,null)}
        }
    }
    private fun openDeviceSettings(kind:String){
        val intent=when(kind){
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "exact" -> if(Build.VERSION.SDK_INT>=31)Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:$packageName"))else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName"))
            "vibration" -> {
                val channel = BellScheduler.vibrationChannel(this)
                if (Build.VERSION.SDK_INT >= 26 && channel != null) {
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, channel)
                } else if (Build.VERSION.SDK_INT >= 26) {
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                } else {
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                }
            }
            "battery" -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            else -> if(Build.VERSION.SDK_INT>=26)Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,packageName)else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName"))
        }
        startActivity(intent)
    }
    @Deprecated("Uses FlutterActivity activity result dispatch")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode!=4001)return
        val result=pickResult?:return;pickResult=null
        if(resultCode!=RESULT_OK||data?.data==null){result.success(null);return}
        val source=data.data!!
        Thread {
            var output:File?=null
            try {
                var name="نغمة من الهاتف"
                contentResolver.query(source,arrayOf(OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE),null,null,null)?.use{cursor->
                    if(cursor.moveToFirst()){
                        val column=cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(column>=0)name=cursor.getString(column)
                        val size=cursor.getColumnIndex(OpenableColumns.SIZE);if(size>=0&&!cursor.isNull(size)&&cursor.getLong(size)>20*1024*1024)throw IllegalArgumentException("Audio file exceeds 20 MiB")
                    }
                }
                val type=contentResolver.getType(source)
                if(type!=null&&!type.startsWith("audio/"))throw IllegalArgumentException("Select an audio file")
                val extension=name.substringAfterLast('.',"mp3").lowercase().takeIf{it in listOf("mp3","wav","m4a","ogg","aac","flac","opus")}?:"mp3"
                val dir=File(filesDir,"tones").apply{mkdirs()}
                output=File(dir,"${UUID.randomUUID()}.$extension")
                val input=contentResolver.openInputStream(source)?:throw IllegalArgumentException("Cannot open audio file")
                input.use{stream->output!!.outputStream().use{out->val buf=ByteArray(8192);var total=0;while(true){val read=stream.read(buf);if(read<0)break;total+=read;if(total>20*1024*1024)throw IllegalArgumentException("Audio file exceeds 20 MiB");out.write(buf,0,read)}}}
                if(output!!.length()==0L)throw IllegalArgumentException("Empty audio file")
                val uri=FileProvider.getUriForFile(this,"$packageName.files",output!!)
                // Stored in private app files: playback continues after the original document permission expires.
                BellAudio.prepareUri(this,JSONObject().put("tone","device").put("toneUri",uri.toString()))
                runOnUiThread{result.success(mapOf("uri" to uri.toString(),"name" to name))}
            }catch(error:Exception){output?.delete();runOnUiThread{result.error("audio_error",error.localizedMessage,null)}}
        }.start()
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==4002){permissionResult?.success(grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED);permissionResult=null}
    }
}
