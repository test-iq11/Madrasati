package com.school.teacherbell
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BellBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        Thread {
            try { BellScheduler.cancel(context); BellScheduler.config(context)?.let { BellAudio.prepareAll(context,it) }; BellScheduler.schedule(context); BellWidget.updateAll(context) }
            catch (_: Exception) { BellScheduler.log(context, "تحتاج التنبيهات إلى مراجعة من إعدادات التطبيق.") }
            finally { pending.finish() }
        }.start()
    }
}
