package com.school.teacherbell

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/** Keeps a short Arabic announcement alive while Flutter is closed. */
class BellSpeechService:Service(){
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        val config=BellScheduler.config(this)
        if(config==null||!config.optBoolean("speech")||!config.optBoolean("enabled")){stopSelf();return START_NOT_STICKY}
        val manager=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val id="teacher_bell_speech_status"
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(NotificationChannel(id,"حالة الإعلان الصوتي",NotificationManager.IMPORTANCE_LOW).apply{setSound(null,null)})
        val builder=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,id)else Notification.Builder(this)
        val notification=builder.setSmallIcon(R.drawable.ic_notification).setContentTitle("جرس المعلم").setContentText("جارٍ تشغيل تذكير الحصة الصوتي").setOngoing(true).build()
        try{startForeground(3301,notification)}catch(_:Exception){BellScheduler.log(this,"منع النظام تشغيل الإعلان الصوتي في الخلفية.");stopSelf();return START_NOT_STICKY}
        val text=intent?.getStringExtra("text").orEmpty()
        if(text.isBlank()){stopSelf();return START_NOT_STICKY}
        BellAudio.speak(applicationContext,text,intent?.getFloatExtra("volume",.8f)?:.8f){stopSelf(startId)}
        return START_NOT_STICKY
    }
    override fun onDestroy(){BellAudio.stop();if(Build.VERSION.SDK_INT>=24)stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()}
}
