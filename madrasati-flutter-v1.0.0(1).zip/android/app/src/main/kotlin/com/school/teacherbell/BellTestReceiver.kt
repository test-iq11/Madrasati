package com.school.teacherbell

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

/** A separate one-shot alarm that uses the same notification path as a scheduled lesson. */
class BellTestReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences(BellScheduler.PREFS, Context.MODE_PRIVATE)
        val expected = prefs.getLong("testAt", 0)
        if (expected == 0L || intent.getLongExtra("at", 0) != expected) {
            return
        }
        val raw = prefs.getString("testConfig", null) ?: return
        prefs.edit().remove("testAt").remove("testConfig").commit()
        val outcome = try {
            val config = JSONObject(raw).put("speech", false)
            val sample = testLesson(config, expected)
            val event = JSONObject().put("lesson", sample).put("type", "start").put("at", expected)
            val sent = BellScheduler.deliver(context, config, event)
            val status = BellScheduler.status(context)
            when {
                !sent -> "تعذّر نشر إشعار الاختبار. راجع الإذن وقناة التنبيه."
                status["channelVibration"] == false -> "نُشر الاختبار، والاهتزاز متوقف في قناة التنبيه."
                else -> "نُشر إشعار اختبار قفل الشاشة. تحقّق إن شعرت بالهزات."
            }
        } catch (error: RuntimeException) {
            "تعذّر اختبار قفل الشاشة: ${error.javaClass.simpleName}"
        }
        prefs.edit().putString("testOutcome", outcome).apply()
        BellScheduler.log(context, outcome, "test")
    }

    companion object {
        private const val CODE = 3101
        private fun pending(context: Context, at: Long = 0) = PendingIntent.getBroadcast(
            context, CODE, Intent(context, BellTestReceiver::class.java).putExtra("at", at),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        internal fun testLesson(config: JSONObject, at: Long): JSONObject {
            val next = BellScheduler.nextLesson(config, at)?.optJSONObject("lesson")
            val mode = next?.optString("mode")
            val useLesson = mode == "vibration" || mode == "both"
            return (if (useLesson) JSONObject(next!!.toString()) else JSONObject().put("mode", "vibration"))
                .put("id", "clock_vibration_test")
                .put("subject", "اختبار جرس المعلم")
                .put("grade", "تنبيه تجريبي")
                .put("section", "").put("place", "")
                .put("allowSpeech", false)
        }

        fun cancel(context: Context) {
            (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(context))
            context.getSharedPreferences(BellScheduler.PREFS, Context.MODE_PRIVATE).edit()
                .remove("testAt").remove("testConfig")
                .putString("testOutcome", "أُلغي اختبار قفل الشاشة.").commit()
        }

        fun schedule(context: Context, raw: String): Boolean {
            val notifications = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!notifications.areNotificationsEnabled() || !BellVibration.available(context) ||
                (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms())) {
                return false
            }
            cancel(context)
            val at = System.currentTimeMillis() + 60_000L
            val prefs = context.getSharedPreferences(BellScheduler.PREFS, Context.MODE_PRIVATE)
            if (!prefs.edit().putLong("testAt", at).putString("testConfig", raw).remove("testOutcome").commit()) {
                return false
            }
            try {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(context, at))
            } catch (error: RuntimeException) {
                cancel(context)
                throw error
            }
            return true
        }
    }
}
