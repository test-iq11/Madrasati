package com.school.teacherbell

import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import org.json.JSONObject

internal data class BellVibration(val count: Int, val pulse: Int, val gap: Int) {
    // Android waveforms begin with a pause. The initial zero starts the first pulse immediately.
    fun timings(): LongArray = LongArray(count * 2) { index ->
        when {
            index == 0 -> 0L
            index % 2 == 1 -> pulse.toLong()
            else -> gap.toLong()
        }
    }

    val channelSuffix: String get() = "${count}_${pulse}_${gap}"

    companion object {
        fun from(config: JSONObject?, lessonCount: Int = 0): BellVibration {
            val count = if (lessonCount in 1..12) lessonCount
                else (config?.optInt("count", 3) ?: 3).coerceIn(1, 12)
            return BellVibration(
                count,
                (config?.optInt("pulse", 240) ?: 240).coerceIn(80, 700),
                (config?.optInt("gap", 160) ?: 160).coerceIn(70, 650)
            )
        }

        @Suppress("DEPRECATION")
        private fun motor(context: Context): Vibrator? {
            if (Build.VERSION.SDK_INT >= 31) {
                val manager = context.getSystemService(VibratorManager::class.java)
                manager?.defaultVibrator?.takeIf { it.hasVibrator() }?.let { return it }
                if (manager != null) manager.vibratorIds.forEach { id ->
                    manager.getVibrator(id).takeIf { it.hasVibrator() }?.let { return it }
                }
            }
            return (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)
                ?.takeIf { it.hasVibrator() }
        }

        fun available(context: Context): Boolean = motor(context)?.hasVibrator() == true

        @Suppress("DEPRECATION")
        fun play(context: Context, profile: BellVibration): Boolean {
            val motor = motor(context) ?: return false
            if (!motor.hasVibrator()) { return false }
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            if (Build.VERSION.SDK_INT >= 33) {
                motor.vibrate(
                    VibrationEffect.createWaveform(profile.timings(), -1),
                    VibrationAttributes.createForUsage(VibrationAttributes.USAGE_ALARM)
                )
            } else if (Build.VERSION.SDK_INT >= 26) {
                motor.vibrate(VibrationEffect.createWaveform(profile.timings(), -1), attributes)
            } else {
                motor.vibrate(profile.timings(), -1, attributes)
            }
            return true
        }

        fun cancel(context: Context) { motor(context)?.cancel() }
    }
}
