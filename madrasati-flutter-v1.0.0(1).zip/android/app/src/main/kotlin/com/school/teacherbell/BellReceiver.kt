package com.school.teacherbell

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager

class BellReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val result = goAsync()
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val lock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "${context.packageName}:BellAlarm")
        try { lock.acquire(20_000L) } catch (_: Exception) { }
        Thread {
            try { BellScheduler.onAlarm(context, intent) }
            catch (error: Exception) { BellScheduler.log(context, "تعذر إطلاق تنبيه: ${error.javaClass.simpleName}"); try { BellScheduler.schedule(context) } catch (_: Exception) { } }
            finally { if (lock.isHeld) lock.release(); result.finish() }
        }.start()
    }
}
