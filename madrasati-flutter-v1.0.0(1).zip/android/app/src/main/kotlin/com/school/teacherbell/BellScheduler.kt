package com.school.teacherbell

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/** A single next alarm is re-evaluated from the saved rules after every event.
 * This avoids a finite scheduling horizon and honours dated overrides without reopening Flutter. */
internal object BellScheduler {
    const val PREFS = "teacher_bell_native_v3"
    private const val REQUEST = 3100
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun config(context: Context): JSONObject? = try { JSONObject(prefs(context).getString("config", "") ?: "") } catch (_: Exception) { null }
    fun key(date: Calendar): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(date.time)
    fun parseDate(value: String): Calendar? = try {
        val parser = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
        parser.parse(value)?.let { Calendar.getInstance().apply { time = it } }
    } catch (_: Exception) { null }
    fun lessons(config: JSONObject, day: Calendar): List<JSONObject> {
        val date = key(day)
        val override = config.optJSONObject("exceptions")?.optJSONObject(date)
        if (override?.optBoolean("closed") == true) return emptyList()
        val index = day.get(Calendar.DAY_OF_WEEK) - 1
        if (override == null && config.optJSONArray("work")?.optBoolean(index, false) != true) return emptyList()
        val array = override?.optJSONArray("lessons") ?: config.optJSONArray("week")?.optJSONArray(index) ?: JSONArray()
        val season = config.optJSONObject("seasonal") ?: JSONObject()
        val seasonal = override == null && season.optString("type", "normal") != "normal" &&
            season.optString("from").isNotBlank() && date >= season.optString("from") && date <= season.optString("until")
        return (0 until array.length()).mapNotNull { i ->
            val original = array.optJSONObject(i) ?: return@mapNotNull null
            val lesson = JSONObject(original.toString())
            if (seasonal) {
                val start = season.optInt("start", 480) + i * (season.optInt("duration", 35) + season.optInt("rest", 5))
                lesson.put("start", start).put("end", start + season.optInt("duration", 35))
            }
            if (!lesson.optBoolean("enabled") || lesson.optString("subject").isBlank() || lesson.optString("grade").isBlank()) return@mapNotNull null
            if (lesson.optInt("start", -1) !in 0..1439 || lesson.optInt("end", -1) !in 1..1439 || lesson.optInt("end") <= lesson.optInt("start")) return@mapNotNull null
            lesson.put("ordinal", i + 1)
        }.sortedBy { it.optInt("start") }
    }
    private fun vacation(config: JSONObject, day: Calendar): Boolean = config.optString("vacationUntil").let { it.isNotBlank() && key(day) <= it }
    private fun at(day: Calendar, minute: Int): Long = (day.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, minute / 60); set(Calendar.MINUTE, minute % 60); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    private fun events(config: JSONObject, day: Calendar): List<JSONObject> {
        if (vacation(config, day)) return emptyList()
        val reminder = config.optInt("reminder", 0).coerceIn(0, 60)
        return lessons(config, day).flatMap { lesson ->
            val items = mutableListOf<JSONObject>()
            val start = at(day, lesson.optInt("start"))
            fun event(type: String, time: Long) = JSONObject().put("lesson", lesson).put("type", type).put("at", time)
            items.add(event("start", start))
            // The vacation boundary applies to the instant of the reminder as well as the lesson day.
            val before = start - reminder * 60_000L
            val reminderDay = Calendar.getInstance().apply { timeInMillis = before }
            if (reminder > 0 && !vacation(config, reminderDay)) items.add(event("before", before))
            if (config.optBoolean("endAlert")) items.add(event("end", at(day, lesson.optInt("end"))))
            items
        }
    }
    fun nextEvents(config: JSONObject, after: Long): List<JSONObject> {
        if (!config.optBoolean("enabled")) return emptyList()
        var first = Calendar.getInstance().apply { timeInMillis = after }
        val until = parseDate(config.optString("vacationUntil"))
        if (until != null && vacation(config, first)) first = until.apply { add(Calendar.DAY_OF_YEAR, 1) }
        var best = Long.MAX_VALUE
        val result = mutableListOf<JSONObject>()
        for (offset in 0..370) {
            val day = (first.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, offset) }
            for (event in events(config, day)) {
                val time = event.optLong("at")
                if (time <= after) continue
                if (time < best) { best = time; result.clear(); result.add(event) }
                else if (time == best) result.add(event)
            }
            // Include the following day's pre-midnight reminders before finalizing today's earliest event.
            if (result.isNotEmpty() && offset > 0) break
        }
        return result
    }
    fun nextLesson(config: JSONObject, after: Long): JSONObject? {
        var first = Calendar.getInstance().apply { timeInMillis = after }
        val until = parseDate(config.optString("vacationUntil"))
        if (until != null && vacation(config, first)) first = until.apply { add(Calendar.DAY_OF_YEAR, 1) }
        for (offset in 0..370) {
            val day = (first.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, offset) }
            if (vacation(config, day)) continue
            for (lesson in lessons(config, day)) {
                val time = at(day, lesson.optInt("start"))
                if (time > after) return JSONObject().put("lesson", lesson).put("at", time)
            }
        }
        return null
    }
    @Synchronized fun sync(context: Context, raw: String) {
        val config = JSONObject(raw)
        require(config.optJSONArray("week")?.length() == 7) { "Invalid weekly timetable" }
        if (raw == prefs(context).getString("config", null)) {
            val pending = PendingIntent.getBroadcast(context, REQUEST, Intent(context, BellReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (!config.optBoolean("enabled") || (pending != null && prefs(context).getLong("nextAt", 0L) >= System.currentTimeMillis() - 15 * 60_000L)) {
                return
            }
        }
        val revision = UUID.randomUUID().toString()
        prefs(context).edit().putString("config", raw).putString("revision", revision).commit()
        BellAudio.prepareAll(context, config)
        cancel(context)
        schedule(context)
        BellWidget.updateAll(context)
    }
    @Synchronized fun cancel(context: Context) {
        val pending = PendingIntent.getBroadcast(context, REQUEST, Intent(context, BellReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pending != null) { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending); pending.cancel() }
        prefs(context).edit().remove("nextLabel").remove("nextAt").remove("nextEvents").apply()
    }
    @Synchronized fun schedule(context: Context) {
        val config = config(context) ?: return
        if (!config.optBoolean("enabled")) return
        val events = nextEvents(config, System.currentTimeMillis())
        if (events.isEmpty()) {
            cancel(context)
            return
        }
        val at = events.first().optLong("at")
        val array = JSONArray().apply { events.forEach { put(it) } }
        val label = "${events.first().getJSONObject("lesson").optString("subject")} · " + SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(at))
        prefs(context).edit().putLong("nextAt", at).putString("nextLabel", label).putString("nextEvents", array.toString()).commit()
        val intent = Intent(context, BellReceiver::class.java).putExtra("revision", prefs(context).getString("revision", "")).putExtra("at", at)
        val pending = PendingIntent.getBroadcast(context, REQUEST, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        }
    }
    @Synchronized fun onAlarm(context: Context, intent: Intent) {
        val prefs = prefs(context)
        if (intent.getStringExtra("revision") != prefs.getString("revision", "")) return
        if (intent.getLongExtra("at", -1) != prefs.getLong("nextAt", -2)) return
        val config = config(context) ?: return
        if (!config.optBoolean("enabled")) return
        val now = System.currentTimeMillis()
        val expected = intent.getLongExtra("at", now)
        if (now >= expected && now - expected <= 15 * 60_000L) {
            val events = JSONArray(prefs.getString("nextEvents", "[]"))
            for (i in 0 until events.length()) {
                try {
                    deliver(context, config, events.getJSONObject(i))
                } catch (error: RuntimeException) {
                    log(context, "تعذّر نشر أحد التنبيهات: ${error.javaClass.simpleName}")
                }
            }
        } else log(context, "تجاوز تنبيه متأخر بأكثر من 15 دقيقة؛ راجع أذونات البطارية.")
        schedule(context)
        BellWidget.updateAll(context)
    }
    fun deliver(context: Context, config: JSONObject, event: JSONObject): Boolean {
        val lesson = event.getJSONObject("lesson")
        val subject = lesson.optString("subject")
        val type = event.optString("type")
        val title = when (type) { "before" -> "تذكير قبل الحصة"; "end" -> "انتهت حصتك"; else -> "حان موعد الحصة" }
        val text = "$subject · ${lesson.optString("grade")} ${lesson.optString("section")} ${lesson.optString("place")}"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!manager.areNotificationsEnabled()) { log(context, "لم يُعرض تنبيه $subject: إذن الإشعارات متوقف."); return false }
        val mode = lesson.optString("mode", "notification")
        val sound = mode == "both" || mode == "sound"
        val vibration = mode == "both" || mode == "vibration"
        val vibrationProfile = BellVibration.from(config.optJSONObject("vibration"), lesson.optInt("vibrationCount"))
        val soundConfig=JSONObject(config.toString())
        val lessonTone=lesson.optString("tone","global")
        if(lessonTone!="global"){soundConfig.put("tone",lessonTone);if(lesson.optString("toneUri").isNotBlank())soundConfig.put("toneUri",lesson.optString("toneUri"))}
        BellAudio.prepareUri(context,soundConfig)
        val uri = BellAudio.toneUri(context, soundConfig)
        val toneKey = if (sound) uri.toString().hashCode() else 0
        // Android keeps each channel's alert behavior after creation.
        val legacyChannelId = "teacher_bell_v5_${mode}_${toneKey}_${vibrationProfile.channelSuffix}"
        val channelId = when {
            vibration && Build.VERSION.SDK_INT >= 35 -> "teacher_bell_v6_${mode}_${toneKey}_${vibrationProfile.channelSuffix}"
            vibration -> legacyChannelId
            else -> "teacher_bell_v3_${mode}_${uri.toString().hashCode()}"
        }
        if (Build.VERSION.SDK_INT >= 26) {
            val legacy = if (vibration && channelId != legacyChannelId)
                manager.getNotificationChannel(legacyChannelId) else null
            val channel = NotificationChannel(
                channelId,
                if (vibration) "جرس المعلم · ${vibrationProfile.count} هزات" + if (sound) " مع نغمة" else "" else "جرس المعلم · إشعارات الحصص",
                legacy?.importance ?: NotificationManager.IMPORTANCE_HIGH
            )
            val allowVibration = vibration && (legacy == null || legacy.shouldVibrate())
            if (allowVibration && Build.VERSION.SDK_INT >= 35) {
                channel.vibrationEffect = VibrationEffect.createWaveform(vibrationProfile.timings(), -1)
            } else if (allowVibration) {
                channel.vibrationPattern = vibrationProfile.timings()
            }
            channel.enableVibration(allowVibration)
            val attributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val configuredSound = if (legacy != null) legacy.sound else if (sound) uri else null
            channel.setSound(configuredSound, legacy?.audioAttributes ?: attributes)
            manager.createNotificationChannel(channel)
            val current = manager.getNotificationChannel(channelId)
            if (vibration) {
                prefs(context).edit().putString("lastVibrationChannel", channelId).apply()
                if (current?.shouldVibrate() == false) {
                    log(context, "الهزاز متوقف لقناة تنبيه $subject. افتح إعدادات قناة التنبيه.")
                }
            }
            if (current?.importance == NotificationManager.IMPORTANCE_NONE) {
                log(context, "قناة تنبيه $subject محظورة في إعدادات Android.")
                return false
            }
        }
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, channelId) else android.app.Notification.Builder(context)
        builder.setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(text).setStyle(android.app.Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(open).setCategory(android.app.Notification.CATEGORY_REMINDER).setVisibility(android.app.Notification.VISIBILITY_PRIVATE)
        if (Build.VERSION.SDK_INT < 26) { builder.setPriority(android.app.Notification.PRIORITY_HIGH); if (sound) builder.setSound(uri); if (vibration) builder.setVibrate(vibrationProfile.timings()) }
        try {
            // A new occurrence must alert as a new notification even if yesterday's is still visible.
            val occurrence = "${lesson.optString("id")}:${type}:${event.optLong("at")}"
            manager.notify(occurrence, 1, builder.build())
            log(context, "أُطلق تنبيه $subject · ${when(type){"before"->"تذكير مسبق";"end"->"نهاية الحصة";else->"بداية الحصة"}}")
        } catch (_: SecurityException) {
            log(context, "تعذر عرض إشعار $subject بسبب الإذن.")
            return false
        }
        // Speech is independent of ringtone/vibration and is disabled by the settings switch.
        if (type == "start" && config.optBoolean("speech", false) && lesson.optBoolean("allowSpeech",true)) {
            val textTemplate = config.optString("speechText", "حان موعد {lesson}. مادة {subject}، للصف {grade}.")
            val speech = textTemplate.replace("{lesson}", "الدرس ${lesson.optInt("ordinal", 1)}").replace("{subject}", subject).replace("{grade}", lesson.optString("grade"))
            val voiceIntent=Intent(context,BellSpeechService::class.java).putExtra("text",speech).putExtra("volume",config.optDouble("volume",.8).toFloat())
            try { if(Build.VERSION.SDK_INT>=26)context.startForegroundService(voiceIntent)else context.startService(voiceIntent) }
            catch(_:Exception){log(context,"تعذر بدء الإعلان الصوتي في الخلفية؛ راجع قيود البطارية.")}
        }
        return true
    }
    @Synchronized fun log(context: Context, text: String, kind: String = if (text.contains("اختبار")) "test" else "alert") {
        val prefs = prefs(context)
        val before = try { JSONArray(prefs.getString("logs", "[]")) } catch (_: Exception) { JSONArray() }
        val result = JSONArray().put(JSONObject().put("text", text).put("kind", kind).put("time", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())))
        for (i in 0 until minOf(before.length(), 79)) result.put(before.get(i))
        prefs.edit().putString("logs", result.toString()).apply()
    }
    fun vibrationChannel(context: Context): String? =
        prefs(context).getString("lastVibrationChannel", null)

    fun status(context: Context): Map<String, Any?> {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val power = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val notifications = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = if (Build.VERSION.SDK_INT >= 26) {
            vibrationChannel(context)?.let(notifications::getNotificationChannel)
        } else null
        val prefs = prefs(context)
        val filter = notifications.currentInterruptionFilter
        return mapOf(
            "vibrator" to BellVibration.available(context),
            "notifications" to notifications.areNotificationsEnabled(),
            "exact" to (Build.VERSION.SDK_INT < 31 || alarm.canScheduleExactAlarms()),
            "batteryExempt" to power.isIgnoringBatteryOptimizations(context.packageName),
            "dnd" to (filter != NotificationManager.INTERRUPTION_FILTER_ALL && filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN),
            "channelVibration" to channel?.shouldVibrate(),
            "channelEnabled" to channel?.let { it.importance != NotificationManager.IMPORTANCE_NONE },
            "nextLabel" to prefs.getString("nextLabel", null),
            "testAt" to prefs.getLong("testAt", 0L),
            "testOutcome" to prefs.getString("testOutcome", null)
        )
    }
}
