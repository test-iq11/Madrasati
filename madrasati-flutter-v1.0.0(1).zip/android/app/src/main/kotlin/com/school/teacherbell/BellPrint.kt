package com.school.teacherbell

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint

internal object BellPrint {
    fun open(context: Context, title: String, lines: List<String>, landscape: Boolean) {
        val media = if (landscape) PrintAttributes.MediaSize.ISO_A4.asLandscape()
            else PrintAttributes.MediaSize.ISO_A4.asPortrait()
        val adapter = SchedulePrintAdapter(context, title, lines)
        val manager = requireNotNull(context.getSystemService(PrintManager::class.java))
        manager.print(
            "جدول جرس المعلم", adapter, PrintAttributes.Builder().setMediaSize(media).build()
        )
    }
}

private class SchedulePrintAdapter(
    private val context: Context,
    private val title: String,
    private val lines: List<String>
) : PrintDocumentAdapter() {
    private var attributes: PrintAttributes? = null

    private fun pages(document: PrintedPdfDocument): List<List<StaticLayout>> {
        val rect = document.pageContentRect
        val titlePaint = TextPaint().apply { color = Color.rgb(16, 62, 50); textSize = 19f; isAntiAlias = true }
        val bodyPaint = TextPaint().apply { color = Color.DKGRAY; textSize = 13f; isAntiAlias = true }
        val pages = mutableListOf<MutableList<StaticLayout>>()
        var y = 0
        for ((index, text) in (listOf(title) + lines).withIndex()) {
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, if (index == 0) titlePaint else bodyPaint, rect.width())
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(true)
                .build()
            if (pages.isEmpty() || y + layout.height + 8 > rect.height()) {
                pages.add(mutableListOf())
                y = 0
            }
            pages.last().add(layout)
            y += layout.height + 8
        }
        return pages
    }

    override fun onLayout(
        old: PrintAttributes?, current: PrintAttributes, cancel: CancellationSignal,
        callback: LayoutResultCallback, extras: Bundle?
    ) {
        if (cancel.isCanceled) {
            callback.onLayoutCancelled()
            return
        }
        attributes = current
        val doc = PrintedPdfDocument(context, current)
        try {
            val info = PrintDocumentInfo.Builder("teacher_bell_schedule.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(pages(doc).size).build()
            callback.onLayoutFinished(info, old != current)
        } finally {
            doc.close()
        }
    }

    override fun onWrite(
        ranges: Array<PageRange>, destination: ParcelFileDescriptor,
        cancel: CancellationSignal, callback: WriteResultCallback
    ) {
        val settings = attributes
        if (settings == null) {
            callback.onWriteFailed("تعذر إعداد ورقة الطباعة.")
            return
        }
        try {
            val document = PrintedPdfDocument(context, settings)
            try {
                val written = mutableListOf<PageRange>()
                val rect = document.pageContentRect
                for ((index, layouts) in pages(document).withIndex()) {
                    if (cancel.isCanceled) {
                        callback.onWriteCancelled()
                        return
                    }
                    // PageRange.contains is not part of the public Android SDK.
                    // Both bounds are inclusive and use zero-based page indices.
                    if (ranges.none { index >= it.start && index <= it.end }) {
                        continue
                    }
                    val page = document.startPage(index)
                    var y = rect.top.toFloat()
                    for (layout in layouts) {
                        page.canvas.save()
                        page.canvas.translate(rect.left.toFloat(), y)
                        layout.draw(page.canvas)
                        page.canvas.restore()
                        y += layout.height + 8
                    }
                    document.finishPage(page)
                    written.add(PageRange(index, index))
                }
                ParcelFileDescriptor.AutoCloseOutputStream(destination).use(document::writeTo)
                callback.onWriteFinished(written.toTypedArray())
            } finally {
                document.close()
            }
        } catch (error: Exception) {
            callback.onWriteFailed(error.localizedMessage ?: "تعذر كتابة ملف PDF.")
        }
    }
}
