package com.school.teacherbell

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.PowerManager
import org.json.JSONObject
import java.util.Locale

internal object BellAudio {
    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var engine: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var generation = 0
    fun toneUri(context: Context, config: JSONObject): Uri {
        if (config.optString("tone") == "device" && config.optString("toneUri").isNotBlank()) return Uri.parse(config.optString("toneUri"))
        val name = when(config.optString("tone")){"soft"->"soft_chime";"doubleBell"->"double_bell";else->"bell_tone"}
        return Uri.parse("android.resource://${context.packageName}/raw/$name")
    }
    fun prepareUri(context: Context, config: JSONObject) {
        val uri = toneUri(context,config)
        if (uri.scheme != "content" || uri.authority != "${context.packageName}.files") return
        for (name in listOf("com.android.systemui", "android", "com.android.providers.media")) {
            try { context.grantUriPermission(name, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
    }
    fun prepareAll(context:Context,config:JSONObject){
        prepareUri(context,config)
        fun visit(list:org.json.JSONArray?){if(list==null)return;for(i in 0 until list.length()){val lesson=list.optJSONObject(i)?:continue;if(lesson.optString("tone")=="device"&&lesson.optString("toneUri").isNotBlank())prepareUri(context,JSONObject().put("tone","device").put("toneUri",lesson.optString("toneUri")))}}
        val week=config.optJSONArray("week");if(week!=null)for(d in 0 until week.length())visit(week.optJSONArray(d))
        val exceptions=config.optJSONObject("exceptions");if(exceptions!=null)for(key in exceptions.keys())visit(exceptions.optJSONObject(key)?.optJSONArray("lessons"))
    }
    fun stop() { handler.post { generation++; try { player?.stop(); player?.release() } catch (_: Exception) { }; player=null; try { engine?.stop(); engine?.shutdown() } catch (_: Exception) { }; engine=null; if(wakeLock?.isHeld==true)wakeLock?.release();wakeLock=null } }
    fun play(context: Context, config: JSONObject) {
        handler.post {
            try {
                player?.release()
                val media = MediaPlayer()
                media.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                media.setDataSource(context,toneUri(context,config))
                val volume=config.optDouble("volume",.8).toFloat().coerceIn(0f,1f)
                media.setVolume(volume,volume)
                media.setOnCompletionListener { it.release();if(player===it)player=null }
                media.setOnErrorListener { p,_,_->p.release();if(player===p)player=null;BellScheduler.log(context,"تعذر تشغيل النغمة المختارة.");true }
                media.prepare();media.start();player=media
            } catch (_: Exception) { BellScheduler.log(context,"تعذر تشغيل النغمة؛ اختر ملفًا صوتيًا آخر.") }
        }
    }
    fun speak(context: Context, text: String, volume: Float, onFinished: () -> Unit = {}) {
        handler.post {
            generation++
            val ticket=generation
            var finished=false
            try { engine?.stop(); engine?.shutdown() } catch (_: Exception) { }
            if(wakeLock?.isHeld==true)wakeLock?.release()
            wakeLock=(context.getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"${context.packageName}:Speech").apply { acquire(20_000L) }
            fun finish() { if(ticket!=generation||finished)return;finished=true;try { engine?.stop();engine?.shutdown() }catch(_:Exception){};engine=null;if(wakeLock?.isHeld==true)wakeLock?.release();wakeLock=null;onFinished() }
            engine=TextToSpeech(context.applicationContext) { status ->
                handler.post inner@{
                    if(ticket!=generation)return@inner
                    val tts=engine
                    if(status!=TextToSpeech.SUCCESS||tts==null){BellScheduler.log(context,"تعذر تشغيل محرك النطق العربي.");finish();return@inner}
                    var language=tts.setLanguage(Locale("ar","IQ"))
                    if(language<0)language=tts.setLanguage(Locale("ar"))
                    if(language<0){BellScheduler.log(context,"لا يتوفر صوت عربي؛ ثبّته من إعدادات تحويل النص إلى كلام.");finish();return@inner}
                    tts.setSpeechRate(.92f)
                    tts.setOnUtteranceProgressListener(object:UtteranceProgressListener(){
                        override fun onStart(id:String?) {}
                        override fun onDone(id:String?) {handler.post{finish()}}
                        override fun onError(id:String?) {handler.post{finish()}}
                    })
                    val bundle=Bundle().apply{putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME,volume.coerceIn(0f,1f))}
                    if(tts.speak(text,TextToSpeech.QUEUE_FLUSH,bundle,"teacher_bell_$ticket")==TextToSpeech.ERROR)finish()
                }
            }
            handler.postDelayed({finish()},18_000L)
        }
    }
}
