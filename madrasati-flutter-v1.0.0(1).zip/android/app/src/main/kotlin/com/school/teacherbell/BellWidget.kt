package com.school.teacherbell

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BellWidget:AppWidgetProvider(){
    override fun onUpdate(context:Context,manager:AppWidgetManager,ids:IntArray){ids.forEach{update(context,manager,it)}}
    companion object{
        fun updateAll(context:Context){val manager=AppWidgetManager.getInstance(context);manager.getAppWidgetIds(ComponentName(context,BellWidget::class.java)).forEach{update(context,manager,it)}}
        private fun update(context:Context,manager:AppWidgetManager,id:Int){
            val config=BellScheduler.config(context)
            val next=config?.let{BellScheduler.nextLesson(it,System.currentTimeMillis())}
            val views=RemoteViews(context.packageName,R.layout.bell_widget)
            views.setTextViewText(R.id.widget_title,"جرس المعلم · الحصة القادمة")
            views.setTextViewText(R.id.widget_subject,next?.optJSONObject("lesson")?.optString("subject")?:"جهّز جدولك")
            views.setTextViewText(R.id.widget_grade,next?.optJSONObject("lesson")?.optString("grade")?:"لا توجد حصص مفعّلة")
            val time=next?.optLong("at")?.let{SimpleDateFormat("EEE  HH:mm",Locale("ar","IQ")).format(Date(it))}?:"افتح التطبيق لإضافة حصصك"
            views.setTextViewText(R.id.widget_time,time)
            views.setTextViewText(R.id.widget_status,if(config?.optBoolean("enabled")==true)"التنبيهات مفعّلة"else "التنبيهات متوقفة")
            val intent=PendingIntent.getActivity(context,0,Intent(context,MainActivity::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root,intent)
            manager.updateAppWidget(id,views)
        }
    }
}
