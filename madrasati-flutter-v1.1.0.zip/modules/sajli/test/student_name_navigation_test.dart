import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:sajli/main.dart';
import 'package:sajli/records.dart';

void main() {
  testWidgets('tapping student name opens real profile, not blank page',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final folder = Directory.systemTemp.createTempSync('sajli-name-test-');
    addTearDown(() => folder.deleteSync(recursive: true));
    final records = Records.decode(File('assets/demo.json').readAsStringSync());
    final classId = records.activeClasses.first['id'].toString();
    final pupil = records.students(classId).first;
    final id = pupil['id'].toString();
    final name = pupil['name'].toString();
    await tester.pumpWidget(SajliApp(
      records: records,
      file: File('${folder.path}/sajli.json'),
    ));
    await tester.pumpAndSettle();
    final studentName = find.byKey(ValueKey('student-name-$id'));
    await tester.ensureVisible(studentName);
    await tester.tap(studentName);
    await tester.pumpAndSettle();
    expect(find.text('ملف التلميذ'), findsOneWidget);
    expect(find.text(name), findsWidgets);
    expect(find.text('تعديل البيانات'), findsOneWidget);
    expect(find.text('حذف التلميذ'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('إغلاق'));
    await tester.pumpAndSettle();
    expect(find.text('كشف الدرجات'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
