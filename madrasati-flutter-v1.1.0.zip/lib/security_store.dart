import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Only salted PIN verifiers are stored, never PINs in SharedPreferences.
/// The underlying encrypted storage is provided by Android Keystore.
class MadrasatiPinStore {
  MadrasatiPinStore({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage();

  final FlutterSecureStorage _storage;

  String _key(String purpose) => 'madrasati.pin.$purpose';

  static bool valid(String pin) => RegExp(r'^[0-9]{4,8}$').hasMatch(pin);

  static String hash(String salt, String pin) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<bool> hasPin(String purpose) async =>
      (await _storage.read(key: _key(purpose))) != null;

  Future<void> setPin(String purpose, String pin) async {
    if (!valid(pin)) {
      throw const FormatException('يجب أن يتكون الرمز من 4 إلى 8 أرقام.');
    }
    final random = Random.secure();
    final salt = base64UrlEncode(
      List<int>.generate(24, (_) => random.nextInt(256)),
    );
    await _storage.write(
      key: _key(purpose),
      value: '$salt:${hash(salt, pin)}',
    );
  }

  Future<bool> verify(String purpose, String pin) async {
    final saved = await _storage.read(key: _key(purpose));
    if (saved == null || !valid(pin)) return false;
    final separator = saved.indexOf(':');
    if (separator < 0) return false;
    final expected = saved.substring(separator + 1);
    final actual = hash(saved.substring(0, separator), pin);
    if (expected.length != actual.length) return false;
    var diff = 0;
    for (var i = 0; i < actual.length; i++) {
      diff |= expected.codeUnitAt(i) ^ actual.codeUnitAt(i);
    }
    return diff == 0;
  }

  Future<void> remove(String purpose) => _storage.delete(key: _key(purpose));
}
