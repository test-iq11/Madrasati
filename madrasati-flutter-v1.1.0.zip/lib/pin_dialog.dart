import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Local, never sends digits to any server or the app preferences.
class MadrasatiPinDialog extends StatefulWidget {
  const MadrasatiPinDialog({
    required this.title,
    this.confirm = false,
    super.key,
  });
  final String title;
  final bool confirm;

  @override
  State<MadrasatiPinDialog> createState() => _MadrasatiPinDialogState();
}

class _MadrasatiPinDialogState extends State<MadrasatiPinDialog> {
  final first = TextEditingController();
  final second = TextEditingController();
  String? error;

  @override
  void dispose() {
    first.dispose();
    second.dispose();
    super.dispose();
  }

  Widget field(TextEditingController controller, String label) => TextField(
        controller: controller,
        obscureText: true,
        enableSuggestions: false,
        autocorrect: false,
        keyboardType: TextInputType.number,
        textDirection: TextDirection.ltr,
        maxLength: 8,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        decoration: InputDecoration(
          labelText: label,
          counterText: '',
          border: const OutlineInputBorder(),
        ),
        onSubmitted: (_) => submit(),
      );

  void submit() {
    final entered = first.text;
    if (!RegExp(r'^[0-9]{4,8}$').hasMatch(entered)) {
      setState(() => error = 'أدخل رمزاً من 4 إلى 8 أرقام.');
      return;
    }
    if (widget.confirm && entered != second.text) {
      setState(() => error = 'الرمزان غير متطابقين.');
      return;
    }
    Navigator.of(context).pop(entered);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(widget.title),
        content: SingleChildScrollView(
          child: SizedBox(
            width: 290,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                field(first, widget.confirm ? 'الرمز الجديد' : 'الرمز'),
                if (widget.confirm) ...[
                  const SizedBox(height: 10),
                  field(second, 'تأكيد الرمز'),
                ],
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(error!,
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.error)),
                  ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: submit,
            child: const Text('تأكيد'),
          ),
        ],
      );
}
