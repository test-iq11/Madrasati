import 'package:flutter/material.dart';

class MosaicEntry {
  const MosaicEntry({
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.onTap,
  });
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
}

/// Native Flutter implementation of the approved "فسيفساء التطبيقات" layout.
class MosaicHome extends StatelessWidget {
  const MosaicHome({
    required this.school,
    required this.entries,
    required this.day,
    required this.accent,
    required this.compact,
    required this.rounded,
    required this.showDescriptions,
    required this.showDay,
    required this.showShortcuts,
    required this.showDecoration,
    required this.quickAttendance,
    required this.quickBell,
    required this.quickSettings,
    super.key,
  });
  final String school;
  final List<MosaicEntry> entries;
  final Widget day;
  final Color accent;
  final bool compact;
  final double rounded;
  final bool showDescriptions;
  final bool showDay;
  final bool showShortcuts;
  final bool showDecoration;
  final VoidCallback quickAttendance;
  final VoidCallback quickBell;
  final VoidCallback quickSettings;

  @override
  Widget build(BuildContext context) {
    final ink = Theme.of(context).colorScheme.onSurface;
    return LayoutBuilder(
      builder: (context, bounds) {
        final width = bounds.maxWidth;
        final pad = width >= 700 ? 22.0 : 13.0;
        final gap = 10.0;
        final gridWidth = width - pad * 2;
        final isWide = gridWidth >= 720;
        final half = (gridWidth - gap) / 2;
        final smallHeight = compact ? 114.0 : 136.0;
        final tallHeight = smallHeight * 2 + gap;
        final homeCards = entries.take(5).toList();
        if (homeCards.length < 5) {
          return const Center(child: Text('الأقسام غير مكتملة'));
        }
        final headText = showDescriptions
            ? 'الجدول، الدرجات، الجرس، المناهج والمستمسكات'
            : 'مساحتك التعليمية';
        final body = <Widget>[
          Container(
            constraints: BoxConstraints(minHeight: compact ? 108 : 133),
            padding: EdgeInsets.all(compact ? 18 : 23),
            decoration: BoxDecoration(
              gradient: showDecoration
                  ? LinearGradient(
                      begin: AlignmentDirectional.topStart,
                      end: AlignmentDirectional.bottomEnd,
                      colors: [accent, Color.lerp(accent, Colors.black, .32)!],
                    )
                  : null,
              color: showDecoration ? null : accent,
              borderRadius: BorderRadius.circular(rounded + 4),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('مساحتك التعليمية',
                          style: TextStyle(color: Colors.white70, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(school,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: compact ? 24 : 30,
                              fontWeight: FontWeight.w900)),
                      const SizedBox(height: 4),
                      Text(headText,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 11)),
                    ],
                  ),
                ),
                if (showDecoration) ...[
                  const SizedBox(width: 10),
                  Container(
                    width: 58,
                    height: 58,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .14),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Icon(Icons.school_outlined,
                        color: Colors.white, size: 38),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Icon(Icons.grid_view_rounded, size: 19, color: accent),
              const SizedBox(width: 7),
              Text('تطبيقات مدرستي',
                  style: TextStyle(
                      fontSize: 17, fontWeight: FontWeight.w900, color: ink)),
            ],
          ),
          const SizedBox(height: 11),
          if (isWide)
            Row(
              children: [
                Expanded(
                    child: _entryCard(context, homeCards[0], tallHeight,
                        big: true)),
                SizedBox(width: gap),
                for (var i = 1; i < 5; i++) ...[
                  Expanded(child: _entryCard(context, homeCards[i], tallHeight)),
                  if (i != 4) SizedBox(width: gap),
                ],
              ],
            )
          else ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                    width: half,
                    child: _entryCard(context, homeCards[0], tallHeight,
                        big: true)),
                SizedBox(width: gap),
                SizedBox(
                  width: half,
                  child: Column(
                    children: [
                      _entryCard(context, homeCards[1], smallHeight),
                      SizedBox(height: gap),
                      _entryCard(context, homeCards[2], smallHeight),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: gap),
            Row(
              children: [
                SizedBox(
                    width: half,
                    child: _entryCard(context, homeCards[3], smallHeight)),
                SizedBox(width: gap),
                SizedBox(
                    width: half,
                    child: _entryCard(context, homeCards[4], smallHeight)),
              ],
            ),
          ],
          if (showDay) ...[
            const SizedBox(height: 15),
            day,
          ],
          if (showShortcuts) ...[
            const SizedBox(height: 15),
            Text('اختصارات سريعة',
                style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800, color: ink)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 7,
              children: [
                ActionChip(
                    avatar: const Icon(Icons.how_to_reg_outlined, size: 17),
                    label: const Text('تسجيل الحضور'),
                    onPressed: quickAttendance),
                ActionChip(
                    avatar: const Icon(Icons.notifications_outlined, size: 17),
                    label: const Text('الجرس'),
                    onPressed: quickBell),
                ActionChip(
                    avatar: const Icon(Icons.tune_outlined, size: 17),
                    label: const Text('تخصيص الواجهة'),
                    onPressed: quickSettings),
              ],
            ),
          ],
        ];
        return ListView(
          key: const PageStorageKey('mosaic-home'),
          padding: EdgeInsets.fromLTRB(pad, 12, pad, 35),
          children: body,
        );
      },
    );
  }

  Widget _entryCard(BuildContext context, MosaicEntry entry, double height,
      {bool big = false}) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final background = dark
        ? Color.lerp(entry.color, const Color(0xff17202b), .45)!
        : entry.color;
    return Material(
      clipBehavior: Clip.antiAlias,
      color: background,
      borderRadius: BorderRadius.circular(rounded),
      child: InkWell(
        onTap: entry.onTap,
        child: SizedBox(
          height: height,
          child: Padding(
            padding: EdgeInsets.all(big ? 16 : 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: big ? 47 : 39,
                  height: big ? 47 : 39,
                  decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .19),
                      borderRadius: BorderRadius.circular(13)),
                  child: Icon(entry.icon,
                      color: Colors.white, size: big ? 27 : 23),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(entry.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: big ? 19 : 15,
                            fontWeight: FontWeight.w900)),
                    if (showDescriptions) ...[
                      const SizedBox(height: 3),
                      Text(entry.description,
                          maxLines: big ? 3 : 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 10)),
                    ],
                  ],
                ),
                if (big)
                  const Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: Icon(Icons.arrow_back_rounded,
                        color: Colors.white, size: 22),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
