import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/security_store.dart';

void main() {
  test('PIN rules prevent empty and short values', () {
    expect(MadrasatiPinStore.valid('1234'), true);
    expect(MadrasatiPinStore.valid('12345678'), true);
    expect(MadrasatiPinStore.valid('123'), false);
    expect(MadrasatiPinStore.valid('abcdefgh'), false);
    expect(MadrasatiPinStore.valid('123456789'), false);
  });

  test('PIN verifier varies with salt and secret', () {
    expect(MadrasatiPinStore.hash('salt-1', '123456'),
        isNot(MadrasatiPinStore.hash('salt-2', '123456')));
    expect(MadrasatiPinStore.hash('salt-1', '123456'),
        isNot(MadrasatiPinStore.hash('salt-1', '654321')));
  });
}
