// Unified native workflows. Never launches a second (legacy) application UI.
// All mutations use the owning module's persisted model/service.
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:sajli/records.dart';
import 'package:teacher_bell/domain.dart' as bell;
import 'package:teacher_bell/platform_service.dart' as bell_device;
import 'package:iraqi_school_library_dual/services/library_repository.dart';
import 'package:iraqi_school_library_dual/models/library_catalog.dart';
import 'package:iraqi_school_library_dual/user/downloaded_books.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:mustamsakati/perspective.dart' as scan_perspective;
import 'package:mustamsakati/scan_filters.dart' as scan_filters;
import 'package:mustamsakati/layouts.dart' as scan_layouts;
import 'unified_design.dart';

class UnifiedUI {
  static Widget headline(String heading, [String? hint]) => UnifiedHeading(
    heading, subtitle: hint);
  static Widget card(Widget child) => UnifiedPanel(child: child);
  static Widget action(String title, String detail, IconData icon, VoidCallback tap,
      {Color color = UnifiedStyle.turquoise}) => UnifiedRow(
    title: title, subtitle: detail, icon: icon, tone: color, onTap: tap);
  static Widget control(String title, VoidCallback callback,
      {IconData icon = Icons.arrow_back_rounded}) => Padding(
      padding: const EdgeInsets.only(top: 9),
      child: SizedBox(width: double.infinity,
        child: FilledButton.icon(onPressed: callback, icon: Icon(icon), label: Text(title))));
  static Widget chip(String label, bool selected, VoidCallback action) =>
      ChoiceChip(label: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
        selected: selected, onSelected: (_) => action());
  static Widget field(String label, String value, ValueChanged<String> changed,
      {TextInputType? type, int lines = 1}) => TextFormField(
      initialValue: value, keyboardType: type, maxLines: lines,
      decoration: InputDecoration(labelText: label, isDense: true,
        filled: true, fillColor: Colors.transparent, border: const OutlineInputBorder()),
      onChanged: changed);
  static Widget empty(String message) => UnifiedPanel(child: Padding(
      padding: const EdgeInsets.symmetric(vertical: 26), child: Center(
        child: Text(message, textAlign: TextAlign.center))));
  static void notice(BuildContext context, String message) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
  static Future<bool> confirm(BuildContext context, String title, String details) async =>
      await showDialog<bool>(context: context, builder: (c) => AlertDialog(
        title: Text(title), content: Text(details), actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('تأكيد')),
        ])) ?? false;
  static Future<String?> ask(BuildContext context, String title, String initial,
      {TextInputType? type}) async {
    var text = initial;
    return showDialog<String>(context: context, builder: (c) => AlertDialog(
      title: Text(title), content: TextFormField(initialValue: initial,
        keyboardType: type, autofocus: true, onChanged: (v) => text = v,
        decoration: const InputDecoration(border: OutlineInputBorder())),
      actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(c, text.trim()),
          child: const Text('حفظ'))]));
  }
  static Widget colored(String title, IconData icon, Color tone, List<Widget> body) =>
    UnifiedPanel(padding: EdgeInsets.zero, child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(
          color: tone.withValues(alpha: .12), borderRadius: const BorderRadius.vertical(top: Radius.circular(21))),
          child: Row(children: [Icon(icon, color: tone, size: 21),
            const SizedBox(width: 8), Expanded(child: Text(title, style: TextStyle(
              fontWeight: FontWeight.w900, color: tone, fontSize: 14)))])),
        Padding(padding: const EdgeInsets.all(15), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: body)),
      ]));
}

class SajliWorkspace extends StatefulWidget {
  const SajliWorkspace({super.key, required this.tab, required this.records,
      required this.file, required this.onChanged, required this.onTab, this.focusStudentId});
  final String tab;
  final Records? records;
  final File? file;
  final VoidCallback onChanged;
  final ValueChanged<String> onTab;
  final String? focusStudentId;
  @override State<SajliWorkspace> createState() => _SajliWorkspaceState();
}

class _SajliWorkspaceState extends State<SajliWorkspace> {
  String search = '', classId = '', selectedId = '', course = '', detail = '';
  DateTime date = DateTime.now();
  int batch = 32;
  bool saving = false;
  @override void initState(){super.initState();
    if(widget.focusStudentId!=null){selectedId=widget.focusStudentId!;detail='profile';}
  }
  @override void didUpdateWidget(covariant SajliWorkspace old){
    super.didUpdateWidget(old);
    if(widget.focusStudentId!=null && widget.focusStudentId!=old.focusStudentId){
      setState((){selectedId=widget.focusStudentId!;detail='profile';});
    }
  }
  final List<String> statuses = const ['حاضر','غائب','متأخر','بعذر','غير مسجّل'];
  static const tones = [Color(0xff4b83b1), Color(0xff8068a8),
    Color(0xff218f81), Color(0xffba8456), Color(0xffac6889), Color(0xff5489a0)];
  Records? get model => widget.records;
  List<Map<String,dynamic>> get groups => model?.activeClasses ?? [];
  List<Map<String,dynamic>> get pupils => model?.people.where((r) =>
      r['archived'] != true && (classId.isEmpty || r['classId'].toString() == classId) &&
      (search.isEmpty || '${r['name']} ${r['number']}'.contains(search))).toList() ?? [];
  Map<String,dynamic>? get selected {
    final items = model?.people ?? [];
    for (final r in items) { if (r['id'].toString() == selectedId) return r; }
    return items.where((s) => s['archived'] != true).firstOrNull;
  }
  String get day => '${date.year}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}';
  String groupName(String? id) => model?.className(id ?? '') ?? 'غير محدد';
  String _status(String id) => switch(model?.attendance(day)[id]?.toString() ?? '') {
    'present' => 'حاضر', 'absent' => 'غائب', 'late' => 'متأخر',
    'excused' => 'بعذر', _ => 'غير مسجّل',
  };
  String _statusValue(String title) => switch(title) {
    'حاضر' => 'present', 'غائب' => 'absent', 'متأخر' => 'late',
    'بعذر' => 'excused', _ => '',
  };
  int count(String status) => pupils.where((r) => _status(r['id'].toString()) == status).length;

  Future<void> _save(VoidCallback mutate) async {
    if (saving || model == null || widget.file == null) return;
    setState(() => saving = true);
    final previous = jsonEncode(model!.data);
    try {
      mutate();
      final file = widget.file!;
      final temp = File('${file.path}.tmp');
      await temp.writeAsString(jsonEncode(model!.data), flush: true);
      await temp.rename(file.path);
      if (!mounted) return;
      setState(() => saving = false);
      widget.onChanged();
      UnifiedUI.notice(context, 'تم حفظ البيانات في سجلي');
    } catch (e) {
      model!.data..clear()..addAll(Map<String,dynamic>.from(jsonDecode(previous) as Map));
      if (mounted) { setState(() => saving = false); UnifiedUI.notice(context, 'تعذر الحفظ: $e'); }
    }
  }

  Future<void> _editPerson({Map<String,dynamic>? row}) async {
    if (groups.isEmpty) return UnifiedUI.notice(context, 'أضف الصف والشعبة أولًا');
    var name = row?['name']?.toString() ?? '';
    var number = row?['number']?.toString() ?? '';
    var cid = row?['classId']?.toString() ?? (classId.isEmpty ? groups.first['id'].toString() : classId);
    final result = await showDialog<bool>(context: context,
      builder: (c) => StatefulBuilder(builder: (c,refresh) => AlertDialog(
      title: Text(row == null ? 'إضافة تلميذ' : 'تعديل التلميذ'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        UnifiedUI.field('اسم التلميذ', name, (v) => name = v),
        const SizedBox(height: 12),
        UnifiedUI.field('رقم القيد (اختياري)', number, (v) => number = v),
        DropdownButtonFormField<String>(value: cid,
          isExpanded: true, decoration: const InputDecoration(labelText: 'الصف والشعبة'),
          items: [for (final g in groups) DropdownMenuItem(value: g['id'].toString(),
            child: Text(g['name'].toString()))], onChanged: (v) => refresh(() => cid = v ?? cid)),
      ])), actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حفظ')),
      ])));
    if (result != true || !mounted) return;
    if (name.trim().isEmpty) return UnifiedUI.notice(context, 'اسم التلميذ مطلوب');
    await _save(() {
      final list = model!.people;
      if (row == null) {
        final id = DateTime.now().microsecondsSinceEpoch.toString();
        list.add({'id': id, 'name': name.trim(), 'number': number.trim().isEmpty ? 'ST-$id' : number.trim(),
          'classId': cid, 'gender': 'unknown'});
        selectedId = id;
      } else {
        list.firstWhere((e) => e['id'].toString() == row['id'].toString())
          ..['name'] = name.trim()..['number'] = number.trim()..['classId'] = cid;
      }
      model!.data['students'] = list;
    });
  }

  Future<void> _deletePerson(Map<String,dynamic> row) async {
    if (!await UnifiedUI.confirm(context, 'حذف التلميذ',
        'ستُحذف درجات وحضور «${row['name']}» أيضًا. هل أنت متأكد؟')) return;
    await _save(() { model!.deleteStudent(row['id'].toString()); });
    if (mounted) setState(() => detail = '');
  }

  Future<void> _editClass({Map<String,dynamic>? row}) async {
    final name = await UnifiedUI.ask(context, row == null ? 'إضافة صف وشعبة' : 'تعديل اسم الصف',
        row?['name']?.toString() ?? '');
    if (name == null || !mounted) return;
    if (name.isEmpty) return UnifiedUI.notice(context, 'اسم الصف مطلوب');
    if (groups.any((g) => g['name'] == name && g['id'] != row?['id'])) {
      return UnifiedUI.notice(context, 'يوجد صف بنفس الاسم');
    }
    await _save(() {
      final list = model!.classes;
      if (row == null) list.add({'id':'c${DateTime.now().microsecondsSinceEpoch}', 'name':name});
      else list.firstWhere((g) => g['id'] == row['id'])['name'] = name;
      model!.data['classes'] = list;
    });
  }

  Future<void> _deleteClass(Map<String,dynamic> row) async {
    if (!await UnifiedUI.confirm(context, 'حذف الصف',
      'سيُحذف الصف «${row['name']}» وكل التلاميذ والدرجات التابعة له.')) return;
    await _save(() => model!.deleteClass(row['id'].toString()));
    if (mounted) setState(() => classId = '');
  }

  Future<void> _setStatus(Map<String,dynamic> row, String title) async {
    await _save(() => model!.setAttendance(day, row['id'].toString(), _statusValue(title)));
  }

  Future<void> _editMark(Map<String,dynamic> row, String sub, Map<String,dynamic> period) async {
    final key = period['key'].toString();
    final current = model!.score(row['id'].toString(), sub, key);
    final value = await UnifiedUI.ask(context, 'درجة ${row['name']} - ${period['label'] ?? key}',
        current?.toString() ?? '', type: const TextInputType.numberWithOptions(decimal: true));
    if (value == null || !mounted) return;
    final number = value.isEmpty ? null : num.tryParse(value
      .replaceAll('٠','0').replaceAll('١','1').replaceAll('٢','2')
      .replaceAll('٣','3').replaceAll('٤','4').replaceAll('٥','5')
      .replaceAll('٦','6').replaceAll('٧','7').replaceAll('٨','8').replaceAll('٩','9')
      .replaceAll('٫','.'));
    if (value.isNotEmpty && number == null) return UnifiedUI.notice(context, 'درجة غير صحيحة');
    if (number != null && (number < 0 || number > model!.maximum(sub))) {
      return UnifiedUI.notice(context, 'الدرجة يجب أن تكون بين 0 و${model!.maximum(sub)}');
    }
    await _save(() => model!.setScore(row['id'].toString(), sub, key, number));
  }

  @override Widget build(BuildContext context) {
    if (model == null || widget.file == null) return UnifiedUI.empty('جارٍ تحميل بيانات سجلي...');
    if (detail.isNotEmpty) return _detail();
    return switch(widget.tab) {
      'students' => _students(), 'attendance' => _attendance(),
      'reports' => _report(), 'tools' => _tools(), _ => _dashboard(),
    };
  }
  Widget _dashboard() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    UnifiedUI.headline('ملفات التلاميذ', 'نفس بطاقات التصميم الموحّد وببياناتك الأصلية'),
    _metrics(), const SizedBox(height: 12), _studentTiles(4),
    UnifiedUI.control('جميع التلاميذ', () => widget.onTab('students')),
    UnifiedUI.headline('إحصاءات المدرسة', 'رسومات داخلية رفيعة ومؤشرات محدثة'),
    _schoolStats(), UnifiedUI.headline('عمليات سريعة'),
    _actions([('تحضير الحضور',Icons.fact_check_outlined,()=>widget.onTab('attendance')),
      ('تقرير ولي الأمر',Icons.assignment_outlined,()=>widget.onTab('reports')),
      ('إدارة الدرجات',Icons.school_outlined,()=>setState(()=>detail='marks')),
      ('إدارة الصفوف',Icons.groups_outlined,()=>setState(()=>detail='classes'))]),
  ]);

  Widget _metrics() => LayoutBuilder(builder: (context,c) => Wrap(spacing: 11,runSpacing:11,
    children: [
      _metric(c, '${pupils.length}', 'عدد التلاميذ', Icons.people_outline,
          const Color(0xffe9f4fa),const Color(0xff467eb1)),
      _metric(c, '${count('غير مسجّل')}', 'غير مسجّل اليوم', Icons.history_rounded,
          const Color(0xfff0ecfa),const Color(0xff8a76ae)),
    ]));
  Widget _metric(BoxConstraints c,String value,String label,IconData icon,Color tint,Color tone) =>
    SizedBox(width: (c.maxWidth-11)/2,child: UnifiedMetric(
      value:value,label:label,icon:icon,tint:tint,tone:tone));
  Widget _schoolStats() => LayoutBuilder(builder:(context,c) {
    final labels = [
      ('${pupils.length}','عدد التلاميذ',Icons.people_outline,const Color(0xffe8f5f2),const Color(0xff248e7f)),
      ('${groups.length}','الصفوف والشعب',Icons.school_outlined,const Color(0xffedf1fb),const Color(0xff708ab1)),
      ('${count('حاضر')}','حاضر',Icons.check_circle_outline,const Color(0xffeaf8ee),const Color(0xff388b72)),
      ('${count('غائب')}','غائب',Icons.person_off_outlined,const Color(0xfffff2e9),const Color(0xffbf8757)),
      ('${count('متأخر')}','متأخر',Icons.access_time_outlined,const Color(0xffecf8fa),const Color(0xff4189a0)),
      ('${count('بعذر')}','بعذر',Icons.verified_user_outlined,const Color(0xfff7eef4),const Color(0xffac6988)),
    ];
    return Wrap(spacing:11,runSpacing:11,children:[for(final m in labels)
      _metric(c,m.$1,m.$2,m.$3,m.$4,m.$5)]);
  });
  Widget _studentTiles(int? limit) {
    final list = pupils.take(limit ?? batch).toList();
    return Column(children: [
      if (list.isEmpty) UnifiedUI.empty('لا توجد أسماء مطابقة للبحث'),
      if (list.isNotEmpty) LayoutBuilder(builder:(context,c)=>Wrap(spacing:10,runSpacing:10,children:[
        for (var i=0;i<list.length;i++) SizedBox(width:(c.maxWidth-10)/2,
          child: UnifiedStudentTile(key:ValueKey('unified-student-${list[i]['id']}'),
            student:UnifiedStudent(id:list[i]['id'].toString(),name:list[i]['name'].toString(),
              group:groupName(list[i]['classId'].toString()),
              registerNumber:list[i]['number']?.toString()??'',
              attendance:_status(list[i]['id'].toString()),
              gradeCount:_gradeCount(list[i])),index:i,
            onTap:()=>setState(() {selectedId=list[i]['id'].toString();detail='profile';}))),
      ])),
      if (limit==null && list.length<pupils.length) UnifiedUI.control('عرض المزيد',
        ()=>setState(()=>batch+=32)),
    ]);
  }
  int _gradeCount(Map<String,dynamic> row) {
    final id=row['id'].toString(),cl=row['classId'].toString();
    var n=0;
    for(final subject in model!.subjects(cl)) {
      for(final period in model!.periods) {
        if(model!.score(id,subject,period['key'].toString())!=null) n++;
      }
    }
    return n;
  }

  Widget _students() => Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('اختر تلميذًا','البطاقات الملونة تفتح ملف التلميذ الجديد مباشرة'),
    TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),
      labelText:'ابحث باسم التلميذ أو رقم القيد',border:OutlineInputBorder()),
      onChanged:(v)=>setState(() {search=v;batch=32;})),
    const SizedBox(height:12), _groupChips(),
    Align(alignment:AlignmentDirectional.centerStart,
      child: TextButton.icon(onPressed:()=>_editPerson(),
        icon:const Icon(Icons.add),label:const Text('إضافة تلميذ'))),
    const SizedBox(height:10), _studentTiles(null),
  ]);
  Widget _groupChips() => SizedBox(height:46,child:ListView(scrollDirection:Axis.horizontal,
      children:[UnifiedUI.chip('جميع الصفوف',classId.isEmpty,()=>setState(()=>classId='')),
        for(final g in groups) Padding(padding:const EdgeInsetsDirectional.only(start:7),
          child:UnifiedUI.chip(g['name'].toString(),classId==g['id'].toString(),
            ()=>setState(()=>classId=g['id'].toString())))]));

  Widget _attendance() => Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('الحضور والغياب', 'تحضير يومي مرتبط بإحصاءات المدرسة وتقرير ولي الأمر'),
    UnifiedPanel(child:Row(children:[Expanded(child:Text('التاريخ: $day')),
      IconButton(icon:const Icon(Icons.event),onPressed:()async{
        final next=await showDatePicker(context:context,initialDate:date,
          firstDate:DateTime(2022),lastDate:DateTime(2039));
        if(next!=null && mounted)setState(()=>date=next);
      })])),
    const SizedBox(height:12), _groupChips(), _schoolStats(),
    const SizedBox(height:12),
    for(final row in pupils) Padding(padding:const EdgeInsets.only(bottom:9),
      child:UnifiedPanel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(row['name'].toString(),style:const TextStyle(fontWeight:FontWeight.w900)),
        const SizedBox(height:8), Wrap(spacing:6,runSpacing:7,children:[
          for(final st in statuses) UnifiedUI.chip(st,_status(row['id'].toString())==st,
              ()=>_setStatus(row,st)),
        ]),
      ]))),
    if(pupils.isEmpty) UnifiedUI.empty('لا يوجد تلاميذ في هذا الصف'),
  ]);

  Widget _report() {
    final row=selected;
    final cid=row?['classId']?.toString()??'';
    final subs=model!.subjects(cid);
    final subject=subs.contains(course)?course:(subs.firstOrNull??'');
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      UnifiedUI.headline('تقرير ولي الأمر','أقسام ملونة واضحة، مع عرض الدرجات والحضور الحقيقيين'),
      if(pupils.isNotEmpty) UnifiedPanel(child:DropdownButtonFormField<String>(
        value:row?['id'].toString(),isExpanded:true,
        decoration:const InputDecoration(labelText:'التلميذ'),
        items:[for(final s in model!.people.where((s)=>s['archived']!=true))
          DropdownMenuItem(value:s['id'].toString(),child:Text(s['name'].toString(),overflow:TextOverflow.ellipsis))],
        onChanged:(v)=>setState(()=>selectedId=v??''))),
      const SizedBox(height:10),
      if(subs.isNotEmpty) UnifiedPanel(child:DropdownButtonFormField<String>(
        value:subject,isExpanded:true,
        decoration:const InputDecoration(labelText:'المادة الدراسية'),
        items:[for(final s in subs) DropdownMenuItem(value:s,child:Text(s))],
        onChanged:(v)=>setState(()=>course=v??''))),
      const SizedBox(height:13),
      if(row!=null) ..._reportBlocks(row,subject),
      if(row!=null) UnifiedUI.control('إضافة ملاحظة ولي الأمر',()=>_editParentNote(row),icon:Icons.edit_note_outlined),
      if(row!=null) UnifiedUI.control('طباعة تقرير A4',()=>_printGuardian(row,subject),icon:Icons.print_outlined),
    ]);
  }
  List<Widget> _reportBlocks(Map<String,dynamic> row,String subject) {
    final id=row['id'].toString();
    final annual=subject.isEmpty?null:model!.annual(id,subject);
    final attendance=model!.attendanceSummary(id,day.substring(0,7));
    final notes=row['notes']?.toString()??'';
    Widget info(String label,String value)=>Padding(padding:const EdgeInsets.only(bottom:8),
      child:Row(children:[Expanded(child:Text(label)),Text(value,style:const TextStyle(fontWeight:FontWeight.w800))]));
    return [
      UnifiedUI.colored('أولًا • معلومات التلميذ',Icons.person_outline,const Color(0xff4e79a2),[
        info('الاسم',row['name'].toString()),info('الصف',groupName(row['classId'].toString())),
        info('رقم القيد',row['number']?.toString()??'—')]),
      const SizedBox(height:10),
      UnifiedUI.colored('ثانيًا • التحصيل الدراسي',Icons.school_outlined,const Color(0xff238a7a),[
        info('المادة',subject.isEmpty?'غير محددة':subject),
        info('معدل الفصل الأول',annual?.first?.toString()??'—'),
        info('نصف السنة',annual?.mid?.toString()??'—'),
        info('معدل الفصل الثاني',annual?.second?.toString()??'—'),
        info('السعي السنوي',annual?.effort?.toString()??'—'),
        info('الامتحان النهائي',annual?.exam?.toString()??'—'),
        info('الدرجة النهائية',annual?.finalGrade?.toString()??'—'),
      ]),const SizedBox(height:10),
      UnifiedUI.colored('ثالثًا • المواظبة والحضور',Icons.calendar_today_outlined,const Color(0xffb28446),[
        info('حالة اليوم',_status(id)),
        for(final st in ['present','absent','late','excused'])
          info({'present':'حاضر','absent':'غائب','late':'متأخر','excused':'بعذر'}[st]!,
            '${attendance[st]??0}'),
      ]),const SizedBox(height:10),
      UnifiedUI.colored('رابعًا • الملاحظات والتوصيات',Icons.note_alt_outlined,const Color(0xff9366a9),[
        Text(notes.isEmpty?'لا توجد ملاحظات مسجلة':notes),
      ]),const SizedBox(height:10),
    ];
  }
  Future<void> _editParentNote(Map<String,dynamic> row) async {
    final text=await UnifiedUI.ask(context,'ملاحظات وتوصيات ولي الأمر',
      row['notes']?.toString()??'');
    if(text==null || !mounted)return;
    await _save((){
      final list=model!.people;
      list.firstWhere((s)=>s['id'].toString()==row['id'].toString())['notes']=text;
      model!.data['students']=list;
    });
  }
  Future<void> _printGuardian(Map<String,dynamic> row,String subject) async {
    try {
      final font=pw.Font.ttf(await rootBundle.load('modules/sajli/assets/fonts/NotoSansArabic-400.ttf'));
      final annual=subject.isEmpty?null:model!.annual(row['id'].toString(),subject);
      final id=row['id'].toString();
      final attendance=model!.attendanceSummary(id,day.substring(0,7));
      pw.Widget group(String title,String color,List<String> rows)=>pw.Container(
        margin:const pw.EdgeInsets.only(bottom:11),
        padding:const pw.EdgeInsets.all(13),
        decoration:pw.BoxDecoration(color:PdfColor.fromHex(color)),
        child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.stretch,
          children:[pw.Text(title,style:pw.TextStyle(font:font,fontSize:14)),
          pw.SizedBox(height:8),
          for(final value in rows)pw.Padding(
            padding:const pw.EdgeInsets.only(bottom:6),
            child:pw.Text(value,style:pw.TextStyle(font:font,fontSize:11))),
        ]));
      final pdf=pw.Document();
      pdf.addPage(pw.MultiPage(pageFormat:PdfPageFormat.a4,
        textDirection:pw.TextDirection.rtl,
        theme:pw.ThemeData.withFont(base:font,bold:font),
        build:(ctx)=>[
          pw.Text('تقرير ولي الأمر — سجلي',style:pw.TextStyle(font:font,fontSize:20)),
          pw.SizedBox(height:16),
          group('أولًا • معلومات التلميذ','#EAF0FA',[
            'الاسم: ${row['name']}','الصف: ${groupName(row['classId'].toString())}',
            'رقم القيد: ${row['number']??'—'}',
          ]),
          group('ثانيًا • التحصيل الدراسي','#E7F5ED',[
            'المادة: $subject','معدل الفصل الأول: ${annual?.first??'—'}',
            'نصف السنة: ${annual?.mid??'—'}',
            'معدل الفصل الثاني: ${annual?.second??'—'}',
            'السعي: ${annual?.effort??'—'}',
            'الامتحان النهائي: ${annual?.exam??'—'}',
            'الدرجة النهائية: ${annual?.finalGrade??'—'}',
          ]),
          group('ثالثًا • المواظبة والحضور','#FFF3E6',[
            'حالة اليوم: ${_status(id)}',
            for(final st in ['present','absent','late','excused'])
              '${{'present':'حاضر','absent':'غائب','late':'متأخر','excused':'بعذر'}[st]}: ${attendance[st]??0}',
          ]),
          group('رابعًا • الملاحظات والتوصيات','#F4ECF8',[
            (row['notes']?.toString()??'').isNotEmpty?row['notes'].toString():
              'لا توجد ملاحظات مسجلة',
          ]),
        ]));
      await Printing.layoutPdf(name:'sajli-guardian-report.pdf',onLayout:(_)=>pdf.save());
    }catch(e){if(mounted)UnifiedUI.notice(context,'تعذر الطباعة: $e');}
  }

  Widget _tools()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('إدارة سجلي','كل أداة تبقى داخل الواجهة الموحدة'),
    _actions([('إدارة الدرجات',Icons.workspace_premium_outlined,()=>setState(()=>detail='marks')),
      ('الصفوف والشعب',Icons.school_outlined,()=>setState(()=>detail='classes')),
      ('ملفات التلاميذ',Icons.people_outline,()=>widget.onTab('students')),
      ('الحضور اليومي',Icons.fact_check_outlined,()=>widget.onTab('attendance')),
      ('تقرير ولي الأمر',Icons.summarize_outlined,()=>widget.onTab('reports'))]),
    UnifiedUI.headline('إحصائيات المدرسة'),_schoolStats(),
  ]);
  Widget _actions(List<(String,IconData,VoidCallback)> actions) =>
      LayoutBuilder(builder:(context,c)=>Wrap(spacing:11,runSpacing:11,
        children:[for(final a in actions) SizedBox(width:(c.maxWidth-11)/2,
          child:UnifiedQuick(title:a.$1,icon:a.$2,onTap:a.$3))]));
  Widget _detail()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    TextButton.icon(onPressed:()=>setState(()=>detail=''),icon:const Icon(Icons.arrow_forward),
      label:const Text('العودة إلى القسم')),
    if(detail=='profile')_profile(),
    if(detail=='marks')_marks(),
    if(detail=='classes')_classes(),
  ]);
  Widget _profile(){final row=selected;
    if(row==null)return UnifiedUI.empty('لم يعد هذا التلميذ موجودًا');
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      UnifiedUI.colored('التلميذ • ${row['name']}',Icons.person_outline,const Color(0xff7660a1),[
        Text('${groupName(row['classId'].toString())} • رقم القيد ${row['number']??'—'}'),
        const SizedBox(height:9),
        Text('حالة الحضور: ${_status(row['id'].toString())} • الدرجات المدخلة: ${_gradeCount(row)}')]),
      UnifiedUI.headline('البيانات الأساسية'),
      UnifiedUI.colored('ملف التلميذ',Icons.badge_outlined,const Color(0xff4e79a2),[
        Text('الاسم: ${row['name']}'),const SizedBox(height:8),
        Text('الصف والشعبة: ${groupName(row['classId'].toString())}'),
        const SizedBox(height:8),Text('القيد: ${row['number']??'—'}'),
        UnifiedUI.control('تعديل البيانات',()=>_editPerson(row:row),icon:Icons.edit_outlined),
      ]),const SizedBox(height:10),
      _actions([('درجات التلميذ',Icons.school_outlined,()=>setState(()=>detail='marks')),
        ('تقرير ولي الأمر',Icons.description_outlined,()=>setState((){detail='';widget.onTab('reports');})),
        ('الحضور',Icons.event_available_outlined,()=>setState((){detail='';widget.onTab('attendance');}))]),
      const SizedBox(height:10),
      OutlinedButton.icon(onPressed:()=>_deletePerson(row),icon:const Icon(Icons.delete_outline),
        label:const Text('حذف التلميذ')),
    ]);
  }
  Widget _marks(){final row=selected;
    if(row==null)return UnifiedUI.empty('اختر تلميذًا من الشبكة أولًا');
    final subs=model!.subjects(row['classId'].toString());
    final subject=subs.contains(course)?course:subs.firstOrNull??'';
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      UnifiedUI.headline('دفتر الدرجات','الدرجات محفوظة في قاعدة سجلي الأصلية'),
      UnifiedPanel(child:Column(children:[
        DropdownButtonFormField<String>(value:row['id'].toString(),isExpanded:true,
          decoration:const InputDecoration(labelText:'التلميذ'),
          items:[for(final st in model!.people.where((s)=>s['archived']!=true))
            DropdownMenuItem(value:st['id'].toString(),child:Text(st['name'].toString(),overflow:TextOverflow.ellipsis))],
          onChanged:(id)=>setState(()=>selectedId=id??'')),
        if(subs.isNotEmpty)DropdownButtonFormField<String>(value:subject,isExpanded:true,
          decoration:const InputDecoration(labelText:'المادة'),
          items:[for(final sub in subs)DropdownMenuItem(value:sub,child:Text(sub))],
          onChanged:(v)=>setState(()=>course=v??'')),
      ])),
      const SizedBox(height:12),
      if(subject.isNotEmpty)UnifiedPanel(child:Column(children:[
        for(final p in model!.periods)...[
          UnifiedUI.action('${p['label']??p['name']??p['key']}',
            'الدرجة: ${model!.score(row['id'].toString(),subject,p['key'].toString())??'—'} / ${model!.maximum(subject)}',
            Icons.edit_note_outlined,()=>_editMark(row,subject,p)),
          const Divider(height:10),
        ],
      ])),
    ]);
  }
  Widget _classes()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('الصفوف والشعب','إضافة وتعديل وحذف آمن مع تنبيه قبل حذف التلاميذ'),
    UnifiedUI.control('إضافة صف وشعبة',()=>_editClass(),icon:Icons.add),
    const SizedBox(height:12),
    if(groups.isEmpty)UnifiedUI.empty('لم تُضف أي صفوف بعد'),
    for(final g in groups)Padding(padding:const EdgeInsets.only(bottom:10),child:
      UnifiedPanel(child:Column(children:[
        UnifiedUI.action(g['name'].toString(),
          '${model!.students(g['id'].toString()).length} تلميذ',
          Icons.groups_outlined,()=>_editClass(row:g)),
        Row(children:[TextButton.icon(onPressed:()=>_editClass(row:g),
          icon:const Icon(Icons.edit_outlined),label:const Text('تعديل')),
          TextButton.icon(onPressed:()=>_deleteClass(g),
          icon:const Icon(Icons.delete_outline),label:const Text('حذف'))]),
      ]))),
  ]);
}

class JadwaliWorkspace extends StatefulWidget {
  const JadwaliWorkspace({super.key, required this.tab, required this.lessons,
      required this.dayName, required this.database,
      required this.onEditLesson, required this.onSwap, required this.onChangeDay,
      required this.onTransferToBell, required this.onRefresh,
      required this.onOpenBell, required this.onTab});
  final String tab, dayName;
  final List<UnifiedLesson> lessons;
  final DatabaseService database;
  final ValueChanged<int> onEditLesson;
  final void Function(int,int) onSwap;
  final VoidCallback onChangeDay,onTransferToBell,onRefresh,onOpenBell;
  final ValueChanged<String> onTab;
  @override State<JadwaliWorkspace> createState()=>_JadwaliWorkspaceState();
}
class _JadwaliWorkspaceState extends State<JadwaliWorkspace> {
  int? firstSwap;
  String detail='';
  bool landscape=true;
  Future<List<Map<String,Object?>>>? data;
  String table='teachers';
  String get tableLabel => switch(table) {
    'teachers'=>'المعلمون','subjects'=>'المواد','sections'=>'الشعب',_=>'البيانات'
  };
  void _pickTable(String value){setState((){table=value;detail='table';data=null;});}
  Future<void> _editRow({Map<String,Object?>? row}) async {
    var title=row?['name']?.toString()??'';
    final name=await UnifiedUI.ask(context,row==null?'إضافة $tableLabel':'تعديل $tableLabel',title);
    if(name==null || !mounted)return;
    if(name.isEmpty)return UnifiedUI.notice(context,'الاسم مطلوب');
    try {
      if(row!=null){await widget.database.edit(table,row['id'] as int,{'name':name});}
      else if(table=='sections'){
        UnifiedUI.notice(context,'اختر الصف الأساسي من إعدادات المدرسة قبل إنشاء الشعبة.');return;
      }else{await widget.database.add(table,{'name':name});}
      setState((){data=null;});widget.onRefresh();
      if(mounted)UnifiedUI.notice(context,'تم الحفظ بنجاح');
    }catch(e){if(mounted)UnifiedUI.notice(context,'تعذّر الحفظ: $e');}
  }
  Future<void> _deleteRow(Map<String,Object?> row) async {
    if(!await UnifiedUI.confirm(context,'حذف $tableLabel',
      'قد تؤثر هذه العملية في قيود الجدول وإسناد المعلمين. هل تريد المتابعة؟'))return;
    try {await widget.database.remove(table,row['id'] as int);
      setState((){data=null;});widget.onRefresh();
    }catch(e){if(mounted)UnifiedUI.notice(context,'تعذّر الحذف: $e');}
  }
  @override Widget build(BuildContext context) {
    if(detail=='table')return _tableView();
    return switch(widget.tab){
      'schedule'=>_schedule(), 'repair'=>_repair(), 'reports'=>_reports(),
      'tools'=>_tools(),_=>_dashboard(),
    };
  }
  Widget _dashboard()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('جدول اليوم', 'الحصص المحفوظة من قاعدة جدولي الأصلية'),
    _scheduleList(editable:true),
    UnifiedUI.headline('اختصارات جدولي'), _actionGrid([
      ('تعديل الحصص',Icons.edit_calendar_outlined,()=>widget.onTab('schedule')),
      ('الإصلاح الذكي',Icons.swap_horiz_rounded,()=>widget.onTab('repair')),
      ('تقارير A4',Icons.summarize_outlined,()=>widget.onTab('reports')),
      ('الإعداد',Icons.tune_outlined,()=>widget.onTab('tools')),
    ]),
    UnifiedUI.headline('التكامل مع جرس المعلم'),
    UnifiedPanel(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const Text('انقل الحصص المحفوظة للجرس بعد مراجعتها. تبقى قيود الجدولة والبيانات محفوظة.'),
      UnifiedUI.control('نقل حصص اليوم إلى الجرس',widget.onTransferToBell,
        icon:Icons.notifications_active_outlined),
    ])),
  ]);
  Widget _scheduleList({bool editable=false})=>Column(children:[
    if(widget.lessons.isEmpty)UnifiedUI.empty('لا توجد حصص لهذا اليوم أو الصف'),
    for(final item in widget.lessons) Padding(padding:const EdgeInsets.only(bottom:10),
      child:UnifiedPanel(child:UnifiedUI.action('الحصة ${item.period} • ${item.subject}',
        '${item.time}${item.teacher.isEmpty?'':' • ${item.teacher}'}',
        Icons.calendar_today_outlined,
        ()=>editable?widget.onEditLesson(item.period-1):_swapAt(item.period-1)))),
  ]);
  void _swapAt(int i){if(firstSwap==null){setState(()=>firstSwap=i);return;}
    if(firstSwap==i){setState(()=>firstSwap=null);return;}
    final first=firstSwap!;setState(()=>firstSwap=null);widget.onSwap(first,i);
  }
  Widget _schedule()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('الجدول الدراسي','حدد اليوم ثم انقر أي حصة لتغيير المادة لهذا التاريخ أو أسبوعيًا'),
    UnifiedPanel(child:UnifiedUI.action('اليوم: ${widget.dayName}',
        'فتح التقويم لتغيير التاريخ',Icons.event_outlined,widget.onChangeDay)),
    const SizedBox(height:12),_scheduleList(editable:true),
    UnifiedUI.headline('تبديل مباشر'),
    UnifiedUI.control('الانتقال إلى أداة التبديل',()=>widget.onTab('repair'),icon:Icons.swap_horiz),
  ]);
  Widget _repair()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('الإصلاح الذكي','تبديل الحصص عبر محرك التحقق الحقيقي من القيود'),
    UnifiedPanel(child:Text(firstSwap==null?'اختر الحصة الأولى ثم الحصة الثانية للتحقق من إمكانية التبديل.':
        'تم اختيار الحصة ${firstSwap!+1}. اختر الحصة الثانية الآن.')),
    const SizedBox(height:12),
    for(final l in widget.lessons)Padding(padding:const EdgeInsets.only(bottom:9),
      child:UnifiedPanel(child:UnifiedUI.action(
        'الحصة ${l.period} • ${l.subject}',
        firstSwap==l.period-1?'الحصة الأولى المحددة':'انقر لاختيار الحصة',
        firstSwap==l.period-1?Icons.check_circle:Icons.swap_horiz,
        ()=>_swapAt(l.period-1)))),
    if(widget.lessons.length<2)UnifiedUI.empty('يلزم وجود حصتين على الأقل للتبديل'),
  ]);
  Widget _reports()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('تقارير جدولي','معاينة جدول اليوم بألوان واضحة وورقة A4'),
    UnifiedPanel(child:SwitchListTile.adaptive(title:const Text('تقرير أفقي A4'),
      subtitle:const Text('أوقف التبديل لاختيار A4 عمودي'),value:landscape,
      onChanged:(v)=>setState(()=>landscape=v))),
    const SizedBox(height:12),
    UnifiedPanel(child:Column(children:[
      for(final l in widget.lessons) UnifiedUI.action('الحصة ${l.period}',
        '${l.subject} • ${l.time}',Icons.table_rows_outlined,()=>widget.onEditLesson(l.period-1)),
    ])),
    UnifiedUI.control('طباعة الجدول على A4',_printTable,icon:Icons.print_outlined),
  ]);
  Future<void> _printTable()async{
    try {
      final font=pw.Font.ttf(await rootBundle.load('modules/sajli/assets/fonts/NotoSansArabic-400.ttf'));
      final pdf=pw.Document();
      pdf.addPage(pw.MultiPage(pageFormat:landscape?PdfPageFormat.a4.landscape:PdfPageFormat.a4,
        textDirection:pw.TextDirection.rtl,
        theme:pw.ThemeData.withFont(base:font,bold:font),
        build:(_)=>[pw.Text('جدولي المدرسي • ${widget.dayName}',style:pw.TextStyle(font:font,fontSize:18)),
          pw.SizedBox(height:15),
          for(final l in widget.lessons)pw.Container(padding:const pw.EdgeInsets.all(10),
            margin:const pw.EdgeInsets.only(bottom:6),
            decoration:pw.BoxDecoration(color:PdfColor.fromHex('#E9F4F1')),
            child:pw.Text('الحصة ${l.period} • ${l.subject} • ${l.time}',
              style:pw.TextStyle(font:font,fontSize:12))),
        ]));
      await Printing.layoutPdf(onLayout:(_)=>pdf.save(),name:'jadwali-report.pdf');
    }catch(e){if(mounted)UnifiedUI.notice(context,'تعذّرت الطباعة: $e');}
  }
  Widget _tools()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('إعداد الجدول','إدارة المعلمين والمواد والشعب دون فتح واجهة قديمة'),
    _actionGrid([('المعلمون',Icons.people_outline,()=>_pickTable('teachers')),
      ('المواد',Icons.menu_book_outlined,()=>_pickTable('subjects')),
      ('الشعب',Icons.school_outlined,()=>_pickTable('sections')),
      ('الجدول',Icons.calendar_month_outlined,()=>widget.onTab('schedule'))]),
    UnifiedUI.headline('قواعد التوزيع'),
    UnifiedUI.colored('قيود المعلمين',Icons.rule_outlined,const Color(0xff398c83),[
      const Text('لا يتجاوز التبديل القيود المحفوظة، ولا تغيّر هذه الواجهة خوارزميات جدولي.')]),
  ]);
  Widget _tableView(){data??=widget.database.rows(table);return Column(
    crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      TextButton.icon(onPressed:()=>setState(()=>detail=''),
        icon:const Icon(Icons.arrow_forward),label:const Text('العودة إلى إعداد القسم')),
      UnifiedUI.headline(tableLabel,'بيانات أصلية محفوظة في قاعدة جدولي'),
      if(table!='sections')UnifiedUI.control('إضافة $tableLabel',()=>_editRow(),icon:Icons.add),
      const SizedBox(height:12),
      FutureBuilder<List<Map<String,Object?>>>(future:data,builder:(context,snapshot){
        if(snapshot.hasError)return UnifiedUI.empty('تعذر قراءة البيانات: ${snapshot.error}');
        if(!snapshot.hasData)return const Center(child:CircularProgressIndicator());
        return Column(children:[
          if(snapshot.data!.isEmpty)UnifiedUI.empty('لم تُحفظ بيانات بعد'),
          for(final row in snapshot.data!) Padding(padding:const EdgeInsets.only(bottom:8),
            child:UnifiedPanel(child:Row(children:[
              Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(row['name']?.toString()??'',style:const TextStyle(fontWeight:FontWeight.w800)),
                if(table=='teachers')Text('النصاب الأسبوعي: ${row['weekly_load']??'—'}'),
              ])),
              IconButton(onPressed:()=>_editRow(row:row),icon:const Icon(Icons.edit_outlined)),
              IconButton(onPressed:()=>_deleteRow(row),icon:const Icon(Icons.delete_outline)),
            ]))),
        ]);
      }),
    ]);
  }
  Widget _actionGrid(List<(String,IconData,VoidCallback)> items)=>
      LayoutBuilder(builder:(context,c)=>Wrap(spacing:11,runSpacing:11,children:[
        for(final item in items)SizedBox(width:(c.maxWidth-11)/2,
          child:UnifiedQuick(title:item.$1,icon:item.$2,onTap:item.$3)),
      ]));
}

class BellWorkspace extends StatefulWidget {
  const BellWorkspace({super.key,required this.tab,required this.onTab,
    required this.onTransfer,required this.onOpenJadwali});
  final String tab;
  final ValueChanged<String> onTab;
  final VoidCallback onTransfer,onOpenJadwali;
  @override State<BellWorkspace> createState()=>_BellWorkspaceState();
}
class _BellWorkspaceState extends State<BellWorkspace> {
  bell.PlannerState? state;
  bool busy=false;
  int day=DateTime.now().weekday%7;
  String detail='';
  @override void initState(){super.initState();_load();}
  Future<void> _load()async{
    try{final result=await bell_device.DeviceService.load();
      if(mounted)setState(()=>state=result);
    }catch(e){if(mounted)UnifiedUI.notice(context,'تعذّر تحميل الجرس: $e');}
  }
  Future<void> _save(VoidCallback change)async{
    if(state==null||busy)return;
    final snapshot=state!.clone();setState(()=>busy=true);
    try {
      change();
      await bell_device.DeviceService.save(state!);
      await bell_device.DeviceService.sync(state!);
      if(mounted){setState(()=>busy=false);UnifiedUI.notice(context,'حُفظت مواعيد الجرس والتنبيهات');}
    }catch(e){state=snapshot;if(mounted){setState(()=>busy=false);
      UnifiedUI.notice(context,'لم تُحفظ إعدادات الجرس: $e');}}
  }
  String get todayName=>bell.weekdays[day];
  Widget _dayPicker()=>SizedBox(height:44,child:ListView(scrollDirection:Axis.horizontal,
    children:[for(var i=0;i<7;i++)Padding(padding:const EdgeInsetsDirectional.only(start:6),
      child:UnifiedUI.chip(bell.weekdays[i],i==day,()=>setState(()=>day=i)))]));
  @override Widget build(BuildContext context) {
    if(state==null)return UnifiedUI.empty('جارٍ تحميل الحصص الحقيقية من جرس المعلم...');
    if(detail.isNotEmpty)return _detail();
    return switch(widget.tab) {
      'periods'=>_periods(),'week'=>_week(),'alerts'=>_alerts(),
      'tools'=>_tools(),_=>_home(),
    };
  }
  Widget _home()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('حصص اليوم','نفس الحصص التي تستخدمها خدمة Android للتنبيه'),
    _dayPicker(),_periodList(),
    UnifiedUI.headline('تحكم سريع'),
    _grid([('تعديل الحصص',Icons.edit_calendar_outlined,()=>widget.onTab('periods')),
      ('الأسبوع',Icons.calendar_month_outlined,()=>widget.onTab('week')),
      ('النغمة والاهتزاز',Icons.vibration_rounded,()=>widget.onTab('alerts')),
      ('النقل من جدولي',Icons.swap_horiz,widget.onTransfer)]),
    UnifiedUI.headline('الجرس مرتبط بجدولي'),
    UnifiedUI.colored('البرنامج المدرسي',Icons.notifications_active_outlined,
      const Color(0xffab6e5c),[
        const Text('تعديل جدول جدولي ونقله إلى الجرس يتم بتأكيد. يعمل التنبيه عبر خدمة Android الأصلية.'),
        UnifiedUI.control('فتح جدولي',widget.onOpenJadwali),
      ]),
  ]);
  Widget _periodList()=>Column(children:[
    if(state!.week[day].isEmpty) UnifiedUI.empty('لم تضف حصص لهذا اليوم'),
    for(var i=0;i<state!.week[day].length;i++)Padding(
      padding:const EdgeInsets.only(bottom:9),child:UnifiedPanel(child:
      UnifiedUI.action('الحصة ${i+1} • ${state!.week[day][i].subject.isEmpty?'غير محددة':state!.week[day][i].subject}',
        '${bell.clock(state!.week[day][i].start)} - ${bell.clock(state!.week[day][i].end)} • ${state!.week[day][i].grade}\n${state!.week[day][i].enabled?'مفعّل':'معطّل'}',
        Icons.notifications_outlined,()=>setState(()=>detail='edit:$i'),
        color:const Color(0xffab6e5c)))),
  ]);
  Widget _periods()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('الحصص والمواعيد','اختر يومًا والحصة، وعدّلها داخل التصميم الجديد'),
    _dayPicker(),const SizedBox(height:12),_periodList(),
    UnifiedUI.control('إضافة حصة',(){final i=state!.week[day].length;
      if(i>=12)return UnifiedUI.notice(context,'الحد الأقصى 12 حصة في اليوم');
      final end=state!.week[day].isEmpty?480:state!.week[day].last.end+5;
      final finish=(end+40).clamp(0,1439).toInt();
      _save(()=>state!.week[day].add(bell.Lesson(id:'d${day}l${i+1}',
        start:end.clamp(0,1400).toInt(),end:finish,enabled:false)));
    },icon:Icons.add),
  ]);
  Widget _week()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('البرنامج الأسبوعي','تفعيل الأيام ومراجعة حصصها'),
    for(var i=0;i<7;i++)Padding(padding:const EdgeInsets.only(bottom:9),
      child:UnifiedPanel(child:Column(children:[
        SwitchListTile.adaptive(value:state!.work[i],
          title:Text(bell.weekdays[i]),
          subtitle:Text('${state!.week[i].length} حصص محفوظة'),
          onChanged:(v)=>_save(()=>state!.work[i]=v)),
        TextButton(onPressed:()=>setState(()=>day=i),child:const Text('عرض حصص اليوم')),
      ]))),
    _dayPicker(),_periodList(),
  ]);
  Widget _alerts()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('إعدادات التنبيه','إشعارات واهتزاز ونغمة على الهاتف'),
    UnifiedPanel(child:SwitchListTile.adaptive(
      value:state!.enabled,title:const Text('تشغيل تنبيهات الجرس'),
      subtitle:const Text('تنبيهات Android المجدولة'),
      onChanged:(v)async{if(v)await bell_device.DeviceService.requestNotifications();
        if(mounted)_save(()=>state!.enabled=v);})),
    const SizedBox(height:10),
    UnifiedUI.colored('نغمة الجرس',Icons.music_note_rounded,const Color(0xffb77462),[
      for(final tone in ['classic','soft','doubleBell'])RadioListTile<String>(
        title:Text({'classic':'جرس كلاسيكي','soft':'نغمة هادئة','doubleBell':'رنتان متتاليتان'}[tone]!),
        value:tone,groupValue:state!.tone,
        onChanged:(v)=>_save(()=>state!.tone=v??'classic')),
      UnifiedUI.control('اختبار النغمة',()async{
        try{await bell_device.DeviceService.testTone(state!);}
        catch(e){if(mounted)UnifiedUI.notice(context,'تعذّر الاختبار: $e');}
      },icon:Icons.volume_up_outlined),
    ]),const SizedBox(height:10),
    UnifiedUI.colored('الاهتزاز',Icons.vibration_rounded,const Color(0xff548e92),[
      Text('عدد الاهتزازات: ${state!.vibration.count}'),
      Slider(value:state!.vibration.count.toDouble(),min:1,max:12,divisions:11,
        label:'${state!.vibration.count}',onChanged:(v)=>setState((){
          state!.vibration=state!.vibration.copyWith(count:v.round());
        }),onChangeEnd:(v)=>_save(()=>state!.vibration=state!.vibration.copyWith(count:v.round()))),
      UnifiedUI.control('اختبار الاهتزاز على الهاتف',()async{
        try{final ok=await bell_device.DeviceService.testVibration(state!.vibration);
          if(mounted)UnifiedUI.notice(context,ok?'تم إرسال اختبار الاهتزاز':'الاهتزاز غير متاح أو مرفوض');}
        catch(e){if(mounted)UnifiedUI.notice(context,'فشل الاهتزاز: $e');}
      },icon:Icons.vibration_rounded),
    ]),
  ]);
  Widget _tools()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('إعدادات جرس المعلم','كل عناصر التحكم تنتمي إلى نفس الواجهة'),
    _grid([('المواعيد',Icons.schedule_outlined,()=>widget.onTab('periods')),
      ('البرنامج الأسبوعي',Icons.calendar_month_outlined,()=>widget.onTab('week')),
      ('الصوت والهزاز',Icons.vibration_outlined,()=>widget.onTab('alerts')),
      ('النقل من جدولي',Icons.swap_horiz,widget.onTransfer)]),
    const SizedBox(height:13),
    UnifiedPanel(child:SwitchListTile.adaptive(title:const Text('إعلان صوتي باسم الحصة'),
      value:state!.speech,onChanged:(v)=>_save(()=>state!.speech=v))),
    const SizedBox(height:12),
    OutlinedButton.icon(onPressed:()async{
      if(!await UnifiedUI.confirm(context,'استعادة إعدادات الجرس','سيُعاد ضبط جميع أوقات الجرس.'))return;
      await _save(()=>state=bell.PlannerState());
    },icon:const Icon(Icons.restart_alt),label:const Text('استعادة إعدادات الجرس')),
  ]);
  Widget _detail(){final i=int.tryParse(detail.split(':').last)??0;
    if(i<0||i>=state!.week[day].length)return UnifiedUI.empty('الحصة غير موجودة');
    final l=state!.week[day][i];
    var sub=l.subject,grade=l.grade,from=bell.clock(l.start),to=bell.clock(l.end);
    var enabled=l.enabled,mode=l.mode;
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      TextButton.icon(onPressed:()=>setState(()=>detail=''),
        icon:const Icon(Icons.arrow_forward),label:const Text('العودة إلى الحصص')),
      UnifiedUI.headline('تعديل الحصة ${i+1}','تأثير مباشر على جدولة جرس Android'),
      UnifiedPanel(child:Column(children:[
        UnifiedUI.field('المادة',sub,(v)=>sub=v),const SizedBox(height:10),
        UnifiedUI.field('الصف',grade,(v)=>grade=v),const SizedBox(height:10),
        UnifiedUI.field('وقت البداية (HH:MM)',from,(v)=>from=v),const SizedBox(height:10),
        UnifiedUI.field('وقت النهاية (HH:MM)',to,(v)=>to=v),const SizedBox(height:12),
        DropdownButtonFormField<String>(value:mode,
          decoration:const InputDecoration(labelText:'نوع التنبيه'),
          items:[for(final item in ['notification','vibration','sound','both'])
            DropdownMenuItem(value:item,child:Text(bell.alertNames[item]!))],
          onChanged:(v)=>mode=v??mode),
        StatefulBuilder(builder:(context,refresh)=>SwitchListTile.adaptive(title:const Text('الحصة مفعّلة'),
          value:enabled,onChanged:(v)=>refresh(()=>enabled=v))),
        UnifiedUI.control('حفظ الحصة',()async{
          final f=_minute(from),t=_minute(to);
          if(f==null||t==null||f>=t)return UnifiedUI.notice(context,'توقيت الحصة غير صحيح');
          if(enabled&&(sub.trim().isEmpty||grade.trim().isEmpty))return UnifiedUI.notice(context,'أدخل المادة والصف أولًا');
          await _save(()=>state!.week[day][i]=l.copyWith(subject:sub.trim(),grade:grade.trim(),
            start:f,end:t,enabled:enabled,mode:mode));
          if(mounted)setState(()=>detail='');
        },icon:Icons.save_outlined),
      ])),
    ]);
  }
  int? _minute(String value){final m=RegExp(r'^([01]?\d|2[0-3]):([0-5]\d)$').firstMatch(value.trim());
    return m==null?null:int.parse(m[1]!)*60+int.parse(m[2]!);}
  Widget _grid(List<(String,IconData,VoidCallback)> items)=>
    LayoutBuilder(builder:(context,c)=>Wrap(spacing:11,runSpacing:11,children:[
      for(final item in items)SizedBox(width:(c.maxWidth-11)/2,
        child:UnifiedQuick(title:item.$1,icon:item.$2,onTap:item.$3)),
    ]));
}

class LibraryWorkspace extends StatefulWidget {
  const LibraryWorkspace({super.key,required this.tab,required this.onTab});
  final String tab;
  final ValueChanged<String> onTab;
  @override State<LibraryWorkspace> createState()=>_LibraryWorkspaceState();
}
class _LibraryWorkspaceState extends State<LibraryWorkspace> {
  LibraryCatalog? catalog;
  String stage='',grade='',subject='',query='',detail='';
  final downloader=DownloadedBooks();
  Map<String,dynamic> downloaded={};
  final Set<String> favorites={};
  int page=0;
  int? answer;
  String? error;
  int? downloading;
  double? downloadProgress;
  @override void initState(){super.initState();_load();}
  Future<void> _load()async{
    try {
      final data=await LibraryRepository().cachedOrPackaged();
      final prefs=await SharedPreferences.getInstance();
      final saved=await downloader.entries();
      if (mounted) {
        setState(() {
          catalog = data;
          downloaded = saved;
          favorites.addAll(prefs.getStringList('native_user_favorites_v23') ?? []);
        });
      }
    }catch(e){if(mounted)setState(()=>error='$e');}
  }
  Future<void> _refresh()async{
    try{
      final fresh=await LibraryRepository().refreshPublic();
      if(fresh==null){if(mounted)UnifiedUI.notice(context,'تحديث المناهج غير مهيأ دون إعداد GitHub');return;}
      if(mounted)setState(()=>catalog=fresh);
    }catch(e){if(mounted)UnifiedUI.notice(context,'تعذر تحديث الكتب: $e');}
  }
  List<Map<String,dynamic>> get books{
    final c=catalog;
    if(c==null)return [];
    final visibleGrades=c.grades.where((x)=>LibraryCatalog.visible(x) &&
        (stage.isEmpty||x['stageId']==stage)).map((x)=>x['id']).toSet();
    final visibleSubs=c.subjects.where((x)=>LibraryCatalog.visible(x) &&
        visibleGrades.contains(x['gradeId']) &&
        (grade.isEmpty||x['gradeId']==grade)).map((x)=>x['id']).toSet();
    final ids=subject.isEmpty?visibleSubs:c.subjects.where((x)=>x['id']==subject).map((x)=>x['id']).toSet();
    return c.books.where((x)=>LibraryCatalog.visible(x) && ids.contains(x['subjectId']) &&
      (query.isEmpty || '${x['title']} ${x['name']}'.contains(query))).toList();
  }
  String name(Map<String,dynamic> x)=>LibraryCatalog.name(x);
  Future<void> _favorite(String id)async{
    setState((){if(!favorites.remove(id))favorites.add(id);});
    final prefs=await SharedPreferences.getInstance();
    await prefs.setStringList('native_user_favorites_v23',favorites.toList());
  }
  Future<void> _download(Map<String,dynamic> book)async{
    final url=(book['url']??'').toString();
    if(!LibraryCatalog.validWebUrl(url))return UnifiedUI.notice(context,'الرابط غير صالح');
    setState(()=>downloading=books.indexOf(book));
    try{
      await downloader.download(book,onProgress:(p){if(mounted)setState(()=>downloadProgress=p.fraction);});
      final results=await downloader.entries();
      if(mounted){setState(()=>downloaded=results);UnifiedUI.notice(context,'تم تنزيل الكتاب');}
    }catch(e){if(mounted)UnifiedUI.notice(context,'فشل التنزيل: $e');}
    finally{if(mounted)setState((){downloading=null;downloadProgress=null;});}
  }
  void _reader(Map<String,dynamic> book)async{
    final id=book['id']?.toString()??'';
    final local=await downloader.localFile(id);
    if(!mounted)return;
    final url=book['url']?.toString()??'';
    if(local==null&&!LibraryCatalog.validWebUrl(url)){
      UnifiedUI.notice(context,'الكتاب بلا رابط PDF صالح');return;
    }
    await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>UnifiedBookReader(
      name:name(book),bookId:id,local:local,url:url)));
  }
  @override Widget build(BuildContext context){
    if(error!=null)return UnifiedUI.empty('تعذر تحميل المناهج: $error');
    if(catalog==null)return const Center(child:CircularProgressIndicator());
    if(detail.isNotEmpty)return _detail();
    return switch(widget.tab){
      'books'=>_booksView(),'saved'=>_saved(),'reviews'=>_reviews(),
      'tools'=>_tools(),_=>_home(),
    };
  }
  Widget _home()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('المراحل الدراسية','اختر مرحلتك ثم صفك ومادتك'),
    _stageFilters(),
    UnifiedUI.headline('كتب مناهجك','الفهرس الحقيقي المنشور من قسم المناهج'),
    _bookGrid(4),
    UnifiedUI.control('عرض جميع الكتب',()=>widget.onTab('books'),icon:Icons.menu_book_outlined),
    UnifiedUI.headline('اختصارات المكتبة'),
    _grid([('المفضلة',Icons.favorite_border,()=>widget.onTab('saved')),
      ('التنزيلات',Icons.download_outlined,()=>widget.onTab('saved')),
      ('المراجعات',Icons.quiz_outlined,()=>widget.onTab('reviews')),
      ('تحديث الفهرس',Icons.sync_outlined,_refresh)]),
  ]);
  Widget _stageFilters()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    SizedBox(height:45,child:ListView(scrollDirection:Axis.horizontal,children:[
      UnifiedUI.chip('جميع المراحل',stage.isEmpty,()=>setState((){stage='';grade='';subject='';})),
      for(final x in catalog!.stages.where(LibraryCatalog.visible))Padding(
        padding:const EdgeInsetsDirectional.only(start:8),
        child:UnifiedUI.chip(name(x),stage==x['id'],()=>setState((){
          stage=x['id']?.toString()??'';grade='';subject='';
        }))),
    ])),
    if(stage.isNotEmpty)SizedBox(height:45,child:ListView(scrollDirection:Axis.horizontal,children:[
      UnifiedUI.chip('كل الصفوف',grade.isEmpty,()=>setState((){grade='';subject='';})),
      for(final x in catalog!.grades.where((x)=>x['stageId']==stage&&LibraryCatalog.visible(x)))
        Padding(padding:const EdgeInsetsDirectional.only(start:8),
          child:UnifiedUI.chip(name(x),grade==x['id'],()=>setState((){
            grade=x['id']?.toString()??'';subject='';
          }))),
    ])),
    if(grade.isNotEmpty)SizedBox(height:45,child:ListView(scrollDirection:Axis.horizontal,children:[
      UnifiedUI.chip('جميع المواد',subject.isEmpty,()=>setState(()=>subject='')),
      for(final x in catalog!.subjects.where((x)=>x['gradeId']==grade&&LibraryCatalog.visible(x)))
        Padding(padding:const EdgeInsetsDirectional.only(start:8),
          child:UnifiedUI.chip(name(x),subject==x['id'],()=>setState(()=>subject=x['id'].toString()))),
    ])),
  ]);
  Widget _bookGrid(int? max){final list=books.take(max??10000).toList();
    return Column(children:[if(list.isEmpty)UnifiedUI.empty('لا توجد كتب مطابقة'),
      for(var i=0;i<list.length;i++)Padding(padding:const EdgeInsets.only(bottom:10),
        child:UnifiedPanel(child:Column(children:[
          UnifiedUI.action(name(list[i]),
            'كتاب مدرسي • ${downloaded.containsKey(list[i]['id'])?'متوفر دون إنترنت':'متوفر عند الاتصال'}',
            Icons.menu_book_outlined,()=>_reader(list[i]),color:const Color(0xff36799a)),
          Row(children:[
            TextButton.icon(onPressed:()=>_reader(list[i]),
              icon:const Icon(Icons.auto_stories_outlined),label:const Text('قراءة')),
            TextButton.icon(onPressed:()=>_download(list[i]),
              icon:const Icon(Icons.download_outlined),label:const Text('تنزيل')),
            IconButton(onPressed:()=>_favorite(list[i]['id'].toString()),
              icon:Icon(favorites.contains(list[i]['id'])?Icons.favorite:Icons.favorite_border)),
          ]),
          if(downloading==books.indexOf(list[i]))LinearProgressIndicator(value:downloadProgress),
        ]))),
    ]);
  }
  Widget _booksView()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('الكتب الدراسية','البحث والقراءة والتنزيل دون فتح تصميم قديم'),
    TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),
      labelText:'بحث عن كتاب',border:OutlineInputBorder()),
      onChanged:(v)=>setState(()=>query=v)),
    const SizedBox(height:12),_stageFilters(),const SizedBox(height:10),_bookGrid(null),
  ]);
  Widget _saved()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('المفضلة والتنزيلات','ملفات PDF المحفوظة والكتب المميزة'),
    if(favorites.isEmpty&&downloaded.isEmpty)UnifiedUI.empty('لم تحفظ كتبًا بعد'),
    for(final x in catalog!.books.where((b)=>favorites.contains(b['id'])||downloaded.containsKey(b['id'])))
      Padding(padding:const EdgeInsets.only(bottom:9),child:UnifiedPanel(child:
        UnifiedUI.action(name(x),downloaded.containsKey(x['id'])?'منزّل على الهاتف':'في المفضلة',
          Icons.bookmark_outline,()=>_reader(x)))),
  ]);
  Widget _reviews(){final questions=catalog!.reviews.where(LibraryCatalog.visible).toList();
    if(questions.isEmpty)return UnifiedUI.empty('لا توجد أسئلة مراجعة منشورة');
    final q=questions[page%questions.length],items=(q['choices'] as List).cast<String>();
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      UnifiedUI.headline('المراجعات والتمارين','أسئلة حقيقية من بنك أسئلة المناهج'),
      UnifiedPanel(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Text('سؤال ${page%questions.length+1} من ${questions.length}',
          style:const TextStyle(color:Color(0xff36799a))),
        const SizedBox(height:12),Text(q['text'].toString(),
          style:const TextStyle(fontSize:17,fontWeight:FontWeight.w800)),
        RadioGroup<int>(
          groupValue: answer,
          onChanged: (v) => setState(() => answer = v),
          child: Column(children: [
            for (var i = 0; i < items.length; i++)
              RadioListTile<int>(title: Text(items[i]), value: i),
          ])),
        if(answer!=null)Text(answer==q['answer']?'الإجابة صحيحة':'الإجابة غير صحيحة، جرّب مرة أخرى',
          style:const TextStyle(fontWeight:FontWeight.w900)),
        UnifiedUI.control('السؤال التالي',()=>setState((){page++;answer=null;}),icon:Icons.arrow_back),
      ])),
    ]);
  }
  Widget _tools()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('أدوات المناهج','واجهة واحدة للكتب والمراجعات والمحفوظات'),
    _grid([('الكتب',Icons.menu_book_outlined,()=>widget.onTab('books')),
      ('التنزيلات',Icons.download_outlined,()=>widget.onTab('saved')),
      ('المراجعات',Icons.quiz_outlined,()=>widget.onTab('reviews')),
      ('تحديث المناهج',Icons.sync_outlined,_refresh)]),
    UnifiedUI.headline('خصوصية وصلاحيات'),
    UnifiedUI.colored('الإدارة محمية',Icons.shield_outlined,const Color(0xff36799a),[
      const Text('يبقى نشر المناهج وتحرير الفهرس مقتصرًا على حساب المدير المحمي في مدرستي. لا تُمنح صلاحية النشر للمستخدم العادي.')]),
  ]);
  Widget _detail()=>UnifiedUI.empty('تفاصيل المكتبة');
  Widget _grid(List<(String,IconData,VoidCallback)> items)=>
    LayoutBuilder(builder:(context,c)=>Wrap(spacing:11,runSpacing:11,children:[
      for(final item in items)SizedBox(width:(c.maxWidth-11)/2,
        child:UnifiedQuick(title:item.$1,icon:item.$2,onTap:item.$3)),
    ]));
}

class UnifiedBookReader extends StatefulWidget {
  const UnifiedBookReader({super.key,required this.bookId,required this.name,
    required this.url,this.local});
  final String bookId,name,url;
  final String? local;
  @override State<UnifiedBookReader> createState()=>_UnifiedBookReaderState();
}
class _UnifiedBookReaderState extends State<UnifiedBookReader> {
  final controller=PdfViewerController();
  int page=1,total=0;
  bool night=false;
  @override Widget build(BuildContext context)=>Scaffold(
    backgroundColor:night?Colors.black:UnifiedStyle.background,
    appBar:AppBar(title:Text(widget.name,maxLines:1,overflow:TextOverflow.ellipsis),
      backgroundColor:night?const Color(0xff182331):null,
      actions:[IconButton(tooltip:'الوضع الليلي',onPressed:()=>setState(()=>night=!night),
        icon:Icon(night?Icons.light_mode_outlined:Icons.dark_mode_outlined))]),
    body:Column(children:[
      Expanded(child:Builder(builder:(context){
        final params=PdfViewerParams(
          backgroundColor:night?Colors.black:const Color(0xffe9eef5),
          onPageChanged:(p){if(p!=null&&mounted)setState(()=>page=p);},
          onViewerReady:(doc,ctrl){if(mounted)setState(()=>total=doc.pages.length);},
        );
        return widget.local!=null?PdfViewer.file(widget.local!,controller:controller,params:params):
          PdfViewer.uri(DownloadedBooks.directPdfUri(widget.url),controller:controller,
            params:params,timeout:const Duration(seconds:30));
      })),
      SafeArea(top:false,child:Padding(padding:const EdgeInsets.all(9),child:
        Row(mainAxisAlignment:MainAxisAlignment.center,children:[
          IconButton(onPressed:page>1?()=>controller.goToPage(pageNumber:page-1):null,
            icon:const Icon(Icons.chevron_right)),
          Text('صفحة $page من $total',style:TextStyle(color:night?Colors.white:UnifiedStyle.foreground)),
          IconButton(onPressed:page<total?()=>controller.goToPage(pageNumber:page+1):null,
            icon:const Icon(Icons.chevron_left)),
        ]))),
    ]));
}

class ScannerWorkspace extends StatefulWidget {
  const ScannerWorkspace({super.key,required this.tab,required this.onTab});
  final String tab;
  final ValueChanged<String> onTab;
  @override State<ScannerWorkspace> createState()=>_ScannerWorkspaceState();
}
class _ScannerWorkspaceState extends State<ScannerWorkspace> {
  final List<String?> photos=List<String?>.filled(8,null);
  final List<String?> originals=List<String?>.filled(8,null);
  final List<String> archive=[];
  final picker=ImagePicker();
  bool landscape=false,fillPage=false,rounded=true,busy=false;
  double scale=1;
  String detail='';
  int selected=0;
  List<Offset> corners=[const Offset(.04,.04),const Offset(.96,.04),
    const Offset(.96,.96),const Offset(.04,.96)];
  @override void initState(){super.initState();_load();}
  Future<void> _load()async{
    final prefs=await SharedPreferences.getInstance();
    final saved=prefs.getStringList('madrasati.scanner.unified.slots.v1')??[];
    for(var i=0;i<8&&i<saved.length;i++){
      final path=saved[i];if(path.isNotEmpty&&await File(path).exists()) photos[i]=path;
    }
    final raw=prefs.getStringList('madrasati.scanner.unified.originals.v1')??[];
    for(var i=0;i<8&&i<raw.length;i++){
      if(raw[i].isNotEmpty&&await File(raw[i]).exists())originals[i]=raw[i];
    }
    archive.addAll((prefs.getStringList('madrasati.scanner.unified.archive.v1')??[])
      .where((s)=>File(s).existsSync()));
    if(mounted)setState((){});
  }
  Future<void> _save()async{
    final prefs=await SharedPreferences.getInstance();
    await prefs.setStringList('madrasati.scanner.unified.slots.v1',
      photos.map((x)=>x??'').toList());
    await prefs.setStringList('madrasati.scanner.unified.originals.v1',
      originals.map((x)=>x??'').toList());
    await prefs.setStringList('madrasati.scanner.unified.archive.v1',archive);
  }
  Future<Directory> _dir()async{
    final base=await getApplicationDocumentsDirectory();
    final dir=Directory('${base.path}/madrasati_scans');
    await dir.create(recursive:true);
    return dir;
  }
  Future<void> _choose(int index)async{
    final source=await showDialog<ImageSource>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('إضافة صورة المستمسك'),
      content:const Text('اختر كاميرا الهاتف أو صورة من المعرض.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,ImageSource.camera),child:const Text('الكاميرا')),
        FilledButton(onPressed:()=>Navigator.pop(ctx,ImageSource.gallery),child:const Text('المعرض'))]));
    if(source==null||!mounted)return;
    try{
      final taken=await picker.pickImage(source:source,imageQuality:94,maxWidth:2600);
      if(taken==null||!mounted)return;
      setState(()=>busy=true);
      final bytes=await scan_perspective.normalizeImage(await taken.readAsBytes());
      final dir=await _dir();
      final id=DateTime.now().microsecondsSinceEpoch;
      final path='${dir.path}/card_${index}_$id.jpg';
      await File(path).writeAsBytes(bytes,flush:true);
      photos[index]=path;originals[index]=path;
      await _save();
      if(mounted)setState(()=>busy=false);
    }catch(e){if(mounted){setState(()=>busy=false);UnifiedUI.notice(context,'تعذّر اختيار الصورة: $e');}}
  }
  Future<void> _applyFilter(scan_layouts.ScanAppearance filter)async{
    final original=originals[selected]??photos[selected];
    if(original==null)return;
    setState(()=>busy=true);
    try{
      final raw=await File(original).readAsBytes();
      final bytes=await scan_filters.scanImageAsync(raw,filter);
      final dir=await _dir();
      final dest='${dir.path}/filtered_${selected}_${DateTime.now().microsecondsSinceEpoch}.jpg';
      await File(dest).writeAsBytes(bytes,flush:true);
      photos[selected]=dest;await _save();
      if(mounted){setState(()=>busy=false);UnifiedUI.notice(context,'طُبّق الفلتر مع إبقاء الأصل');}
    }catch(e){if(mounted){setState(()=>busy=false);UnifiedUI.notice(context,'فشل الفلتر: $e');}}
  }
  Future<void> _applyCrop()async{
    final source=originals[selected]??photos[selected];if(source==null)return;
    setState(()=>busy=true);
    try{
      final bytes=await scan_perspective.rectifyImage(scan_perspective.PerspectiveArgs(
        await File(source).readAsBytes(),corners,0,0,roundCard:rounded));
      final dir=await _dir();
      final dest='${dir.path}/cropped_${selected}_${DateTime.now().microsecondsSinceEpoch}.jpg';
      await File(dest).writeAsBytes(bytes,flush:true);
      photos[selected]=dest;await _save();
      if(mounted){setState((){busy=false;detail='';});UnifiedUI.notice(context,'تم القص مع الحفاظ على الصورة الأصلية');}
    }catch(e){if(mounted){setState(()=>busy=false);UnifiedUI.notice(context,'تعذر القص: $e');}}
  }
  Future<void> _archive()async{
    final current=photos.whereType<String>().toList();
    if(current.isEmpty)return UnifiedUI.notice(context,'أضف صورة واحدة على الأقل');
    final folder=Directory('${(await _dir()).path}/archive_${DateTime.now().microsecondsSinceEpoch}');
    await folder.create(recursive:true);
    for(var i=0;i<current.length;i++){
      final copy=await File(current[i]).copy('${folder.path}/doc_${i+1}.jpg');
      archive.add(copy.path);
    }
    await _save();if(mounted){setState((){});UnifiedUI.notice(context,'حفظت النسخ في أرشيف المستمسكات');}
  }
  Future<void> _print()async{
    final paths=photos.whereType<String>().toList();
    if(paths.isEmpty)return UnifiedUI.notice(context,'لا توجد صور للطباعة');
    setState(()=>busy=true);
    try{
      final images=<pw.MemoryImage>[];
      for(final path in paths)images.add(pw.MemoryImage(await File(path).readAsBytes()));
      final pdf=pw.Document();
      final pageFormat=landscape?PdfPageFormat.a4.landscape:PdfPageFormat.a4;
      for(var p=0;p<images.length;p+=8){
        final chunk=images.skip(p).take(8).toList();
        pdf.addPage(pw.Page(pageFormat:pageFormat,margin:pw.EdgeInsets.all(fillPage?0:22),
          build:(ctx)=>pw.Column(children:[
            for(var row=0;row<4;row++)pw.Expanded(child:pw.Row(children:[
              for(var col=0;col<2;col++)pw.Expanded(child:pw.Padding(
                padding:pw.EdgeInsets.all(fillPage?0:5),
                child:row*2+(1-col)<chunk.length
                  ?pw.Container(alignment:pw.Alignment.center,
                    child:pw.Transform.scale(scale:scale,child:pw.ClipRRect(
                      horizontalRadius:rounded?12:0,verticalRadius:rounded?12:0,
                      child:pw.Image(chunk[row*2+(1-col)],fit:fillPage?pw.BoxFit.fill:pw.BoxFit.contain))))
                  :pw.SizedBox())),
            ])),
          ])));
      }
      await Printing.layoutPdf(name:'mustamsakati-A4.pdf',onLayout:(_)=>pdf.save());
    }catch(e){if(mounted)UnifiedUI.notice(context,'تعذّرت الطباعة: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context){
    if(detail=='crop')return _cropUI();
    if(detail=='filters')return _filterUI();
    return switch(widget.tab){
      'docs'=>_docs(),'card'=>_card(),'print'=>_printing(),
      'tools'=>_tools(),_=>_home(),
    };
  }
  Widget _home()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('ابدأ بمستند جديد','رفع الصور والتصوير داخل مستمسكاتي الجديد'),
    _grid([('تصوير مستند',Icons.add_a_photo_outlined,()=>_choose(0)),
      ('بطاقة في دقيقة',Icons.badge_outlined,()=>widget.onTab('card')),
      ('المستندات',Icons.folder_outlined,()=>widget.onTab('docs')),
      ('الطباعة',Icons.print_outlined,()=>widget.onTab('print'))]),
    UnifiedUI.headline('حالة البطاقات'),
    UnifiedPanel(child:Column(children:[
      Text('${photos.whereType<String>().length} صور جاهزة للطباعة'),
      const SizedBox(height:10),_slotGrid(),
    ])),
  ]);
  Widget _slotGrid()=>LayoutBuilder(builder:(context,c)=>Wrap(spacing:10,runSpacing:10,
    children:[for(var i=0;i<8;i++)SizedBox(width:(c.maxWidth-10)/2,
      child:InkWell(onTap:()=>_choose(i),borderRadius:BorderRadius.circular(20),
        child:Container(height:120,clipBehavior:Clip.antiAlias,
          decoration:BoxDecoration(color:UnifiedStyle.surface(context),
            borderRadius:BorderRadius.circular(19),
            border:Border.all(color:UnifiedStyle.line(context))),
          child:photos[i]==null?Column(mainAxisAlignment:MainAxisAlignment.center,children:[
            const Icon(Icons.add_photo_alternate_outlined,size:30),
            const SizedBox(height:8),Text(i.isEven?'الأمامي ${i~/2+1}':'الخلفي ${i~/2+1}',
              style:const TextStyle(fontSize:12,fontWeight:FontWeight.w800)),
          ]):Stack(fit:StackFit.expand,children:[
            Image.file(File(photos[i]!),fit:BoxFit.cover),
            PositionedDirectional(end:5,bottom:5,child:Container(padding:const EdgeInsets.all(5),
              decoration:BoxDecoration(color:const Color(0xd9203040),borderRadius:BorderRadius.circular(9)),
              child:Text(i.isEven?'الأمامي ${i~/2+1}':'الخلفي ${i~/2+1}',
                style:const TextStyle(fontSize:10,color:Colors.white)))),
          ])),
        )),
    ]));
  Widget _card()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('بطاقة في دقيقة','٤ أماميات + ٤ خلفيات؛ اضغط لإضافة الصور'),
    _slotGrid(),
    const SizedBox(height:12),
    UnifiedUI.control('حفظ مجموعة المستمسكات',_archive,icon:Icons.save_outlined),
    UnifiedUI.control('الانتقال إلى الطباعة',()=>widget.onTab('print'),icon:Icons.print_outlined),
  ]);
  Widget _docs()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('مستنداتي','أرشيف الصور المحفوظة محليًا على الهاتف'),
    if(archive.isEmpty)UnifiedUI.empty('الأرشيف فارغ — احفظ مجموعة من البطاقة'),
    for(final path in archive)Padding(padding:const EdgeInsets.only(bottom:10),
      child:UnifiedPanel(child:Row(children:[
        ClipRRect(borderRadius:BorderRadius.circular(12),child:
          Image.file(File(path),width:76,height:76,fit:BoxFit.cover)),
        const SizedBox(width:12),Expanded(child:Text(path.split('/').last)),
        IconButton(onPressed:()async{if(await UnifiedUI.confirm(context,'حذف المستند','هل تريد حذف هذه النسخة؟')){
          setState(()=>archive.remove(path));await _save();
        }},icon:const Icon(Icons.delete_outline)),
      ]))),
  ]);
  Widget _printing()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('الطباعة والتصدير','A4 فقط بألوان وحواف دائرية وتحكم بالحجم'),
    UnifiedPanel(child:Column(children:[
      SwitchListTile.adaptive(title:const Text('ورقة أفقية'),value:landscape,
        onChanged:(v)=>setState(()=>landscape=v)),
      SwitchListTile.adaptive(title:const Text('الصورة تملأ الورقة'),value:fillPage,
        onChanged:(v)=>setState(()=>fillPage=v)),
      SwitchListTile.adaptive(title:const Text('حواف دائرية للبطاقات'),value:rounded,
        onChanged:(v)=>setState(()=>rounded=v)),
      Text('حجم الصورة: ${(scale*100).round()}%'),
      Slider(value:scale,min:.65,max:1.2,onChanged:(v)=>setState(()=>scale=v)),
    ])),
    const SizedBox(height:12),_slotGrid(),
    if(busy)const LinearProgressIndicator(),
    UnifiedUI.control('تصدير وطباعة PDF A4',_print,icon:Icons.print_outlined),
  ]);
  Widget _tools()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    UnifiedUI.headline('تحسين الصور','قص بأربع زوايا وفلاتر حقيقية بنفس محرك مستمسكاتي'),
    _slotGrid(),
    const SizedBox(height:12),
    _grid([('قص الصورة',Icons.crop_rotate_outlined,()=>_goTool('crop')),
      ('تحسين الألوان',Icons.tune_outlined,()=>_goTool('filters')),
      ('بطاقة في دقيقة',Icons.badge_outlined,()=>widget.onTab('card')),
      ('التصدير',Icons.print_outlined,()=>widget.onTab('print'))]),
  ]);
  void _goTool(String name){if(photos[selected]==null){
      final next=photos.indexWhere((x)=>x!=null);
      if(next<0)return UnifiedUI.notice(context,'أضف صورة أولاً');
      selected=next;
    }setState(()=>detail=name);}
  Widget _slotChoose()=>SizedBox(height:45,child:ListView(scrollDirection:Axis.horizontal,
    children:[for(var i=0;i<8;i++)if(photos[i]!=null)Padding(
      padding:const EdgeInsetsDirectional.only(start:5),child:
        UnifiedUI.chip('صورة ${i+1}',selected==i,()=>setState(()=>selected=i)))]));
  Widget _filterUI()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    TextButton.icon(onPressed:()=>setState(()=>detail=''),icon:const Icon(Icons.arrow_forward),
      label:const Text('العودة إلى الأدوات')),
    UnifiedUI.headline('تحسين الصورة','اختر الصورة والفلتر مع الحفاظ على أصلها'),
    _slotChoose(),const SizedBox(height:10),
    if(photos[selected]!=null)ClipRRect(borderRadius:BorderRadius.circular(21),
      child:Image.file(File(photos[selected]!),height:230,fit:BoxFit.contain)),
    const SizedBox(height:12),
    if(busy)const LinearProgressIndicator(),
    for(final app in scan_layouts.ScanAppearance.values)
      Padding(padding:const EdgeInsets.only(bottom:8),
        child:UnifiedPanel(child:UnifiedUI.action(app.name, 'فلتر الصورة ${app.name}',
          Icons.auto_awesome_outlined,()=>_applyFilter(app)))),
  ]);
  Widget _cropUI()=>Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    TextButton.icon(onPressed:()=>setState(()=>detail=''),icon:const Icon(Icons.arrow_forward),
      label:const Text('العودة إلى الأدوات')),
    UnifiedUI.headline('قص الصورة بأربع زوايا','اسحب النقاط الأربع لتحديد حدود المستند'),
    _slotChoose(),const SizedBox(height:12),
    if(photos[selected]!=null)LayoutBuilder(builder:(context,c){
      final width=c.maxWidth,height=width*.78;
      return SizedBox(height:height,child:Stack(children:[
        Positioned.fill(child:Image.file(File(originals[selected]??photos[selected]!),fit:BoxFit.fill)),
        Positioned.fill(child:CustomPaint(painter:_CropOutline(corners))),
        for(var i=0;i<4;i++)Positioned(left:corners[i].dx*width-17,
          top:corners[i].dy*height-17,child:GestureDetector(
            onPanUpdate:(e){setState((){
              final next=List<Offset>.of(corners);
              next[i]=Offset((next[i].dx+e.delta.dx/width).clamp(0.0,1.0).toDouble(),
                (next[i].dy+e.delta.dy/height).clamp(0.0,1.0).toDouble());
              if(scan_perspective.isValidQuadrilateral(next))corners=next;
            });},
            child:Container(width:34,height:34,decoration:BoxDecoration(
              color:Colors.white,shape:BoxShape.circle,border:Border.all(color:UnifiedStyle.turquoise,width:3))),
          )),
      ]));
    }),
    const SizedBox(height:12),
    if(busy)const LinearProgressIndicator(),
    UnifiedUI.control('تطبيق القص الدقيق',_applyCrop,icon:Icons.crop_rotate_outlined),
  ]);
  Widget _grid(List<(String,IconData,VoidCallback)> items)=>
    LayoutBuilder(builder:(context,c)=>Wrap(spacing:11,runSpacing:11,children:[
      for(final item in items)SizedBox(width:(c.maxWidth-11)/2,
        child:UnifiedQuick(title:item.$1,icon:item.$2,onTap:item.$3)),
    ]));
}
class _CropOutline extends CustomPainter {
  const _CropOutline(this.points);
  final List<Offset> points;
  @override void paint(Canvas canvas,Size size){
    final path=Path()..moveTo(points[0].dx*size.width,points[0].dy*size.height);
    for (var i = 1; i < points.length; i++) {
      path.lineTo(points[i].dx * size.width, points[i].dy * size.height);
    }
    path.close();
    canvas.drawPath(path,Paint()..color=const Color(0xff29d4b8)..style=PaintingStyle.stroke..strokeWidth=2);
  }
  @override bool shouldRepaint(_CropOutline old)=>true;
}
