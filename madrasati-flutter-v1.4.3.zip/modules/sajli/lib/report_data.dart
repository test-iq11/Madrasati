import 'records.dart';
import 'report_model.dart';

enum ReportKind {
  annual('كشف الدرجات السنوي'),
  monthly('كشف الدرجات لفترة'),
  attendance('كشف الحضور الشهري'),
  student('كشف درجات تلميذ'),
  parent('بطاقة متابعة ولي الأمر');

  const ReportKind(this.label);
  final String label;
}

enum ParentField {
  grades('الدرجات'),
  trend('تطور المستوى'),
  attendance('ملخص الحضور'),
  note('ملاحظة المعلم');

  const ParentField(this.label);
  final String label;
}

SchoolReport prepareReport({
  required Records records,
  required ReportKind kind,
  required String classId,
  required String subject,
  required String period,
  required DateTime month,
  required String studentId,
  required bool landscape,
  required Set<ParentField> fields,
  required String note,
}) {
  final students = records.students(classId);
  final student = students
      .where((s) => s['id'].toString() == studentId)
      .firstOrNull;
  final subjects = records.subjects(classId);
  final sections = <ReportSection>[];
  var details = records.className(classId);
  var printableNote = '';
  final monthKey = dayKey(month).substring(0, 7);
  String number(num? value) => value == null ? '—' : numText(value);
  String id(Json person) => person['id'].toString();
  String name(Json person) => person['name'].toString();
  String attendanceMonth() => '${monthNames[month.month - 1]} ${month.year}';

  switch (kind) {
    case ReportKind.annual:
      details =
          '$details  ·  $subject  ·  ${records.year}  ·  من ${numText(records.maximum(subject))}';
      final first = records.periods
          .where((p) => p['section'] == groups[0])
          .toList();
      final second = records.periods
          .where((p) => p['section'] == groups[2])
          .toList();
      String short(Json p) => (p['short'] ?? p['key']).toString();
      sections.add(
        ReportSection(
          '',
          [
            'اسم التلميذ',
            ...first.map(short),
            'معدل الأول',
            'نصف السنة',
            ...second.map(short),
            'معدل الثاني',
            'السعي',
            'الامتحان النهائي',
            'الدرجة النهائية',
          ],
          students.map((s) {
            final a = records.annual(id(s), subject);
            return [
              name(s),
              ...first.map(
                (p) => records.gradeText(id(s), subject, p['key'].toString()),
              ),
              number(a.first),
              number(a.mid),
              ...second.map(
                (p) => records.gradeText(id(s), subject, p['key'].toString()),
              ),
              number(a.second),
              number(a.effort),
              number(a.exam),
              number(a.finalGrade),
            ];
          }).toList(),
        ),
      );
    case ReportKind.monthly:
      details = '$details  ·  $subject  ·  $period';
      sections.add(
        ReportSection(
          '',
          ['اسم التلميذ', 'الدرجة', 'من'],
          students
              .map(
                (s) => [
                  name(s),
                  records.gradeText(id(s), subject, period),
                  numText(records.maximum(subject)),
                ],
              )
              .toList(),
        ),
      );
    case ReportKind.attendance:
      details = '$details  ·  ${attendanceMonth()}';
      sections.add(
        ReportSection(
          '',
          ['اسم التلميذ', ...attendanceLabels.values],
          students.map((s) {
            final a = records.attendanceSummary(id(s), monthKey);
            return [
              name(s),
              ...attendanceLabels.keys.map((k) => a[k].toString()),
            ];
          }).toList(),
        ),
      );
    case ReportKind.student:
    case ReportKind.parent:
      if (student == null)
        throw const FormatException('اختر تلميذاً لإعداد البطاقة');
      details = '${name(student)}  ·  $details  ·  $period  ·  ${records.year}';
      if (kind == ReportKind.student || fields.contains(ParentField.grades)) {
        sections.add(
          ReportSection(
            kind == ReportKind.parent ? 'التحصيل الدراسي · الدرجات' : 'الدرجات',
            ['المادة', 'الدرجة', 'من'],
            subjects
                .map(
                  (s) => [
                    s,
                    records.gradeText(studentId, s, period),
                    numText(records.maximum(s)),
                  ],
                )
                .toList(),
          ),
        );
      }
      if (kind == ReportKind.parent && fields.contains(ParentField.trend)) {
        final entries = records.trend(studentId, classId);
        sections.add(
          ReportSection(
            'تطور المستوى',
            ['الفترة', 'متوسط الدرجات المدخلة', 'عدد المواد'],
            entries
                .map(
                  (e) => [
                    e.period,
                    e.percent == null ? '—' : '${numText(e.percent!)}%',
                    e.count.toString(),
                  ],
                )
                .toList(),
          ),
        );
      }
      if (kind == ReportKind.parent &&
          fields.contains(ParentField.attendance)) {
        final a = records.attendanceSummary(studentId, monthKey);
        sections.add(
          ReportSection(
            'المواظبة · الحضور · ${attendanceMonth()}',
            attendanceLabels.values.toList(),
            [attendanceLabels.keys.map((k) => a[k].toString()).toList()],
          ),
        );
      }
      if (kind == ReportKind.parent && fields.contains(ParentField.note))
        printableNote = note.trim();
  }
  return SchoolReport(
    title: kind.label,
    school: records.school,
    details: details,
    sections: sections,
    landscape: landscape,
    note: printableNote,
    teacher: records.teacher.trim(),
    director: records.director.trim(),
  );
}
