import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/painting.dart';

import 'report_model.dart';
export 'report_model.dart';

const reportInk = Color(0xff173e47);
const reportTeal = Color(0xff246d65);
const reportSand = Color(0xffa97135);
const reportPale = Color(0xffedf5f2);
const reportSlate = Color(0xff517073);
const reportWhite = Color(0xffffffff);
const reportBlue = Color(0xff3d679a);
const reportBluePale = Color(0xffedf3fb);
const reportPurple = Color(0xff78609e);
const reportPurplePale = Color(0xfff2edfa);
const reportGreen = Color(0xff287e73);
const reportGreenPale = Color(0xffeaf6f2);
const reportAmber = Color(0xff9e713c);
const reportAmberPale = Color(0xfffff5e8);

(Color, Color) _sectionColors(String title) {
  if (title.contains('التحصيل') || title == 'الدرجات') {
    return (reportBlue, reportBluePale);
  }
  if (title.contains('تطور')) return (reportPurple, reportPurplePale);
  if (title.contains('الحضور') || title.contains('المواظبة')) {
    return (reportGreen, reportGreenPale);
  }
  return (reportTeal, reportPale);
}


class RenderedReport {
  const RenderedReport(this.images, this.pdf);
  final List<Uint8List> images;
  final Uint8List pdf;
}

class _Line {
  const _Line(
    this.values,
    this.height,
    this.fill,
    this.color,
    this.size, {
    this.bold = false,
    this.single = false,
  });
  final List<String> values;
  final double height, size;
  final Color fill, color;
  final bool bold, single;
}

List<List<_Line>> _paginate(SchoolReport report) {
  final pages = <List<_Line>>[[]];
  final limit = report.height - (report.hasSignatures ? 205 : 162);
  var used = 0.0;
  void next() {
    pages.add([]);
    used = 0;
  }

  void add(_Line row) {
    pages.last.add(row);
    used += row.height;
  }

  for (final section in report.sections) {
    final (sectionInk, sectionPale) = _sectionColors(section.title);
    final heading = _Line(
      section.headings,
      41,
      sectionInk,
      reportWhite,
      13,
      bold: true,
    );
    if (used + 107 > limit) next();
    if (section.title.isNotEmpty) {
      add(
        _Line(
          [section.title],
          34,
          sectionPale,
          sectionInk,
          15,
          bold: true,
          single: true,
        ),
      );
    }
    add(heading);
    for (var i = 0; i < section.rows.length; i++) {
      final row = section.rows[i];
      if (used + 32 > limit) {
        next();
        add(heading);
      }
      add(_Line(row, 32, i.isEven ? reportWhite : sectionPale, reportInk, 13));
    }
    add(const _Line([''], 5, reportWhite, reportInk, 12, single: true));
  }
  if (report.note.trim().isNotEmpty) {
    if (used + 106 > limit) next();
    add(
      const _Line(
        ['ملاحظة المعلم'],
        34,
        reportAmberPale,
        reportAmber,
        15,
        bold: true,
        single: true,
      ),
    );
    add(_Line([report.note], 73, reportWhite, reportInk, 14, single: true));
  }
  return pages;
}

void _text(
  Canvas canvas,
  String value,
  Rect rect,
  double size,
  Color color, {
  bool bold = false,
  bool right = false,
  int maxLines = 2,
}) {
  final painter = TextPainter(
    text: TextSpan(
      text: value,
      style: TextStyle(
        color: color,
        fontSize: size,
        fontWeight: bold ? FontWeight.w700 : FontWeight.w400,
      ),
    ),
    textDirection: TextDirection.rtl,
    textAlign: right ? TextAlign.right : TextAlign.center,
    maxLines: maxLines,
    ellipsis: '…',
  );
  painter.layout(minWidth: rect.width, maxWidth: rect.width);
  painter.paint(
    canvas,
    Offset(rect.left, rect.top + (rect.height - painter.height) / 2),
  );
  painter.dispose();
}

Future<RenderedReport> renderReport(SchoolReport report) async {
  final plan = _paginate(report);
  final previews = <Uint8List>[];
  final rasters = <({Uint8List bytes, int width, int height})>[];
  for (var index = 0; index < plan.length; index++) {
    const scale = 1.5;
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder)..scale(scale);
    final paint = Paint()..color = reportWhite;
    canvas.drawRect(Rect.fromLTWH(0, 0, report.width, report.height), paint);
    canvas.drawRect(
      Rect.fromLTWH(27, 23, report.width - 54, 6),
      paint..color = reportTeal,
    );
    _text(
      canvas,
      report.school,
      Rect.fromLTWH(31, 35, report.width - 62, 23),
      17,
      reportTeal,
      bold: true,
    );
    _text(
      canvas,
      report.title,
      Rect.fromLTWH(31, 60, report.width - 62, 31),
      23,
      reportInk,
      bold: true,
    );
    if (report.title == 'بطاقة متابعة ولي الأمر') {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(27, 94, report.width - 54, 34),
          const Radius.circular(8),
        ),
        Paint()..color = reportBluePale,
      );
    }
    _text(
      canvas,
      report.details,
      Rect.fromLTWH(35, 94, report.width - 70, 31),
      13,
      report.title == 'بطاقة متابعة ولي الأمر' ? reportBlue : reportSlate,
    );
    var y = 131.0;
    final contentWidth = report.width - 54;
    for (final row in plan[index]) {
      final count = row.values.length;
      if (count == 0) continue;
      final unit = contentWidth / (count + (row.single ? 0 : 1.15));
      var right = report.width - 27;
      for (var col = 0; col < count; col++) {
        final width = row.single ? contentWidth : unit * (col == 0 ? 2.15 : 1);
        final rect = Rect.fromLTWH(right - width, y, width, row.height);
        canvas.drawRect(rect, paint..color = row.fill);
        canvas.drawRect(
          rect,
          Paint()
            ..color = const Color(0x28517073)
            ..style = PaintingStyle.stroke
            ..strokeWidth = .5,
        );
        _text(
          canvas,
          row.values[col],
          rect.deflate(4),
          row.size,
          row.color,
          bold: row.bold,
          right: row.single || (!row.bold && col == 0),
          maxLines: row.single && row.height > 40 ? 4 : 2,
        );
        right -= width;
      }
      y += row.height;
    }
    if (report.hasSignatures) {
      final signatureWidth = (contentWidth - 16) / 2;
      final y = report.height - 65;
      if (report.teacher.isNotEmpty) {
        _text(
          canvas,
          'اسم المعلم: ${report.teacher}',
          Rect.fromLTWH(
            report.width - 27 - signatureWidth,
            y,
            signatureWidth,
            30,
          ),
          14,
          reportInk,
          bold: true,
        );
      }
      if (report.director.isNotEmpty) {
        _text(
          canvas,
          'مدير المدرسة: ${report.director}',
          Rect.fromLTWH(27, y, signatureWidth, 30),
          14,
          reportInk,
          bold: true,
        );
      }
    }
    _text(
      canvas,
      'سجلّي  ·  A4  ·  ${index + 1} / ${plan.length}',
      Rect.fromLTWH(30, report.height - 26, report.width - 60, 19),
      11,
      reportSlate,
    );
    final picture = recorder.endRecording();
    final image = await picture.toImage(
      (report.width * scale).round(),
      (report.height * scale).round(),
    );
    picture.dispose();
    try {
      final png = await image.toByteData(format: ui.ImageByteFormat.png);
      final rgba = await image.toByteData(format: ui.ImageByteFormat.rawRgba);
      if (png == null || rgba == null)
        throw StateError('تعذر تجهيز صفحة التقرير');
      previews.add(
        png.buffer.asUint8List(png.offsetInBytes, png.lengthInBytes),
      );
      final rgb = Uint8List(image.width * image.height * 3);
      final pixels = rgba.buffer.asUint8List(
        rgba.offsetInBytes,
        rgba.lengthInBytes,
      );
      for (var i = 0, j = 0; i < pixels.length; i += 4, j += 3) {
        rgb[j] = pixels[i];
        rgb[j + 1] = pixels[i + 1];
        rgb[j + 2] = pixels[i + 2];
      }
      rasters.add((
        bytes: Uint8List.fromList(zlib.encode(rgb)),
        width: image.width,
        height: image.height,
      ));
    } finally {
      image.dispose();
    }
  }
  return RenderedReport(previews, _pdf(rasters, report.landscape));
}

Uint8List _pdf(
  List<({Uint8List bytes, int width, int height})> pages,
  bool landscape,
) {
  final out = BytesBuilder();
  final offsets = <int>[0];
  void text(String value) => out.add(ascii.encode(value));
  void start() {
    offsets.add(out.length);
    text('${offsets.length - 1} 0 obj\n');
  }

  void end() => text('\nendobj\n');
  text('%PDF-1.4\n');
  start();
  text('<< /Type /Catalog /Pages 2 0 R >>');
  end();
  final refs = List.generate(pages.length, (i) => '${3 + i * 3} 0 R').join(' ');
  start();
  text('<< /Type /Pages /Count ${pages.length} /Kids [$refs] >>');
  end();
  final w = landscape ? '841.89' : '595.28';
  final h = landscape ? '595.28' : '841.89';
  for (var i = 0; i < pages.length; i++) {
    final page = pages[i];
    final n = 3 + i * 3;
    start();
    text(
      '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $w $h] '
      '/Resources << /XObject << /Im ${n + 1} 0 R >> >> /Contents ${n + 2} 0 R >>',
    );
    end();
    start();
    text(
      '<< /Type /XObject /Subtype /Image /Width ${page.width} /Height ${page.height} '
      '/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${page.bytes.length} >>\nstream\n',
    );
    out.add(page.bytes);
    text('\nendstream');
    end();
    final commands = 'q $w 0 0 $h 0 0 cm /Im Do Q';
    start();
    text('<< /Length ${commands.length} >>\nstream\n$commands\nendstream');
    end();
  }
  final xref = out.length;
  text('xref\n0 ${offsets.length}\n0000000000 65535 f \n');
  for (final offset in offsets.skip(1)) {
    text('${offset.toString().padLeft(10, '0')} 00000 n \n');
  }
  text(
    'trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n',
  );
  return out.takeBytes();
}
