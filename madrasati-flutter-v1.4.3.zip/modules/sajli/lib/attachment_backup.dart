import 'dart:convert';
import 'dart:io';

import 'records.dart';

Future<Map<String, dynamic>> portableRecords(Records source, Directory folder) async {
  final students = source.people;
  for (final student in students) {
    if (student['attachments'] is! List) continue;
    final docs = <Json>[];
    for (final value in student['attachments'] as List) {
      final doc = object(value);
      final name = _ownedFile(doc['path'], folder);
      if (name == null) throw const FormatException('مسار مستمسك غير صالح');
      docs.add({'title': doc['title'], 'image': base64Encode(await name.readAsBytes())});
    }
    student['attachments'] = docs;
  }
  return {...source.data, 'students': students};
}

File? _ownedFile(Object? path, Directory folder) {
  final prefix = '${folder.path}/';
  if (path is! String || !path.startsWith(prefix)) return null;
  final name = path.substring(prefix.length);
  if (!RegExp(r'^\d+(?:_\d+)?\.image$').hasMatch(name)) return null;
  return File(path);
}

Future<void> restoreAttachments(Records source, Directory folder) async {
  final students = source.people;
  final created = <File>[];
  final stamp = DateTime.now().microsecondsSinceEpoch;
  try {
    for (final student in students) {
      if (student['attachments'] is! List) continue;
      final docs = <Json>[];
      for (final value in student['attachments'] as List) {
        final doc = object(value);
        final image = doc['image'];
        File? file;
        if (image is String) {
          final bytes = base64Decode(image);
          await folder.create(recursive: true);
          file = File('${folder.path}/${stamp}_${created.length}.image');
          await file.create(exclusive: true);
          created.add(file);
          await file.writeAsBytes(bytes, flush: true);
        } else {
          file = _ownedFile(doc['path'], folder);
          if (file == null || !await file.exists()) throw const FormatException('مستمسك غير متاح');
        }
        docs.add({'title': doc['title'], 'path': file.path});
      }
      student['attachments'] = docs;
    }
    source.data['students'] = students;
  } catch (_) {
    for (final file in created) {
      if (await file.exists()) await file.delete();
    }
    rethrow;
  }
}
