import 'package:madrasati_cards/card_size.dart' show cardDimensions;
import 'package:material_ui/material_ui.dart';

// Sajli owns a material_ui navigator and its Arabic localization delegates.
class SajliCardSizeSettings extends StatelessWidget {
  const SajliCardSizeSettings(this.section, {super.key});
  final String section;
  @override
  Widget build(BuildContext context) {
    final model = cardDimensions(section);
    return ValueListenableBuilder<Size>(
      valueListenable: model,
      builder: (_, size, _) => Card(child: ExpansionTile(
        title: Text(section.startsWith('tile-') ? 'حجم بطاقة القسم في الرئيسية' : 'حجم البطاقة داخل القسم'),
        leading: const Icon(Icons.aspect_ratio),
        childrenPadding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          for (final width in [true, false]) ...[
            Text('${width ? 'العرض' : 'الارتفاع'} · ${((width ? size.width : size.height) * 100).round()}٪'),
            Slider(
              value: width ? size.width : size.height,
              min: width ? .7 : .8, max: width ? 1 : 1.4,
              divisions: width ? 6 : 12,
              onChanged: (v) => model.update(width ? Size(v, size.height) : Size(size.width, v)),
              onChangeEnd: (_) => model.save(),
            ),
          ],
        ],
      )),
    );
  }
}
