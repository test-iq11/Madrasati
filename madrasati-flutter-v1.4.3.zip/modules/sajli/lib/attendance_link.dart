typedef AttendanceLink = ({String grade, String section, DateTime date});

/// Class labels in Sajli are editable. A schedule shortcut must resolve to
/// exactly one class before its attendance register can be opened.
String? linkedClassId(Iterable<Map<String, dynamic>> classes, String grade, String section) {
  String normalize(String s) => s.replaceAll(RegExp(r'[\sـ·—–/()\-]+'), ' ')
      .split(' ').where((word) => word.isNotEmpty &&
          !const {'الصف', 'الشعبة', 'شعبة'}.contains(word)).join(' ');
  final g = normalize(grade);
  final part = normalize(section);
  if (g.isEmpty) return null;
  final expected = part.isEmpty ? g : '$g $part';
  final matches = classes.where((row) => normalize(row['name']?.toString() ?? '') == expected);
  return matches.length == 1 ? matches.single['id']?.toString() : null;
}
