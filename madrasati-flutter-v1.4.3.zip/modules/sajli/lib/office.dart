import 'dart:convert';
import 'dart:typed_data';

import 'records.dart' show arabicDigits;
import 'report_model.dart';

String _xml(String value) => value
    .replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]'), '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", "&apos;");

const _xmlHeader = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
const _relSpace =
    'http://schemas.openxmlformats.org/package/2006/relationships';
const _officeRel =
    'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
String _rootRel(String target) =>
    '$_xmlHeader<Relationships xmlns="$_relSpace">'
    '<Relationship Id="rId1" Type="$_officeRel/officeDocument" Target="$target"/></Relationships>';
String _types(String parts) =>
    '$_xmlHeader<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    '<Default Extension="xml" ContentType="application/xml"/>$parts</Types>';

int _sectionTone(String title) {
  if (title.contains('التحصيل') || title == 'الدرجات') return 1;
  if (title.contains('تطور')) return 2;
  if (title.contains('الحضور') || title.contains('المواظبة')) return 3;
  if (title.contains('ملاحظة')) return 4;
  return 0;
}

const _sectionInks = <String>[
  '173E47', '3D679A', '78609E', '287E73', '9E713C',
];

Uint8List wordReport(SchoolReport report) {
  const wordSpace =
      'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  String p(
    String text, {
    bool bold = false,
    String alignment = 'right',
    int size = 20,
    String color = '173E47',
  }) =>
      '<w:p><w:pPr><w:bidi/><w:jc w:val="$alignment"/></w:pPr><w:r><w:rPr>'
      '<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:rtl/>'
      '<w:color w:val="$color"/><w:sz w:val="$size"/><w:szCs w:val="$size"/>'
      '${bold ? '<w:b/><w:bCs/>' : ''}<w:lang w:bidi="ar-IQ"/></w:rPr>'
      '<w:t xml:space="preserve">${_xml(arabicDigits(text))}</w:t></w:r></w:p>';
  final body = StringBuffer()
    ..write(p(report.school, bold: true, alignment: 'center', size: 28))
    ..write(
      p(
        report.title,
        bold: true,
        alignment: 'center',
        size: 36,
        color: '246D65',
      ),
    )
    ..write(p(report.details, alignment: 'center'));
  for (final section in report.sections) {
    final sectionInk = _sectionInks[_sectionTone(section.title)];
    if (section.title.isNotEmpty)
      body.write(p(section.title, bold: true, size: 24, color: sectionInk));
    body.write(
      '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="5000" w:type="pct"/>'
      '<w:tblBorders><w:top w:val="single" w:sz="4" w:color="C2D6D2"/>'
      '<w:bottom w:val="single" w:sz="4" w:color="C2D6D2"/>'
      '<w:insideH w:val="single" w:sz="4" w:color="C2D6D2"/>'
      '<w:insideV w:val="single" w:sz="4" w:color="C2D6D2"/></w:tblBorders></w:tblPr>',
    );
    body.write('<w:tblGrid>');
    final width = report.landscape ? 15900 : 10900;
    final columns = section.headings.length;
    final unit = (width / (columns + 1)).round();
    for (var i = 0; i < columns; i++) {
      body.write('<w:gridCol w:w="${i == 0 ? unit * 2 : unit}"/>');
    }
    body.write('</w:tblGrid>');
    final rows = [section.headings, ...section.rows];
    for (var i = 0; i < rows.length; i++) {
      body.write(
        '<w:tr><w:trPr><w:cantSplit/>${i == 0 ? '<w:tblHeader/>' : ''}</w:trPr>',
      );
      for (final value in rows[i]) {
        body.write(
          '<w:tc><w:tcPr><w:shd w:fill="${i == 0
              ? sectionInk
              : i.isEven
              ? 'EDF5F2'
              : 'FFFFFF'}"/></w:tcPr>'
          '${p(value, bold: i == 0, alignment: 'center', size: columns > 10 ? 16 : 20, color: i == 0 ? 'FFFFFF' : '173E47')}</w:tc>',
        );
      }
      body.write('</w:tr>');
    }
    body.write('</w:tbl>');
  }
  if (report.note.isNotEmpty) {
    body
      ..write(p('ملاحظة المعلم', bold: true, color: '9E713C'))
      ..write(p(report.note));
  }
  body.write(
    '<w:sectPr>${report.hasSignatures ? '<w:footerReference w:type="default" r:id="rId1"/>' : ''}<w:pgSz w:w="${report.landscape ? 16838 : 11906}" '
    'w:h="${report.landscape ? 11906 : 16838}" w:orient="${report.landscape ? 'landscape' : 'portrait'}"/>'
    '<w:pgMar w:top="480" w:right="480" w:bottom="${report.hasSignatures ? 1050 : 480}" w:left="480" w:header="200" w:footer="310" w:gutter="0"/><w:bidi/></w:sectPr>',
  );
  return _zip({
    '[Content_Types].xml': _types(
      '<Override PartName="/word/document.xml" '
      'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
      '${report.hasSignatures ? '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>' : ''}',
    ),
    '_rels/.rels': _rootRel('word/document.xml'),
    'word/document.xml':
        '$_xmlHeader<w:document xmlns:w="$wordSpace" xmlns:r="$_officeRel">'
        '<w:body>$body</w:body></w:document>',
    if (report.hasSignatures) ...{
      'word/_rels/document.xml.rels':
          '$_xmlHeader<Relationships xmlns="$_relSpace">'
          '<Relationship Id="rId1" Type="$_officeRel/footer" Target="footer1.xml"/></Relationships>',
      'word/footer1.xml':
          '$_xmlHeader<w:ftr xmlns:w="$wordSpace">'
          '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="5000" w:type="pct"/></w:tblPr>'
          '<w:tblGrid><w:gridCol/><w:gridCol/></w:tblGrid><w:tr>'
          '<w:tc><w:tcPr><w:tcW w:w="2500" w:type="pct"/></w:tcPr>'
          '${p(report.teacher.isEmpty ? '' : 'اسم المعلم: ${report.teacher}', bold: true)}</w:tc>'
          '<w:tc><w:tcPr><w:tcW w:w="2500" w:type="pct"/></w:tcPr>'
          '${p(report.director.isEmpty ? '' : 'مدير المدرسة: ${report.director}', bold: true, alignment: 'left')}</w:tc>'
          '</w:tr></w:tbl></w:ftr>',
    },
  });
}

Uint8List excelReport(SchoolReport report) {
  final rows = <List<String>>[
    [report.school],
    [report.title],
    [report.details],
    [],
  ];
  final headers = <int>{};
  final headerStyle = <int, int>{};
  final titleStyle = <int, int>{};
  for (final s in report.sections) {
    final tone = _sectionTone(s.title);
    if (s.title.isNotEmpty) {
      titleStyle[rows.length] = 5 + (tone == 0 ? 1 : tone);
      rows.add([s.title]);
    }
    headers.add(rows.length);
    headerStyle[rows.length] = tone == 0 ? 1 : tone + 1;
    rows
      ..add(s.headings)
      ..addAll(s.rows)
      ..add([]);
  }
  if (report.note.isNotEmpty) {
    titleStyle[rows.length] = 9;
    rows
      ..add(['ملاحظة المعلم'])
      ..add([report.note]);
  }
  if (report.hasSignatures) {
    rows.add([
      if (report.teacher.isNotEmpty) 'اسم المعلم: ${report.teacher}',
      if (report.director.isNotEmpty) 'مدير المدرسة: ${report.director}',
    ]);
  }
  const xlSpace = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  final sheet = StringBuffer(
    '$_xmlHeader<worksheet xmlns="$xlSpace">'
    '<sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews>'
    '<cols><col min="1" max="1" width="36" customWidth="1"/>'
    '<col min="2" max="128" width="17" customWidth="1"/></cols><sheetData>',
  );
  for (var i = 0; i < rows.length; i++) {
    sheet.write('<row r="${i + 1}">');
    for (final text in rows[i]) {
      final header = headers.contains(i);
      final style = headerStyle[i] ?? titleStyle[i] ?? 0;
      final n = double.tryParse(text);
      if (!header && i > 3 && n != null && n.isFinite) {
        sheet.write('<c s="0"><v>$n</v></c>');
      } else {
        sheet.write(
          '<c t="inlineStr" s="$style"><is><t xml:space="preserve">${_xml(text)}</t></is></c>',
        );
      }
    }
    sheet.write('</row>');
  }
  sheet.write(
    '</sheetData><pageSetup paperSize="9" orientation="${report.landscape ? 'landscape' : 'portrait'}"/></worksheet>',
  );
  return _zip({
    '[Content_Types].xml': _types(
      '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
      '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
      '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
    ),
    '_rels/.rels': _rootRel('xl/workbook.xml'),
    'xl/workbook.xml':
        '$_xmlHeader<workbook xmlns="$xlSpace" xmlns:r="$_officeRel"><sheets>'
        '<sheet name="التقرير" sheetId="1" r:id="rId1"/></sheets></workbook>',
    'xl/_rels/workbook.xml.rels':
        '$_xmlHeader<Relationships xmlns="$_relSpace">'
        '<Relationship Id="rId1" Type="$_officeRel/worksheet" Target="worksheets/sheet1.xml"/>'
        '<Relationship Id="rId2" Type="$_officeRel/styles" Target="styles.xml"/></Relationships>',
    'xl/worksheets/sheet1.xml': sheet.toString(),
    'xl/styles.xml':
        '$_xmlHeader<styleSheet xmlns="$xlSpace">'
        '<fonts count="3">'
        '<font><sz val="11"/><name val="Arial"/></font>'
        '<font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Arial"/></font>'
        '<font><b/><color rgb="FF173E47"/><sz val="11"/><name val="Arial"/></font>'
        '</fonts>'
        '<fills count="11">'
        '<fill><patternFill patternType="none"/></fill>'
        '<fill><patternFill patternType="gray125"/></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF173E47"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF3D679A"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF78609E"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF287E73"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FF9E713C"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFEDF3FB"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFF2EDFA"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFEAF6F2"/></patternFill></fill>'
        '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF5E8"/></patternFill></fill>'
        '</fills>'
        '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="10">'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="1" fillId="3" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="1" fillId="4" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="1" fillId="5" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="1" fillId="6" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="2" fillId="7" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="2" fillId="8" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="2" fillId="9" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '<xf numFmtId="0" fontId="2" fillId="10" borderId="0" xfId="0" applyFill="1" applyFont="1"/>'
        '</cellXfs>'
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        '</styleSheet>',
  });
}

int _crc32(List<int> input) {
  var crc = 0xffffffff;
  for (final byte in input) {
    crc ^= byte;
    for (var i = 0; i < 8; i++) {
      crc = (crc >>> 1) ^ ((crc & 1) == 1 ? 0xedb88320 : 0);
    }
  }
  return crc ^ 0xffffffff;
}

Uint8List _zip(Map<String, String> entries) {
  final out = BytesBuilder();
  final dir = BytesBuilder();
  void put(BytesBuilder b, int val, int size) {
    final part = ByteData(size);
    if (size == 2) {
      part.setUint16(0, val, Endian.little);
    } else {
      part.setUint32(0, val, Endian.little);
    }
    b.add(part.buffer.asUint8List());
  }

  for (final entry in entries.entries) {
    final name = utf8.encode(entry.key), body = utf8.encode(entry.value);
    final crc = _crc32(body), offset = out.length;
    put(out, 0x04034b50, 4);
    for (final v in [20, 0, 0, 0, 33]) {
      put(out, v, 2);
    }
    for (final v in [crc, body.length, body.length]) {
      put(out, v, 4);
    }
    put(out, name.length, 2);
    put(out, 0, 2);
    out.add(name);
    out.add(body);
    put(dir, 0x02014b50, 4);
    for (final v in [20, 20, 0, 0, 0, 33]) {
      put(dir, v, 2);
    }
    for (final v in [crc, body.length, body.length]) {
      put(dir, v, 4);
    }
    for (final v in [name.length, 0, 0, 0, 0]) {
      put(dir, v, 2);
    }
    put(dir, 0, 4);
    put(dir, offset, 4);
    dir.add(name);
  }
  final offset = out.length, length = dir.length;
  out.add(dir.takeBytes());
  put(out, 0x06054b50, 4);
  for (final v in [0, 0, entries.length, entries.length]) {
    put(out, v, 2);
  }
  put(out, length, 4);
  put(out, offset, 4);
  put(out, 0, 2);
  return out.takeBytes();
}
