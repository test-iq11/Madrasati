import 'package:flutter_test/flutter_test.dart';
import 'package:sajli/attendance_link.dart';

void main() {
  const groups = [
    {'id': 'a', 'name': 'الرابع الابتدائي — أ'},
    {'id': 'b', 'name': 'الرابع الابتدائي · شعبة ب'},
  ];
  test('opens the requested section even when another comes first', () {
    expect(linkedClassId(groups, 'الرابع الابتدائي', 'ب'), 'b');
  });
  test('does not guess a missing or ambiguous roster', () {
    expect(linkedClassId(groups, 'الرابع الابتدائي', 'ج'), isNull);
    expect(linkedClassId(groups, 'الرابع الابتدائي', ''), isNull);
    expect(linkedClassId([...groups, groups.first], 'الرابع الابتدائي', 'أ'), isNull);
  });
}
