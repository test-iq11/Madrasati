import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:sajli/attachment_backup.dart';
import 'package:sajli/records.dart';

void main() {
  test('a restored pupil photo can be read on another device', () async {
    final dir = await Directory.systemTemp.createTemp('sajli-backup-test');
    addTearDown(() => dir.delete(recursive: true));
    final from = await Directory('${dir.path}/first').create();
    final photo = await File('${from.path}/123.image').writeAsBytes([1, 2, 3]);
    final records = Records.decode(await File('assets/demo.json').readAsString());
    final people = records.people;
    people.first['attachments'] = [{'title': 'مستمسك', 'path': photo.path}];
    records.data['students'] = people;
    final payload = await portableRecords(records, from);
    expect(jsonEncode(payload), isNot(contains(from.path)));
    final copy = Records.decode(jsonEncode(payload));
    final to = Directory('${dir.path}/second');
    await restoreAttachments(copy, to);
    final restored = copy.people.first['attachments'][0]['path'] as String;
    expect(restored, startsWith(to.path));
    expect(await File(restored).readAsBytes(), [1, 2, 3]);
  });
}
