import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:sajli/main.dart';
import 'package:sajli/records.dart';
import 'package:sajli/report_data.dart';

void main() {
  testWidgets('parent report controls display four colored, independent sections',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(1200, 900);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final folder = Directory.systemTemp.createTempSync('sajli-parent-test-');
    addTearDown(() => folder.deleteSync(recursive: true));
    final records = Records.decode(File('assets/demo.json').readAsStringSync());
    await tester.pumpWidget(SajliApp(
      records: records,
      file: File('${folder.path}/sajli.json'),
    ));
    await tester.pumpAndSettle();
    await tester.tap(find.text('التقارير').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('كشف الدرجات السنوي'));
    await tester.pumpAndSettle();
    await tester.tap(find.text(ReportKind.parent.label).last);
    await tester.pumpAndSettle();
    final groups = find.byKey(const ValueKey('sajli-parent-report-groups'));
    expect(groups, findsOneWidget);
    for (final field in ParentField.values) {
      expect(find.byKey(ValueKey('sajli-parent-field-${field.name}')),
          findsOneWidget);
    }
    expect(find.text('أقسام التقرير'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
