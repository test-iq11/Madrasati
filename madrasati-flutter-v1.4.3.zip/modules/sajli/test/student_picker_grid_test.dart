import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:sajli/main.dart';
import 'package:sajli/records.dart';

void main() {
  testWidgets('student profile picker is a searchable grid of square colored cards',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final folder = Directory.systemTemp.createTempSync('sajli-picker-test-');
    addTearDown(() => folder.deleteSync(recursive: true));
    final records = Records.decode(File('assets/demo.json').readAsStringSync());
    final firstClass = records.activeClasses.first;
    final student = records.students(firstClass['id'].toString()).first;
    final firstId = student['id'].toString();
    final center = ValueNotifier<String?>('student');
    addTearDown(center.dispose);
    await tester.pumpWidget(SajliApp(
      records: records,
      file: File('${folder.path}/sajli.json'),
      center: center,
    ));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('student-picker-search')), findsOneWidget);
    expect(find.byKey(const ValueKey('student-selection-grid')), findsOneWidget);
    final first = find.byKey(ValueKey('student-selection-card-$firstId'));
    await tester.ensureVisible(first);
    await tester.pumpAndSettle();
    expect(first, findsOneWidget);
    expect(find.descendant(of: first,
        matching: find.byIcon(Icons.person_outline_rounded)), findsOneWidget);
    expect(find.descendant(of: first,
        matching: find.byIcon(Icons.arrow_back_rounded)), findsOneWidget);
    final size = tester.getSize(first);
    expect(size.width / size.height, closeTo(.99, .07));
    await tester.tap(first);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('student-sheet-name')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
