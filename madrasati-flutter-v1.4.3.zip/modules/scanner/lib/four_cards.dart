import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:flutter/foundation.dart' show compute;
import 'dart:typed_data';
import 'package:image/image.dart' as img;

import 'exporters.dart';
import 'layouts.dart';

Uint8List renderCardSheetPng((LayoutSheet, double, double) input) {
  final (sheet, width, height) = input;
  const scale = 200 / 72;
  final canvas = img.Image(width: (width * scale).round(), height: (height * scale).round());
  img.fill(canvas, color: img.ColorRgb8(255, 255, 255));
  for (final item in sheet.placements) {
    final source = img.decodeImage(item.photo.bytes);
    if (source == null) throw const FormatException('تعذّر قراءة الصورة');
    final rect = item.rect;
    img.compositeImage(canvas, img.bakeOrientation(source),
      dstX: (rect.left * scale).round(), dstY: (rect.top * scale).round(),
      dstW: (rect.width * scale).round(), dstH: (rect.height * scale).round());
  }
  return img.encodePng(canvas);
}

class FourCardsPage extends StatefulWidget {
  const FourCardsPage({required this.faces, required this.camera,
    required this.gallery, required this.edit, required this.documents, super.key});
  final List<PhotoData?> faces;
  final List<ScanDocument> documents;
  final Future<PhotoData?> Function(BuildContext, String, bool) camera;
  final Future<PhotoData?> Function() gallery;
  final Future<PhotoData?> Function(BuildContext, PhotoData) edit;
  @override
  State<FourCardsPage> createState() => _FourCardsPageState();
}

class _FourCardsPageState extends State<FourCardsPage> {
  final settings = PrintSettings();
  bool busy = false;
  void message(String text) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(text)));

  Future<void> select(int i) async {
    final previous = widget.faces[i];
    final mode = await showModalBottomSheet<String>(context: context,
      builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min,
        children: [
          for (final option in [
            ('camera', 'التقاط بالكاميرا', Icons.photo_camera_outlined),
            ('gallery', 'اختيار من الاستوديو', Icons.photo_library_outlined),
            if (widget.documents.any((d) => d.photos.isNotEmpty))
              ('existing', 'اختيار صورة من مستمسكاتي', Icons.folder_open_outlined),
            if (previous != null) ('edit', 'تعديل الصورة', Icons.crop),
            if (previous != null) ('remove', 'إزالة هذا الوجه', Icons.delete_outline),
          ]) ListTile(leading: Icon(option.$3), title: Text(option.$2),
            onTap: () => Navigator.pop(ctx, option.$1)),
        ],
      )));
    if (mode == null || !mounted) return;
    if (mode == 'remove') {
      setState(() => widget.faces[i] = null);
      return;
    }
    setState(() => busy = true);
    try {
      final photo = switch (mode) {
        'camera' => await widget.camera(context, 'البطاقة ${1 + i ~/ 2}', i.isOdd),
        'edit' => await widget.edit(context, previous!),
        'existing' => await showModalBottomSheet<PhotoData>(context: context,
          builder: (sheet) => SafeArea(child: ListView(children: [
            for (final doc in widget.documents)
              for (final entry in doc.photos.indexed)
                ListTile(title: Text(doc.title), subtitle: Text('صورة ${entry.$1 + 1}'),
                  leading: Image.memory(entry.$2.bytes, width: 64, cacheWidth: 128),
                  onTap: () => Navigator.pop(sheet, entry.$2)),
          ]))),
        _ => await widget.gallery(),
      };
      if (photo != null && mounted) setState(() => widget.faces[i] = photo);
    } catch (_) {
      if (mounted) message('تعذّر فتح الصورة. يمكنك اختيار صورة أخرى.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> export(bool word, {bool printSheet = false, bool png = false}) async {
    setState(() => busy = true);
    try {
      final sheets = [fourCardSheet(widget.faces, settings)];
      final bytes = png ? await compute(renderCardSheetPng,
          (sheets.first, settings.paper.width, settings.paper.height)) : word ? Exporter.makeDocx(sheets, settings)
          : await Exporter.makePdf(sheets, settings);
      if (printSheet) {
        await Printing.layoutPdf(name: 'مستمسكاتي', onLayout: (_) async => bytes);
        return;
      }
      final path = await FilePicker.saveFile(dialogTitle: 'حفظ ورقة المستمسكات',
          fileName: 'مستمسكاتي.${png ? 'png' : word ? 'docx' : 'pdf'}', bytes: bytes);
      if (mounted && path != null) message('تم حفظ ورقة المستمسكات');
    } catch (_) {
      if (mounted) message('تعذّر حفظ الورقة. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget slot(int i) {
    final photo = widget.faces[i];
    return Expanded(child: Card(clipBehavior: Clip.antiAlias, child: InkWell(
      onTap: busy ? null : () => select(i),
      child: Column(children: [
        AspectRatio(aspectRatio: 1.7, child: photo == null
          ? const Icon(Icons.add_a_photo_outlined)
          : Image.memory(photo.bytes, fit: BoxFit.contain, cacheWidth: 420)),
        Text('البطاقة ${1 + i ~/ 2} · ${i.isEven ? 'الأمام' : 'الخلف'}'),
        const SizedBox(height: 6),
      ]),
    )));
  }

  @override
  Widget build(BuildContext context) {
    final sheet = fourCardSheet(widget.faces, settings);
    return Scaffold(appBar: AppBar(title: const Text('أربع بطاقات في ورقة')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('اضغط على الخانة للتصوير أو لاختيار صورة من الاستوديو.'),
        for (var row = 0; row < 4; row++)
          Row(textDirection: TextDirection.rtl, children: [slot(row * 2), slot(row * 2 + 1)]),
        SwitchListTile(title: const Text('عرض ورقة A4 بالاتجاه الأفقي'),
          value: settings.landscape, onChanged: busy ? null : (v) => setState(() => settings.landscape = v)),
        const ListTile(title: Text('معاينة ورقة A4')),
        AspectRatio(aspectRatio: settings.paper.aspectRatio, child: ColoredBox(
          color: Colors.white, child: LayoutBuilder(builder: (_, box) {
            final k = box.maxWidth / settings.paper.width;
            return Stack(children: [for (final p in sheet.placements)
              Positioned(left: p.rect.left * k, top: p.rect.top * k,
                width: p.rect.width * k, height: p.rect.height * k,
                child: Image.memory(p.photo.bytes, fit: BoxFit.contain, cacheWidth: 440)),
            ]);
          }),
        )),
        Wrap(alignment: WrapAlignment.center, spacing: 12, children: [
          OutlinedButton.icon(onPressed: busy || sheet.placements.isEmpty ? null : () => export(false, printSheet: true),
            icon: const Icon(Icons.print_outlined), label: const Text('طباعة')),
          OutlinedButton(onPressed: busy || sheet.placements.isEmpty ? null : () => export(false, png: true),
            child: const Text('حفظ صورة PNG')),
          for (final word in [false, true])
            FilledButton(onPressed: busy || sheet.placements.isEmpty ? null : () => export(word),
              child: Text(word ? 'حفظ Word' : 'حفظ PDF')),
        ]),
      ])));
  }
}
