import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'card_geometry.dart';

enum LayoutStyle {
  sideCenter('متجاورتان بالوسط', Icons.view_column_outlined),
  sideTop('متجاورتان بالأعلى', Icons.vertical_align_top_rounded),
  verticalCenter('أعلى وأسفل', Icons.view_agenda_outlined),
  stackRight('عمود جهة اليمين', Icons.align_horizontal_right_rounded),
  stackLeft('عمود جهة اليسار', Icons.align_horizontal_left_rounded),
  separate('كل وجه بصفحة', Icons.layers_outlined),
  halves('نصفا الصفحة', Icons.vertical_distribute_outlined),
  single('صورة واحدة', Icons.crop_portrait),
  free('ترتيب حر', Icons.open_with_rounded);

  const LayoutStyle(this.label, this.icon);
  final String label;
  final IconData icon;
}

class PhotoData {
  const PhotoData(this.bytes, this.width, this.height);
  final Uint8List bytes;
  final int width;
  final int height;
  double get aspect => width / height;
}

enum ScanAppearance {
  original, smart, color, gray, blackWhite, soft, whitePaper,
  highContrast, warm, cool,
}

class ExtraScanPage {
  PhotoData? image;
  PhotoData? original;
  ScanAppearance appearance = ScanAppearance.original;
}

class ScanDocument {
  ScanDocument(this.title);
  final String title;
  bool get usesNaturalCardSize => isIdentityCard(title);
  PhotoData? front;
  PhotoData? back;
  PhotoData? frontOriginal;
  PhotoData? backOriginal;
  ScanAppearance frontAppearance = ScanAppearance.original;
  ScanAppearance backAppearance = ScanAppearance.original;
  final List<ExtraScanPage> extras = [];
  final Map<int, Offset> freeOffsets = {};
  final Map<int, double> freeScales = {};

  List<PhotoData> get photos => [
    if (front != null) front!,
    if (back != null) back!,
    for (final p in extras) if (p.image != null) p.image!,
  ];

  void swapSides() {
    final oldFront = front;
    final oldFrontOriginal = frontOriginal;
    final oldFrontAppearance = frontAppearance;
    front = back;
    frontOriginal = backOriginal;
    frontAppearance = backAppearance;
    back = oldFront;
    backOriginal = oldFrontOriginal;
    backAppearance = oldFrontAppearance;
  }

  void moveExtra(int from, int to) {
    if (from == to || from < 0 || from >= extras.length ||
        to < 0 || to >= extras.length) {
      return;
    }
    extras.insert(to, extras.removeAt(from));
  }
}

class ImagePlacement {
  ImagePlacement(this.photo, this.rect, this.index);
  final PhotoData photo;
  Rect rect;
  final int index;
}

class LayoutSheet {
  LayoutSheet(this.placements, {this.cutLine = false});
  final List<ImagePlacement> placements;
  final bool cutLine;
}

class PrintSettings {
  bool a5 = false;
  bool landscape = false;
  double margin = 28;
  double gap = 14;
  double scale = 1.0;
  LayoutStyle style = LayoutStyle.sideCenter;
  bool showCut = false;
  bool fillPage = false;
  int? singleFace;
  Color accent = const Color(0xFF4874EB);
  bool dark = false;
  Size get paper {
    final base = a5 ? const Size(419.53, 595.28) : const Size(595.28, 841.89);
    return landscape ? Size(base.height, base.width) : base;
  }
}

/// Single source of truth for the preview, PDF and positioned Word images.
/// Each document can contain 1..N photos; paired layouts create one sheet
/// for every two photos, preserving order and never dropping extra pages.
List<LayoutSheet> layoutDocument(
  ScanDocument doc,
  PrintSettings settings, {
  Map<int, Offset> freeOffsets = const {},
}) {
  final photos = doc.photos;
  if (photos.isEmpty) {
    return [];
  }
  final page = settings.paper;
  final margin = settings.margin.clamp(0.0, page.shortestSide / 3).toDouble();
  final gap = settings.gap;
  final usableWidth = page.width - 2 * margin;
  final usableHeight = page.height - 2 * margin;
  final sheets = <LayoutSheet>[];

  Size fit(PhotoData image, double width, double height, {double sizeScale = 1}) {
    if (doc.usesNaturalCardSize) {
      final naturalWidth = identityCardWidthMm * pointsPerMm * settings.scale * sizeScale;
      final naturalHeight = identityCardHeightMm * pointsPerMm * settings.scale * sizeScale;
      final shrinkFactor = math.min(1.0,
          math.min(width / naturalWidth, height / naturalHeight));
      return Size(naturalWidth * shrinkFactor, naturalHeight * shrinkFactor);
    }
    final maxW = math.max(12.0, width);
    final maxH = math.max(12.0, height);
    final actualW = math.min(maxW, maxH * image.aspect);
    return Size(actualW, actualW / image.aspect);
  }

  Rect centered(PhotoData image, double maxW, double maxH) {
    final size = fit(image, maxW, maxH);
    return Rect.fromLTWH((page.width - size.width) / 2,
        (page.height - size.height) / 2, size.width, size.height);
  }

  final mode = settings.style;
  if (settings.fillPage) {
    for (var i = 0; i < photos.length; i++) {
      final photo = photos[i];
      final width = math.min(usableWidth, usableHeight * photo.aspect);
      final height = width / photo.aspect;
      sheets.add(LayoutSheet([ImagePlacement(photo,
        Rect.fromLTWH((page.width - width) / 2, (page.height - height) / 2,
          width, height), i)]));
    }
    return sheets;
  }
  if (mode == LayoutStyle.single && doc.usesNaturalCardSize &&
      doc.front != null && doc.back != null && photos.length == 2 &&
      settings.singleFace != null) {
    final index = settings.singleFace == 1 ? 1 : 0;
    final photo = photos[index];
    sheets.add(LayoutSheet([ImagePlacement(photo,
        centered(photo, usableWidth, usableHeight), index)]));
    return sheets;
  }
  if (mode == LayoutStyle.separate || mode == LayoutStyle.single ||
      photos.length == 1 && mode != LayoutStyle.free) {
    for (var i = 0; i < photos.length; i++) {
      final rect = centered(photos[i], usableWidth * .83 * settings.scale,
          usableHeight * .60 * settings.scale);
      sheets.add(LayoutSheet([ImagePlacement(photos[i], rect, i)]));
    }
    return sheets;
  }

  for (var i = 0; i < photos.length; i += 2) {
    final first = photos[i];
    if (i + 1 >= photos.length) {
      var rect = centered(first, usableWidth * .83 * settings.scale,
          usableHeight * .60 * settings.scale);
      if (mode == LayoutStyle.free) {
        final size = fit(first, usableWidth, usableHeight, sizeScale: doc.freeScales[i] ?? 1);
        final offset = freeOffsets[i] ?? doc.freeOffsets[i] ??
            Offset((page.width - size.width) / 2, (page.height - size.height) / 2);
        rect = Rect.fromLTWH(
          offset.dx.clamp(margin, page.width - margin - size.width).toDouble(),
          offset.dy.clamp(margin, page.height - margin - size.height).toDouble(),
          size.width, size.height,
        );
      }
      sheets.add(LayoutSheet([ImagePlacement(first, rect, i)]));
      continue;
    }
    final second = photos[i + 1];
    final placements = <ImagePlacement>[];
    var cutLine = false;

    if (mode == LayoutStyle.sideTop || mode == LayoutStyle.sideCenter) {
      final cellWidth = doc.usesNaturalCardSize
          ? (usableWidth - gap) / 2
          : math.min((usableWidth - gap) / 2, 252.0 * settings.scale);
      final cellHeight = usableHeight * .5;
      final a = fit(first, cellWidth, cellHeight);
      final b = fit(second, cellWidth, cellHeight);
      final rowWidth = a.width + gap + b.width;
      final left = (page.width - rowWidth) / 2;
      final top = mode == LayoutStyle.sideTop
          ? margin
          : (page.height - math.max(a.height, b.height)) / 2;
      placements.add(ImagePlacement(first,
          Rect.fromLTWH(left, top, a.width, a.height), i));
      placements.add(ImagePlacement(second,
          Rect.fromLTWH(left + a.width + gap, top, b.width, b.height), i + 1));
    } else if (mode == LayoutStyle.verticalCenter ||
        mode == LayoutStyle.stackRight || mode == LayoutStyle.stackLeft ||
        mode == LayoutStyle.halves) {
      final maxW = doc.usesNaturalCardSize ? usableWidth
          : math.min(usableWidth * .78, 345.0 * settings.scale);
      final maxH = mode == LayoutStyle.halves
          ? (usableHeight - gap) / 2 * .82
          : usableHeight * .41;
      final a = fit(first, maxW, maxH);
      final b = fit(second, maxW, maxH);
      final top = mode == LayoutStyle.verticalCenter
          ? (page.height - a.height - b.height - gap) / 2
          : mode == LayoutStyle.halves
              ? margin + (usableHeight / 2 - a.height) / 2
              : margin;
      final secondTop = mode == LayoutStyle.halves
          ? margin + usableHeight / 2 + (usableHeight / 2 - b.height) / 2
          : top + a.height + gap;
      double xFor(double width) {
        if (mode == LayoutStyle.stackRight) {
          return page.width - margin - width;
        }
        if (mode == LayoutStyle.stackLeft) {
          return margin;
        }
        return (page.width - width) / 2;
      }
      placements.add(ImagePlacement(first,
          Rect.fromLTWH(xFor(a.width), top, a.width, a.height), i));
      placements.add(ImagePlacement(second,
          Rect.fromLTWH(xFor(b.width), secondTop, b.width, b.height), i + 1));
      cutLine = mode == LayoutStyle.halves && settings.showCut;
    } else {
      final a = fit(first, usableWidth * .63 * settings.scale,
          usableHeight * .35, sizeScale: doc.freeScales[i] ?? 1);
      final b = fit(second, usableWidth * .63 * settings.scale,
          usableHeight * .35, sizeScale: doc.freeScales[i + 1] ?? 1);
      Rect free(int index, Size size, Offset fallback) {
        final p = freeOffsets[index] ?? doc.freeOffsets[index] ?? fallback;
        return Rect.fromLTWH(
          p.dx.clamp(margin, page.width - margin - size.width).toDouble(),
          p.dy.clamp(margin, page.height - margin - size.height).toDouble(),
          size.width, size.height,
        );
      }
      placements.add(ImagePlacement(first,
          free(i, a, Offset(margin, margin)), i));
      placements.add(ImagePlacement(second,
          free(i + 1, b, Offset(page.width - margin - b.width,
              margin + a.height + gap)), i + 1));
    }
    sheets.add(LayoutSheet(placements, cutLine: cutLine));
  }
  return sheets;
}

/// Slots are interleaved front/back and never compacted when a side is empty.
LayoutSheet fourCardSheet(List<PhotoData?> photos, PrintSettings settings) {
  final page = settings.paper;
  final width = (page.width - 2 * settings.margin - settings.gap) / 2;
  final height = (page.height - 2 * settings.margin - 3 * settings.gap) / 4;
  final result = <ImagePlacement>[];
  for (var index = 0; index < 8; index++) {
    final photo = photos[index];
    if (photo == null) continue;
    final x = settings.margin + (index.isEven ? width + settings.gap : 0);
    final y = settings.margin + (index ~/ 2) * (height + settings.gap);
    final w = math.min(width, math.min(identityCardWidthMm * pointsPerMm, height * photo.aspect));
    final h = w / photo.aspect;
    result.add(ImagePlacement(photo, Rect.fromLTWH(x + (width - w) / 2,
      y + (height - h) / 2, w, h), index));
  }
  return LayoutSheet(result);
}
