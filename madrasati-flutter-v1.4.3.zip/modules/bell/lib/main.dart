import 'package:madrasati_cards/card_size.dart';
import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'domain.dart';
import 'bell_design.dart';
import 'lesson_tile.dart';
import 'platform_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TeacherBellApp());
}

class TeacherBellApp extends StatefulWidget {
  const TeacherBellApp({
    super.key,
    this.initialState,
    this.platformEnabled = true,
    this.readTime,
    this.darkOverride,
  });
  final PlannerState? initialState;
  final bool platformEnabled;
  final DateTime Function()? readTime;
  final bool? darkOverride;
  @override
  State<TeacherBellApp> createState() => TeacherBellAppState();
}

class TeacherBellAppState extends State<TeacherBellApp>
    with WidgetsBindingObserver {
  PlannerState? data;
  int tab = 0, selectedDay = dayIndex(DateTime.now());
  DateTime now = DateTime.now();
  Timer? timer;
  final undo = <PlannerState>[];
  Map<String, dynamic> device = {};
  List<Map<String, dynamic>> events = [];
  final navKey = GlobalKey<NavigatorState>();
  final messenger = GlobalKey<ScaffoldMessengerState>();
  final speechController = TextEditingController();
  Future<void> queue = Future<void>.value();
  String? loadError;
  static const accentColors = [0xff087451, 0xff26639c, 0xff7652a0, 0xff9b5a27];
  static const darkAccents = [0xff83e2ae, 0xff9dccff, 0xffdfbaff, 0xffffc694];
  final pageScroll = ScrollController();
  Color get green =>
      Color((dark ? darkAccents : accentColors)[data?.accentIndex ?? 0]);
  Color get ink => dark ? const Color(0xfff5f5f5) : const Color(0xff192f27);
  Color get muted => dark ? const Color(0xffbdbdbd) : const Color(0xff54685e);
  Color get surface => dark ? const Color(0xff141414) : const Color(0xfffffefa);
  Color get bg => dark ? const Color(0xff000000) : const Color(0xfff1f4ef);
  Color get mint => Color.alphaBlend(green.withValues(alpha: .15), surface);
  BuildContext get ctx => navKey.currentContext!;
  PlannerState get s => data!;
  bool get dark => widget.darkOverride ?? data?.dark ?? false;

  Future<bool> importSchoolDay(int day, List<Lesson> lessons) async {
    if (data == null) await _initialLoad;
    if (!mounted || data == null || lessons.isEmpty || day < 0 || day > 6) {
      return false;
    }
    for (var i = 0; i < lessons.length; i++) {
      if (!lessons[i].validTime ||
          (i > 0 && lessons[i - 1].end > lessons[i].start)) {
        return false;
      }
    }
    final next = s.clone();
    final previous = next.week[day];
    next.week[day] = [
      for (var i = 0; i < lessons.length; i++)
        if (i < previous.length)
          previous[i].copyWith(
            subject: lessons[i].subject,
            grade: lessons[i].grade,
            section: lessons[i].section,
            start: lessons[i].start,
            end: lessons[i].end,
          )
        else
          lessons[i],
    ];
    setState(() {
      selectedDay = day;
      tab = 1;
    });
    await _commit(
      next,
      editLabel: 'استيراد حصص اليوم من مدرستي',
      propagateFailure: true,
    );
    return true;
  }

  Future<void>? _initialLoad;
  @override
  void initState() {
    super.initState();
    now = widget.readTime?.call() ?? DateTime.now();
    selectedDay = dayIndex(now);
    WidgetsBinding.instance.addObserver(this);
    if (widget.initialState != null) {
      data = widget.initialState!.clone();
      speechController.text = s.speechText;
      _setVibrationFields(s.vibration);
    } else {
      _initialLoad = _load();
    }
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && tab == 0) {
        setState(() => now = widget.readTime?.call() ?? DateTime.now());
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    minuteTest?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    speechController.dispose();
    pageScroll.dispose();
    pulseField.dispose();
    gapField.dispose();
    _clearVibrationAnimation();
    pulseIndex.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused && vibrationTimers.isNotEmpty) {
      _stopVibration(report: false);
    }
    if (state == AppLifecycleState.resumed) {
      _refresh();
      if (data != null && widget.platformEnabled) {
        _syncOnResume();
      }
    }
  }

  Future<void> _syncOnResume() async {
    try {
      await queue;
      await DeviceService.sync(s);
    } catch (_) {
      _message('تعذر تحديث التنبيهات؛ راجع جاهزية التطبيق.');
    }
  }

  Future<void> _load() async {
    try {
      final loaded = await DeviceService.load();
      if (!mounted) {
        return;
      }
      setState(() => data = loaded);
      speechController.text = loaded.speechText;
      _setVibrationFields(loaded.vibration);
      await _refresh();
      try {
        await DeviceService.save(loaded);
        await DeviceService.sync(loaded);
      } catch (_) {
        _message('حُملت بياناتك؛ تعذر تحديث بعض التنبيهات. راجع الإعدادات.');
      }
    } catch (e) {
      if (mounted) {
        setState(() => loadError = 'تعذر تحميل الإعدادات. بياناتك لم تُحذف.');
      }
    }
  }

  Future<void> _refresh() async {
    if (!widget.platformEnabled) {
      return;
    }
    try {
      final d = await DeviceService.status();
      final logs = await DeviceService.logs();
      if (mounted) {
        setState(() {
          device = d;
          events = logs;
          now = DateTime.now();
        });
      }
    } catch (_) {
      /* The main interface remains available when a device permission check fails. */
    }
  }

  Future<void> _commit(
    PlannerState next, {
    bool schedule = true,
    bool remember = true,
    String? editLabel,
    bool propagateFailure = false,
  }) async {
    if (remember) {
      undo.add(s.clone());
      if (undo.length > 15) {
        undo.removeAt(0);
      }
    }
    setState(() => data = next);
    if (!widget.platformEnabled) {
      return;
    }
    final captured = next.clone();
    Object? failure;
    queue = queue
        .then((_) async {
          await DeviceService.save(captured);
          if (schedule) {
            await DeviceService.sync(captured);
          }
          if (editLabel != null) {
            await DeviceService.channel.invokeMethod<void>(
              'logEdit',
              editLabel,
            );
          }
        })
        .catchError((Object error) {
          failure = error;
          _message(
            'تعذر حفظ الإعدادات أو تحديث التنبيهات. أعد المحاولة من الجاهزية.',
          );
        });
    await queue;
    if (propagateFailure && failure != null) throw failure!;
    await _refresh();
  }

  void _message(String text) {
    messenger.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _toggle(bool enabled) async {
    if (enabled &&
        !s.week.asMap().entries.any(
          (entry) =>
              s.work[entry.key] &&
              entry.value.any((l) => l.enabled && l.configured),
        )) {
      setState(() => tab = 1);
      _message('جهّز مادة وصفًا وفعّل حصة أولًا.');
      return;
    }
    if (enabled && widget.platformEnabled) {
      await DeviceService.requestNotifications();
      await _refresh();
      if (device['notifications'] != true) {
        _message('اسمح بإشعارات التطبيق ثم فعّل الجدول.');
        return;
      }
    }
    final next = s.clone()..enabled = enabled;
    await _commit(next);
    _message(enabled ? 'تم تفعيل جدول التنبيهات.' : 'تم إيقاف تنبيهات الجدول.');
  }

  void _navigate(int index) {
    if (tab != index && vibrationTimers.isNotEmpty) {
      _stopVibration(report: false);
    }
    if (pageScroll.hasClients) {
      pageScroll.jumpTo(0);
    }
    setState(() {
      pendingVibrationCount = null;
      tab = index;
    });
    if (index == 2 || index == 3) {
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = this.dark;
    final scheme =
        ColorScheme.fromSeed(
          seedColor: green,
          brightness: dark ? Brightness.dark : Brightness.light,
        ).copyWith(
          surface: surface,
          primary: green,
          onPrimary: dark ? const Color(0xff133125) : Colors.white,
        );
    return MaterialApp(
      navigatorKey: navKey,
      scaffoldMessengerKey: messenger,
      title: 'جرس المعلم',
      locale: const Locale('ar', 'IQ'),
      supportedLocales: const [Locale('ar', 'IQ')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        splashFactory: InkRipple.splashFactory,
        colorScheme: scheme,
        scaffoldBackgroundColor: bg,
        fontFamily: 'sans-serif',
        appBarTheme: AppBarTheme(
          backgroundColor: bg,
          foregroundColor: ink,
          scrolledUnderElevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: bg,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 13,
          ),
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: const Color(0xff193632),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        dividerColor: muted.withValues(alpha: .15),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(
              (data?.textSize == 2
                      ? 1.28
                      : safelyLarge
                      ? 1.15
                      : 1.0) *
                  MediaQuery.textScalerOf(context).scale(1).clamp(.9, 1.25),
            ),
          ),
          child: child ?? const SizedBox(),
        ),
      ),
      home: Builder(
        builder: (context) {
          if (data == null) {
            return Scaffold(
              body: Center(
                child: loadError == null
                    ? const CircularProgressIndicator()
                    : Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(loadError!),
                          TextButton(
                            onPressed: () {
                              setState(() => loadError = null);
                              _load();
                            },
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
              ),
            );
          }
          return Scaffold(
            body: SafeArea(
              bottom: false,
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1050),
                  child: tab == 1 && MediaQuery.sizeOf(context).width <= 720
                      ? _pinnedSchedule(dark)
                      : SingleChildScrollView(
                          key: ValueKey(tab),
                          controller: pageScroll,
                          padding: EdgeInsets.symmetric(
                            horizontal: MediaQuery.sizeOf(context).width > 720
                                ? 24
                                : 13,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              if (tab != 0 || widget.darkOverride == null) _referenceHeader(dark),
                              switch (tab) {
                                0 => _home(),
                                1 => _schedule(),
                                2 => _history(),
                                _ => _settings(),
                              },
                              const SizedBox(height: 20),
                            ],
                          ),
                        ),
                ),
              ),
            ),
            bottomNavigationBar: _referenceNavigation(),
          );
        },
      ),
    );
  }

  bool get safelyLarge => data?.large ?? false;
  Widget _topIcon(IconData icon, String label, VoidCallback onTap) =>
      IconButton(
        onPressed: onTap,
        tooltip: label,
        icon: Icon(icon, size: 19),
        style: IconButton.styleFrom(
          minimumSize: const Size(43, 43),
          backgroundColor: surface,
          foregroundColor: ink,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(13),
            side: BorderSide(color: line),
          ),
        ),
      );
  Widget _card(Widget child, {Color? color}) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(19),
    margin: const EdgeInsets.only(bottom: 16),
    decoration: BoxDecoration(
      color: color ?? surface,
      borderRadius: BorderRadius.circular(21),
      border: Border.all(color: muted.withValues(alpha: .12)),
    ),
    child: child,
  );
  Widget _sub(String text) =>
      Text(text, style: TextStyle(fontSize: 11, color: muted, height: 1.7));
  Widget _section(String title, {Widget? action}) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: ink,
            ),
          ),
        ),
        if (action != null) action,
      ],
    ),
  );
  Widget _button(
    String title,
    VoidCallback onTap, {
    IconData? icon,
    bool primary = false,
  }) => primary
      ? FilledButton(
          onPressed: onTap,
          style: FilledButton.styleFrom(
            backgroundColor: green,
            foregroundColor: dark ? const Color(0xff133125) : Colors.white,
            minimumSize: const Size(0, 45),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 17),
                const SizedBox(width: 7),
              ],
              Flexible(
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        )
      : OutlinedButton(
          onPressed: onTap,
          style: OutlinedButton.styleFrom(
            foregroundColor: green,
            minimumSize: const Size(0, 44),
            side: BorderSide(color: muted.withValues(alpha: .22)),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 16),
                const SizedBox(width: 6),
              ],
              Flexible(
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
        );
  Widget _pair(Widget a, Widget b) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Expanded(child: a),
      const SizedBox(width: 9),
      Expanded(child: b),
    ],
  );
  Widget _switch(
    String title,
    String description,
    bool value,
    ValueChanged<bool> change,
  ) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 10),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: ink,
                ),
              ),
              _sub(description),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: change,
          activeThumbColor: Colors.white,
          activeTrackColor: green,
        ),
      ],
    ),
  );
  Color _subjectColor(String subject) {
    if (s.cardColors[subject] != null) {
      return Color(s.cardColors[subject]!);
    }
    var hash = 0;
    for (final rune in subject.runes) {
      hash = (hash * 31 + rune) & 0x7fffffff;
    }
    const palette = [
      0xff628fcd,
      0xff258c77,
      0xff9981ba,
      0xffca984e,
      0xffc17f89,
      0xff648ca2,
      0xff8b9b51,
    ];
    return Color(palette[hash % palette.length]);
  }

  DateTime _selectedDate() =>
      dayDate(now, (selectedDay - dayIndex(now) + 7) % 7);
  Color get line => dark ? const Color(0xff343434) : const Color(0xffdfe6dd);
  Color get wash => dark ? const Color(0xff202020) : const Color(0xffedf2eb);

  Widget _referenceHeader(bool dark) => Padding(
    padding: const EdgeInsets.only(top: 13, bottom: 11),
    child: Row(
      children: [
        BellBadge(
          icon: Icons.notifications_none_rounded,
          background: green,
          foreground: dark ? const Color(0xff133125) : Colors.white,
          size: 40,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'جرس المعلم',
                style: TextStyle(
                  color: ink,
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              _sub('ساعة الدوام'),
            ],
          ),
        ),
        _topIcon(Icons.vibration, 'إعدادات الهزاز', _openVibration),
        const SizedBox(width: 8),
        if (widget.darkOverride == null)
          _topIcon(
            dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
            'تبديل المظهر',
            () => _commit(
              s.clone()..dark = !dark,
              schedule: false,
              remember: false,
            ),
          ),
      ],
    ),
  );

  Widget _referenceNavigation() {
    const labels = ['الرئيسية', 'الجدول', 'السجل', 'الإعدادات'];
    const icons = [
      Icons.home_outlined,
      Icons.calendar_today_outlined,
      Icons.schedule_rounded,
      Icons.tune_rounded,
    ];
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(12, 7, 12, 7),
      child: Align(
        alignment: Alignment.center,
        heightFactor: 1,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: surface,
              border: Border.all(color: line),
              borderRadius: BorderRadius.circular(19),
            ),
            child: Row(
              children: [
                for (var i = 0; i < labels.length; i++)
                  Expanded(
                    child: Semantics(
                      selected: i == tab,
                      button: true,
                      child: Material(
                        color: i == tab ? mint : surface,
                        borderRadius: BorderRadius.circular(14),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => _navigate(i),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 7),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  icons[i],
                                  size: 19,
                                  color: i == tab ? green : muted,
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  labels[i],
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: i == tab ? green : muted,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _columns(Widget primary, Widget secondary, {int primaryFlex = 162}) =>
      LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth <= 694) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [primary, const SizedBox(height: 12), secondary],
            );
          }
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(flex: primaryFlex, child: primary),
              const SizedBox(width: 18),
              Expanded(flex: 100, child: secondary),
            ],
          );
        },
      );

  Widget _stack(List<Widget> children, {double gap = 12}) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      for (var i = 0; i < children.length; i++) ...[
        if (i > 0) SizedBox(height: gap),
        children[i],
      ],
    ],
  );

  Widget _panel(List<Widget> children) => Container(
    padding: EdgeInsets.all(MediaQuery.sizeOf(ctx).width <= 720 ? 12 : 16),
    decoration: BoxDecoration(
      color: surface,
      border: Border.all(color: line),
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        if (!dark)
          const BoxShadow(
            color: Color(0x09193f2a),
            blurRadius: 24,
            offset: Offset(0, 8),
          ),
      ],
    ),
    child: Material(
      type: MaterialType.transparency,
      child: _stack(children, gap: 10),
    ),
  );

  Widget _cardTitle(IconData icon, String title, String subtitle) => Row(
    children: [
      BellBadge(icon: icon, background: mint, foreground: green),
      const SizedBox(width: 10),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(color: ink, fontWeight: FontWeight.bold),
            ),
            _sub(subtitle),
          ],
        ),
      ),
    ],
  );

  Widget _referenceHeading(
    String eyebrow,
    String title,
    String detail,
  ) => _stack([
    Text(
      eyebrow,
      style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: muted),
    ),
    Text(
      title,
      style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: ink),
    ),
    _sub(detail),
  ], gap: 2);

  DateTime? demoTime, demoStartedAt;
  bool clockControls = false;
  DateTime get clockTime =>
      demoTime == null ? now : demoTime!.add(now.difference(demoStartedAt!));

  PlannerState _simulationSchedule() {
    if (s.week.any(
      (day) => day.any((lesson) => lesson.enabled && lesson.configured),
    )) {
      return s;
    }
    final sample = PlannerState()..enabled = true;
    const names = [
      'اللغة العربية',
      'العلوم',
      'الرياضيات',
      'اللغة الإنكليزية',
      'التربية الإسلامية',
      'التربية الفنية',
    ];
    const indexes = [3, 1, 5, 4, 2, 0];
    const places = [
      'القاعة ٤',
      'مختبر العلوم',
      'القاعة ٦',
      '',
      '',
      'قاعة الفنون',
    ];
    const modes = [
      'both',
      'vibration',
      'both',
      'sound',
      'notification',
      'vibration',
    ];
    sample.week[0] = [
      for (var i = 0; i < names.length; i++)
        sample.week[0][i].copyWith(
          subject: names[i],
          grade: grades[indexes[i]],
          section: i == 1 ? 'ب' : 'أ',
          place: places[i],
          mode: modes[i],
          enabled: true,
        ),
    ];
    return sample;
  }

  void _previewClock(String phase) {
    final model = _simulationSchedule();
    final sunday = dayDate(now, -dayIndex(now));
    DateTime? date;
    List<Lesson> lessons = [];
    for (var offset = 0; offset < 7; offset++) {
      final candidate = dayDate(sunday, offset);
      final entries = model.effective(candidate);
      if (entries.isNotEmpty && !model.vacation(candidate)) {
        date = candidate;
        lessons = entries;
        break;
      }
    }
    if (date == null) {
      _message('لا توجد حصص مفعلة للمحاكاة.');
      return;
    }
    int minute;
    switch (phase) {
      case 'before':
        minute = (lessons.first.start - 15).clamp(0, 1439);
      case 'during':
        final current = lessons.length > 1 ? lessons[1] : lessons.first;
        minute = (current.start + current.end) ~/ 2;
      case 'break':
        final i = List<int>.generate(lessons.length, (i) => i)
            .skip(1)
            .where((i) => lessons[i - 1].end < lessons[i].start)
            .firstOrNull;
        if (i == null) {
          _message('لا يوجد فاصل بين الحصص في هذا اليوم.');
          return;
        }
        minute = (lessons[i - 1].end + lessons[i].start) ~/ 2;
      default:
        minute = (lessons.last.end + 1).clamp(0, 1439);
    }
    setState(() {
      demoTime = atMinute(date!, minute);
      demoStartedAt = now;
    });
  }

  Widget _clockControls() => _panel([
    InkWell(
      onTap: () => setState(() => clockControls = !clockControls),
      child: Row(
        children: [
          const Icon(Icons.schedule, size: 19),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              'تجربة ساعة الدوام',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Icon(
            clockControls ? Icons.remove : Icons.add,
            color: green,
            size: 20,
          ),
        ],
      ),
    ),
    if (clockControls) ...[
      _sub('انتقل بين حالات اليوم أو اختر ساعة لتجربتها.'),
      Wrap(
        spacing: 6,
        runSpacing: 5,
        children: [
          for (final item in const [
            ('before', 'قبل الدوام'),
            ('during', 'حصة جارية'),
            ('break', 'استراحة'),
            ('after', 'بعد الدوام'),
          ])
            ActionChip(
              label: Text(item.$2),
              onPressed: () => _previewClock(item.$1),
            ),
        ],
      ),
      _button('وقت المحاكاة', () async {
        final time = await showTimePicker(
          context: ctx,
          initialTime: TimeOfDay.fromDateTime(clockTime),
        );
        if (time == null || !mounted) {
          return;
        }
        final simulation = _simulationSchedule();
        final offset = simulation.week.indexWhere(
          (day) => day.any((lesson) => lesson.enabled && lesson.configured),
        );
        final date =
            demoTime ?? dayDate(now, offset < 0 ? 0 : offset - dayIndex(now));
        setState(() {
          demoTime = atMinute(date, time.hour * 60 + time.minute);
          demoStartedAt = now;
        });
      }, icon: Icons.schedule),
      if (demoTime != null)
        _button(
          'استخدام وقت الهاتف',
          () => setState(() {
            demoTime = null;
            demoStartedAt = null;
          }),
        ),
    ],
  ]);

  Widget _home() {
    final moment = clockTime;
    final model = demoTime == null ? s : _simulationSchedule();
    final index = dayIndex(moment);
    final vacation = model.vacation(moment);
    final lessons = vacation ? <Lesson>[] : model.effective(moment);
    final cards = vacation
        ? <Lesson>[]
        : model.effective(moment, configuredOnly: false);
    final current = lessons
        .where(
          (lesson) =>
              !atMinute(moment, lesson.start).isAfter(moment) &&
              atMinute(moment, lesson.end).isAfter(moment),
        )
        .firstOrNull;
    final done = lessons
        .where((lesson) => !atMinute(moment, lesson.end).isAfter(moment))
        .toList();
    final next = model.next(moment);
    final nextToday = next != null && dayDate(next.at) == dayDate(moment);
    var status = 'لا توجد حصص مفعّلة',
        title = 'جدولك اليومي',
        detail = 'أضف حصة من الجدول.';
    var label = '', hours = '', unit = '', progress = 0.0;
    String value = next == null ? '—' : clock(next.lesson.start);
    int? seconds;
    if (current != null) {
      status = 'الحصة الجارية';
      title = current.subject;
      detail = [
        current.grade,
        if (current.section.isNotEmpty) 'شعبة ${current.section}',
        current.place,
      ].where((item) => item.isNotEmpty).join(' · ');
      seconds = atMinute(moment, current.end).difference(moment).inSeconds;
      progress = 1 - seconds / ((current.end - current.start) * 60);
      hours = '${clock(current.start)}–${clock(current.end)}';
      label = 'حتى نهاية الحصة';
    } else if (nextToday) {
      status = done.isEmpty ? 'قبل الدوام' : 'استراحة';
      title = done.isEmpty ? 'بداية الدوام' : 'وقت الاستراحة';
      detail =
          'تبدأ حصة ${next.lesson.subject} عند ${clock(next.lesson.start)}';
      seconds = next.at.difference(moment).inSeconds;
      label = 'حتى الحصة التالية';
      if (done.isNotEmpty) {
        final end = done.last.end;
        final interval = (next.lesson.start - end) * 60;
        if (interval > 0) {
          progress = 1 - seconds / interval;
          hours = '${clock(end)}–${clock(next.lesson.start)}';
        }
      }
    } else if (lessons.isNotEmpty) {
      status = 'انتهى الدوام';
      title = 'اكتمل يومك';
      detail = 'انتهت حصص ${weekdays[index]}.';
      value = '${done.length}/${lessons.length}';
      label = 'الحصص مكتملة';
      progress = 1;
    } else if (next != null) {
      status = vacation
          ? 'إجازة'
          : model.work[index]
          ? 'لا حصص اليوم'
          : 'يوم عطلة';
      title = 'الدوام القادم';
      detail = '${weekdays[dayIndex(next.at)]} · ${next.lesson.subject}';
      label = 'موعد البداية';
    }
    if (seconds != null) {
      final n = seconds.clamp(0, 86400);
      final large = n >= 3600;
      final left = large ? n ~/ 3600 : n ~/ 60;
      final right = large ? n ~/ 60 % 60 : n % 60;
      value =
          '${left.toString().padLeft(2, '0')}:${right.toString().padLeft(2, '0')}';
      unit = large ? 'ساعة : دقيقة' : 'دقيقة : ثانية';
    }
    final hero = SectionCard('bell', child: BellHero(
      color: Color(s.heroColor),
      status: model.enabled ? status : 'التنبيه متوقف',
      clockLabel:
          '${demoTime == null ? 'وقت الهاتف' : 'محاكاة'} · ${clock(moment.hour * 60 + moment.minute)}',
      day: weekdays[index],
      title: title,
      detail: detail,
      value: value,
      unit: unit,
      dialLabel: label,
      progress: progress,
      hours: hours,
      nextTitle: next == null
          ? 'لا توجد حصة مجدولة'
          : '${nextToday ? '' : '${weekdays[dayIndex(next.at)]} · '}${next.lesson.subject}',
      nextTime: next == null ? '' : clock(next.lesson.start),
      onClock: () => setState(() => clockControls = !clockControls),
    ));
    final dateOverride =
        s.exceptions.containsKey(dateKey(moment)) ||
        s.seasonal.active(dateKey(moment));
    final today = _panel([
      Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'حصص ${weekdays[index]}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 17,
                  ),
                ),
                _sub('اضغط على الحصة لتعديلها'),
              ],
            ),
          ),
          _button('حصة', () {
            if (demoTime != null) {
              _message('عد إلى وقت الهاتف لتعديل الحصص.');
            } else {
              _edit(weekDay: index);
            }
          }, icon: Icons.add),
        ],
      ),
      if (lessons.isNotEmpty) ...[
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _sub('تقدّم الدوام'),
            _sub('${done.length} من ${lessons.length}'),
          ],
        ),
        Row(
          children: [
            for (var i = 0; i < lessons.length; i++)
              Expanded(
                child: Container(
                  height: 5,
                  margin: EdgeInsetsDirectional.only(
                    end: i + 1 == lessons.length ? 0 : 4,
                  ),
                  decoration: BoxDecoration(
                    color: lessons[i] == current
                        ? green
                        : done.contains(lessons[i])
                        ? Color.lerp(wash, green, .43)
                        : wash,
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
              ),
          ],
        ),
      ],
      if (cards.isEmpty)
        _sub(vacation ? 'إجازة في هذا اليوم.' : 'لا توجد حصص لهذا اليوم.'),
      _stack([
        for (var i = 0; i < cards.length; i++)
          _lessonCard(
            cards[i],
            i,
            date: moment,
            moment: moment,
            compact: true,
            onTap: () {
              if (demoTime != null) {
                _message('عد إلى وقت الهاتف لتعديل الحصص.');
              } else {
                _edit(
                  lesson: cards[i],
                  date: dateOverride ? moment : null,
                  weekDay: index,
                );
              }
            },
            actions: demoTime == null && index == selectedDay,
          ),
      ], gap: 6),
    ]);
    final embedded = widget.darkOverride != null;
    if (s.focus) {
      return _stack([hero, if (embedded) _referenceHeader(dark), if (clockControls) _clockControls()]);
    }
    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth <= 694;
        return _stack([
          hero,
          if (embedded) _referenceHeader(dark),
          if (mobile) ...[
            if (clockControls) _clockControls(),
            today,
            _vibrationCard(compact: true),
          ] else
            _columns(
              today,
              _stack([_clockControls(), _vibrationCard(compact: true)]),
            ),
        ], gap: mobile ? 10 : 14);
      },
    );
  }

  Widget _days() {
    const shortDays = ['أحد', 'اثن', 'ثلا', 'أرب', 'خمي', 'جمع', 'سبت'];
    return Row(
      children: [
        for (var d = 0; d < 7; d++) ...[
          if (d > 0) const SizedBox(width: 4),
          Expanded(
            child: Tooltip(
              message: weekdays[d],
              child: Semantics(
                selected: d == selectedDay,
                child: Material(
                  color: d == selectedDay ? mint : surface,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(13),
                    side: BorderSide(color: d == selectedDay ? green : line),
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(13),
                    onTap: () => setState(() => selectedDay = d),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 7,
                        horizontal: 1,
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            shortDays[d],
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 9,
                              color: d == selectedDay ? green : muted,
                            ),
                          ),
                          Text(
                            s.work[d]
                                ? '${s.week[d].where((l) => l.enabled).length}'
                                : '–',
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                              color: d == selectedDay ? green : ink,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }

  static const lessonPalette = [
    0xff5883c0,
    0xff409b77,
    0xff9267b6,
    0xffb38341,
    0xffc27089,
    0xff4c9eaa,
  ];

  Widget _lessonCard(
    Lesson lesson,
    int index, {
    required VoidCallback onTap,
    DateTime? date,
    DateTime? moment,
    bool actions = true,
    bool compact = false,
    bool showTime = true,
  }) => LessonTile(
    lesson: lesson,
    index: index,
    color: Color(
      lesson.color != 0
          ? lesson.color
          : s.cardColors[lesson.subject] ??
                lessonPalette[index % lessonPalette.length],
    ),
    date: date ?? _selectedDate(),
    now: moment ?? now,
    dark: dark,
    compact: compact,
    showTime: showTime,
    accent: green,
    exception: date != null && s.exceptions.containsKey(dateKey(date)),
    vibrationCount: s.vibrationFor(lesson).count,
    onTap: onTap,
    onActions: actions
        ? () => _lessonActions(lesson, index, date: date)
        : onTap,
  );

  Widget _timelineRow(Lesson lesson, int index) => Row(
    key: ValueKey('timeline-${lesson.id}'),
    children: [
      SizedBox(
        width: 46,
        child: Column(
          children: [
            Text(
              clock(lesson.start),
              style: TextStyle(
                color: ink,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
            ),
            Text(
              clock(lesson.end),
              style: TextStyle(color: muted, fontSize: 10),
            ),
          ],
        ),
      ),
      SizedBox(
        width: 14,
        height: 49,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(width: 1, color: line),
            Icon(
              Icons.circle,
              size: 7,
              color: Color(lessonPalette[index % lessonPalette.length]),
            ),
          ],
        ),
      ),
      Expanded(
        child: _lessonCard(
          lesson,
          index,
          compact: true,
          showTime: false,
          onTap: () => _edit(lesson: lesson),
        ),
      ),
    ],
  );

  Widget _pinnedSchedule(bool dark) => CustomScrollView(
    key: const ValueKey('weekly-scroll'),
    controller: pageScroll,
    slivers: [
      SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: 13),
        sliver: SliverToBoxAdapter(
          child: _stack([
            _referenceHeader(dark),
            _referenceHeading(
              'الخطة الأسبوعية',
              'جدول الحصص',
              'اضغط بطاقة الحصة لتغيير وقتها أو تنبيهها.',
            ),
          ], gap: 0),
        ),
      ),
      SliverPersistentHeader(
        pinned: true,
        delegate: _WeekHeader(
          color: bg,
          height: (54 * MediaQuery.textScalerOf(ctx).scale(1)).clamp(
            57.0,
            85.0,
          ),
          child: _days(),
        ),
      ),
      SliverPadding(
        padding: const EdgeInsets.fromLTRB(13, 4, 13, 20),
        sliver: SliverToBoxAdapter(child: _schedule(showHeader: false)),
      ),
    ],
  );

  Widget _schedule({bool showHeader = true}) {
    final list = [...s.week[selectedDay]]
      ..sort((a, b) => a.start.compareTo(b.start));
    final issues = audit(s).where((issue) => issue.day == selectedDay).toList();
    return _stack([
      if (showHeader)
        _referenceHeading(
          'الخطة الأسبوعية',
          'جدول الحصص',
          'اضغط بطاقة الحصة لتغيير وقتها أو تنبيهها.',
        ),
      _columns(
        _stack([
          if (showHeader) _days(),
          _panel([
            _section(
              'حصص ${weekdays[selectedDay]}',
              action: _button(
                'حصة جديدة',
                () => _edit(),
                primary: true,
                icon: Icons.add,
              ),
            ),
            if (list.isEmpty) _sub('أضف حصة للبدء بتجهيز هذا اليوم.'),
            for (var i = 0; i < list.length; i++) ...[
              if (i > 0 && list[i].start > list[i - 1].end)
                Padding(
                  padding: const EdgeInsetsDirectional.only(start: 61),
                  child: _sub('فاصل · ${list[i].start - list[i - 1].end} د'),
                ),
              _timelineRow(list[i], i),
            ],
          ]),
        ]),
        _stack([
          _panel([
            const Text(
              'إدارة اليوم',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            _switch(
              'يوم دوام',
              'الجدول الأسبوعي المعتاد',
              s.work[selectedDay],
              (value) => _commit(s.clone()..work[selectedDay] = value),
            ),
            _button('ترتيب أوقات اليوم', _autoTimes, icon: Icons.schedule),
            _button(
              'نسخ حصص اليوم إلى أيام الدوام',
              _copyDay,
              icon: Icons.calendar_today_outlined,
            ),
          ]),
          _panel([
            _cardTitle(
              Icons.check_rounded,
              'فحص الجدول',
              issues.isEmpty
                  ? 'الأوقات خالية من التداخل'
                  : 'راجع الأوقات والبيانات',
            ),
            for (final issue in issues) _sub(issue.message),
            _button('فحص الأسبوع كاملًا', _audit),
          ]),
          _panel([
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('خيارات الجدول'),
              children: [
                _button('ملخّص اليوم', _brief),
                _button('استثناء ليوم واحد', _exceptions),
                _button('تأخير بقية حصص يوم واحد', _delayDay),
                _button('إجازتي والعطل', _vacation),
                _button('مشاركة الجدول', _share),
                _button('تراجع عن آخر تعديل', () {
                  if (undo.isEmpty) {
                    _message('لا يوجد تعديل للتراجع عنه.');
                    return;
                  }
                  final previous = undo.removeLast();
                  speechController.text = previous.speechText;
                  _commit(previous, remember: false);
                }),
              ],
            ),
          ]),
        ]),
      ),
    ]);
  }

  Future<void> _showEditorDialog(WidgetBuilder builder) async {
    final navigator = navKey.currentState!;
    final route = DialogRoute<void>(
      context: ctx,
      builder: builder,
      barrierLabel: MaterialLocalizations.of(ctx).modalBarrierDismissLabel,
    );
    await navigator.push(route);
    // Text fields still use their controllers during the exit transition.
    await route.completed;
  }

  Future<void> _modal(String title, Widget child) async {
    await _showEditorDialog(
      (context) => Dialog(
        insetPadding: const EdgeInsets.all(16),
        backgroundColor: surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(21),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: ink,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      tooltip: 'إغلاق',
                      icon: const Icon(Icons.close, size: 20),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                child,
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<bool> _confirm(String title, String description) async =>
      await showDialog<bool>(
        context: ctx,
        builder: (context) => AlertDialog(
          title: Text(title),
          content: Text(description),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('تأكيد'),
            ),
          ],
        ),
      ) ??
      false;
  Future<DateTime?> _date(DateTime initial) => showDatePicker(
    context: ctx,
    initialDate: initial,
    firstDate: DateTime(2020),
    lastDate: DateTime(2100),
    helpText: 'اختيار التاريخ',
    cancelText: 'إلغاء',
    confirmText: 'اختيار',
  );
  Future<void> _brief() async {
    final list = s.effective(now);
    await _modal(
      'ملخّص اليوم',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sub('${weekdays[dayIndex(now)]} · ${dateKey(now)}'),
          if (s.vacation(now)) _sub('إجازة حتى ${s.vacationUntil}'),
          if (list.isEmpty) _sub('لا توجد حصص مفعّلة اليوم.'),
          for (var i = 0; i < list.length; i++)
            _lessonCard(
              list[i],
              i,
              date: dayDate(now),
              actions: false,
              onTap: () {
                navKey.currentState!.pop();
                _edit(lesson: list[i], date: dayDate(now));
              },
            ),
        ],
      ),
    );
  }

  Future<void> _vacation() async {
    DateTime end = DateTime.tryParse(s.vacationUntil) ?? dayDate(now);
    await _modal(
      'إجازتي والعطل',
      StatefulBuilder(
        builder: (context, update) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sub(
              'تتوقف التنبيهات حتى نهاية التاريخ المحدد، ثم تستأنف تلقائيًا.',
            ),
            const SizedBox(height: 14),
            _button('آخر يوم للإجازة: ${dateKey(end)}', () async {
              final picked = await _date(end);
              if (picked != null) {
                update(() => end = picked);
              }
            }),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: _button('بدء الإجازة', () {
                if (dayDate(end).isBefore(dayDate(now))) {
                  _message('اختر اليوم أو تاريخًا لاحقًا.');
                  return;
                }
                Navigator.pop(context);
                _commit(s.clone()..vacationUntil = dateKey(end));
              }, primary: true),
            ),
            _button('إنهاء الإجازة الآن', () {
              Navigator.pop(context);
              _commit(s.clone()..vacationUntil = '');
            }),
          ],
        ),
      ),
    );
  }

  Future<void> _edit({Lesson? lesson, DateTime? date, int? weekDay}) async {
    final day = date == null ? weekDay ?? selectedDay : dayIndex(date),
        baseList = date == null
            ? s.week[day]
            : s.effective(date, configuredOnly: false);
    final fallbackStart = baseList.isEmpty
        ? 480
        : baseList.map((l) => l.end).reduce((a, b) => a > b ? a : b);
    var start = lesson?.start ?? fallbackStart,
        end = lesson?.end ?? (fallbackStart + 40).clamp(0, 1439),
        mode = lesson?.mode ?? 'both',
        enabled = lesson?.enabled ?? true,
        grade = lesson?.grade ?? '';
    var once = date != null;
    var vibrationCount = lesson?.vibrationCount ?? 0;
    var lessonColor = lesson?.color ?? 0;
    var testedVibration = false;
    final fixedDate = date ?? dayDate(now, (day - dayIndex(now) + 7) % 7);
    final subject = TextEditingController(text: lesson?.subject ?? '');
    final section = TextEditingController(text: lesson?.section ?? ''),
        place = TextEditingController(text: lesson?.place ?? '');
    await _showEditorDialog(
      (context) => StatefulBuilder(
        builder: (context, update) => Dialog(
          insetPadding: const EdgeInsets.all(16),
          backgroundColor: surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                21,
                16,
                21,
                21 + MediaQuery.viewInsetsOf(context).bottom,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          lesson == null ? 'إضافة حصة جديدة' : 'تعديل الحصة',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: ink,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                  _sub(date == null ? weekdays[day] : dateKey(date)),
                  const SizedBox(height: 14),
                  TextField(
                    controller: subject,
                    maxLength: 60,
                    decoration: const InputDecoration(
                      labelText: 'اسم المادة',
                      counterText: '',
                    ),
                  ),
                  const SizedBox(height: 9),
                  Wrap(
                    spacing: 5,
                    children: [
                      for (final name in {
                        ...s.week
                            .expand((a) => a)
                            .map((l) => l.subject)
                            .where((name) => name.isNotEmpty),
                        ...subjects,
                      }.take(8))
                        ActionChip(
                          label: Text(
                            name,
                            style: const TextStyle(fontSize: 10),
                          ),
                          onPressed: () => subject.text = name,
                        ),
                    ],
                  ),
                  const SizedBox(height: 9),
                  DropdownButtonFormField<String>(
                    initialValue: grades.contains(grade) ? grade : '',
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'الصف'),
                    items: [
                      const DropdownMenuItem(
                        value: '',
                        child: Text('اختر الصف'),
                      ),
                      for (final g in grades)
                        DropdownMenuItem(value: g, child: Text(g)),
                    ],
                    onChanged: (v) => grade = v ?? '',
                  ),
                  const SizedBox(height: 10),
                  _pair(
                    TextField(
                      controller: section,
                      maxLength: 20,
                      decoration: const InputDecoration(
                        labelText: 'الشعبة',
                        counterText: '',
                      ),
                    ),
                    TextField(
                      controller: place,
                      maxLength: 60,
                      decoration: const InputDecoration(
                        labelText: 'مكان الحصة',
                        counterText: '',
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _pair(
                    _button('البداية ${clock(start)}', () async {
                      final t = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay(
                          hour: start ~/ 60,
                          minute: start % 60,
                        ),
                        helpText: 'بداية الحصة',
                        cancelText: 'إلغاء',
                        confirmText: 'اختيار',
                      );
                      if (t != null) {
                        update(() => start = t.hour * 60 + t.minute);
                      }
                    }),
                    _button('النهاية ${clock(end)}', () async {
                      final t = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay(
                          hour: end ~/ 60,
                          minute: end % 60,
                        ),
                        helpText: 'نهاية الحصة',
                        cancelText: 'إلغاء',
                        confirmText: 'اختيار',
                      );
                      if (t != null) {
                        update(() => end = t.hour * 60 + t.minute);
                      }
                    }),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: mode,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'طريقة التنبيه',
                    ),
                    items: [
                      for (final entry in alertNames.entries)
                        DropdownMenuItem(
                          value: entry.key,
                          child: Text(
                            entry.value,
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                    ],
                    onChanged: (v) => update(() => mode = v ?? 'notification'),
                  ),
                  const SizedBox(height: 12),
                  _sub('لون بطاقة الحصة'),
                  Wrap(
                    spacing: 6,
                    runSpacing: 5,
                    children: [
                      ChoiceChip(
                        label: const Text('تلقائي'),
                        selected: lessonColor == 0,
                        onSelected: (_) => update(() => lessonColor = 0),
                      ),
                      for (var i = 0; i < lessonPalette.length; i++)
                        _smallSwatch(
                          lessonPalette[i],
                          'لون الحصة ${i + 1}',
                          lessonColor == lessonPalette[i],
                          () => update(() => lessonColor = lessonPalette[i]),
                        ),
                    ],
                  ),
                  if (mode == 'vibration' || mode == 'both') ...[
                    const SizedBox(height: 12),
                    DropdownButtonFormField<int>(
                      key: ValueKey('lesson-vibration-$vibrationCount'),
                      initialValue: vibrationCount,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'عدد هزات هذه الحصة',
                      ),
                      items: [
                        DropdownMenuItem(
                          value: 0,
                          child: Text(
                            'النمط العام · ${vibrationCountLabel(s.vibration.count)}',
                          ),
                        ),
                        for (var n = 1; n <= 12; n++)
                          DropdownMenuItem(
                            value: n,
                            child: Text(vibrationCountLabel(n)),
                          ),
                      ],
                      onChanged: (n) {
                        if (testedVibration) {
                          _stopVibration(report: false);
                        }
                        update(() => vibrationCount = n ?? 0);
                      },
                    ),
                    const SizedBox(height: 8),
                    _vibrationWave(
                      s.vibration.copyWith(
                        count: vibrationCount == 0 ? null : vibrationCount,
                      ),
                    ),
                    Wrap(
                      spacing: 6,
                      runSpacing: 5,
                      children: [
                        _button('اختبار هزات الحصة', () {
                          testedVibration = true;
                          _testVibration(
                            s.vibration.copyWith(
                              count: vibrationCount == 0
                                  ? null
                                  : vibrationCount,
                            ),
                            inEditor: true,
                          );
                        }, icon: Icons.play_arrow_rounded),
                        _button(
                          'إيقاف',
                          _stopVibration,
                          icon: Icons.stop_outlined,
                        ),
                      ],
                    ),
                  ],
                  _switch(
                    'الحصة مفعّلة',
                    'يجب تحديد المادة والصف',
                    enabled,
                    (v) => update(() => enabled = v),
                  ),
                  if (date == null)
                    _switch(
                      'لهذا التاريخ فقط',
                      dateKey(fixedDate),
                      once,
                      (v) => update(() => once = v),
                    )
                  else
                    _sub('استثناء لهذا التاريخ فقط؛ يبقى الأسبوع محفوظًا.'),
                  SizedBox(
                    width: double.infinity,
                    child: _button('حفظ الحصة', () async {
                      if (subject.text.trim().isEmpty || grade.isEmpty) {
                        _message('اكتب اسم المادة واختر الصف.');
                        return;
                      }
                      if (end <= start) {
                        _message('يجب أن تكون النهاية بعد البداية.');
                        return;
                      }
                      final next = s.clone();
                      final list = once
                          ? List<Lesson>.of(
                              next.exceptions[dateKey(fixedDate)]?.lessons ??
                                  (date != null ? baseList : next.week[day]),
                            )
                          : next.week[day];
                      final id =
                          lesson?.id ??
                          'd${day}t${DateTime.now().microsecondsSinceEpoch}';
                      final changed = Lesson(
                        id: id,
                        subject: subject.text.trim(),
                        grade: grade,
                        section: section.text.trim(),
                        place: place.text.trim(),
                        tone: lesson?.tone ?? 'global',
                        toneUri: lesson?.toneUri ?? '',
                        toneName: lesson?.toneName ?? '',
                        allowSpeech: lesson?.allowSpeech ?? true,
                        vibrationCount: vibrationCount,
                        color: lessonColor,
                        start: start,
                        end: end,
                        enabled: enabled,
                        mode: mode,
                      );
                      if (enabled &&
                          list.any(
                            (v) =>
                                v.id != id &&
                                v.enabled &&
                                start < v.end &&
                                end > v.start,
                          )) {
                        _message(
                          'يتداخل الوقت مع حصة أخرى؛ غيّر البداية أو النهاية.',
                        );
                        return;
                      }
                      final target = list.indexWhere((l) => l.id == id);
                      if (target < 0) {
                        list.add(changed);
                      } else {
                        list[target] = changed;
                      }
                      list.sort((a, b) => a.start.compareTo(b.start));
                      if (once) {
                        next.exceptions[dateKey(fixedDate)] = DayOverride(
                          lessons: list,
                        );
                      } else {
                        next.week[day] = list;
                      }
                      Navigator.pop(context);
                      await _commit(
                        next,
                        editLabel:
                            'حُفظت حصة ${changed.subject} · ${weekdays[day]}',
                      );
                      _message('تم حفظ الحصة.');
                    }, primary: true),
                  ),
                  if (lesson != null) ...[
                    const SizedBox(height: 12),
                    _button('إعادة ضبط هذه الحصة', () async {
                      final next = s.clone();
                      final list = once
                          ? List<Lesson>.of(
                              next.exceptions[dateKey(fixedDate)]?.lessons ??
                                  baseList,
                            )
                          : next.week[day];
                      final target = list.indexWhere((l) => l.id == lesson.id);
                      if (target >= 0) {
                        final pos = baseList.indexWhere(
                          (l) => l.id == lesson.id,
                        );
                        final reset = Lesson(
                          id: lesson.id,
                          start: pos >= 0 && pos < originalStarts.length
                              ? originalStarts[pos]
                              : lesson.start,
                          end: pos >= 0 && pos < originalStarts.length
                              ? originalEnds[pos]
                              : lesson.end,
                        );
                        list[target] = reset;
                      }
                      if (once) {
                        next.exceptions[dateKey(fixedDate)] = DayOverride(
                          lessons: list,
                        );
                      }
                      Navigator.pop(context);
                      await _commit(next);
                      _message('أُوقفت الحصة وأُعيد ضبطها؛ التراجع متاح.');
                    }),
                    _sub(
                      'يمسح المادة والصف ويوقف الحصة. يمكنك التراجع من الجدول.',
                    ),
                    TextButton(
                      onPressed: () async {
                        final next = s.clone();
                        final list = once
                            ? List<Lesson>.of(
                                next.exceptions[dateKey(fixedDate)]?.lessons ??
                                    baseList,
                              )
                            : next.week[day];
                        list.removeWhere((l) => l.id == lesson.id);
                        if (once) {
                          next.exceptions[dateKey(fixedDate)] = DayOverride(
                            lessons: list,
                          );
                        }
                        Navigator.pop(context);
                        await _commit(next);
                        _message('حُذفت الحصة؛ التراجع متاح.');
                      },
                      child: const Text(
                        'حذف الحصة',
                        style: TextStyle(color: Color(0xffa9554e)),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
    if (testedVibration && mounted) {
      await _stopVibration(report: false);
    }
    subject.dispose();
    section.dispose();
    place.dispose();
  }

  Future<void> _lessonActions(
    Lesson lesson,
    int index, {
    DateTime? date,
  }) async {
    final targetDate = date ?? _selectedDate();
    await _modal(
      'الحصة ${index + 1} · ${lesson.subject.isEmpty ? 'غير مضبوطة' : lesson.subject}',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sub(
            '${lesson.grade} ${lesson.section} · ${clock(lesson.start)} — ${clock(lesson.end)}',
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: _button('تعديل الحصة', () {
              navKey.currentState!.pop();
              _edit(lesson: lesson, date: date);
            }),
          ),
          SizedBox(
            width: double.infinity,
            child: _button('نسخ إلى أيام محددة', () {
              navKey.currentState!.pop();
              _copyOne(lesson);
            }),
          ),
          SizedBox(
            width: double.infinity,
            child: _button('إيقافها لهذا التاريخ فقط', () async {
              try {
                final next = pauseLessonForDate(s, targetDate, lesson.id);
                navKey.currentState!.pop();
                await _commit(next);
                _message('أُوقفت الحصة في ${dateKey(targetDate)} فقط.');
              } on ArgumentError catch (e) {
                _message('${e.message}');
              }
            }),
          ),
          SizedBox(
            width: double.infinity,
            child: _button('نغمة وتذكير هذه الحصة', () {
              navKey.currentState!.pop();
              _lessonTone(lesson, date: date);
            }),
          ),
        ],
      ),
    );
  }

  Future<void> _copyOne(Lesson lesson) async {
    final targets = <int>{};
    await _modal(
      'نسخ حصة إلى أيام محددة',
      StatefulBuilder(
        builder: (context, update) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sub('تُضاف نسخة مستقلة من الحصة. يُفحص تداخل الوقت قبل النسخ.'),
            for (var d = 0; d < 7; d++)
              CheckboxListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(weekdays[d], style: const TextStyle(fontSize: 13)),
                subtitle: !s.work[d]
                    ? const Text(
                        'يوم غير مفعّل؛ سيبقى غير مفعّل بعد النسخ',
                        style: TextStyle(fontSize: 10),
                      )
                    : null,
                value: targets.contains(d),
                onChanged: (v) => update(() {
                  if (v == true) {
                    targets.add(d);
                  } else {
                    targets.remove(d);
                  }
                }),
              ),
            SizedBox(
              width: double.infinity,
              child: _button('نسخ الحصة', () async {
                try {
                  final next = copyLessonToDays(s, lesson, targets);
                  Navigator.pop(context);
                  await _commit(next);
                  _message('تم نسخ الحصة إلى ${targets.length} أيام.');
                } on ArgumentError catch (e) {
                  _message('${e.message}');
                }
              }, primary: true),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _delayDay() async {
    var date = _selectedDate(), from = 0;
    final amount = TextEditingController(text: '10');
    await _modal(
      'تأخير بقية حصص يوم واحد',
      StatefulBuilder(
        builder: (context, update) {
          final list = s.effective(date, configuredOnly: false);
          if (from >= list.length) {
            from = 0;
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _sub('يُحفظ كتعديل لهذا التاريخ فقط، دون تغيير الجدول الأسبوعي.'),
              _button('التاريخ: ${dateKey(date)}', () async {
                final picked = await _date(date);
                if (picked != null) {
                  update(() {
                    date = picked;
                    from = 0;
                  });
                }
              }),
              const SizedBox(height: 12),
              if (list.isNotEmpty)
                DropdownButtonFormField<int>(
                  key: ValueKey('delay-${dateKey(date)}'),
                  initialValue: from,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'ابدأ التأخير من الحصة',
                  ),
                  items: [
                    for (var i = 0; i < list.length; i++)
                      DropdownMenuItem(
                        value: i,
                        child: Text(
                          'الحصة ${i + 1} · ${list[i].subject}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                  ],
                  onChanged: (v) => from = v ?? 0,
                ),
              const SizedBox(height: 12),
              TextField(
                controller: amount,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'مقدار التأخير بالدقائق',
                ),
              ),
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: _button('معاينة التوقيت', () {
                  final minutes = int.tryParse(amount.text);
                  if (minutes == null) {
                    _message('أدخل عدد دقائق صحيحًا.');
                    return;
                  }
                  try {
                    final preview = delayDay(s, date, from, minutes);
                    Navigator.pop(context);
                    _modal(
                      'معاينة التأخير',
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _sub('${dateKey(date)} · تأخير $minutes دقائق'),
                          for (final l in preview.effective(
                            date,
                            configuredOnly: false,
                          ))
                            _sub(
                              '${l.subject.isEmpty ? 'حصة غير مضبوطة' : l.subject} · ${clock(l.start)} — ${clock(l.end)}',
                            ),
                          const SizedBox(height: 15),
                          _button('اعتماد التوقيت', () {
                            navKey.currentState!.pop();
                            _commit(preview);
                          }, primary: true),
                        ],
                      ),
                    );
                  } on ArgumentError catch (e) {
                    _message('${e.message}');
                  }
                }, primary: true),
              ),
            ],
          );
        },
      ),
    );
    amount.dispose();
  }

  Future<void> _lessonTone(Lesson lesson, {DateTime? date}) async {
    var tone = lesson.tone,
        uri = lesson.toneUri,
        name = lesson.toneName,
        allow = lesson.allowSpeech;
    final d = date == null ? selectedDay : dayIndex(date);
    await _modal(
      'نغمة وتذكير الحصة',
      StatefulBuilder(
        builder: (context, update) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sub('${lesson.subject} · ${lesson.grade}'),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              key: ValueKey('tone-$tone'),
              initialValue: tone,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'نغمة الحصة'),
              items: const [
                DropdownMenuItem(
                  value: 'global',
                  child: Text('استخدام النغمة العامة'),
                ),
                DropdownMenuItem(value: 'classic', child: Text('جرس كلاسيكي')),
                DropdownMenuItem(value: 'soft', child: Text('نغمة هادئة')),
                DropdownMenuItem(value: 'doubleBell', child: Text('جرس مزدوج')),
                DropdownMenuItem(
                  value: 'device',
                  child: Text('نغمة من الهاتف'),
                ),
              ],
              onChanged: (v) => update(() => tone = v ?? 'global'),
            ),
            if (tone == 'device') ...[
              _button('اختيار نغمة لهذه الحصة', () async {
                if (!widget.platformEnabled) {
                  return;
                }
                try {
                  final chosen = await DeviceService.pickTone();
                  if (chosen != null) {
                    update(() {
                      uri = chosen['uri'] as String;
                      name = chosen['name'] as String;
                    });
                  }
                } catch (_) {
                  _message('تعذر قراءة النغمة.');
                }
              }),
              _sub(
                name.isEmpty
                    ? (s.toneName.isEmpty ? 'لم تُختر نغمة بعد' : s.toneName)
                    : name,
              ),
            ],
            _switch(
              'السماح بالإعلان المنطوق',
              'يتطلب أيضًا تفعيل مفتاح التذكير المنطوق العام في الإعدادات.',
              allow,
              (v) => update(() => allow = v),
            ),
            _button('تجربة نغمة الحصة', () async {
              final temporary = s.clone();
              if (tone != 'global') {
                temporary.tone = tone;
                if (tone == 'device') {
                  temporary.toneUri = uri.isEmpty ? s.toneUri : uri;
                }
              }
              if (temporary.tone == 'device' && temporary.toneUri.isEmpty) {
                _message('اختر نغمة من الهاتف أولًا.');
                return;
              }
              if (widget.platformEnabled) {
                await DeviceService.testTone(temporary);
              }
            }),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: _button('حفظ الاختيارات', () async {
                if (tone == 'device' && uri.isEmpty && s.toneUri.isEmpty) {
                  _message('اختر نغمة من الهاتف أولًا.');
                  return;
                }
                final next = s.clone();
                final list = date == null
                    ? next.week[d]
                    : List<Lesson>.of(
                        next.exceptions[dateKey(date)]?.lessons ??
                            next.effective(date, configuredOnly: false),
                      );
                final i = list.indexWhere((v) => v.id == lesson.id);
                if (i < 0) {
                  _message('الحصة لم تعد موجودة.');
                  return;
                }
                list[i] = list[i].copyWith(
                  tone: tone,
                  toneUri: uri,
                  toneName: name,
                  allowSpeech: allow,
                );
                if (date != null) {
                  next.exceptions[dateKey(date)] = DayOverride(lessons: list);
                }
                Navigator.pop(context);
                await _commit(next);
                _message('حُفظت اختيارات الحصة.');
              }, primary: true),
            ),
          ],
        ),
      ),
    );
  }

  Timer? minuteTest;
  Future<void> _minuteTest() async {
    if (!widget.platformEnabled) {
      return;
    }
    try {
      var status = await DeviceService.status();
      if (status['notifications'] != true) {
        await DeviceService.requestNotifications();
        status = await DeviceService.status();
      }
      if (status['notifications'] != true) {
        _message('اسمح بإشعارات التطبيق أولًا.');
        return;
      }
      if (status['vibrator'] != true) {
        _message('لم يبلّغ الهاتف عن هزاز متاح.');
        return;
      }
      if (status['exact'] != true) {
        _message('اضغط السماح بالتنبيه الدقيق ثم أعد الاختبار.');
        return;
      }
      await queue;
      final scheduled = await DeviceService.channel.invokeMethod<bool>(
        'scheduleTest',
        s.encode(),
      );
      if (scheduled != true) {
        _message('تعذّر جدولة الاختبار. راجع جاهزية التنبيهات.');
        return;
      }
      await _refresh();
      minuteTest?.cancel();
      if (!mounted) {
        return;
      }
      minuteTest = Timer(const Duration(seconds: 65), _refresh);
      _message('جُدول الاختبار بعد دقيقة. اقفل الشاشة الآن.');
    } catch (_) {
      _message('تعذّر بدء اختبار قفل الشاشة.');
    }
  }

  Future<void> _autoTimes() async {
    final day = selectedDay;
    final list = [...s.week[day]]..sort((a, b) => a.start.compareTo(b.start));
    if (list.isEmpty) {
      _message('أضف حصة أولًا.');
      return;
    }
    var start = list.first.start;
    final duration = TextEditingController(text: '40');
    final rest = TextEditingController(text: '5');
    await _modal(
      'ترتيب أوقات اليوم',
      StatefulBuilder(
        builder: (context, update) {
          final d = int.tryParse(duration.text), r = int.tryParse(rest.text);
          final valid =
              d != null &&
              r != null &&
              d >= 10 &&
              d <= 180 &&
              r >= 0 &&
              r <= 60 &&
              start + list.length * d + (list.length - 1) * r < 1440;
          final proposal = !valid
              ? <Lesson>[]
              : [
                  for (var i = 0; i < list.length; i++)
                    list[i].copyWith(
                      start: start + i * (d + r),
                      end: start + i * (d + r) + d,
                    ),
                ];
          return _stack([
            _sub('${weekdays[day]} · معاينة قبل الحفظ'),
            _button('بداية الحصة الأولى ${clock(start)}', () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: TimeOfDay(hour: start ~/ 60, minute: start % 60),
              );
              if (picked != null && context.mounted) {
                update(() => start = picked.hour * 60 + picked.minute);
              }
            }),
            _pair(
              TextField(
                controller: duration,
                keyboardType: TextInputType.number,
                onChanged: (_) => update(() {}),
                decoration: const InputDecoration(
                  labelText: 'مدة الحصة بالدقائق',
                ),
              ),
              TextField(
                controller: rest,
                keyboardType: TextInputType.number,
                onChanged: (_) => update(() {}),
                decoration: const InputDecoration(labelText: 'الفاصل بالدقائق'),
              ),
            ),
            if (!valid)
              _sub('راجع المدة والفاصل. يجب أن تنتهي الحصص قبل منتصف الليل.'),
            for (var i = 0; i < proposal.length; i++)
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: wash,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: _sub(
                  '${proposal[i].subject.isEmpty ? 'الحصة ${i + 1}' : proposal[i].subject} · ${clock(proposal[i].start)}–${clock(proposal[i].end)}',
                ),
              ),
            if (valid)
              _button('اعتماد الأوقات', () async {
                final next = s.clone()..week[day] = proposal;
                Navigator.pop(context);
                await _commit(
                  next,
                  editLabel: 'رُتّبت أوقات حصص ${weekdays[day]}.',
                );
                _message('حُفظت الأوقات الجديدة.');
              }, primary: true),
          ]);
        },
      ),
    );
    duration.dispose();
    rest.dispose();
  }

  Future<void> _copyDay() async {
    if (!await _confirm(
      'نسخ حصص اليوم',
      'سيستبدل حصص بقية أيام الدوام بنسخة من ${weekdays[selectedDay]}. يمكنك التراجع عن آخر تعديل.',
    )) {
      return;
    }
    final next = s.clone();
    for (var d = 0; d < 7; d++) {
      if (d != selectedDay && s.work[d]) {
        next.week[d] = s.week[selectedDay]
            .map((l) => l.copyWith(id: 'd${d}_${l.id}'))
            .toList();
      }
    }
    await _commit(next);
    _message('تم نسخ اليوم.');
  }

  Future<void> _audit() async {
    final issues = audit(s);
    await _modal(
      'فحص الجدول الذكي',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (issues.isEmpty)
            _sub(
              '✓ لا توجد أوقات متداخلة أو بيانات ناقصة في حصص أيام الدوام المفعّلة.',
            ),
          for (final issue in issues)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Text(
                issue.message,
                style: TextStyle(color: ink, fontSize: 12),
              ),
            ),
          const SizedBox(height: 14),
          _button('اقتراح أوقات لهذا اليوم', () {
            navKey.currentState!.pop();
            _repair();
          }),
        ],
      ),
    );
  }

  Future<void> _repair() async {
    final proposal = proposeTimes(s.week[selectedDay]);
    if (proposal == null) {
      _message('لا توجد مساحة كافية ضمن اليوم.');
      return;
    }
    final moved = [
      for (var i = 0; i < proposal.length; i++)
        if (proposal[i].start != s.week[selectedDay][i].start ||
            proposal[i].end != s.week[selectedDay][i].end)
          i,
    ].length;
    await _modal(
      'مقترح أوقات بلا تداخل',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sub('$moved حصص ستتغيّر · تبقى المواد والصفوف محفوظة.'),
          for (var i = 0; i < proposal.length; i++)
            _sub(
              '${i + 1}. ${proposal[i].subject} · ${clock(proposal[i].start)} — ${clock(proposal[i].end)}',
            ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: _button('اعتماد المقترح', () {
              navKey.currentState!.pop();
              final next = s.clone();
              next.week[selectedDay] = proposal;
              _commit(next);
            }, primary: true),
          ),
        ],
      ),
    );
  }

  Future<void> _exceptions() async {
    DateTime date = dayDate(now);
    await _modal(
      'استثناء ليوم واحد',
      StatefulBuilder(
        builder: (context, update) {
          final list = s.effective(date, configuredOnly: false),
              key = dateKey(date),
              override = s.exceptions[key];
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _sub('غيّر هذا التاريخ فقط مع الاحتفاظ بالجدول الأسبوعي.'),
              const SizedBox(height: 10),
              _button('${weekdays[dayIndex(date)]} · $key', () async {
                final picked = await _date(date);
                if (picked != null) {
                  update(() => date = picked);
                }
              }),
              const SizedBox(height: 12),
              if (override?.closed == true) _sub('أُلغيت حصص هذا اليوم.'),
              for (var i = 0; i < list.length; i++)
                _lessonCard(
                  list[i],
                  i,
                  date: date,
                  actions: false,
                  onTap: () {
                    Navigator.pop(context);
                    _edit(lesson: list[i], date: date);
                  },
                ),
              _button('إضافة حصة لهذا التاريخ', () {
                Navigator.pop(context);
                _edit(date: date);
              }),
              _button('إلغاء جميع حصص هذا التاريخ', () async {
                final next = s.clone();
                next.exceptions[key] = DayOverride(closed: true);
                await _commit(next);
                if (context.mounted) {
                  update(() {});
                }
              }),
              if (override != null)
                _button('إزالة الاستثناء واستعادة الجدول', () async {
                  final next = s.clone();
                  next.exceptions.remove(key);
                  await _commit(next);
                  if (context.mounted) {
                    update(() {});
                  }
                }),
            ],
          );
        },
      ),
    );
  }

  String colorTarget = '__hero__';
  static const palette = <int, String>{
    0xff173f39: 'أخضر عميق',
    0xff287b64: 'زمردي',
    0xff376db4: 'أزرق',
    0xff7860a5: 'بنفسجي',
    0xffba7a31: 'ذهبي',
    0xffb75b78: 'وردي',
    0xffb65d4b: 'مرجاني',
    0xff418b98: 'فيروزي',
  };
  Widget _colors() {
    final names = s.week
        .expand((l) => l)
        .map((l) => l.subject)
        .where((v) => v.isNotEmpty)
        .toSet()
        .toList();
    if (colorTarget != '__hero__' && !names.contains(colorTarget)) {
      colorTarget = '__hero__';
    }
    final chosen = colorTarget == '__hero__'
        ? s.heroColor
        : _subjectColor(colorTarget).toARGB32();
    return _card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _section('ألوان البطاقات'),
          DropdownButtonFormField<String>(
            key: ValueKey('target-$colorTarget'),
            initialValue: colorTarget,
            isExpanded: true,
            items: [
              const DropdownMenuItem(
                value: '__hero__',
                child: Text(
                  'البطاقة الرئيسية الكبيرة',
                  style: TextStyle(fontSize: 12),
                ),
              ),
              for (final name in names)
                DropdownMenuItem(
                  value: name,
                  child: Text(
                    'بطاقات $name',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
            ],
            onChanged: (v) => setState(() => colorTarget = v ?? '__hero__'),
          ),
          const SizedBox(height: 16),
          LayoutBuilder(
            builder: (context, constraints) {
              final width = (constraints.maxWidth - 24) / 4;
              return Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final entry in palette.entries)
                    SizedBox(
                      width: width,
                      child: Semantics(
                        selected: chosen == entry.key,
                        label: 'اختيار اللون ${entry.value}',
                        button: true,
                        child: InkWell(
                          onTap: () {
                            final next = s.clone();
                            if (colorTarget == '__hero__') {
                              next.heroColor = entry.key;
                            } else {
                              next.cardColors[colorTarget] = entry.key;
                            }
                            _commit(next, schedule: false);
                          },
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                              color: bg,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: chosen == entry.key
                                    ? green
                                    : Colors.transparent,
                                width: 2,
                              ),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  height: 43,
                                  decoration: BoxDecoration(
                                    color: Color(entry.key),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  alignment: Alignment.center,
                                  child: Icon(
                                    chosen == entry.key
                                        ? Icons.check
                                        : Icons.view_agenda_outlined,
                                    color: Colors.white.withValues(alpha: .8),
                                    size: 21,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  child: Text(
                                    entry.value,
                                    style: TextStyle(fontSize: 9, color: muted),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          TextButton(
            onPressed: () {
              final next = s.clone();
              if (colorTarget == '__hero__') {
                next.heroColor = defaultHeroColor;
              } else {
                next.cardColors.remove(colorTarget);
              }
              _commit(next, schedule: false);
            },
            child: const Text(
              'استعادة اللون الأصلي لهذه البطاقة',
              style: TextStyle(fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  final vibrationKey = GlobalKey();
  final pulseField = TextEditingController(text: '240');
  final gapField = TextEditingController(text: '160');
  final pulseIndex = ValueNotifier<int>(-1);
  final vibrationTimers = <Timer>[];
  int? pendingVibrationCount;
  int vibrationRun = 0;
  String vibrationStatus = '';
  int historyFilter = 0;

  void _openVibration() {
    _navigate(3);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final context = vibrationKey.currentContext;
      if (mounted && tab == 3 && context != null) {
        Scrollable.ensureVisible(
          context,
          duration: const Duration(milliseconds: 180),
        );
      }
    });
  }

  void _setVibrationFields(VibrationProfile p) {
    pulseField.text = '${p.pulse}';
    gapField.text = '${p.gap}';
  }

  void _clearVibrationAnimation() {
    for (final timer in vibrationTimers) {
      timer.cancel();
    }
    vibrationTimers.clear();
    pulseIndex.value = -1;
  }

  Future<void> _stopVibration({bool report = true}) async {
    vibrationRun++;
    _clearVibrationAnimation();
    if (widget.platformEnabled) {
      try {
        await DeviceService.stopVibration();
      } catch (_) {
        if (report && mounted) {
          _message('تعذّر إيقاف اختبار الهزاز.');
        }
        return;
      }
    }
    if (report && mounted) {
      setState(() => vibrationStatus = 'أُوقف اختبار الهزاز.');
    }
  }

  Future<void> _testVibration(
    VibrationProfile profile, {
    bool inEditor = false,
  }) async {
    final run = ++vibrationRun;
    _clearVibrationAnimation();
    bool sent = false;
    var failure = 'لم يعثر التطبيق على هزاز متاح في الهاتف.';
    if (widget.platformEnabled) {
      try {
        sent = await DeviceService.testVibration(profile);
      } catch (error) {
        failure = 'تعذّر تشغيل الهزاز: $error';
        sent = false;
      }
    }
    if (!mounted || run != vibrationRun) {
      return;
    }
    final label = sent
        ? 'أُرسل نمط الاهتزاز إلى الهاتف. تحقق مما تشعر به.'
        : widget.platformEnabled
        ? failure
        : 'محاكاة بصرية فقط.';
    setState(() => vibrationStatus = label);
    if (inEditor) {
      _message(label);
    }
    if (widget.platformEnabled && !sent) {
      return;
    }
    pulseIndex.value = 0;
    for (var index = 0; index < profile.count; index++) {
      final at = index * (profile.pulse + profile.gap);
      if (index > 0) {
        vibrationTimers.add(
          Timer(Duration(milliseconds: at), () => pulseIndex.value = index),
        );
      }
      vibrationTimers.add(
        Timer(
          Duration(milliseconds: at + profile.pulse),
          () => pulseIndex.value = -1,
        ),
      );
    }
    vibrationTimers.add(
      Timer(Duration(milliseconds: profile.duration + 40), () {
        vibrationTimers.clear();
        if (mounted && run == vibrationRun) {
          setState(
            () => vibrationStatus = 'انتهى عرض النمط. إذا لم تشعر بالهزات، افتح إعدادات الصوت والاهتزاز.',
          );
        }
      }),
    );
  }

  void _saveVibrationTimes() {
    final pulse = int.tryParse(pulseField.text.trim());
    final gap = int.tryParse(gapField.text.trim());
    if (pulse == null ||
        gap == null ||
        pulse < 80 ||
        pulse > 700 ||
        gap < 70 ||
        gap > 650) {
      _message('مدة الهزة من 80 إلى 700، والفاصل من 70 إلى 650 مللي ثانية.');
      return;
    }
    _commit(
      s.clone()..vibration = s.vibration.copyWith(pulse: pulse, gap: gap),
      remember: false,
    );
    _message('حُفظت مدة الهزة والفاصل.');
  }

  Widget _vibrationWave(VibrationProfile profile) =>
      ValueListenableBuilder<int>(
        valueListenable: pulseIndex,
        builder: (context, active, _) => Semantics(
          label: vibrationCountLabel(profile.count),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 7),
            height: 45,
            decoration: BoxDecoration(
              color: wash,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              textDirection: TextDirection.ltr,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < profile.count; i++)
                  Flexible(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 100),
                      width: 21,
                      height: active == i
                          ? 28
                          : i.isEven
                          ? 23
                          : 15,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        color: active == i ? green : mint,
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: green),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );

  Widget _vibrationCard({bool compact = false}) {
    final profile = s.vibration.copyWith(count: pendingVibrationCount);
    final summary =
        '${vibrationCountLabel(profile.count)} · ${profile.pulse} مللي ثانية للهزة';
    return _panel([
      _cardTitle(
        Icons.vibration,
        compact ? 'اختبار الهزاز' : 'الهزاز',
        compact ? summary : 'النمط العام للحصص التي تستخدم الاهتزاز',
      ),
      if (!compact) ...[
        Wrap(
          spacing: 6,
          runSpacing: 4,
          children: [
            for (final (name, p) in const [
              ('خفيف', VibrationProfile(count: 2, pulse: 150, gap: 130)),
              ('متوازن', VibrationProfile()),
              ('متكرر', VibrationProfile(count: 6, pulse: 190, gap: 140)),
            ])
              ChoiceChip(
                label: Text('$name · ${p.count}'),
                selected:
                    profile.count == p.count &&
                    profile.pulse == p.pulse &&
                    profile.gap == p.gap,
                onSelected: (_) {
                  _stopVibration(report: false);
                  pendingVibrationCount = null;
                  _setVibrationFields(p);
                  _commit(s.clone()..vibration = p, remember: false);
                },
              ),
          ],
        ),
        Text(
          'عدد الهزات · ${profile.count}',
          style: TextStyle(color: ink, fontWeight: FontWeight.bold),
        ),
        Slider(
          key: const ValueKey('vibration-count'),
          min: 1,
          max: 12,
          divisions: 11,
          value: profile.count.toDouble(),
          label: '${profile.count}',
          onChanged: (value) =>
              setState(() => pendingVibrationCount = value.round()),
          onChangeEnd: (value) {
            pendingVibrationCount = null;
            _commit(
              s.clone()..vibration = s.vibration.copyWith(count: value.round()),
              remember: false,
            );
          },
        ),
        _pair(
          TextField(
            controller: pulseField,
            keyboardType: TextInputType.number,
            maxLength: 3,
            decoration: const InputDecoration(
              labelText: 'مدة الهزة (مللي ثانية)',
              counterText: '',
            ),
          ),
          TextField(
            controller: gapField,
            keyboardType: TextInputType.number,
            maxLength: 3,
            decoration: const InputDecoration(
              labelText: 'الفاصل (مللي ثانية)',
              counterText: '',
            ),
          ),
        ),
        _button('حفظ المدة والفاصل', _saveVibrationTimes),
      ],
      _vibrationWave(profile),
      if (!compact) _sub(summary),
      Wrap(
        spacing: 6,
        runSpacing: 5,
        children: [
          _button(
            compact ? 'جرّب الهزاز' : 'تجربة النمط',
            () => _testVibration(profile),
            primary: true,
            icon: Icons.play_arrow_rounded,
          ),
          _button('إعدادات الصوت والاهتزاز', () async {
            if (widget.platformEnabled) {
              await DeviceService.openSettings('sound');
            }
          }, icon: Icons.settings_outlined),
          if (compact) _button('ضبط النمط', _openVibration, icon: Icons.tune),
          _button('إيقاف', _stopVibration, icon: Icons.stop_outlined),
        ],
      ),
      _sub(
        vibrationStatus.isEmpty
            ? 'اختبر النمط مباشرةً، أو جرّب تنبيه الحصة من اختبار الدقيقة.'
            : vibrationStatus,
      ),
      if (!compact) _lockTestPanel(),
    ]);
  }

  Widget _heroPalette() => _stack([
    _cardTitle(
      Icons.palette_outlined,
      'لون البطاقة الرئيسية',
      'اختر لونًا للبطاقة التي تعرض حالة حصصك',
    ),
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      decoration: BoxDecoration(
        gradient: bellGradient(Color(s.heroColor)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'الحصة الجارية',
                  style: TextStyle(color: Colors.white70, fontSize: 10),
                ),
                Text(
                  'العلوم',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: bellSignal(Color(s.heroColor)),
                width: 2,
              ),
            ),
            child: const Text(
              '23:00',
              textDirection: TextDirection.ltr,
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    ),
    Wrap(
      spacing: 6,
      runSpacing: 7,
      children: [
        for (final entry in const {
          defaultHeroColor: 'أخضر',
          0xff184a69: 'أزرق',
          0xff513774: 'بنفسجي',
          0xff734023: 'نحاسي',
          0xff712f48: 'وردي',
          0xff165655: 'فيروزي',
        }.entries)
          HeroColorTile(
            key: ValueKey('hero-color-${entry.key}'),
            color: Color(entry.key),
            name: entry.value,
            selected: s.heroColor == entry.key,
            accent: green,
            onTap: () => _commit(
              s.clone()..heroColor = entry.key,
              schedule: false,
              remember: false,
            ),
          ),
      ],
    ),
  ]);

  Widget _smallSwatch(
    int color,
    String label,
    bool active,
    VoidCallback onTap,
  ) => Tooltip(
    message: label,
    child: Semantics(
      button: true,
      selected: active,
      label: label,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: 38,
          width: 38,
          decoration: BoxDecoration(
            color: Color(color),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: active ? green : line,
              width: active ? 2 : 1,
            ),
          ),
          child: active
              ? const Icon(Icons.check_rounded, size: 18, color: Colors.white)
              : null,
        ),
      ),
    ),
  );

  Widget _appearance() => _panel([
    const Text('المظهر', style: TextStyle(fontWeight: FontWeight.bold)),
    if (widget.darkOverride == null)
      _switch(
        'الوضع الليلي',
        'ألوان مريحة في الإضاءة المنخفضة',
        s.dark,
        (v) => _commit(s.clone()..dark = v, schedule: false, remember: false),
      ),
    _heroPalette(),
    const Divider(),
    _sub('لون الواجهة'),
    Wrap(
      spacing: 7,
      runSpacing: 6,
      children: [
        for (var i = 0; i < accentColors.length; i++)
          _smallSwatch(
            accentColors[i],
            ['واجهة خضراء', 'واجهة زرقاء', 'واجهة بنفسجية', 'واجهة نحاسية'][i],
            s.accentIndex == i,
            () => _commit(
              s.clone()..accentIndex = i,
              schedule: false,
              remember: false,
            ),
          ),
      ],
    ),
    DropdownButtonFormField<int>(
      key: ValueKey('font-${s.textSize}'),
      initialValue: s.textSize,
      isExpanded: true,
      decoration: const InputDecoration(labelText: 'حجم النص'),
      items: const [
        DropdownMenuItem(value: 0, child: Text('عادي')),
        DropdownMenuItem(value: 1, child: Text('أكبر')),
        DropdownMenuItem(value: 2, child: Text('كبير جدًا')),
      ],
      onChanged: (v) {
        if (v != null) {
          _commit(
            s.clone()
              ..textSize = v
              ..large = v > 0,
            schedule: false,
            remember: false,
          );
        }
      },
    ),
    _switch(
      'وضع التركيز',
      'البطاقة الرئيسية والحصة التالية',
      s.focus,
      (v) => _commit(s.clone()..focus = v, schedule: false, remember: false),
    ),
  ]);

  Widget _alertSettings() => _panel([
    _cardTitle(
      Icons.notifications_none_rounded,
      'تنبيهات الحصص',
      'مواعيد التنبيه على أندرويد',
    ),
    _switch(
      'تفعيل الجدول',
      'جدولة التنبيهات والعمل في الخلفية',
      s.enabled,
      _toggle,
    ),
    _switch(
      'تنبيه عند انتهاء الحصة',
      'تنبيه إضافي عند النهاية',
      s.endAlert,
      (v) => _commit(s.clone()..endAlert = v, remember: false),
    ),
    DropdownButtonFormField<int>(
      key: ValueKey('reminder-${s.reminder}'),
      initialValue: s.reminder,
      isExpanded: true,
      decoration: const InputDecoration(labelText: 'التذكير قبل الحصة'),
      items: [
        for (final v in {
          ...[0, 3, 5, 10, 15, 30, 60],
          s.reminder,
        })
          DropdownMenuItem(
            value: v,
            child: Text(v == 0 ? 'عند البداية' : 'قبل $v دقائق'),
          ),
      ],
      onChanged: (v) {
        if (v != null) {
          _commit(s.clone()..reminder = v, remember: false);
        }
      },
    ),
  ]);

  Widget _soundSettings() => _panel([
    _cardTitle(
      Icons.volume_up_outlined,
      'النغمة والتذكير المنطوق',
      'جرّب الصوت من هذه البطاقة',
    ),
    DropdownButtonFormField<String>(
      key: ValueKey('tone-${s.tone}'),
      initialValue: ['classic', 'soft', 'doubleBell', 'device'].contains(s.tone)
          ? s.tone
          : 'classic',
      isExpanded: true,
      decoration: const InputDecoration(labelText: 'النغمة'),
      items: const [
        DropdownMenuItem(value: 'soft', child: Text('هادئة')),
        DropdownMenuItem(value: 'classic', child: Text('كلاسيكية')),
        DropdownMenuItem(value: 'doubleBell', child: Text('مزدوجة')),
        DropdownMenuItem(value: 'device', child: Text('ملف من الهاتف')),
      ],
      onChanged: (value) {
        if (value == 'device' && s.toneUri.isEmpty) {
          _pickTone();
        } else if (value != null) {
          _commit(s.clone()..tone = value, remember: false);
        }
      },
    ),
    if (s.tone == 'device') _sub(s.toneName),
    _button('اختيار ملف من الهاتف', _pickTone, icon: Icons.audio_file_outlined),
    _sub('مستوى صوت الاختبار والنطق ${(s.volume * 100).round()}%'),
    Slider(
      value: s.volume,
      onChanged: (value) =>
          _commit(s.clone()..volume = value, schedule: false, remember: false),
      onChangeEnd: (_) {
        if (widget.platformEnabled) {
          _syncOnResume();
        }
      },
    ),
    Wrap(
      spacing: 6,
      runSpacing: 5,
      children: [
        _button('تجربة النغمة', _testTone, icon: Icons.play_arrow),
        _button('إيقاف الصوت', () {
          if (widget.platformEnabled) {
            DeviceService.stopSound();
          }
        }, icon: Icons.stop_outlined),
      ],
    ),
    Divider(color: line),
    _switch(
      'التذكير الصوتي المنطوق',
      'يذكر اسم الحصة والمادة والصف',
      s.speech,
      (value) async {
        if (!value && widget.platformEnabled) {
          await DeviceService.stopSound();
        }
        if (mounted) {
          await _commit(s.clone()..speech = value, remember: false);
        }
      },
    ),
    if (s.speech) ...[
      TextField(
        controller: speechController,
        minLines: 2,
        maxLines: 4,
        decoration: const InputDecoration(labelText: 'نص الإعلان الصوتي'),
      ),
      _sub('استخدم {lesson} و{subject} و{grade}.'),
      Wrap(
        spacing: 6,
        runSpacing: 5,
        children: [
          _button('حفظ النص', () {
            final text = speechController.text.trim();
            _commit(
              s.clone()..speechText = text.isEmpty ? defaultSpeech : text,
            );
            _message('تم حفظ نص الإعلان.');
          }),
          _button('تجربة النطق', _speak),
        ],
      ),
    ],
  ]);

  final alertKey = GlobalKey();
  final appearanceKey = GlobalKey();
  final appSettingsKey = GlobalKey();

  Widget _settingsShortcuts() => Row(
    children: [
      for (final item in [
        ('التنبيهات', Icons.notifications_none_rounded, alertKey),
        ('الهزاز', Icons.vibration, vibrationKey),
        ('المظهر', Icons.light_mode_outlined, appearanceKey),
        ('التطبيق', Icons.tune, appSettingsKey),
      ]) ...[
        if (item.$3 != alertKey) const SizedBox(width: 7),
        Expanded(
          child: Material(
            color: surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13),
              side: BorderSide(color: line),
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(13),
              onTap: () {
                final target = item.$3.currentContext;
                if (target != null) {
                  Scrollable.ensureVisible(
                    target,
                    duration: const Duration(milliseconds: 220),
                  );
                }
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 11,
                  horizontal: 3,
                ),
                child: Column(
                  children: [
                    Icon(item.$2, size: 19, color: green),
                    const SizedBox(height: 5),
                    Text(
                      item.$1,
                      style: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ],
  );

  Widget _lockTestPanel() {
    final scheduled = device['testAt'] as num?;
    final outcome = device['testOutcome']?.toString();
    final status = [
      if (device.containsKey('vibrator'))
        device['vibrator'] == true ? 'هزاز الهاتف متاح' : 'الهزاز غير متاح',
      if (device.containsKey('notifications'))
        device['notifications'] == true
            ? 'الإشعارات مسموحة'
            : 'الإشعارات محظورة',
      if (device.containsKey('exact'))
        device['exact'] == true
            ? 'التنبيه الدقيق متاح'
            : 'التنبيه الدقيق يحتاج إذنًا',
      if (device['channelEnabled'] == false)
        'قناة التنبيه محظورة'
      else if (device['channelVibration'] == false)
        'الاهتزاز متوقف في القناة',
      if (device['dnd'] == true) 'عدم الإزعاج مفعّل',
    ].join(' · ');
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      title: const Text(
        'جاهزية الهزاز واختبار قفل الشاشة',
        style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
      ),
      onExpansionChanged: (expanded) {
        if (expanded) {
          _refresh();
        }
      },
      children: [
        if (status.isNotEmpty) _sub(status),
        if (scheduled != null && scheduled > 0)
          _sub(
            'الاختبار عند ${TimeOfDay.fromDateTime(DateTime.fromMillisecondsSinceEpoch(scheduled.toInt())).format(ctx)}. اقفل الشاشة الآن.',
          )
        else if (outcome != null)
          _sub(outcome),
        Wrap(
          spacing: 6,
          runSpacing: 5,
          children: [
            _button(
              'اختبار بعد دقيقة',
              _minuteTest,
              primary: true,
              icon: Icons.schedule,
            ),
            _button('إلغاء الاختبار', () async {
              if (!widget.platformEnabled) {
                return;
              }
              try {
                await DeviceService.channel.invokeMethod<void>('cancelTest');
                minuteTest?.cancel();
                await _refresh();
              } catch (_) {
                _message('تعذّر إلغاء الاختبار.');
              }
            }),
            _button('السماح بالإشعارات', () async {
              if (widget.platformEnabled) {
                await DeviceService.requestNotifications();
                await _refresh();
              }
            }),
            _button('إعدادات قناة التنبيه', () {
              if (widget.platformEnabled) {
                DeviceService.openSettings('vibration');
              }
            }),
            _button('السماح بالتنبيه الدقيق', () {
              if (widget.platformEnabled) {
                DeviceService.openSettings('exact');
              }
            }),
          ],
        ),
      ],
    );
  }

  Widget _settings() => _stack([
    _referenceHeading('خياراتك', 'الإعدادات', 'خصّص أسلوب التنبيه والقراءة.'),
      const CardSizeSettings('bell'),
      const CardSizeSettings('tile-bell'),
    _settingsShortcuts(),
    _columns(
      _stack([
        KeyedSubtree(key: vibrationKey, child: _vibrationCard()),
        KeyedSubtree(key: alertKey, child: _alertSettings()),
      ]),
      _stack([
        _soundSettings(),
        KeyedSubtree(key: appearanceKey, child: _appearance()),
        _panel([
          const Text(
            'جرس المعلم',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          _sub('الإصدار $appVersion · Android'),
          KeyedSubtree(
            key: appSettingsKey,
            child: _button('إعادة ضبط التطبيق', _reset),
          ),
        ]),
      ]),
      primaryFlex: 100,
    ),
    _panel([
      ExpansionTile(
        tilePadding: EdgeInsets.zero,
        title: const Text('إعدادات متقدمة'),
        subtitle: _sub('الجاهزية · اختبار تنبيه بعد دقيقة · أداة الهاتف'),
        children: [_advancedSettings()],
      ),
    ]),
  ]);

  Widget _advancedSettings() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _colors(),
      _card(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _section('نماذج الدوام الموسمية'),
            _sub(
              s.seasonal.type == 'normal'
                  ? 'الدوام المعتاد'
                  : '${s.seasonal.type == 'exam' ? 'الامتحانات' : 'رمضان'} · من ${s.seasonal.from} حتى ${s.seasonal.until}',
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: _button('تعديل نموذج الدوام', _seasonal),
            ),
            _sub('تُعاد أوقات الأسبوع المعتادة تلقائيًا بعد نهاية الفترة.'),
          ],
        ),
      ),
      _card(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _section('جاهزية التنبيهات'),
            _ready(
              'هزاز الهاتف',
              device['vibrator'] == true,
              device['vibrator'] == true
                  ? 'الهزاز متاح للاختبار'
                  : 'الهزاز غير متاح أو لم تُفحص الجاهزية',
            ),
            _ready(
              'إشعارات التطبيق',
              device['notifications'] == true,
              device['notifications'] == true ? 'مسموح بها' : 'تحتاج إلى إذن',
            ),
            _ready(
              'المنبهات الدقيقة',
              device['exact'] == true,
              device['exact'] == true
                  ? 'متاحة'
                  : 'الجدولة تقريبية حتى تسمح بها',
            ),
            _ready(
              'إعدادات البطارية',
              device['batteryExempt'] == true,
              device['batteryExempt'] == true
                  ? 'القيود مخففة'
                  : 'راجع تقييد عمل التطبيق في الخلفية',
            ),
            _sub(
              'الموعد المحفوظ: ${device['nextLabel'] ?? 'لا يوجد موعد مفعّل'}',
            ),
            const SizedBox(height: 12),
            _pair(
              _button('إذن الإشعارات', () async {
                if (widget.platformEnabled) {
                  await DeviceService.requestNotifications();
                }
                await _refresh();
              }),
              _button('التنبيهات الدقيقة', () {
                if (widget.platformEnabled) {
                  DeviceService.openSettings('exact');
                }
              }),
            ),
            const SizedBox(height: 8),
            _pair(
              _button('إعدادات البطارية', () {
                if (widget.platformEnabled) {
                  DeviceService.openSettings('battery');
                }
              }),
              _button('تحديث الجاهزية', () async {
                await _syncOnResume();
                await _refresh();
              }),
            ),
            _sub(
              'قد يؤخر النظام التنبيهات عند تقييد البطارية أو إيقاف التطبيق إجباريًا.',
            ),
          ],
        ),
      ),
      _card(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _section('أداة شاشة الهاتف'),
            _widgetPreview(),
            _sub('تعرض أقرب حصة وموعدها دون فتح التطبيق.'),
            const SizedBox(height: 12),
            _button('إضافة الأداة للشاشة', () async {
              if (!widget.platformEnabled) {
                return;
              }
              final ok =
                  await DeviceService.channel.invokeMethod<bool>('pinWidget') ??
                  false;
              if (!ok) {
                _message(
                  'اضغط مطولًا على الشاشة الرئيسية ثم اختر الأدوات ← جرس المعلم.',
                );
              }
            }),
          ],
        ),
      ),
    ],
  );
  Widget _ready(String title, bool ready, String detail) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 9),
    child: Row(
      children: [
        Icon(
          ready ? Icons.check_circle_outline : Icons.info_outline,
          color: ready ? green : const Color(0xffbc9450),
          size: 22,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: TextStyle(fontSize: 13, color: ink)),
              _sub(detail),
            ],
          ),
        ),
      ],
    ),
  );
  Widget _widgetPreview() {
    final next = s.next(now);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Color(s.heroColor),
        borderRadius: BorderRadius.circular(21),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'جرس المعلم · الحصة القادمة',
            style: TextStyle(color: Color(0xffbcd5c8), fontSize: 11),
          ),
          const SizedBox(height: 9),
          Text(
            next?.lesson.subject ?? 'جهّز جدولك',
            style: const TextStyle(
              fontSize: 23,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            next?.lesson.grade ?? 'لا توجد حصة مفعّلة',
            style: const TextStyle(color: Color(0xffbcd5c8), fontSize: 12),
          ),
          const Divider(height: 25, color: Colors.white24),
          Text(
            next == null
                ? '—'
                : '${weekdays[dayIndex(next.at)]} · ${clock(next.lesson.start)}',
            style: const TextStyle(color: Color(0xffedc477), fontSize: 12),
          ),
        ],
      ),
    );
  }

  Future<void> _seasonal() async {
    var type = s.seasonal.type,
        from = DateTime.tryParse(s.seasonal.from) ?? dayDate(now),
        until = DateTime.tryParse(s.seasonal.until) ?? dayDate(now, 6),
        start = s.seasonal.start;
    final duration = TextEditingController(text: '${s.seasonal.duration}'),
        rest = TextEditingController(text: '${s.seasonal.rest}');
    await _modal(
      'نماذج الدوام الموسمية',
      StatefulBuilder(
        builder: (context, update) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<String>(
              initialValue: type,
              isExpanded: true,
              items: const [
                DropdownMenuItem(
                  value: 'normal',
                  child: Text('الدوام المعتاد'),
                ),
                DropdownMenuItem(value: 'exam', child: Text('الامتحانات')),
                DropdownMenuItem(value: 'ramadan', child: Text('رمضان')),
              ],
              onChanged: (v) => update(() {
                type = v ?? 'normal';
                duration.text = type == 'ramadan'
                    ? '30'
                    : type == 'exam'
                    ? '60'
                    : '40';
              }),
            ),
            const SizedBox(height: 14),
            _button('من ${dateKey(from)}', () async {
              final picked = await _date(from);
              if (picked != null) {
                update(() => from = picked);
              }
            }),
            _button('حتى ${dateKey(until)}', () async {
              final picked = await _date(until);
              if (picked != null) {
                update(() => until = picked);
              }
            }),
            _button('بداية الدوام ${clock(start)}', () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: TimeOfDay(hour: start ~/ 60, minute: start % 60),
              );
              if (picked != null) {
                update(() => start = picked.hour * 60 + picked.minute);
              }
            }),
            const SizedBox(height: 12),
            TextField(
              controller: duration,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'مدة الحصة بالدقائق',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: rest,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'الاستراحة بالدقائق',
              ),
            ),
            const SizedBox(height: 15),
            SizedBox(
              width: double.infinity,
              child: _button('حفظ النموذج', () {
                final d = int.tryParse(duration.text),
                    r = int.tryParse(rest.text),
                    count = s.week
                        .map((l) => l.length)
                        .reduce((a, b) => a > b ? a : b);
                if (type != 'normal' &&
                    (d == null ||
                        r == null ||
                        d < 10 ||
                        d > 180 ||
                        r < 0 ||
                        r > 60 ||
                        until.isBefore(from) ||
                        start + count * d + (count - 1).clamp(0, 1000) * r >=
                            1440)) {
                  _message('راجع التاريخ ومدة الحصص والاستراحة.');
                  return;
                }
                final next = s.clone()
                  ..seasonal = Seasonal(
                    type: type,
                    from: dateKey(from),
                    until: dateKey(until),
                    start: start,
                    duration: d ?? 40,
                    rest: r ?? 5,
                  );
                Navigator.pop(context);
                _commit(next);
              }, primary: true),
            ),
          ],
        ),
      ),
    );
    duration.dispose();
    rest.dispose();
  }

  Future<void> _pickTone() async {
    if (!widget.platformEnabled) {
      return;
    }
    try {
      final picked = await DeviceService.pickTone();
      if (picked != null) {
        final next = s.clone()
          ..tone = 'device'
          ..toneUri = picked['uri'] as String
          ..toneName = picked['name'] as String;
        await _commit(next);
        _message('تم حفظ نغمة الهاتف.');
      }
    } catch (_) {
      _message(
        'تعذر قراءة الملف الصوتي. جرّب ملف MP3 أو WAV أصغر من 20 ميغابايت.',
      );
    }
  }

  Future<void> _testTone() async {
    if (!widget.platformEnabled) {
      return;
    }
    try {
      await DeviceService.testTone(s);
    } catch (_) {
      _message('تعذر تشغيل النغمة. اختر نغمة أخرى أو تحقق من مستوى الصوت.');
    }
  }

  Future<void> _speak() async {
    if (!s.speech) {
      _message('فعّل التذكير المنطوق أولًا.');
      return;
    }
    final lessons = s.effective(now),
        sample =
            lessons.firstOrNull ??
            const Lesson(
              id: 'test',
              subject: 'العلوم',
              grade: 'الثاني الابتدائي',
              start: 480,
              end: 525,
            );
    try {
      if (widget.platformEnabled) {
        await DeviceService.speech(
          speechController.text
              .trim()
              .replaceAll('{lesson}', 'الدرس الأول')
              .replaceAll('{subject}', sample.subject)
              .replaceAll('{grade}', sample.grade),
          s.volume,
        );
      }
    } catch (_) {
      _message('تأكد من توفر صوت عربي في محرك النطق على الهاتف.');
    }
  }

  Future<void> _reset() async {
    if (!await _confirm(
      'إعادة ضبط التطبيق',
      'ستُمسح الحصص والاستثناءات والألوان والنغمة المختارة والإعدادات. هل تريد المتابعة؟',
    )) {
      return;
    }
    if (widget.platformEnabled) {
      await queue;
      await DeviceService.resetNative();
    }
    undo.clear();
    final next = PlannerState();
    speechController.text = next.speechText;
    _setVibrationFields(next.vibration);
    await _stopVibration(report: false);
    if (!mounted) {
      return;
    }
    await _commit(next, remember: false);
    if (!mounted) {
      return;
    }
    _navigate(0);
    _message('تمت إعادة ضبط التطبيق.');
  }

  Widget _history() {
    final visible = events.where((event) {
      final text = '${event['text'] ?? ''}';
      final kind =
          event['kind'] ?? (text.contains('اختبار') ? 'test' : 'alert');
      return historyFilter == 0 ||
          kind == (historyFilter == 1 ? 'test' : 'edit');
    }).toList();
    return _stack([
      _referenceHeading(
        'التجارب والإجراءات',
        'سجل التنبيهات',
        'طلبات الاختبار وتنبيهات الحصص والتعديلات.',
      ),
      _panel([
        Wrap(
          spacing: 6,
          runSpacing: 5,
          children: [
            for (var i = 0; i < 3; i++)
              ChoiceChip(
                label: Text(['الكل', 'الاختبارات', 'التعديلات'][i]),
                selected: historyFilter == i,
                onSelected: (_) => setState(() => historyFilter = i),
              ),
            _button('تحديث السجل', _refresh),
            if (events.isNotEmpty)
              _button('مسح السجل', () async {
                if (!await _confirm(
                  'مسح السجل',
                  'ستُمسح الأحداث المسجلة في التطبيق.',
                )) {
                  return;
                }
                if (widget.platformEnabled) {
                  await DeviceService.clearLogs();
                }
                await _refresh();
              }),
          ],
        ),
        if (visible.isEmpty) _sub('لا توجد أحداث في هذا القسم.'),
        for (final event in visible)
          Container(
            decoration: BoxDecoration(
              color: wash,
              borderRadius: BorderRadius.circular(12),
            ),
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${event['text'] ?? ''}',
                  style: TextStyle(fontSize: 13, color: ink),
                ),
                _sub('${event['time'] ?? ''}'),
              ],
            ),
          ),
      ]),
    ]);
  }

  List<String> _printLines() => [
    'الجدول المعتاد · لا يتضمن الاستثناءات اليومية أو الأوقات الموسمية',
    for (var d = 0; d < 7; d++)
      if (s.work[d] && (s.reportDay < 0 || s.reportDay == d)) ...[
        weekdays[d],
        for (final lesson in s.week[d])
          if (lesson.enabled)
            '${clock(lesson.start)}–${clock(lesson.end)} · ${lesson.subject} · ${lesson.grade} ${lesson.section} ${lesson.place}',
      ],
  ];

  Future<void> _share() async {
    await _modal(
      'تصدير الجدول',
      StatefulBuilder(
        builder: (context, update) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sub(
              'يُصدَّر الجدول المعتاد مع الشعبة والمكان. لا يشمل استثناءات التواريخ.',
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              initialValue: s.reportDay,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'نطاق التصدير'),
              items: [
                const DropdownMenuItem(
                  value: -1,
                  child: Text('الأسبوع كاملًا'),
                ),
                for (var d = 0; d < 7; d++)
                  DropdownMenuItem(value: d, child: Text(weekdays[d])),
              ],
              onChanged: (v) {
                if (v != null) {
                  _commit(s.clone()..reportDay = v, schedule: false);
                  update(() {});
                }
              },
            ),
            _switch(
              'ورقة A4 أفقية',
              'أوقف الخيار لاستخدام الاتجاه العمودي',
              s.landscape,
              (v) {
                _commit(s.clone()..landscape = v, schedule: false);
                update(() {});
              },
            ),
            SizedBox(
              width: double.infinity,
              child: _button('مشاركة صورة PNG', _shareImage, primary: true),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: _button('طباعة / حفظ PDF', () async {
                if (widget.platformEnabled) {
                  await DeviceService.printSchedule(
                    _printLines(),
                    landscape: s.landscape,
                  );
                }
              }),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _shareImage() async {
    if (!widget.platformEnabled) {
      return;
    }
    try {
      final rows = s.week
          .asMap()
          .entries
          .where(
            (e) => s.work[e.key] && (s.reportDay < 0 || s.reportDay == e.key),
          )
          .fold<int>(
            0,
            (v, e) => v + 1 + e.value.where((l) => l.enabled).length,
          );
      final height = 190.0 + rows * 76;
      final recorder = ui.PictureRecorder(), canvas = Canvas(recorder);
      canvas.drawColor(const Color(0xfff3f5f1), BlendMode.src);
      void text(
        String value,
        double x,
        double y,
        double width,
        double size,
        Color color, {
        bool bold = false,
      }) {
        final p = TextPainter(
          text: TextSpan(
            text: value,
            style: TextStyle(
              fontSize: size,
              color: color,
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          textDirection: TextDirection.rtl,
          textAlign: TextAlign.right,
        )..layout(maxWidth: width);
        p.paint(canvas, Offset(x, y));
      }

      canvas.drawRect(
        const Rect.fromLTWH(0, 0, 900, 140),
        Paint()..color = Color(s.heroColor),
      );
      text(
        'جرس المعلم · الجدول الأسبوعي',
        25,
        35,
        850,
        31,
        Colors.white,
        bold: true,
      );
      text(
        'الجدول المعتاد · لا يشمل الاستثناءات والتوقيتات الموسمية',
        25,
        90,
        850,
        17,
        const Color(0xffc3d9ce),
      );
      double y = 160;
      for (var d = 0; d < 7; d++) {
        if (!s.work[d] || (s.reportDay >= 0 && s.reportDay != d)) {
          continue;
        }
        text(weekdays[d], 25, y, 850, 24, const Color(0xff237463), bold: true);
        y += 65;
        for (final l in s.week[d].where((l) => l.enabled)) {
          final color = _subjectColor(l.subject);
          canvas.drawRRect(
            RRect.fromRectAndRadius(
              Rect.fromLTWH(25, y, 850, 65),
              const Radius.circular(12),
            ),
            Paint()
              ..color = Color.alphaBlend(
                color.withValues(alpha: .12),
                Colors.white,
              ),
          );
          text(
            l.subject,
            580,
            y + 10,
            270,
            20,
            const Color(0xff193632),
            bold: true,
          );
          text(l.place, 310, y + 40, 540, 14, const Color(0xff6e8177));
          text(
            '${l.grade} ${l.section}',
            310,
            y + 12,
            250,
            16,
            const Color(0xff193632),
          );
          text(
            '${clock(l.start)} — ${clock(l.end)}',
            40,
            y + 20,
            240,
            18,
            const Color(0xff193632),
          );
          y += 76;
        }
      }
      final picture = recorder.endRecording(),
          image = await picture.toImage(900, height.ceil());
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      if (bytes != null) {
        await DeviceService.exportImage(bytes.buffer.asUint8List());
      }
      image.dispose();
      picture.dispose();
    } catch (_) {
      _message('تعذر إنشاء الصورة؛ جرّب الطباعة إلى PDF.');
    }
  }
}

class _WeekHeader extends SliverPersistentHeaderDelegate {
  const _WeekHeader({
    required this.child,
    required this.height,
    required this.color,
  });

  final Widget child;
  final double height;
  final Color color;

  @override
  double get minExtent => height;

  @override
  double get maxExtent => height;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) => ColoredBox(
    color: color,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 13),
      child: Center(child: child),
    ),
  );

  @override
  bool shouldRebuild(covariant _WeekHeader oldDelegate) =>
      child != oldDelegate.child ||
      height != oldDelegate.height ||
      color != oldDelegate.color;
}
