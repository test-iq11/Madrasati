import 'dart:async';

/// Pending progress belongs to one book and can be flushed on route disposal.
class ReadingPosition {
  ReadingPosition(this.write);
  final Future<void> Function(int) write;
  Timer? _timer;
  int? _pending;

  void moved(int page) {
    _pending = page;
    _timer?.cancel();
    _timer = Timer(const Duration(milliseconds: 700), () => unawaited(flush()));
  }

  Future<void> flush() async {
    _timer?.cancel();
    final page = _pending;
    if (page == null) return;
    _pending = null;
    await write(page);
  }
}
