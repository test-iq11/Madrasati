import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import '../models/library_catalog.dart';
import 'library_repository.dart';

class RemoteSnapshot {
  const RemoteSnapshot(this.catalog, this.sha);
  final LibraryCatalog? catalog;
  final String? sha;
}

/// Uses repository-scoped, fine-grained PAT stored only on the manager device.
/// Never supply this credential to a webview or a user APK.
/// This is an online *enrollment* check, not a substitute for GitHub's
/// enforcement of Contents: write at publication time. Permission checks are
/// deliberately fail-closed on incomplete/missing API response fields.
class GitHubManagerVerifier {
  GitHubManagerVerifier({
    required this.owner,
    required this.repo,
    required this.client,
  });
  final String owner;
  final String repo;
  final http.Client client;

  Future<void> verify(String token) async {
    if (!RegExp(r'^[a-zA-Z0-9-]{1,100}$').hasMatch(owner) ||
        !RegExp(r'^[a-zA-Z0-9._-]{1,100}$').hasMatch(repo)) {
      throw StateError('المستودع غير محدد بصورة صحيحة في GitHub Actions.');
    }
    if (token.trim().isEmpty || token.contains(RegExp(r'\s'))) {
      throw const FormatException('أدخل رمز GitHub صحيحاً دون فراغات.');
    }
    final response = await client.get(
      Uri.https('api.github.com', '/repos/$owner/$repo'),
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'Madrasati-Manager-Enrollment',
      },
    ).timeout(const Duration(seconds: 20));
    if (response.statusCode == 401) {
      throw StateError('رمز GitHub غير صالح أو منتهي الصلاحية.');
    }
    if (response.statusCode != 200) {
      throw StateError('لا يمكن التحقق من المستودع (${response.statusCode}). ' 
          'تأكد من اتصال الإنترنت واسم المستودع وصلاحية الرمز.');
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes));
    if (payload is! Map<String, dynamic>) {
      throw StateError('استجابة GitHub غير صالحة.');
    }
    final name = (payload['full_name'] ?? '').toString().toLowerCase();
    final permission = payload['permissions'];
    if (name != '$owner/$repo'.toLowerCase() ||
        permission is! Map || permission['push'] != true) {
      throw StateError('ليس لهذا الرمز حق الدفع إلى مستودع المناهج. ' 
          'استخدم رمز المالك المخصص للمستودع مع Contents: Read and write.');
    }
    final identityResponse = await client.get(
      Uri.https('api.github.com', '/user'),
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      },
    ).timeout(const Duration(seconds: 20));
    if (identityResponse.statusCode != 200) {
      throw StateError('تعذّر التحقق من حساب مالك المستودع. أعد التفعيل بحسابك.');
    }
    final identity = jsonDecode(utf8.decode(identityResponse.bodyBytes));
    if (identity is! Map<String, dynamic> ||
        identity['login'] is! String ||
        (identity['login'] as String).toLowerCase() != owner.toLowerCase()) {
      throw StateError('إعدادات المدير متاحة لحساب مالك المستودع فقط.');
    }
    // API metadata alone cannot prove token-scoped Contents:write; the PUT
    // endpoint validates it when publishing. Never bypass that API check.
  }
}

/// Swappable vault boundary so the real Android secure-storage path can be
/// regression-tested without opening a device keystore in widget tests.
abstract class ManagerCredentialVault {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
  Future<void> delete(String key);
}

class _FlutterCredentialVault implements ManagerCredentialVault {
  const _FlutterCredentialVault(this.storage);
  final FlutterSecureStorage storage;

  @override
  Future<String?> read(String key) => storage.read(key: key);
  @override
  Future<void> write(String key, String value) =>
      storage.write(key: key, value: value);
  @override
  Future<void> delete(String key) => storage.delete(key: key);
}

class GitHubPublisher {
  GitHubPublisher({
    http.Client? client,
    ManagerCredentialVault? primaryVault,
    ManagerCredentialVault? legacyVault,
    String? owner,
    String? repo,
  })  : _client = client ?? http.Client(),
        _primary = primaryVault ?? _FlutterCredentialVault(
          const FlutterSecureStorage(
            aOptions: AndroidOptions(
              storageNamespace: 'madrasati_owner_authorization_v2',
              resetOnError: false,
              migrateWithBackup: true,
            ),
          ),
        ),
        _legacy = legacyVault ?? _FlutterCredentialVault(
          const FlutterSecureStorage(
            aOptions: AndroidOptions(
              resetOnError: false,
              migrateWithBackup: true,
            ),
          ),
        ),
        _owner = owner ?? LibraryEndpoint.owner,
        _repo = repo ?? LibraryEndpoint.repo;

  final http.Client _client;
  // Use a fresh isolated Android KeyStore namespace for new enrolments.
  // Legacy keys are READ for compatibility; they are never erased on error.
  final ManagerCredentialVault _primary;
  final ManagerCredentialVault _legacy;
  final String _owner;
  final String _repo;
  static const _key = 'github_manager_fine_grained_access_token';
  static const _enrollmentKey = 'madrasati_manager_verified_owner_v2';

  bool get _configured => _owner.trim().isNotEmpty && _repo.trim().isNotEmpty;
  String get _repoId => '${_owner.toLowerCase()}/${_repo.toLowerCase()}';

  Future<String?> _validatedToken(ManagerCredentialVault vault) async {
    final marker = await vault.read(_enrollmentKey);
    // A token without a matching repository verification marker is never
    // accepted. Reading an invalid/corrupt marker cannot grant admin rights.
    if (marker != _repoId || !_configured) return null;
    final token = await vault.read(_key);
    return token != null && token.trim().isNotEmpty ? token : null;
  }

  Future<String?> _activeToken() async {
    try {
      final token = await _validatedToken(_primary);
      if (token != null) return token;
    } catch (_) {
      // Old or damaged native preferences can cause a platform TypeError.
      // Try the old vault without granting access on an exception.
    }
    try {
      return await _validatedToken(_legacy);
    } catch (_) {
      // Fail closed. The owner can re-enrol online with a valid GitHub token.
      return null;
    }
  }

  /// Existing devices can keep their legacy encrypted enrolment. If it cannot
  /// be read, online GitHub permission verification is required again; neither
  /// a local PIN nor a local preference grants admin rights on its own.
  Future<bool> get enrolledOnDevice async =>
      _configured && await _activeToken() != null;

  Future<bool> get hasToken => enrolledOnDevice;

  Future<void> activateWithToken(String token) async {
    if (!_configured) {
      throw StateError('اضبط LIBRARY_OWNER وLIBRARY_REPO في متغيرات GitHub Actions أولاً.');
    }
    final candidate = token.trim();
    await GitHubManagerVerifier(
      owner: _owner,
      repo: _repo,
      client: _client,
    ).verify(candidate);
    // Credential first, then marker. Never accept local data without an
    // online permission check. Keep legacy data intact for safe rollbacks.
    await _primary.write(_key, candidate);
    await _primary.write(_enrollmentKey, _repoId);
    if (await _validatedToken(_primary) != candidate) {
      throw StateError('تعذّر تأكيد حفظ تفويض GitHub المشفّر. لم تُفتح الإدارة.');
    }
  }

  Future<void> saveToken(String token) => activateWithToken(token);

  Future<void> clearToken() async {
    // Do not pretend to revoke a token if one of the encrypted vaults fails.
    await _primary.delete(_enrollmentKey);
    await _primary.delete(_key);
    await _legacy.delete(_enrollmentKey);
    await _legacy.delete(_key);
  }

  Future<Map<String, String>> _headers() async {
    final token = await _activeToken();
    if (token == null) {
      throw StateError('تعذّر قراءة تفويض GitHub؛ أعد التفعيل بالرمز المصرح به عند توفر الإنترنت.');
    }
    return {
      'Authorization': 'Bearer $token',
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'IraqiSchoolLibrary-Manager',
    };
  }

  Future<RemoteSnapshot> fetch() async {
    if (!LibraryEndpoint.configured) {
      throw StateError('لم تُحدد بيانات مستودع GitHub أثناء بناء التطبيق');
    }
    final uri = Uri.parse(LibraryEndpoint.apiUrl).replace(queryParameters: {
      'ref': LibraryEndpoint.branch,
    });
    final response = await _client.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 20));
    if (response.statusCode == 404) return const RemoteSnapshot(null, null);
    if (response.statusCode != 200) {
      throw StateError(_errorMessage('قراءة الفهرس', response));
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final encoded = (payload['content'] ?? '').toString().replaceAll('\n', '');
    final text = utf8.decode(base64Decode(base64.normalize(encoded)));
    return RemoteSnapshot(LibraryRepository.decode(text), payload['sha'] as String?);
  }

  Future<RemoteSnapshot> publish({
    required LibraryCatalog draft,
    required String? baseSha,
  }) async {
    if (!LibraryEndpoint.configured) throw StateError('المستودع غير مهيأ');
    draft.validate();
    // Read-before-write plus GitHub SHA CAS protects against concurrent editors.
    final latest = await fetch();
    if (latest.sha != baseSha) {
      throw StateError('تغير ملف الكتب على GitHub منذ آخر مزامنة؛ راجع أحدث نسخة قبل النشر حتى لا تفقد تعديلات أخرى.');
    }
    final next = draft.copy();
    next.revision = (latest.catalog?.revision ?? draft.revision) + 1;
    next.updatedAt = DateTime.now().toUtc().toIso8601String();
    final body = <String, dynamic>{
      'message': 'Update Iraqi library catalog (revision ${next.revision})',
      'content': base64Encode(utf8.encode(const JsonEncoder.withIndent('  ').convert(next.toJson()))),
      'branch': LibraryEndpoint.branch,
      'sha': ?baseSha,
    };
    final response = await _client.put(Uri.parse(LibraryEndpoint.apiUrl),
      headers: {...await _headers(), 'Content-Type': 'application/json'},
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 30));
    if (response.statusCode != 200 && response.statusCode != 201) {
      throw StateError(_errorMessage('نشر التعديلات', response));
    }
    final payload = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final content = payload['content'];
    final sha = content is Map ? content['sha'] as String? : null;
    return RemoteSnapshot(next, sha);
  }


  /// Recent published catalog commits, for history/rollback preview.
  Future<List<Map<String, String>>> recentCatalogCommits() async {
    final uri = Uri.https('api.github.com',
        '/repos/${LibraryEndpoint.owner}/${LibraryEndpoint.repo}/commits',
        {'path': LibraryEndpoint.path, 'sha': LibraryEndpoint.branch, 'per_page': '15'});
    final res = await _client.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw StateError(_errorMessage('سجل الإصدارات', res));
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    if (data is! List) return [];
    return data.whereType<Map>().map((m) {
      final commit = m['commit'];
      final details = commit is Map ? commit : <String, dynamic>{};
      final author = details['author'];
      final info = author is Map ? author : <String, dynamic>{};
      return <String, String>{
        'sha': (m['sha'] ?? '').toString(),
        'message': (details['message'] ?? 'تعديل الفهرس').toString(),
        'date': (info['date'] ?? '').toString(),
      };
    }).toList();
  }

  /// Reads an older version without modifying the remote repository.
  Future<LibraryCatalog> fetchCatalogRevision(String commitSha) async {
    if (!RegExp(r'^[0-9a-fA-F]{40}$').hasMatch(commitSha)) {
      throw const FormatException('معرّف إصدار GitHub غير صحيح');
    }
    final uri = Uri.parse(LibraryEndpoint.apiUrl)
        .replace(queryParameters: {'ref': commitSha});
    final res = await _client.get(uri, headers: await _headers())
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) throw StateError(_errorMessage('استعادة إصدار', res));
    final body = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    final encoded = (body['content'] ?? '').toString().replaceAll('\n', '');
    return LibraryRepository.decode(utf8.decode(base64Decode(base64.normalize(encoded))));
  }

  String _errorMessage(String action, http.Response response) {
    final status = response.statusCode;
    if (status == 401) return '$action: رمز GitHub غير صالح أو انتهت صلاحيته (401)';
    if (status == 403) return '$action: لا تمتلك إذن Contents: Read and write أو المستودع غير مسموح (403)';
    if (status == 409) return '$action: تعارض في نسخة الملف (409)، حمّل النسخة الحالية';
    if (status == 404) return '$action: المستودع غير موجود أو الرمز لا يملك صلاحية الوصول (404)';
    return '$action: خطأ GitHub ($status)';
  }
}
