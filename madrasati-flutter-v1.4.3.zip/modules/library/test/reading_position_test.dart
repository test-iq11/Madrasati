import 'package:flutter_test/flutter_test.dart';
import 'package:iraqi_school_library_dual/user/reading_position.dart';

void main() {
  test('closing before the PDF loads preserves the saved page', () async {
    int stored = 23;
    final position = ReadingPosition((page) async { stored = page; });
    await position.flush();
    expect(stored, 23);
  });

  test('closing during a swipe saves only the last pending page', () async {
    final writes = <int>[];
    final position = ReadingPosition((page) async { writes.add(page); });
    position.moved(17);
    position.moved(18);
    await position.flush();
    await position.flush();
    expect(writes, [18]);
  });
}
