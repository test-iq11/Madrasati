import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:iraqi_school_library_dual/services/github_publisher.dart';

void main() {
  GitHubManagerVerifier verifier(http.Client client) => GitHubManagerVerifier(
    owner: 'school-owner', repo: 'curriculum-data', client: client,
  );

  test('authenticated repository push permission permits enrollment check', () async {
    final client = MockClient((request) async {
      if (request.url.path == '/user') {
        return http.Response(jsonEncode({'login': 'school-owner'}), 200);
      }
      expect(request.url.toString(),
          'https://api.github.com/repos/school-owner/curriculum-data');
      expect(request.headers['Authorization'], 'Bearer github_pat_private');
      return http.Response(jsonEncode({
        'full_name': 'school-owner/curriculum-data',
        'permissions': {'push': true},
      }), 200);
    });
    await verifier(client).verify('github_pat_private');
    client.close();
  });

  test('public repository visibility does not grant manager role', () async {
    final client = MockClient((_) async => http.Response(jsonEncode({
      'full_name': 'school-owner/curriculum-data',
      'permissions': {'pull': true, 'push': false},
    }), 200));
    await expectLater(verifier(client).verify('read_only'), throwsStateError);
    client.close();
  });

  test('missing permissions fail closed', () async {
    final client = MockClient((_) async => http.Response(jsonEncode({
      'full_name': 'school-owner/curriculum-data',
    }), 200));
    await expectLater(verifier(client).verify('read_only'), throwsStateError);
    client.close();
  });

  test('wrong repository fails closed', () async {
    final client = MockClient((_) async => http.Response(jsonEncode({
      'full_name': 'other-owner/other-repository',
      'permissions': {'push': true},
    }), 200));
    await expectLater(verifier(client).verify('other_token'), throwsStateError);
    client.close();
  });

  test('invalid and unauthorized credentials never enroll', () async {
    final client = MockClient((_) async => http.Response('Unauthorized', 401));
    await expectLater(verifier(client).verify('expired_token'), throwsStateError);
    await expectLater(verifier(client).verify(''), throwsFormatException);
    client.close();
  });

  test('remote errors never fall back to local PIN enrollment', () async {
    final client = MockClient((_) async => http.Response('Forbidden', 403));
    await expectLater(verifier(client).verify('bad_token'), throwsStateError);
    client.close();
  });
  test('collaborator with push permission cannot activate owner administration', () async {
    final client = MockClient((request) async => http.Response(jsonEncode(
      request.url.path == '/user'
        ? {'login': 'another-user'}
        : {'full_name': 'school-owner/curriculum-data',
           'permissions': {'push': true}},
    ), 200));
    await expectLater(verifier(client).verify('collaborator_token'), throwsStateError);
    client.close();
  });

  test('missing owner identity rejects enrollment despite push permission', () async {
    final client = MockClient((request) async => http.Response(jsonEncode(
      request.url.path == '/user'
        ? <String, dynamic>{}
        : {'full_name': 'school-owner/curriculum-data',
           'permissions': {'push': true}},
    ), 200));
    await expectLater(verifier(client).verify('token'), throwsStateError);
    client.close();
  });

}
