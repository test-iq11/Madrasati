# مدرستي 1.2.8+11 — إصلاح SelectionOverlay لقفل التطبيق

## الخطأ المثبت في GitHub Actions

- `debugCheckHasOverlay` في `EditableText`, أثناء `tester.enterText` في اختبار `lock gate covers nested routes and accepts PIN`.
- خطأ `_batchEditDepth <= 0` في اختبار `recovery requires device authorization and confirms new PIN` بعد اضطراب حقول النص.

## السبب
`MadrasatiAppLockGate` موضوع في طبقة `Stack` فوق Navigator الرئيسي داخل `MaterialApp.builder`. حقول `TextField` ليست من نسل `Navigator` ولذلك لم ترث أي `Overlay`. إدخال النص قد يطلب واجهة تحديد النص فتحدث استثناءات.

## الإصلاح
أصبح `MadrasatiAppLockGate` يملك `Overlay` خاصاً و`OverlayEntry` مستقراً يتضمن جميع محتويات الشاشة ويحافظ على حقول النص أثناء تحديثها، مع التخلص من العنصر بعد إزالته. جرى تعزيز اختبارات القفل لتتحقق من وجود Overlay داخل الحقول ومن اختفاء شاشة القفل بعد الرمز الصحيح، واستقرار إدخال تأكيد الاسترداد. يُغلَق تركيز لوحة المفاتيح قبل التحقق غير المتزامن لتفادي ترك جلسة تحرير نشطة أثناء إزالة شاشة القفل.

## ملاحظات التنفيذ
- المشروع Flutter بالكامل، واجهة الفسيفساء والأيقونات والألوان دون تغيير.
- نسخ ZIP فقط إلى جذر المستودع دون فك الضغط، واستبدال YAML في `.github/workflows/build-madrasati-android.yml`.
- لم يتم تغيير نظام توقيع APK لأن ذلك مؤجل بطلب المستخدم.
- لا توجد أداة Flutter SDK محلياً، ولذلك **لم تجر اختبارات flutter test/flutter analyze أو بناء APK**. أي نتيجة نجاح نهائية تحددها GitHub Actions بعد التشغيل.
- لا تحذف التطبيق المثبت قبل حفظ بياناته لاحتمال اختلاف توقيع Debug.
