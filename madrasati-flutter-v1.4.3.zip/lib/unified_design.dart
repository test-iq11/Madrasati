import 'package:flutter/material.dart';
import 'school_stat_icon.dart';
import 'dart:io';
import 'package:sajli/records.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'unified_workspaces.dart';

/// The approved unified HTML visual language, translated into native Flutter.
/// This layer is deliberately presentation-only: the original school databases,
/// timetable repair engine, document scanner, PDF reader, and permissions remain
/// owned by their existing modules. Never seed fake pupils or books here.
abstract final class UnifiedStyle {
  static const background = Color(0xfff5f7fb);
  static const foreground = Color(0xff172b3d);
  static const subdued = Color(0xff718298);
  static const border = Color(0xffe5ebf2);
  static const turquoise = Color(0xff087c77);
  static const emerald = Color(0xff3cb4a6);
  static const navy = Color(0xff264b73);
  static const darkBackground = Color(0xff000000);
  static const darkSurface = Color(0xff151d26);

  static Color bg(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? darkBackground : background;
  static Color surface(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? darkSurface : Colors.white;
  static Color ink(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xffeef5fa) : foreground;
  static Color muted(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xffa3b2c5) : subdued;
  static Color line(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xff344354) : border;
}

class UnifiedSectionSpec {
  const UnifiedSectionSpec(this.id, this.title, this.subtitle, this.heroTitle,
      this.description, this.first, this.last, this.icon, this.tabs);
  final String id, title, subtitle, heroTitle, description;
  final Color first, last;
  final IconData icon;
  final List<UnifiedTab> tabs;
}

class UnifiedTab {
  const UnifiedTab(this.id, this.title, this.icon);
  final String id, title;
  final IconData icon;
}

const unifiedSections = <UnifiedSectionSpec>[
  UnifiedSectionSpec('jadwali', 'جدولي الذكي', 'الحصص والإصلاح والتقارير', 'جدولي الذكي',
    'جدول منظّم يحترم قيود الحصص ويمنحك مساحة لفهم التعارضات والإصلاح والتقارير.',
    Color(0xff176d77), Color(0xff4a9a92), Icons.calendar_month_outlined, [
      UnifiedTab('main', 'الرئيسية', Icons.home_outlined),
      UnifiedTab('schedule', 'الجدول', Icons.calendar_view_week_outlined),
      UnifiedTab('repair', 'الإصلاح', Icons.swap_horiz_rounded),
      UnifiedTab('reports', 'التقارير', Icons.summarize_outlined),
      UnifiedTab('tools', 'الإعداد', Icons.tune_rounded),
    ]),
  UnifiedSectionSpec('sajli', 'سجلي المدرسي', 'الملفات والدرجات والحضور', 'سجلي المدرسي',
    'مساحة متكاملة لكل تلميذ: ملف شخصي ودرجات وحضور وتقارير ولي الأمر.',
    Color(0xff665789), Color(0xff9788b1), Icons.people_outline_rounded, [
      UnifiedTab('main', 'الملخص', Icons.home_outlined),
      UnifiedTab('students', 'التلاميذ', Icons.people_outline),
      UnifiedTab('attendance', 'الحضور', Icons.done_all_rounded),
      UnifiedTab('reports', 'التقارير', Icons.insert_drive_file_outlined),
      UnifiedTab('tools', 'الأدوات', Icons.grid_view_rounded),
    ]),
  UnifiedSectionSpec('bell', 'جرس المعلم', 'الوقت والتنبيهات', 'جرس المعلم',
    'جدول زمني هادئ، تنبيهات قابلة للضبط، وربط مباشر بحصص جدولي.',
    Color(0xffb37563), Color(0xffd5a18a), Icons.notifications_none_rounded, [
      UnifiedTab('main', 'الرئيسية', Icons.notifications_none_rounded),
      UnifiedTab('periods', 'الحصص', Icons.schedule_outlined),
      UnifiedTab('week', 'الأسبوع', Icons.calendar_month_outlined),
      UnifiedTab('alerts', 'التنبيهات', Icons.volume_up_outlined),
      UnifiedTab('tools', 'الإعدادات', Icons.tune_rounded),
    ]),
  UnifiedSectionSpec('library', 'المناهج العراقية', 'كتب ومراجعات ومتابعة قراءة', 'مناهجك المدرسية',
    'مكتبة منظّمة حسب الصف والمادة، مع المفضلة ومتابعة القراءة.',
    Color(0xff326a9a), Color(0xff70a5bb), Icons.menu_book_outlined, [
      UnifiedTab('main', 'الرئيسية', Icons.home_outlined),
      UnifiedTab('books', 'الكتب', Icons.menu_book_outlined),
      UnifiedTab('saved', 'المحفوظات', Icons.file_download_outlined),
      UnifiedTab('reviews', 'المراجعات', Icons.star_border_rounded),
      UnifiedTab('tools', 'المزيد', Icons.grid_view_outlined),
    ]),
  UnifiedSectionSpec('scanner', 'مستمسكاتي', 'حفظ المستندات وطباعتها', 'مستمسكاتي',
    'بطاقتك في دقيقة، وثائقك محفوظة ومنظمة، من الهاتف إلى طباعة A4.',
    Color(0xff416b7e), Color(0xff77a6af), Icons.document_scanner_outlined, [
      UnifiedTab('main', 'الرئيسية', Icons.home_outlined),
      UnifiedTab('docs', 'مستنداتي', Icons.description_outlined),
      UnifiedTab('card', 'بطاقة بدقيقة', Icons.document_scanner_outlined),
      UnifiedTab('print', 'الطباعة', Icons.print_outlined),
      UnifiedTab('tools', 'الأدوات', Icons.grid_view_outlined),
    ]),
];

class UnifiedStudent {
  const UnifiedStudent({required this.id, required this.name,
      required this.group, required this.registerNumber, required this.attendance,
      this.gradeCount = 0});
  final String id, name, group, registerNumber, attendance;
  final int gradeCount;
}

class UnifiedLesson {
  const UnifiedLesson({required this.subject, required this.time,
      required this.teacher, required this.period});
  final String subject, time, teacher;
  final int period;
}

class UnifiedHero extends StatelessWidget {
  const UnifiedHero({super.key, required this.title, required this.description,
    required this.icon, required this.first, required this.last,
    required this.chips, this.kicker = 'مدرستي • نموذج المدرسة • مساحة تعليمية مترابطة'});
  final String title, description, kicker;
  final IconData icon;
  final Color first, last;
  final List<(IconData, String)> chips;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, size) {
    final small = size.maxWidth < 365;
    return Container(
      constraints: BoxConstraints(minHeight: small ? 225 : 237),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(29),
        gradient: LinearGradient(begin: Alignment.topRight,
            end: Alignment.bottomLeft, colors: [last, first]),
        boxShadow: [BoxShadow(color: first.withValues(alpha: .17), blurRadius: 28,
            offset: const Offset(0, 11))],
      ),
      child: Stack(children: [
        PositionedDirectional(top: -150, end: -80,
          child: Container(width: 300, height: 300, decoration: BoxDecoration(
            shape: BoxShape.circle, border: Border.all(color: Colors.white.withValues(alpha: .14)),
          ))),
        PositionedDirectional(bottom: -110, start: -130,
          child: Container(width: 225, height: 225, decoration: BoxDecoration(
            shape: BoxShape.circle, color: Colors.white.withValues(alpha: .07),
          ))),
        Padding(padding: EdgeInsets.fromLTRB(small ? 17 : 27, 23, small ? 17 : 27, 21),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                Expanded(child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18),
                    borderRadius: BorderRadius.circular(50),
                    border: Border.all(color: Colors.white.withValues(alpha: .27))),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.auto_awesome_outlined, color: Colors.white, size: 14),
                    const SizedBox(width: 7),
                    Expanded(child: Text(kicker, maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 10,
                        color: Colors.white, height: 1.5))),
                  ]))),
                const SizedBox(width: 11),
                const Icon(Icons.auto_awesome_rounded, size: 15, color: Color(0xffe6f9ff)),
              ]),
              const SizedBox(height: 18),
              Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min, children: [
                    Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w900, fontSize: small ? 23 : 28, height: 1.35)),
                    const SizedBox(height: 5),
                    Text(description, maxLines: 3, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xfff4f8fa),
                        fontSize: 11, height: 1.8)),
                  ])),
                const SizedBox(width: 11),
                Transform.rotate(angle: -.12,
                  child: Container(width: small ? 71 : 84, height: small ? 71 : 84,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .17),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white.withValues(alpha: .30))),
                    child: Icon(icon, color: Colors.white, size: small ? 47 : 55))),
              ]),
              const SizedBox(height: 18),
              Wrap(spacing: 7, runSpacing: 7, children: [
                for (final chip in chips)
                  Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .15),
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(color: Colors.white.withValues(alpha: .19))),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(chip.$1, color: Colors.white, size: 12),
                      const SizedBox(width: 5),
                      Text(chip.$2, style: const TextStyle(color: Colors.white,
                        fontSize: 10, fontWeight: FontWeight.w700)),
                    ])),
              ]),
            ])),
      ]),
    );
  });
}

class UnifiedHeading extends StatelessWidget {
  const UnifiedHeading(this.title, {this.subtitle, this.action, super.key});
  final String title;
  final String? subtitle;
  final Widget? action;
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 22, bottom: 12, right: 2, left: 2),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900,
          color: UnifiedStyle.ink(context))),
        if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 3),
          child: Text(subtitle!, style: TextStyle(fontSize: 10,
            color: UnifiedStyle.muted(context)))),
      ])),
      if (action != null) action!,
    ]),
  );
}

class UnifiedPanel extends StatelessWidget {
  const UnifiedPanel({super.key, required this.child, this.padding = const EdgeInsets.all(16)});
  final Widget child;
  final EdgeInsets padding;
  @override Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(color: UnifiedStyle.surface(context),
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: UnifiedStyle.line(context)),
      boxShadow: [BoxShadow(color: const Color(0xff253f55).withValues(alpha: .045),
        blurRadius: 23, offset: const Offset(0, 7))]),
    child: child,
  );
}

class UnifiedPillButton extends StatelessWidget {
  const UnifiedPillButton({super.key, required this.label, required this.onPressed,
    this.icon = Icons.arrow_back_rounded, this.color = UnifiedStyle.turquoise});
  final String label;
  final VoidCallback onPressed;
  final IconData icon;
  final Color color;
  @override Widget build(BuildContext context) => Material(
    color: color.withValues(alpha: Theme.of(context).brightness == Brightness.dark ? .26 : .10),
    borderRadius: BorderRadius.circular(11),
    child: InkWell(borderRadius: BorderRadius.circular(11), onTap: onPressed,
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: 15), const SizedBox(width: 5),
          Text(label, style: TextStyle(fontSize: 11, color: color,
            fontWeight: FontWeight.w900)),
        ]))),
  );
}

class UnifiedMetric extends StatelessWidget {
  const UnifiedMetric({super.key, required this.value, required this.label,
    required this.icon, required this.tint, required this.tone});
  final String value, label;
  final IconData icon;
  final Color tint, tone;
  @override Widget build(BuildContext context) => Container(
    constraints: const BoxConstraints(minHeight: 124),
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(color: UnifiedStyle.surface(context),
      borderRadius: BorderRadius.circular(19),
      border: Border.all(color: UnifiedStyle.line(context))),
    child: Stack(children: [
      PositionedDirectional(bottom: -48, start: -34,
        child: Container(width: 104, height: 104,
          decoration: BoxDecoration(shape: BoxShape.circle,
            color: tint.withValues(alpha: .50)))),
      Padding(padding: const EdgeInsets.all(13), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 38, height: 38,
          decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(12)),
          child: Center(child: SchoolStatLineIcon(
            label: label == 'إجمالي التلاميذ' || label == 'التلاميذ'
                ? 'عدد التلاميذ' : label == 'الصفوف والشعب' ? label
                : label == 'غير مسجل اليوم' || label == 'غير مسجّل'
                  ? 'غير مسجّل' : label,
            color: tone, size: 25, lineWidth: 1.32,
          ))),
        const SizedBox(height: 7),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900,
            color: UnifiedStyle.ink(context))),
        Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
          color: UnifiedStyle.muted(context))),
      ])),
    ]),
  );
}

class UnifiedFeatureCard extends StatelessWidget {
  const UnifiedFeatureCard({super.key, required this.title, required this.description,
    required this.icon, required this.first, required this.last,
    required this.onPressed, this.height = 158});
  final String title, description;
  final IconData icon;
  final Color first, last;
  final VoidCallback onPressed;
  final double height;
  @override Widget build(BuildContext context) => Material(
    color: Colors.transparent,
    child: InkWell(onTap: onPressed, borderRadius: BorderRadius.circular(23),
      child: Ink(height: height, decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(23),
        gradient: LinearGradient(begin: Alignment.topRight,
          end: Alignment.bottomLeft, colors: [first, last]),
        boxShadow: [BoxShadow(color: first.withValues(alpha: .12),
          blurRadius: 20, offset: const Offset(0, 8))]),
      child: Stack(children: [
        PositionedDirectional(top: -52, end: -48,
          child: Container(width: 160, height: 160,
            decoration: BoxDecoration(shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withValues(alpha: .15))))),
        Padding(padding: const EdgeInsets.all(17), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Icon(icon, color: Colors.white, size: 26),
            const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 20),
          ]),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 18,
                fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(description, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Color(0xffe9f2f4), fontSize: 10,
                height: 1.5)),
          ]),
        ])),
      ]))),
  );
}

class UnifiedQuick extends StatelessWidget {
  const UnifiedQuick({super.key, required this.title, required this.icon,
    required this.onTap, this.subtitle});
  final String title;
  final String? subtitle;
  final IconData icon;
  final VoidCallback onTap;
  @override Widget build(BuildContext context) => Material(
    color: UnifiedStyle.surface(context),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17),
      side: BorderSide(color: UnifiedStyle.line(context))),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(17),
      child: SizedBox(height: subtitle == null ? 95 : 102,
        child: Padding(padding: const EdgeInsets.all(9),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: UnifiedStyle.turquoise, size: 25),
            const SizedBox(height: 7),
            Text(title, textAlign: TextAlign.center, maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900,
                color: UnifiedStyle.ink(context))),
            if (subtitle != null) Text(subtitle!, maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: UnifiedStyle.muted(context), fontSize: 9)),
          ]))),
    ),
  );
}

class UnifiedRow extends StatelessWidget {
  const UnifiedRow({super.key, required this.icon, required this.title,
    this.subtitle, this.onTap, this.trailing, this.tone = UnifiedStyle.turquoise});
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color tone;
  @override Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(13),
    child: Padding(padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 3),
      child: Row(children: [
        Container(width: 43, height: 43,
          decoration: BoxDecoration(color: tone.withValues(alpha: .12),
            borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, size: 21, color: tone)),
        const SizedBox(width: 11),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: FontWeight.w800,
                color: UnifiedStyle.ink(context), fontSize: 12)),
            if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 3),
              child: Text(subtitle!, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: TextStyle(color: UnifiedStyle.muted(context), fontSize: 10))),
          ])),
        trailing ?? Icon(Icons.chevron_left_rounded,
          color: UnifiedStyle.muted(context), size: 19),
      ])),
  );
}

class UnifiedStudentTile extends StatelessWidget {
  const UnifiedStudentTile({super.key, required this.student, required this.index,
    required this.onTap, this.height = 171});
  final UnifiedStudent student;
  final int index;
  final VoidCallback onTap;
  final double height;
  static const shades = <(Color, Color)>[
    (Color(0xff3e77a9), Color(0xff5f9ac7)),
    (Color(0xff8062a4), Color(0xffa185bc)),
    (Color(0xff148f80), Color(0xff4aafa1)),
    (Color(0xffbb7d50), Color(0xffd59c71)),
    (Color(0xffa55f78), Color(0xffc17c98)),
    (Color(0xff4b859b), Color(0xff74a8b8)),
  ];
  @override Widget build(BuildContext context) {
    final palette = shades[index % shades.length];
    return Material(color: Colors.transparent, child: InkWell(onTap: onTap,
      borderRadius: BorderRadius.circular(22), child: Ink(height: height,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(begin: Alignment.topRight,
            end: Alignment.bottomLeft, colors: [palette.$1, palette.$2])),
        child: Stack(children: [
          PositionedDirectional(bottom: -46, start: -29,
            child: Container(width: 130, height: 130,
              decoration: BoxDecoration(shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: .10)))),
          Padding(padding: const EdgeInsets.all(13),
            child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(width: 34, height: 34,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .19),
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(color: Colors.white.withValues(alpha: .25))),
                    child: Text(student.name.isEmpty ? 'ت' : student.name[0],
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
                  const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 18),
                ]),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(student.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14,
                    fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(student.group, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xfff0f6fb), fontSize: 10)),
                if (student.registerNumber.isNotEmpty)
                  Text('قيد ${student.registerNumber}', maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Color(0xffeff6f9), fontSize: 9)),
                const SizedBox(height: 9),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Flexible(child: Text(student.attendance, maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 9,
                      fontWeight: FontWeight.w800))),
                  Text('${student.gradeCount} درجات',
                    style: const TextStyle(color: Colors.white, fontSize: 9)),
                ]),
              ]),
            ])),
        ]))),
    );
  }
}

class UnifiedHomePage extends StatelessWidget {
  const UnifiedHomePage({super.key, required this.school, required this.dayName,
    required this.lessons, required this.students, required this.classCount,
    required this.tasks, required this.progress, required this.onSection,
    required this.onDay, required this.onAttendance, required this.onStudent,
    required this.onStats, required this.onTeacherHub, required this.onLibrary,
    required this.onSearch, this.tab = 0, this.cardHeight = 158});
  final String school, dayName, tasks, progress;
  final List<UnifiedLesson> lessons;
  final List<UnifiedStudent> students;
  final int classCount;
  final int tab;
  final double cardHeight;
  final void Function(String) onSection;
  final VoidCallback onDay, onAttendance, onStudent,
      onStats, onTeacherHub, onLibrary, onSearch;

  @override Widget build(BuildContext context) {
    final unregistered = students.where((s) => s.attendance == 'غير مسجّل').length;
    return ColoredBox(color: UnifiedStyle.bg(context), child: ListView(
      key: const PageStorageKey('madrasati-unified-home-scroll'),
      padding: const EdgeInsets.fromLTRB(14, 1, 14, 105),
      children: [
        UnifiedHero(
          key: const ValueKey('unified-home-hero'),
          title: tab == 1 ? 'اليوم الدراسي' : tab == 2 ? 'مركز المهام' :
              tab == 3 ? 'نبض المدرسة' : 'مدرستك، بنظام واحد',
          description: tab == 0
              ? 'جدولك وحضور التلاميذ وتنبيهاتك وكتبك ومستمسكاتك؛ جميعها في تجربة عربية هادئة ومتناسقة.'
              : 'بيانات أقسام مدرستي الأصلية في عرض موحّد ومريح.',
          kicker: '$school • تجربة موحدة حقيقية',
          icon: tab == 0 ? Icons.school_outlined :
              tab == 1 ? Icons.calendar_today_outlined :
              tab == 2 ? Icons.task_alt_rounded : Icons.stacked_bar_chart_outlined,
          first: const Color(0xff066d71), last: const Color(0xff264b73),
          chips: [
            (Icons.calendar_today_outlined, dayName),
            (Icons.verified_user_outlined, 'بيانات مدرسية محلية'),
            (Icons.auto_awesome_outlined, 'أقسام مترابطة'),
          ]),
        if (tab == 0) ...[
          const UnifiedHeading('أقسام التطبيق', subtitle: 'انتقل إلى قسم وجوده في أنشطتك اليومية'),
          LayoutBuilder(builder: (context, box) {
            const gap = 12.0;
            final half = (box.maxWidth - gap) / 2;
            return Wrap(spacing: gap, runSpacing: gap, children: [
              for (final section in unifiedSections)
                SizedBox(width: section.id == 'scanner' ? box.maxWidth : half,
                  child: UnifiedFeatureCard(
                    key: ValueKey('unified-section-${section.id}'),
                    title: section.title, description: section.subtitle,
                    icon: section.icon, first: section.first, last: section.last,
                    height: section.id == 'scanner' ? 126 : cardHeight,
                    onPressed: () => onSection(section.id))),
            ]);
          }),
          const UnifiedHeading('اختصارات يومك', subtitle: 'خطوات سريعة من الأدوات الأكثر استخدامًا'),
          _quickGrid([
            ('ملف التلميذ', Icons.person_outline_rounded, onStudent),
            ('حضور اليوم', Icons.task_alt_rounded, onAttendance),
            ('حصص اليوم', Icons.calendar_month_outlined, onDay),
            ('بطاقة في دقيقة', Icons.document_scanner_outlined, () => onSection('scanner')),
            ('البحث الشامل', Icons.search_rounded, onSearch),
            ('مركز المعلم', Icons.school_outlined, onTeacherHub),
          ]),
          const UnifiedHeading('نبض المدرسة', subtitle: 'أرقام حقيقية من السجلات المحفوظة'),
          _metricGrid([
            ('${students.length}', 'عدد التلاميذ', Icons.people_outline,
                const Color(0xffe4f4ef), const Color(0xff348d86)),
            ('$unregistered', 'غير مسجل حضورهم', Icons.history_rounded,
                const Color(0xffe8f0fb), const Color(0xff7393b8)),
            ('${classCount}', 'الصفوف والشعب', Icons.school_outlined,
                const Color(0xffefe8f7), const Color(0xff85739d)),
            (tasks, 'مهام متبقية', Icons.task_alt_outlined,
                const Color(0xffe9f2f7), const Color(0xff739ab0)),
          ]),
          _todayLessons(context),
          const UnifiedHeading('كيف يعمل الترابط؟'),
          UnifiedPanel(child: Column(children: [
            UnifiedRow(icon: Icons.calendar_month_outlined, title: 'جدولي ← الجرس',
              subtitle: 'الحصة بعد حفظها في الجدول يمكن نقلها إلى برنامج الجرس.',
              onTap: () => onSection('jadwali')),
            Divider(height: 12, color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.people_outline_rounded, title: 'سجلي ← الإحصائيات',
              subtitle: 'تحديث الحضور في السجل ينعكس في المؤشرات والتقارير.', onTap: onStats),
            Divider(height: 12, color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.attach_file_outlined, title: 'مستمسكاتي ← ملف التلميذ',
              subtitle: 'احفظ صور المستمسكات وأرفقها من ملف التلميذ الأصلي.',
              onTap: () => onSection('scanner')),
            Divider(height: 12, color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.menu_book_outlined, title: 'المناهج ← الرئيسية',
              subtitle: 'افتح المكتبة وتابع تنزيل الكتب والدروس.', onTap: onLibrary),
          ])),
        ] else if (tab == 1) ...[
          _todayLessons(context),
          UnifiedHeading('إدارة يومك', subtitle: 'الحصص والحضور مرتبطة بالأقسام الأصلية',
            action: UnifiedPillButton(label: 'عرض الجدول',
                onPressed: () => onSection('jadwali'))),
          _quickGrid([
            ('الحضور', Icons.task_alt_rounded, onAttendance),
            ('الجرس', Icons.notifications_outlined, () => onSection('bell')),
            ('الكتب', Icons.menu_book_outlined, onLibrary),
            ('مركز المعلم', Icons.school_outlined, onTeacherHub),
          ]),
        ] else if (tab == 2) ...[
          UnifiedHeading('متابعة مهامك', subtitle: 'تعتمد على مركز المعلم المحفوظ فعليًا'),
          UnifiedPanel(child: Column(children: [
            UnifiedRow(icon: Icons.task_alt_outlined, title: '$tasks مهام متبقية',
              subtitle: 'فتح وإدارة المهام من مركز المعلم', onTap: onTeacherHub),
            Divider(color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.auto_stories_outlined, title: 'إنجاز المناهج: $progress',
              subtitle: 'راجع الدروس المنجزة من لوحة المتابعة', onTap: onTeacherHub),
          ])),
        ] else ...[
          const UnifiedHeading('المدرسة بالأرقام', subtitle: 'مؤشرات مستخرجة من سجلي وجدولي'),
          _metricGrid([
            ('${students.length}', 'التلاميذ', Icons.people_outline, const Color(0xffe5f5ed), const Color(0xff258f79)),
            ('$unregistered', 'غير مسجّل', Icons.history_rounded, const Color(0xffeef1fa), const Color(0xff7c8db4)),
            ('${lessons.length}', 'حصص اليوم', Icons.calendar_today_outlined, const Color(0xffe9f2f9), const Color(0xff5987b1)),
            (progress, 'إنجاز المنهج', Icons.donut_large_rounded, const Color(0xfff2ebf8), const Color(0xff846cac)),
          ]),
          const SizedBox(height: 13),
          UnifiedPillButton(label: 'إحصائيات المدرسة',
            icon: Icons.stacked_bar_chart_outlined, onPressed: onStats),
        ],
      ],
    ));
  }

  Widget _quickGrid(List<(String, IconData, VoidCallback)> items) =>
      LayoutBuilder(builder: (context, box) => Wrap(spacing: 11, runSpacing: 11,
        children: [for (final item in items)
          SizedBox(width: (box.maxWidth - 11) / 2,
            child: UnifiedQuick(title: item.$1, icon: item.$2, onTap: item.$3))]));

  Widget _metricGrid(List<(String, String, IconData, Color, Color)> items) =>
      LayoutBuilder(builder: (context, box) => Wrap(spacing: 12, runSpacing: 12,
        children: [for (final item in items)
          SizedBox(width: (box.maxWidth - 12) / 2,
            child: UnifiedMetric(value: item.$1, label: item.$2,
              icon: item.$3, tint: item.$4, tone: item.$5))]));

  Widget _todayLessons(BuildContext context) => Column(children: [
    UnifiedHeading('حصصك القادمة', subtitle: 'مرتبطة بجدولي للصف والتاريخ المحددين',
      action: UnifiedPillButton(label: 'الجدول الكامل',
          onPressed: () => onSection('jadwali'))),
    UnifiedPanel(child: lessons.isEmpty
      ? UnifiedRow(icon: Icons.info_outline, title: 'لا توجد حصص لهذا اليوم أو الصف',
          subtitle: 'يمكنك إعداد الجدول من قسم جدولي ثم العودة إلى هنا.',
          onTap: () => onSection('jadwali'))
      : Column(children: [
          for (final lesson in lessons.take(5)) ...[
            UnifiedRow(icon: Icons.event_note_outlined,
              title: 'الحصة ${lesson.period} • ${lesson.subject}',
              subtitle: '${lesson.time}${lesson.teacher.isNotEmpty ? ' • ${lesson.teacher}' : ''}',
              onTap: () => onSection('jadwali'),
              trailing: CircleAvatar(radius: 15,
                backgroundColor: const Color(0xffe6f5f1),
                child: Text('${lesson.period}', style: const TextStyle(
                  fontSize: 11, color: UnifiedStyle.turquoise,
                  fontWeight: FontWeight.w800))),
            ),
            if (lesson != lessons.take(5).last)
              Divider(height: 6, color: UnifiedStyle.line(context)),
          ],
        ])),
  ]);
}


/// One unified Flutter surface for every department. No second application
/// route, old embedded app, or legacy launch button is ever created here.
class UnifiedSectionPage extends StatefulWidget {
  const UnifiedSectionPage({super.key, required this.spec, required this.school,
    required this.dayName, required this.lessons, required this.students,
    required this.classCount, required this.onOpenNative,
    required this.onOpenSection, required this.onStudent,
    required this.onAttendance, required this.onStatistics,
    required this.onTransferToBell, required this.onOpenBooks,
    required this.onChangeDay, this.onOpenReports, this.groupLabel = '',
    this.records, this.recordsFile, this.database, this.onDataChanged,
    this.onEditLesson, this.onSwap, this.initialTab = 'main', this.studentFocus});
  final UnifiedSectionSpec spec;
  final String school, dayName, groupLabel, initialTab;
  final String? studentFocus;
  final List<UnifiedLesson> lessons;
  final List<UnifiedStudent> students;
  final int classCount;
  // Kept solely for compatibility with existing widget construction;
  // onOpenNative is intentionally never called in the unified experience.
  final VoidCallback onOpenNative, onAttendance, onStatistics,
      onTransferToBell, onOpenBooks, onChangeDay;
  final VoidCallback? onOpenReports, onDataChanged;
  final ValueChanged<int>? onEditLesson;
  final void Function(int,int)? onSwap;
  final void Function(String) onOpenSection, onStudent;
  final Records? records;
  final File? recordsFile;
  final DatabaseService? database;
  @override State<UnifiedSectionPage> createState()=>_UnifiedSectionPageState();
}
class _UnifiedSectionPageState extends State<UnifiedSectionPage> {
  late String tab;
  @override void initState(){super.initState();tab=widget.initialTab;}
  @override void didUpdateWidget(covariant UnifiedSectionPage old){
    super.didUpdateWidget(old);
    if(old.initialTab!=widget.initialTab &&
      widget.spec.tabs.any((s)=>s.id==widget.initialTab)){
      setState(()=>tab=widget.initialTab);
    }
  }
  void _tab(String id){if(widget.spec.tabs.any((t)=>t.id==id))setState(()=>tab=id);}
  @override Widget build(BuildContext context)=>ColoredBox(
    color:UnifiedStyle.bg(context),child:Column(children:[
      Expanded(child:ListView(key:PageStorageKey('unified-${widget.spec.id}-$tab'),
        padding:const EdgeInsets.fromLTRB(14,1,14,14),children:[
          UnifiedHero(key:ValueKey('unified-${widget.spec.id}-hero'),
            title:widget.spec.heroTitle, description:widget.spec.description,
            kicker:'${widget.school} • ${widget.spec.subtitle}',
            first:widget.spec.first,last:widget.spec.last,icon:widget.spec.icon,
            chips:_chips()),
          const SizedBox(height:4),
          _contents(),
          const SizedBox(height:25),
        ])),
      _navigation(context),
    ]));
  List<(IconData,String)> _chips()=>switch(widget.spec.id){
    'sajli'=>[(Icons.people_outline,'${widget.students.length} تلميذ'),
      (Icons.verified_user_outlined,'بيانات محفوظة')],
    'jadwali'=>[(Icons.calendar_today_outlined,widget.dayName),
      (Icons.school_outlined,widget.groupLabel)],
    'bell'=>[(Icons.notifications_none,'تنبيهات Android أصلية'),
      (Icons.calendar_month_outlined,'الأسبوع')],
    'library'=>[(Icons.menu_book_outlined,'كتب المناهج'),
      (Icons.offline_pin_outlined,'تنزيلات محلية')],
    _=>[(Icons.document_scanner_outlined,'٤ أماميات + ٤ خلفيات'),
      (Icons.print_outlined,'A4 فقط')],
  };
  Widget _contents()=>switch(widget.spec.id){
    'sajli'=>widget.records!=null && widget.recordsFile!=null
      ?SajliWorkspace(key:const ValueKey('sajli-workspace'),tab:tab,
        records:widget.records,file:widget.recordsFile,
        onChanged:widget.onDataChanged??(){},onTab:_tab,
        focusStudentId:widget.studentFocus)
      :_sajliPreview(),
    'jadwali'=>JadwaliWorkspace(key:const ValueKey('jadwali-workspace'),
      tab:tab,lessons:widget.lessons,dayName:widget.dayName,
      database:widget.database??DatabaseService.instance,
      onTab:_tab,onEditLesson:widget.onEditLesson??(_){},
      onSwap:widget.onSwap??(_,__){},onChangeDay:widget.onChangeDay,
      onTransferToBell:widget.onTransferToBell,
      onOpenBell:()=>widget.onOpenSection('bell'),
      onRefresh:widget.onDataChanged??(){}),
    'bell'=>BellWorkspace(key:const ValueKey('bell-workspace'),tab:tab,
      onTab:_tab,onTransfer:widget.onTransferToBell,
      onOpenJadwali:()=>widget.onOpenSection('jadwali')),
    'library'=>LibraryWorkspace(key:const ValueKey('library-workspace'),tab:tab,onTab:_tab),
    'scanner'=>ScannerWorkspace(key:const ValueKey('scanner-workspace'),tab:tab,onTab:_tab),
    _=>UnifiedUI.empty('هذا القسم غير مدعوم'),
  };
  Widget _sajliPreview(){
    // Only used for isolated widget tests while there is no loaded Records file.
    if(tab=='reports')return Column(children:[
      const UnifiedHeading('تقرير ولي الأمر'),
      for(final title in ['أولًا • معلومات التلميذ','ثانيًا • التحصيل الدراسي',
        'ثالثًا • المواظبة والحضور','رابعًا • الملاحظات والتوصيات'])
        Padding(padding:const EdgeInsets.only(bottom:10),
          child:UnifiedPanel(child:Text(title))),
    ]);
    if(tab=='students')return Column(children:[
      const UnifiedHeading('اختر تلميذًا'),
      LayoutBuilder(builder:(context,c)=>Wrap(spacing:10,runSpacing:10,children:[
        for(var i=0;i<widget.students.length;i++)SizedBox(width:(c.maxWidth-10)/2,
          child:UnifiedStudentTile(key:ValueKey('unified-student-${widget.students[i].id}'),
            student:widget.students[i],index:i,
            onTap:()=>widget.onStudent(widget.students[i].id))),
      ])),
    ]);
    return const UnifiedPanel(child:Text('جارٍ تحميل بيانات سجلي الأصلية...'));
  }
  Widget _navigation(BuildContext context)=>SafeArea(top:false,child:Container(
    margin:const EdgeInsets.fromLTRB(12,5,12,8),
    padding:const EdgeInsets.all(5),
    decoration:BoxDecoration(color:UnifiedStyle.surface(context),
      borderRadius:BorderRadius.circular(21),
      border:Border.all(color:UnifiedStyle.line(context)),
      boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.08),blurRadius:17)]),
    child:Row(children:[for(final choice in widget.spec.tabs)
      Expanded(child:InkWell(key:ValueKey('unified-tab-${widget.spec.id}-${choice.id}'),
        onTap:()=>_tab(choice.id),borderRadius:BorderRadius.circular(13),
        child:Container(height:54,decoration:BoxDecoration(
          color:tab==choice.id?widget.spec.first.withValues(alpha:.12):Colors.transparent,
          borderRadius:BorderRadius.circular(13)),
          child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
            Icon(choice.icon,size:20,color:tab==choice.id?widget.spec.first:
              UnifiedStyle.muted(context)),
            const SizedBox(height:4),
            Text(choice.title,maxLines:1,overflow:TextOverflow.ellipsis,
              style:TextStyle(fontSize:9,fontWeight:FontWeight.w800,
                color:tab==choice.id?widget.spec.first:UnifiedStyle.muted(context))),
          ])))),
    ])));
}
