import 'package:flutter/material.dart';

/// Floating, four-item navigation bar matching the approved HTML.
class MadrasatiNavItem {
  const MadrasatiNavItem(this.label, this.icon, this.color);
  final String label;
  final IconData icon;
  final Color color;
}

class MadrasatiBottomNav extends StatelessWidget {
  const MadrasatiBottomNav({
    required this.items,
    required this.selectedIndex,
    required this.onSelect,
    super.key,
  });
  final List<MadrasatiNavItem> items;
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final index = selectedIndex < 0 ? 0 : selectedIndex >= items.length ? 0 : selectedIndex;
    final navColor = dark
        ? Color.lerp(items[index].color, Colors.white, .30)!
        : items[index].color;
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(23),
        border: Border.all(color: scheme.outlineVariant.withValues(alpha: .55)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: dark ? .20 : .11),
          blurRadius: 25, offset: const Offset(0, 6))],
      ),
      child: ClipRRect(borderRadius: BorderRadius.circular(22),
        child: NavigationBar(
          key: const ValueKey('madrasati-colorful-bottom-nav'),
          height: 63,
          elevation: 0,
          backgroundColor: scheme.surface,
          indicatorColor: navColor.withValues(alpha: dark ? .25 : .12),
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          selectedIndex: index,
          onDestinationSelected: onSelect,
          destinations: [
            for (var i = 0; i < items.length; i++)
              NavigationDestination(
                tooltip: items[i].label,
                icon: Icon(items[i].icon, color: items[i].color, size: 22),
                selectedIcon: Icon(items[i].icon, color: navColor, size: 24),
                label: items[i].label,
              ),
          ],
        )),
    );
  }
}
