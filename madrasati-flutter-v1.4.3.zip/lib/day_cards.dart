import 'package:flutter/material.dart';

import 'school_day.dart';

/// The approved colored day panel. Values come from the real Jadwali database.
class DayCards extends StatelessWidget {
  const DayCards({
    required this.day,
    required this.accent,
    required this.rounded,
    required this.onSectionChanged,
    required this.onChangeDate,
    required this.onSchedule,
    required this.onTransfer,
    required this.onBooks,
    this.onAttendance,
    this.onLessonBook,
    this.onEditLesson,
    required this.transferring,
    super.key,
  });

  final SchoolDay day;
  final Color accent;
  final double rounded;
  final ValueChanged<int> onSectionChanged;
  final VoidCallback onChangeDate;
  final VoidCallback onSchedule;
  final VoidCallback onTransfer;
  final VoidCallback onBooks;
  final VoidCallback? onAttendance;
  final ValueChanged<String>? onLessonBook;
  final ValueChanged<Map<String, Object?>>? onEditLesson;
  final bool transferring;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final surface = Theme.of(context).colorScheme.surface;
    final ink = Theme.of(context).colorScheme.onSurface;
    final lessons = day.lessons;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          key: const ValueKey('day-colored-header'),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              accent,
              Color.lerp(accent, Colors.black, .25)!,
            ]),
            borderRadius: BorderRadius.circular(rounded),
          ),
          child: Row(children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: .19),
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.all(9),
              child: const Icon(Icons.calendar_today_outlined,
                  color: Colors.white, size: 28),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('حصص اليوم', style: TextStyle(
                    fontSize: 21, fontWeight: FontWeight.w900,
                    color: Colors.white)),
                Text('${day.dayName} · ${day.date.day}/${day.date.month}/${day.date.year}',
                  style: const TextStyle(color: Colors.white, fontSize: 12)),
              ],
            )),
          ]),
        ),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            if (day.sections.isNotEmpty)
              Container(
                padding: const EdgeInsetsDirectional.fromSTEB(10, 0, 9, 0),
                decoration: BoxDecoration(color: surface,
                  borderRadius: BorderRadius.circular(12)),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<int>(
                    key: const ValueKey('day-section-picker'),
                    value: day.sectionId,
                    borderRadius: BorderRadius.circular(12),
                    items: [
                      for (final item in day.sections)
                        DropdownMenuItem<int>(
                          value: item['id'] as int,
                          child: Text('${item['grade_name']} · ${item['section_name']}',
                            style: const TextStyle(fontSize: 12)),
                        ),
                    ],
                    onChanged: (id) {
                      if (id != null) onSectionChanged(id);
                    },
                  ),
                ),
              ),
            OutlinedButton.icon(
              onPressed: onChangeDate,
              icon: const Icon(Icons.event_outlined, size: 18),
              label: Text('${day.date.year}/${day.date.month}/${day.date.day}'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (day.section == null)
          _empty(context, 'أضف الصفوف من «جدولي» لعرض حصصها هنا.')
        else if (lessons.isEmpty)
          _empty(context, 'لا توجد حصص لهذا اليوم والصف.')
        else
          ...[
            if (onLessonBook != null)
              StreamBuilder<int>(stream: _clock, builder: (_, _) => _focus(context)),
            for (var i = 0; i < lessons.length; i++) ...[
              _lesson(lessons[i], i, dark, ink),
              if (onLessonBook != null) Wrap(spacing: 8, children: [
                if (onEditLesson != null) IconButton(tooltip: 'تعديل الحصة',
                  icon: const Icon(Icons.edit_calendar_outlined), onPressed: () => onEditLesson!(lessons[i])),
                TextButton(onPressed: onAttendance, child: const Text('حضور الشعبة')),
                TextButton(onPressed: () => onLessonBook!(lessons[i]['subject_name']?.toString() ?? ''),
                  child: const Text('كتاب المادة')),
              ]),
              if (i != lessons.length - 1) const SizedBox(height: 7),
            ],
          ],
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _action(
              context, 'إرسال الحصص للجرس',
              Icons.notifications_active_outlined, accent,
              lessons.isEmpty || transferring ? null : onTransfer)),
          const SizedBox(width: 7),
          Expanded(child: _action(context, 'كتب الصف',
              Icons.menu_book_outlined, const Color(0xff287e78),
              day.grade.isEmpty ? null : onBooks)),
        ]),
        const SizedBox(height: 8),
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: TextButton.icon(
            onPressed: onSchedule,
            icon: const Icon(Icons.calendar_month_outlined),
            label: const Text('فتح جدولي الكامل'),
          ),
        ),
      ],
    );
  }

  static final _clock = Stream<int>.periodic(const Duration(minutes: 1), (i) => i).asBroadcastStream(
    onCancel: (subscription) => subscription.pause(), onListen: (subscription) => subscription.resume());

  Widget _focus(BuildContext context) {
    final now = DateTime.now().toUtc().add(const Duration(hours: 3));
    final today = DateTime(now.year, now.month, now.day);
    final selected = DateTime(day.date.year, day.date.month, day.date.day);
    int minutes(Object? value) {
      final parts = value.toString().split(':');
      if (parts.length < 2) return -1;
      return (int.tryParse(parts[0]) ?? -100) * 60 + (int.tryParse(parts[1]) ?? -100);
    }
    final minute = now.hour * 60 + now.minute;
    final rows = day.lessons.where((l) => minutes(l['start_time']) >= 0 &&
      minutes(l['end_time']) > minutes(l['start_time'])).toList()
      ..sort((a,b) => minutes(a['start_time']).compareTo(minutes(b['start_time'])));
    final same = selected == today;
    final current = same ? rows.where((r) => minutes(r['start_time']) <= minute && minutes(r['end_time']) > minute).firstOrNull : null;
    final next = rows.where((r) => !same || minutes(r['start_time']) > minute).firstOrNull;
    final lesson = current ?? next;
    if (lesson == null || selected.isBefore(today)) return const ListTile(title: Text('انتهت حصص اليوم'));
    final label = current != null ? 'الحصة الجارية' : same ? 'الحصة القادمة' : 'أول حصة';
    return Card(child: ListTile(leading: const Icon(Icons.schedule), title: Text('$label · ${lesson['subject_name']}'),
      subtitle: Text('${lesson['start_time']} – ${lesson['end_time']}' +
        (current != null && next != null ? '\nتليها ${next['subject_name']} · ${next['start_time']}' : ''))));
  }

  Widget _empty(BuildContext context, String message) => Container(
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(rounded),
    ),
    padding: const EdgeInsets.all(17),
    child: Text(message, textAlign: TextAlign.center),
  );

  Widget _lesson(Map<String, Object?> lesson,
      int index, bool dark, Color ink) {
    const tints = [
      Color(0xffd7f6db), Color(0xffd8f2fc), Color(0xffe8e3ff),
      Color(0xfffcebd9), Color(0xfffbe2e7), Color(0xffdceae8),
    ];
    const tones = [
      Color(0xff258549), Color(0xff177aa3), Color(0xff6554a3),
      Color(0xffac6e1d), Color(0xffaa5368), Color(0xff226d71),
    ];
    final tint = tints[index % tints.length];
    final color = tones[index % tones.length];
    final subject = lesson['subject_name']?.toString() ?? 'حصة';
    final icon = subject.contains('إسلام') ? Icons.mosque_outlined
        : subject.contains('إنجلي') || subject.contains('إنكل')
            ? Icons.translate_outlined
        : subject.contains('اجتماع') ? Icons.public_outlined
        : subject.contains('فني') ? Icons.palette_outlined
        : subject.contains('عرب') ? Icons.menu_book_outlined
        : subject.contains('رياض') ? Icons.calculate_outlined
        : Icons.book_outlined;
    final teacher = lesson['teacher_name']?.toString() ?? '';
    return Container(
      key: ValueKey('colored-lesson-$index'),
      decoration: BoxDecoration(
        color: dark ? Color.lerp(tint, const Color(0xff14212b), .84)! :
            Color.lerp(tint, Colors.white, .72)!,
        borderRadius: BorderRadius.circular(rounded - 3 < 8 ? 8 : rounded - 3),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: Row(children: [
        Container(
          width: 47, height: 48,
          decoration: BoxDecoration(color: dark
              ? Color.lerp(tint, Colors.black, .60)! : tint,
              borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: dark ? tint : color, size: 25),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(subject, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 13, color: ink,
                fontWeight: FontWeight.w800)),
            Text('${lesson['start_time'] ?? ''} – ${lesson['end_time'] ?? ''}',
              style: TextStyle(fontSize: 11, color: ink.withValues(alpha: .7))),
          ],
        )),
        if (teacher.trim().isNotEmpty)
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 88),
            child: Text(teacher, maxLines: 2,
              textAlign: TextAlign.end,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, color: ink.withValues(alpha: .80))),
          ),
      ]),
    );
  }

  Widget _action(BuildContext context, String text, IconData icon,
      Color tone, VoidCallback? onTap) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: dark ? Color.lerp(tone, Colors.black, .74)!
          : Color.lerp(tone, Colors.white, .88)!,
      borderRadius: BorderRadius.circular(rounded - 3 < 8 ? 8 : rounded - 3),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(rounded - 3 < 8 ? 8 : rounded - 3),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 13),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 19, color: onTap == null ? Colors.grey : tone),
            const SizedBox(width: 4),
            Flexible(child: Text(text, maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11,
                fontWeight: FontWeight.w700,
                color: onTap == null ? Colors.grey : dark ? Colors.white : tone))),
          ]),
        ),
      ),
    );
  }
}
