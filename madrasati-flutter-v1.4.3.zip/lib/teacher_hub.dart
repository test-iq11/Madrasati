import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _teacherTasksKey = 'madrasati.teacher.tasks.v1';
const _teacherProgressKey = 'madrasati.teacher.progress.v1';

/// Local-only teacher checklist. School / student data stays in existing modules.
class TeacherHubPage extends StatefulWidget {
  const TeacherHubPage({
    required this.preferences,
    required this.onSearch,
    required this.onStudent,
    required this.onClassroom,
    required this.onSchedule,
    required this.onCurriculum,
    required this.onAnalytics,
    super.key,
  });
  final SharedPreferences preferences;
  final VoidCallback onSearch, onStudent, onClassroom, onSchedule,
      onCurriculum, onAnalytics;
  @override
  State<TeacherHubPage> createState() => _TeacherHubPageState();
}

class _TeacherHubPageState extends State<TeacherHubPage> {
  late List<Map<String, dynamic>> tasks;
  @override
  void initState() {
    super.initState();
    try {
      final raw = jsonDecode(widget.preferences.getString(_teacherTasksKey) ?? '[]');
      tasks = (raw as List).whereType<Map>().map((e) => {
        'id': e['id']?.toString() ?? '',
        'title': e['title']?.toString() ?? '',
        'done': e['done'] == true,
      }).where((e) => (e['title'] as String).isNotEmpty).toList();
    } catch (_) {
      tasks = [];
    }
  }

  Future<void> _save() async {
    final ok = await widget.preferences.setString(_teacherTasksKey, jsonEncode(tasks));
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذّر حفظ المهام')));
    }
  }

  Future<void> _addTask() async {
    var title = '';
    final value = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('إضافة مهمة للمعلم'),
      content: TextFormField(autofocus: true,
        onChanged: (text) => title = text,
        textInputAction: TextInputAction.done,
        decoration: const InputDecoration(labelText: 'عنوان المهمة', hintText: 'مثلاً: مراجعة الواجبات')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, title.trim()),
          child: const Text('إضافة')),
      ],
    ));
    if (!mounted || value == null || value.isEmpty) return;
    setState(() => tasks.insert(0, {'id': DateTime.now().microsecondsSinceEpoch.toString(),
      'title': value, 'done': false}));
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final remaining = tasks.where((e) => e['done'] != true).length;
    return Scaffold(
      appBar: AppBar(title: const Text('مركز المعلم الذكي')),
      body: ListView(padding: const EdgeInsets.all(15), children: [
        _hubHero(context, remaining),
        const SizedBox(height: 20),
        _heading(context, 'أدواتك اليومية', 'تنقل مباشر إلى البيانات الحقيقية في التطبيقات'),
        const SizedBox(height: 12),
        GridView.count(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 2, childAspectRatio: 1.62, mainAxisSpacing: 10, crossAxisSpacing: 10,
          children: [
            _action(context, 'البحث الشامل', Icons.search, const Color(0xff16866c), widget.onSearch),
            _action(context, 'ملف التلميذ', Icons.person_outline, const Color(0xff815abd), widget.onStudent),
            _action(context, 'متابعة الصف', Icons.groups_outlined, const Color(0xff137f75), widget.onClassroom),
            _action(context, 'جدولي', Icons.calendar_month_outlined, const Color(0xff3676c1), widget.onSchedule),
            _action(context, 'إنجاز المنهج', Icons.donut_large_rounded, const Color(0xff3676c1), widget.onCurriculum),
            _action(context, 'إحصاءات المدرسة', Icons.bar_chart_outlined, const Color(0xffb77639), widget.onAnalytics),
          ],
        ),
        const SizedBox(height: 24),
        Row(children: [
          Expanded(child: _heading(context, 'مهامي', '$remaining مهمة لم تُنجز')),
          FilledButton.icon(onPressed: _addTask, icon: const Icon(Icons.add, size: 17),
            label: const Text('مهمة جديدة')),
        ]),
        const SizedBox(height: 11),
        if (tasks.isEmpty)
          _panel(context, child: Text('لم تضف مهاماً بعد. اضغط «مهمة جديدة» لتنظيم يومك.',
            style: TextStyle(color: colors.onSurfaceVariant)))
        else _panel(context, child: Column(children: [
          for (final task in tasks) Row(children: [
            Checkbox(value: task['done'] == true, onChanged: (v) {
              setState(() => task['done'] = v == true);
              _save();
            }),
            Expanded(child: Text(task['title'] as String,
              style: TextStyle(decoration: task['done'] == true
                ? TextDecoration.lineThrough : null))),
            IconButton(tooltip: 'حذف المهمة', icon: const Icon(Icons.close_rounded),
              onPressed: () { setState(() => tasks.remove(task)); _save(); }),
          ]),
        ])),
        const SizedBox(height: 24),
        Text('تُحفظ المهام محلياً على هذا الهاتف. لا تُنشر على GitHub.',
          style: TextStyle(color: colors.onSurfaceVariant, fontSize: 11), textAlign: TextAlign.center),
      ]),
    );
  }

  Widget _hubHero(BuildContext context, int remaining) {
    return Container(padding: const EdgeInsets.all(23),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xff075353), Color(0xff0a9574)]),
        borderRadius: BorderRadius.circular(25)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('مساحتك الأكثر ذكاءً',
          style: TextStyle(color: Color(0xffb9eddb), fontWeight: FontWeight.w800, fontSize: 11)),
        const SizedBox(height: 7),
        const Text('كل تفاصيل يومك، في مكان واحد.',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 21)),
        const SizedBox(height: 9),
        Text('$remaining مهام تحتاج إنجازاً',
          style: const TextStyle(color: Colors.white, fontSize: 12)),
      ]),
    );
  }
}

class CurriculumProgressPage extends StatefulWidget {
  const CurriculumProgressPage({required this.preferences, super.key});
  final SharedPreferences preferences;
  @override
  State<CurriculumProgressPage> createState() => _CurriculumProgressPageState();
}

class _CurriculumProgressPageState extends State<CurriculumProgressPage> {
  late List<Map<String, dynamic>> subjects;
  @override
  void initState() {
    super.initState();
    try {
      final raw = jsonDecode(widget.preferences.getString(_teacherProgressKey) ?? '[]');
      subjects = (raw as List).whereType<Map>().map((x) => {
        'name': x['name']?.toString() ?? '',
        'done': (x['done'] as num?)?.toInt() ?? 0,
        'total': (x['total'] as num?)?.toInt() ?? 1,
      }).where((x) => (x['name'] as String).trim().isNotEmpty).toList();
    } catch (_) { subjects = []; }
  }

  Future<void> _save() async {
    final ok = await widget.preferences.setString(_teacherProgressKey, jsonEncode(subjects));
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذّر حفظ إنجاز المنهج')));
    }
  }

  Future<void> _edit([Map<String, dynamic>? subject]) async {
    var name = subject?['name']?.toString() ?? '';
    var total = subject?['total']?.toString() ?? '30';
    final save = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text(subject == null ? 'إضافة مادة' : 'تعديل المادة'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextFormField(initialValue: name, onChanged: (v) => name = v,
          decoration: const InputDecoration(labelText: 'اسم المادة')),
        TextFormField(initialValue: total, onChanged: (v) => total = v,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'عدد الدروس الإجمالي')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
      ],
    ));
    if (save != true || !mounted) return;
    final label = name.trim();
    final count = int.tryParse(total.trim());
    if (label.isEmpty || count == null || count < 1 || count > 10000) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اكتب اسم المادة وعدداً صحيحاً من الدروس')));
      return;
    }
    setState(() {
      if (subject == null) {
        subjects.add({'name': label, 'total': count, 'done': 0});
      } else {
        subject['name'] = label;
        subject['total'] = count;
        subject['done'] = (subject['done'] as int).clamp(0, count);
      }
    });
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final total = subjects.fold<int>(0, (a, b) => a + (b['total'] as int));
    final done = subjects.fold<int>(0, (a, b) => a + (b['done'] as int));
    final percent = total == 0 ? 0 : (done * 100 / total).round();
    return Scaffold(
      appBar: AppBar(title: const Text('إنجاز المنهج الدراسي')),
      body: ListView(padding: const EdgeInsets.all(15), children: [
        Container(padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xff245c9d), Color(0xff467fbd)]),
            borderRadius: BorderRadius.circular(25)),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('سجل إنجاز المنهج', style: TextStyle(color: Colors.white,
                fontWeight: FontWeight.w900, fontSize: 20)),
              const SizedBox(height: 8),
              Text('$done درساً منجزاً من أصل $total',
                style: const TextStyle(color: Colors.white, fontSize: 12)),
              const SizedBox(height: 8),
              const Text('متابعة محلية مستقلة عن فهرس كتب GitHub',
                style: TextStyle(color: Color(0xffebf5ff), fontSize: 10)),
            ])),
            Container(width: 72, height: 72, alignment: Alignment.center,
              decoration: BoxDecoration(shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: .75), width: 7)),
              child: Text('$percent%', style: const TextStyle(color: Colors.white,
                fontWeight: FontWeight.w900, fontSize: 17))),
          ]),
        ),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(child: _heading(context, 'المواد الدراسية', 'سجّل ما أنجزته من الدروس')),
          FilledButton.icon(onPressed: () => _edit(), icon: const Icon(Icons.add, size: 18),
            label: const Text('إضافة مادة')),
        ]),
        const SizedBox(height: 12),
        if (subjects.isEmpty)
          _panel(context, child: Text('لا توجد مواد مدخلة. أضف مادة وحدد عدد دروسها.',
            style: TextStyle(color: scheme.onSurfaceVariant)))
        else for (final subject in subjects) ...[
          _panel(context, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [
              Expanded(child: Text(subject['name'] as String,
                style: const TextStyle(fontWeight: FontWeight.w900))),
              Text('${((subject['done'] as int) * 100 / (subject['total'] as int)).round()}%',
                style: const TextStyle(fontWeight: FontWeight.w900,
                  color: Color(0xff16866c))),
            ]),
            const SizedBox(height: 9),
            LinearProgressIndicator(value: (subject['done'] as int) / (subject['total'] as int),
              minHeight: 8, borderRadius: BorderRadius.circular(9)),
            const SizedBox(height: 9),
            Row(children: [
              Expanded(child: Text('${subject['done']} من ${subject['total']} درساً',
                style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant))),
              IconButton(tooltip: 'تراجع عن درس', icon: const Icon(Icons.remove_circle_outline),
                onPressed: subject['done'] == 0 ? null : () {
                  setState(() => subject['done'] = (subject['done'] as int) - 1);
                  _save();
                }),
              IconButton(tooltip: 'أنجز درساً', icon: const Icon(Icons.add_circle_outline),
                onPressed: subject['done'] == subject['total'] ? null : () {
                  setState(() => subject['done'] = (subject['done'] as int) + 1);
                  _save();
                }),
              IconButton(tooltip: 'تعديل المادة', icon: const Icon(Icons.edit_outlined),
                onPressed: () => _edit(subject)),
              IconButton(tooltip: 'حذف المادة', icon: const Icon(Icons.delete_outline),
                onPressed: () { setState(() => subjects.remove(subject)); _save(); }),
            ]),
          ])),
          const SizedBox(height: 10),
        ],
        Text('البيانات في هذه الصفحة محفوظة محلياً على الجهاز، ولا تغيّر الكتب أو الروابط المنشورة على GitHub.',
          style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 11), textAlign: TextAlign.center),
      ]),
    );
  }
}

Widget _heading(BuildContext context, String title, String subtitle) {
  final colors = Theme.of(context).colorScheme;
  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: TextStyle(color: colors.onSurface,
      fontSize: 17, fontWeight: FontWeight.w900)),
    const SizedBox(height: 3),
    Text(subtitle, style: TextStyle(color: colors.onSurfaceVariant, fontSize: 11)),
  ]);
}

Widget _panel(BuildContext context, {required Widget child}) {
  final colors = Theme.of(context).colorScheme;
  return Container(padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: colors.surface,
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: colors.outlineVariant.withValues(alpha: .7))),
    child: child);
}

Widget _action(BuildContext context, String title, IconData icon, Color tone,
    VoidCallback onTap) {
  final colors = Theme.of(context).colorScheme;
  return Material(color: colors.surface, borderRadius: BorderRadius.circular(17),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(17),
      child: Container(padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(17),
          border: Border.all(color: colors.outlineVariant.withValues(alpha: .6))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: tone, size: 27),
            const SizedBox(height: 8),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: colors.onSurface, fontSize: 12,
                fontWeight: FontWeight.w900)),
          ]),
      ),
    ));
}
