import 'package:flutter/material.dart';
import 'day_cards.dart';
import 'school_day.dart';

/// Display the real timetable in the approved HTML's 2-column lesson panel.
/// The existing full day editor remains accessible via the expandable controls.
class ModernDayPanel extends StatelessWidget {
  const ModernDayPanel({
    required this.day,
    required this.accent,
    required this.rounded,
    required this.onSectionChanged,
    required this.onChangeDate,
    required this.onSchedule,
    required this.onTransfer,
    required this.onBooks,
    required this.onAttendance,
    required this.onEditLesson,
    required this.onLessonBook,
    required this.transferring,
    super.key,
  });
  final SchoolDay day;
  final Color accent;
  final double rounded;
  final ValueChanged<int> onSectionChanged;
  final VoidCallback onChangeDate, onSchedule, onTransfer, onBooks, onAttendance;
  final ValueChanged<Map<String, Object?>> onEditLesson;
  final ValueChanged<String> onLessonBook;
  final bool transferring;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final ink = scheme.onSurface;
    final muted = scheme.onSurfaceVariant;
    final lessons = [...day.lessons]..sort((a, b) =>
      (a['start_time']?.toString() ?? '').compareTo(b['start_time']?.toString() ?? ''));
    return Container(
      key: const ValueKey('modern-day-panel'),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: scheme.surface,
        borderRadius: BorderRadius.circular(rounded + 3),
        border: Border.all(color: scheme.outlineVariant.withValues(alpha: .65))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(
            color: const Color(0xff24bb8e), shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: const Color(0xff24bb8e).withValues(alpha: .25), blurRadius: 8)])),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('جدول الحصص', style: TextStyle(color: ink, fontSize: 13,
              fontWeight: FontWeight.w900)),
            Text(day.section == null ? 'اختر الصف والشعبة من جدولي' : day.sectionLabel,
              maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: muted, fontSize: 10)),
          ])),
          OutlinedButton.icon(
            onPressed: onChangeDate,
            icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 15),
            label: Text(day.dayName, maxLines: 1),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              visualDensity: VisualDensity.compact,
              textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
              foregroundColor: ink,
              backgroundColor: scheme.surfaceContainerLow,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              side: BorderSide(color: scheme.outlineVariant)),
          ),
        ]),
        const SizedBox(height: 12),
        if (day.section == null)
          Padding(padding: const EdgeInsets.all(12),
            child: Text('لا توجد شعبة محددة. افتح «جدولي» وأضف الصفوف والشعب لعرض حصصها هنا.',
              style: TextStyle(color: muted, fontSize: 12), textAlign: TextAlign.center))
        else if (lessons.isEmpty)
          Padding(padding: const EdgeInsets.all(12),
            child: Text('لم تُوزّع حصص لهذا الصف في ${day.dayName} بعد.',
              style: TextStyle(color: muted, fontSize: 12), textAlign: TextAlign.center))
        else LayoutBuilder(builder: (context, box) {
          final gap = 9.0;
          final width = (box.maxWidth - gap) / 2;
          return Wrap(spacing: gap, runSpacing: gap, children: [
            for (var i = 0; i < lessons.length; i++)
              SizedBox(width: width, child: _lesson(context, lessons[i], i, dark)),
          ]);
        }),
        const SizedBox(height: 10),
        Theme(data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            key: const ValueKey('day-advanced-controls'),
            tilePadding: EdgeInsets.zero,
            childrenPadding: EdgeInsets.zero,
            iconColor: accent,
            collapsedIconColor: muted,
            title: Text('خيارات اليوم وتعديل الحصص',
              style: TextStyle(color: accent, fontSize: 11, fontWeight: FontWeight.w800)),
            children: [DayCards(
              day: day, accent: accent, rounded: rounded,
              transferring: transferring,
              onSectionChanged: onSectionChanged,
              onChangeDate: onChangeDate,
              onSchedule: onSchedule,
              onTransfer: onTransfer,
              onBooks: onBooks,
              onAttendance: onAttendance,
              onEditLesson: onEditLesson,
              onLessonBook: onLessonBook,
            )],
          )),
      ]),
    );
  }

  Widget _lesson(BuildContext context, Map<String, Object?> lesson,
      int index, bool dark) {
    final scheme = Theme.of(context).colorScheme;
    const accentColors = [
      Color(0xff138667), Color(0xff4278c2), Color(0xff8a68be), Color(0xffb77c4e),
      Color(0xffcb6a79), Color(0xff217e88),
    ];
    final tone = accentColors[index % accentColors.length];
    final subject = lesson['subject_name']?.toString().trim() ?? '';
    final rawTime = lesson['start_time']?.toString() ?? '';
    final hour = rawTime.isEmpty ? '' : rawTime;
    return Material(
      borderRadius: BorderRadius.circular(15),
      color: dark ? scheme.surfaceContainerHigh : const Color(0xfff1f5f9),
      child: InkWell(
        key: ValueKey('modern-lesson-$index'),
        onTap: onSchedule,
        onLongPress: () => onEditLesson(lesson),
        borderRadius: BorderRadius.circular(15),
        child: Container(
          constraints: const BoxConstraints(minHeight: 76),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(15),
            border: Border.all(color: scheme.outlineVariant.withValues(alpha: .45))),
          child: Row(children: [
            Container(width: 39, height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: tone.withValues(alpha: dark ? .23 : .10),
                borderRadius: BorderRadius.circular(12)),
              child: Text('${index + 1}'.padLeft(2, '0'),
                style: TextStyle(color: tone, fontSize: 14, fontWeight: FontWeight.w900))),
            const SizedBox(width: 8),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min, children: [
                Text(subject.isEmpty ? 'حصة ${index + 1}' : subject,
                  maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: scheme.onSurface,
                    fontWeight: FontWeight.w900, fontSize: 11)),
                const SizedBox(height: 4),
                Text(hour.isEmpty ? 'الحصة ${index + 1}' : hour,
                  style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 9)),
              ])),
            Icon(Icons.arrow_back_ios_new_rounded, size: 11,
              color: scheme.onSurfaceVariant.withValues(alpha: .62)),
          ]),
        ),
      ),
    );
  }
}
