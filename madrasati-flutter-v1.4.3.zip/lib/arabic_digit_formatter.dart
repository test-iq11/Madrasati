import 'package:flutter/services.dart';

/// Normalize numerals entered with an Arabic/Persian Android keyboard before
/// applying Flutter's ASCII digits-only validation for PIN fields.
class MadrasatiAsciiDigitFormatter extends TextInputFormatter {
  const MadrasatiAsciiDigitFormatter();

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final converted = newValue.text.replaceAllMapped(
      RegExp(r'[\u0660-\u0669\u06f0-\u06f9]'),
      (match) {
        final code = match.group(0)!.codeUnitAt(0);
        final digit = code >= 0x06f0 ? code - 0x06f0 : code - 0x0660;
        return String.fromCharCode(0x30 + digit);
      },
    );
    return newValue.copyWith(text: converted);
  }
}
