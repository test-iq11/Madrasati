import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:iraqi_school_library_dual/models/library_catalog.dart';
import 'package:iraqi_school_library_dual/services/library_repository.dart';
import 'package:iraqi_school_timetable/data/database_service.dart';
import 'package:sajli/records.dart' show Records, attendanceLabels, dayKey;
import 'package:shared_preferences/shared_preferences.dart';

import 'school_day.dart';
import 'school_stat_icon.dart';

enum SchoolTool {
  calendar('التقويم المدرسي', Icons.calendar_month),
  search('البحث في المدرسة', Icons.search),
  statistics('إحصاءات المدرسة', Icons.bar_chart),
  integrity('فحص سلامة البيانات', Icons.fact_check_outlined);
  const SchoolTool(this.label, this.icon);
  final String label;
  final IconData icon;
}

class SchoolToolsPage extends StatefulWidget {
  const SchoolToolsPage({required this.tool, required this.records, required this.preferences,
    required this.privateView, super.key});
  final SchoolTool tool;
  final Future<Records> records;
  final SharedPreferences preferences;
  final bool privateView;
  @override
  State<SchoolToolsPage> createState() => _SchoolToolsPageState();
}

typedef _Item = ({String type, String title, String detail});
class _SchoolToolsPageState extends State<SchoolToolsPage> {
  var date = baghdadDate();
  var query = '', filter = 'الكل';
  bool saving = false;
  late Future<List<_Item>> data = _load();

  String norm(String s) => s.trim().toLowerCase().replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll(RegExp('[ـً-ْ]'), '');

  Future<List<_Item>> _load() async {
    final items = <_Item>[];
    final selectedDay = dayKey(date);
    final stats = widget.tool == SchoolTool.statistics;
    final check = widget.tool == SchoolTool.integrity;
    if (!widget.privateView) {
      final r = await widget.records;
      final classes = {for (final row in r.activeClasses) row['id'].toString(): row['name'].toString()};
      final students = r.people.where((row) => row['archived'] != true && classes.containsKey(row['classId'].toString())).toList();
      final statuses = r.attendance(selectedDay);
      if (stats) {
        items.add((type: 'إحصاءات', title: 'عدد التلاميذ', detail: '${students.length}'));
        for (final status in {'': 'غير مسجّل', ...attendanceLabels}.entries) {
          final count = students.where((s) => (statuses[s['id'].toString()] ?? '') == status.key).length;
          items.add((type: 'الحضور', title: status.value, detail: '$count'));
        }
        items.add((type: 'إحصاءات', title: 'الصفوف والشعب', detail: '${classes.length}'));
        return items;
      }
      final ids = <String>{};
      for (final s in students) {
        final id = s['id'].toString(), name = s['name']?.toString().trim() ?? '';
        if (check) {
          if (!ids.add(id) || name.isEmpty) items.add((type: 'التلاميذ', title: 'اسم مفقود أو معرّف مكرر', detail: '$id · $name'));
        } else {
          items.add((type: 'التلاميذ', title: name, detail: '${classes[s['classId'].toString()]} · ${s['number'] ?? ''}'));
        }
      }
    }
    final repo = LibraryRepository();
    late final LibraryCatalog catalog;
    try { catalog = await repo.cachedOrPackaged(); } finally { repo.client.close(); }
    final stages = catalog.stages.where(LibraryCatalog.visible).map((s) => s['id']).toSet();
    final grades = {for (final g in catalog.grades.where(LibraryCatalog.visible))
      if (stages.contains(g['stageId'])) g['id']: LibraryCatalog.name(g)};
    final subjects = {for (final s in catalog.subjects.where(LibraryCatalog.visible))
      if (grades.containsKey(s['gradeId'])) s['id']: s};
    for (final subject in subjects.values) {
      if (!check) items.add((type: 'المواد', title: LibraryCatalog.name(subject), detail: grades[subject['gradeId']] ?? ''));
    }
    for (final book in catalog.books.where(LibraryCatalog.visible)) {
      final subject = subjects[book['subjectId']];
      if (subject == null) continue;
      final name = LibraryCatalog.name(book);
      if (check) {
        if (!LibraryCatalog.validWebUrl(book['url']?.toString() ?? '')) {
          items.add((type: 'الكتب', title: name, detail: 'رابط الكتاب مفقود أو غير صالح'));
        }
      } else {
        items.add((type: 'الكتب', title: name, detail: '${grades[subject['gradeId']]} · ${LibraryCatalog.name(subject)}'));
      }
    }
    if (!check) {
      for (final l in await DatabaseService.instance.entriesDetailed()) {
        items.add((type: 'الحصص', title: l['subject_name']?.toString() ?? '',
          detail: "${l['grade_name']} · ${l['section_name']} · ${l['day_name']} ${l['start_time']} · ${l['teacher_name'] ?? ''}"));
      }
    }
    return items;
  }

  String get _key => 'madrasati.calendar.${dayKey(date)}';
  Future<void> _event() async {
    var title = '', kind = 'موعد';
    final accepted = await showDialog<bool>(context: context, builder: (ctx) =>
      StatefulBuilder(builder: (_, refresh) => AlertDialog(title: const Text('موعد مدرسي'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(autofocus: true, decoration: const InputDecoration(labelText: 'العنوان'), onChanged: (v) => refresh(() => title = v.trim())),
          DropdownButton<String>(value: kind, items: [for (final k in ['موعد','امتحان','عطلة'])
            DropdownMenuItem(value: k, child: Text(k))], onChanged: (v) => refresh(() => kind = v ?? kind)),
        ]), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: title.isEmpty ? null : () => Navigator.pop(ctx, true), child: const Text('حفظ'))])));
    if (accepted != true || !mounted) return;
    await _writeEvents([...(widget.preferences.getStringList(_key) ?? []), jsonEncode([kind,title])]);
  }

  Future<void> _writeEvents(List<String> events) async {
    setState(() => saving = true);
    try {
      if (!await widget.preferences.setStringList(_key, events)) throw StateError('write');
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذّر حفظ الموعد')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Widget _calendar() {
    final events = widget.preferences.getStringList(_key) ?? [];
    return ListView(children: [
      CalendarDatePicker(initialDate: date, firstDate: DateTime(2000), lastDate: DateTime(2100),
        onDateChanged: (v) => setState(() => date = v)),
      ListTile(title: Text(dayKey(date)), trailing: TextButton.icon(onPressed: saving ? null : _event,
        icon: const Icon(Icons.add), label: const Text('إضافة موعد'))),
      if (events.isEmpty) const ListTile(title: Text('لا توجد مواعيد لهذا اليوم')),
      for (final item in events.indexed)
        ListTile(title: Text((jsonDecode(item.$2) as List).last.toString()),
          subtitle: Text((jsonDecode(item.$2) as List).first.toString()),
          trailing: IconButton(tooltip: 'إزالة الموعد', icon: const Icon(Icons.close),
            onPressed: saving ? null : () => _writeEvents([...events]..removeAt(item.$1)))),
    ]);
  }

  Widget _statisticsCards(List<_Item> values) {
    // Softened jewel tones retain category distinction without harsh saturation.
    const tones = <Color>[
      Color(0xff167f76), Color(0xff497ca8), Color(0xff8766ad),
      Color(0xffb47c3f), Color(0xffa95872), Color(0xff2e8092),
      Color(0xff607ca0), Color(0xff338374),
    ];
    return LayoutBuilder(builder: (context, limits) {
      final columns = limits.maxWidth >= 680 ? 4 :
          limits.maxWidth >= 490 ? 3 : 2;
      return GridView.builder(
        key: const ValueKey('school-statistics-colored-grid'),
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 30),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: columns,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.07,
        ),
        itemCount: values.length,
        itemBuilder: (context, index) {
          final item = values[index];
          final tone = tones[index % tones.length];
          return Container(
            key: ValueKey('school-stat-${item.title}'),
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: AlignmentDirectional.topStart,
                end: AlignmentDirectional.bottomEnd,
                colors: [tone, Color.lerp(tone, const Color(0xff25364f), .16)!],
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Stack(children: [
              // Fully inside the tile instead of clipping most of the drawing.
              Positioned(left: 1, bottom: 5,
                child: IgnorePointer(child: SchoolStatLineIcon(
                  label: item.title, size: 94, opacity: .24, lineWidth: 1.15,
                )),
              ),
              Padding(padding: const EdgeInsets.all(13),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    DecoratedBox(
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: .15),
                        border: Border.all(color: Colors.white.withValues(alpha: .22)),
                        borderRadius: BorderRadius.circular(13),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: SchoolStatLineIcon(
                          label: item.title, size: 24, lineWidth: 1.8,
                        ),
                      ),
                    ),
                    Column(crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min, children: [
                        Text(item.detail, maxLines: 1,
                          style: const TextStyle(color: Colors.white,
                            fontSize: 27, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 5),
                        Text(item.title, maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white,
                            fontSize: 12, fontWeight: FontWeight.w700)),
                      ]),
                  ],
                )),
            ]),
          );
        },
      );
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.tool.label)),
    body: SafeArea(child: widget.tool == SchoolTool.calendar ? _calendar() : Column(children: [
      if (widget.tool == SchoolTool.search) Padding(padding: const EdgeInsets.all(12),
        child: Column(children: [
          TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'اسم التلميذ أو الكتاب أو المادة أو الصف'),
            onChanged: (v) => setState(() => query = norm(v))),
          Wrap(spacing: 5, children: [for (final type in ['الكل', if (!widget.privateView) 'التلاميذ','المواد','الكتب','الحصص'])
            ChoiceChip(label: Text(type), selected: filter == type, onSelected: (_) => setState(() => filter = type))]),
        ])),
      if (widget.tool == SchoolTool.statistics) ListTile(title: Text('حضور ${dayKey(date)}'), trailing: IconButton(
        icon: const Icon(Icons.event), onPressed: () async {
          final v = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2000), lastDate: DateTime(2100));
          if (mounted && v != null) setState(() { date = v; data = _load(); });
        })),
      Expanded(child: FutureBuilder<List<_Item>>(future: data, builder: (_, snap) {
        if (snap.hasError) return Center(child: TextButton(onPressed: () => setState(() => data = _load()), child: const Text('تعذّر قراءة البيانات · إعادة المحاولة')));
        if (!snap.hasData || snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        final matches = snap.data!.where((i) => (filter == 'الكل' || filter == i.type) && norm('${i.title} ${i.detail}').contains(query)).toList();
        if (matches.isEmpty) return Center(child: Text(widget.tool == SchoolTool.integrity ? 'اكتمل الفحص دون ملاحظات في البيانات المفحوصة' : 'لا توجد نتائج'));
        if (widget.tool == SchoolTool.statistics) {
          return _statisticsCards(matches);
        }
        return ListView.builder(itemCount: matches.length, itemBuilder: (_, index) {
          final i = matches[index];
          return ListTile(title: Text(i.title), subtitle: Text('${i.type} · ${i.detail}'));
        });
      })),
    ])));
}
