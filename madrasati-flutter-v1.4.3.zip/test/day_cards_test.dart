import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/day_cards.dart';
import 'package:madrasati/school_day.dart';

void main() {
  testWidgets('schedule has colored lesson cards and working actions',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 900);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var bell = 0;
    var books = 0;
    final day = SchoolDay(
      [<String, Object?>{'id': 3, 'grade_name': 'الخامس', 'section_name': 'ب'}],
      [
        <String, Object?>{
          'subject_name': 'اللغة العربية',
          'teacher_name': 'أحمد',
          'start_time': '08:00', 'end_time': '08:40',
        },
        <String, Object?>{
          'subject_name': 'التربية الفنية',
          'teacher_name': 'سارة',
          'start_time': '08:45', 'end_time': '09:25',
        },
      ],
      <String, Object?>{'id': 3, 'grade_name': 'الخامس', 'section_name': 'ب'},
      DateTime(2026, 11, 15),
    );
    await tester.pumpWidget(MaterialApp(
      locale: const Locale('ar'),
      home: Scaffold(body: SingleChildScrollView(child: DayCards(
        day: day,
        accent: const Color(0xff176e54),
        rounded: 18,
        transferring: false,
        onSectionChanged: (_) {},
        onChangeDate: () {},
        onSchedule: () {},
        onTransfer: () => bell++,
        onBooks: () => books++,
      ))),
    ));
    expect(find.byKey(const ValueKey('day-colored-header')), findsOneWidget);
    expect(find.byKey(const ValueKey('colored-lesson-0')), findsOneWidget);
    expect(find.byKey(const ValueKey('colored-lesson-1')), findsOneWidget);
    expect(find.text('اللغة العربية'), findsOneWidget);
    await tester.tap(find.text('إرسال الحصص للجرس'));
    expect(bell, 1);
    await tester.tap(find.text('كتب الصف'));
    expect(books, 1);
    expect(tester.takeException(), isNull);
  });
}
