import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/unified_design.dart';

const pupil = UnifiedStudent(id: '1', name: 'أحمد علي', group: 'الخامس أ',
  registerNumber: 'ST-001', attendance: 'حاضر', gradeCount: 3);
const lesson = UnifiedLesson(subject: 'الرياضيات', time: '08:50 - 09:30',
  teacher: 'المعلم', period: 2);

void main() {
  testWidgets('unified landing preserves five 2+2+1 native cards and live rows',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    String? opened;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: UnifiedHomePage(
      school: 'مدرستي', dayName: 'الأحد',
      lessons: const [lesson], students: const [pupil], classCount: 1,
      tasks: '2', progress: '30%',
      onSection: (id) => opened = id,
      onDay: () {}, onAttendance: () {}, onStudent: () {},
      onStats: () {}, onTeacherHub: () {}, onLibrary: () {},
      onSearch: () {},
    ))));
    await tester.pump();
    expect(find.byKey(const ValueKey('unified-home-hero')), findsOneWidget);
    expect(unifiedSections.length, 5);
    expect(find.byKey(const ValueKey('unified-section-jadwali')), findsOneWidget);
    expect(find.byKey(const ValueKey('unified-section-sajli')), findsOneWidget);
    final card = find.byKey(const ValueKey('unified-section-jadwali'));
    await tester.ensureVisible(card);
    await tester.pump();
    await tester.tap(card);
    expect(opened, 'jadwali');
    expect(tester.takeException(), isNull);
  });

  testWidgets('Sajli has one local bottom bar, square pupil tiles and grouped report',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var native = 0;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: UnifiedSectionPage(
      spec: unifiedSections[1], school: 'مدرستي', dayName: 'الأحد',
      lessons: const [lesson], students: const [pupil], classCount: 1,
      onOpenNative: () => native++,
      onOpenSection: (_) {}, onStudent: (_) {},
      onAttendance: () {}, onStatistics: () {},
      onTransferToBell: () {}, onOpenBooks: () {},
      onChangeDay: () {},
    ))));
    await tester.pump();
    expect(find.byKey(const ValueKey('unified-sajli-hero')), findsOneWidget);
    expect(find.byKey(const ValueKey('unified-tab-sajli-reports')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('unified-tab-sajli-reports')));
    await tester.pump();
    expect(find.text('تقرير ولي الأمر'), findsOneWidget);
    expect(find.textContaining('أولًا • معلومات التلميذ'), findsOneWidget);
    expect(find.textContaining('ثانيًا • التحصيل الدراسي'), findsOneWidget);
    expect(find.textContaining('ثالثًا • المواظبة والحضور'), findsOneWidget);
    expect(find.textContaining('رابعًا • الملاحظات والتوصيات'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('unified-tab-sajli-students')));
    await tester.pump();
    expect(find.byKey(const ValueKey('unified-student-1')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('scanner 4-front-4-back layout never adds secondary navigation',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: UnifiedSectionPage(
      spec: unifiedSections[4], school: 'مدرستي', dayName: 'الأحد',
      lessons: const [], students: const [], classCount: 0,
      onOpenNative: () {}, onOpenSection: (_) {}, onStudent: (_) {},
      onAttendance: () {}, onStatistics: () {}, onTransferToBell: () {},
      onOpenBooks: () {}, onChangeDay: () {},
    ))));
    await tester.tap(find.byKey(const ValueKey('unified-tab-scanner-card')));
    await tester.pump();
    expect(find.text('الأمامي 1'), findsOneWidget);
    expect(find.text('الخلفي 1'), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
    expect(tester.takeException(), isNull);
  });
}
