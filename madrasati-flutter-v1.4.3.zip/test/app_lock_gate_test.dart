import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/app_lock_gate.dart';
import 'package:madrasati/arabic_digit_formatter.dart';
import 'package:madrasati/security_store.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _FakePinBackend implements ManagerSecurePinBackend {
  final pins = <String, String>{};
  bool broken = false;
  String? lastPurpose;

  @override
  Future<bool> hasPin(String purpose) async {
    lastPurpose = purpose;
    if (broken) throw StateError('Keystore unavailable');
    return pins.containsKey(purpose);
  }

  @override
  Future<void> setPin(String purpose, String value) async {
    lastPurpose = purpose;
    if (broken) throw StateError('Keystore unavailable');
    pins[purpose] = value;
  }

  @override
  Future<bool> verify(String purpose, String value) async {
    lastPurpose = purpose;
    if (broken) throw StateError('Keystore unavailable');
    return pins[purpose] == value;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('Arabic and Persian digits are normalized for numeric PIN keyboards', () {
    const formatter = MadrasatiAsciiDigitFormatter();
    final converted = formatter.formatEditUpdate(
      const TextEditingValue(),
      const TextEditingValue(text: '١٢٣٤۵۶'),
    );
    expect(converted.text, '123456');
  });

  test('app PIN purpose and local verifier are isolated from manager PIN', () async {
    final prefs = await SharedPreferences.getInstance();
    final backend = _FakePinBackend();
    final app = ManagerPinStore(
      preferences: prefs, secure: backend,
      purpose: 'app', localKey: 'madrasati.app.localVerifier.v1',
    );
    expect(await app.locate(), ManagerPinLocation.unconfigured);
    await app.setEncrypted('123456');
    expect(backend.lastPurpose, 'app');
    expect(await app.verify('123456', ManagerPinLocation.encrypted), isTrue);
    final manager = ManagerPinStore(preferences: prefs, secure: backend);
    expect(await manager.locate(), ManagerPinLocation.unconfigured);
    expect(app.localKey, isNot(manager.localKey));
  });

  test('local fallback survives restart when Keystore fails', () async {
    final prefs = await SharedPreferences.getInstance();
    final backend = _FakePinBackend()..broken = true;
    final app = ManagerPinStore(
      preferences: prefs, secure: backend,
      purpose: 'app', localKey: 'madrasati.app.localVerifier.v1',
    );
    expect(await app.locate(), ManagerPinLocation.unavailable);
    expect(await app.setLocal('123456'), isTrue);
    expect(await app.locate(), ManagerPinLocation.local);
    expect(await app.verify('123456', ManagerPinLocation.local), isTrue);
    expect(await app.verify('654321', ManagerPinLocation.local), isFalse);
    expect(prefs.getString(app.localKey), contains('pbkdf2-v1:'));
    expect(prefs.getString(app.localKey), isNot(contains('123456')));
    final restarted = ManagerPinStore(
      preferences: prefs, secure: backend,
      purpose: 'app', localKey: 'madrasati.app.localVerifier.v1',
    );
    expect(await restarted.locate(), ManagerPinLocation.local);
    expect(await restarted.verify('123456', ManagerPinLocation.local), isTrue);
  });

  testWidgets('lock gate covers nested routes and accepts PIN', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var unlocked = false;
    await tester.pumpWidget(MaterialApp(
      builder: (context, navigator) => StatefulBuilder(
        builder: (context, rebuildRoot) => Stack(children: [
          navigator!,
          if (!unlocked)
            Positioned.fill(child: MadrasatiAppLockGate(
              verifyPin: (pin) async {
                if (pin == '123456') {
                  rebuildRoot(() => unlocked = true);
                  return true;
                }
                return false;
              },
              verifyBiometrics: () async => false,
              authorizeRecovery: () async => false,
              saveRecoveredPin: (_) async => false,
              biometricEnabled: false,
            )),
        ]),
      ),
      home: const Scaffold(body: Center(child: Text('محتوى خاص'))),
    ));
    expect(find.text('مدرستي مقفل'), findsOneWidget);
    final pinInput = find.byKey(const ValueKey('app-lock-pin-input'));
    expect(pinInput, findsOneWidget);
    // Regression: the gate is a sibling of the root Navigator, so its
    // EditableText needs its OWN ancestor Overlay for selection/composition.
    expect(Overlay.maybeOf(tester.element(pinInput)), isNotNull);
    await tester.enterText(pinInput, '111111');
    await tester.tap(find.byKey(const ValueKey('app-lock-submit')));
    await tester.pump();
    expect(unlocked, isFalse);
    await tester.enterText(find.byKey(const ValueKey('app-lock-pin-input')), '123456');
    await tester.tap(find.byKey(const ValueKey('app-lock-submit')));
    await tester.pump();
    expect(unlocked, isTrue);
    expect(find.text('مدرستي مقفل'), findsNothing);
    expect(find.text('محتوى خاص'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('recovery requires device authorization and confirms new PIN',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var deviceApproved = false;
    String? newPin;
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(body: MadrasatiAppLockGate(
        verifyPin: (_) async => false,
        verifyBiometrics: () async => false,
        authorizeRecovery: () async => deviceApproved,
        saveRecoveredPin: (pin) async { newPin = pin; return true; },
        biometricEnabled: true,
      )),
    ));
    await tester.tap(find.byKey(const ValueKey('app-lock-recover')));
    await tester.pump();
    expect(find.byKey(const ValueKey('app-lock-confirm-input')), findsNothing);
    deviceApproved = true;
    await tester.tap(find.byKey(const ValueKey('app-lock-recover')));
    await tester.pump();
    final confirmInput = find.byKey(const ValueKey('app-lock-confirm-input'));
    expect(confirmInput, findsOneWidget);
    expect(Overlay.maybeOf(tester.element(confirmInput)), isNotNull);
    await tester.enterText(find.byKey(const ValueKey('app-lock-pin-input')), '123456');
    await tester.enterText(find.byKey(const ValueKey('app-lock-confirm-input')), '123456');
    await tester.ensureVisible(find.byKey(const ValueKey('app-lock-submit')));
    await tester.tap(find.byKey(const ValueKey('app-lock-submit')));
    await tester.pump();
    expect(newPin, '123456');
    // Complete the text input session before teardown; checking for pending
    // exceptions still validates the selection-overlay/batch-edit regression.
    tester.binding.focusManager.primaryFocus?.unfocus();
    await tester.pump();
    expect(tester.takeException(), isNull);
  });
  testWidgets('biometric unlock closes a focused PIN input', (tester) async {
    var unlocked = false;
    await tester.pumpWidget(MaterialApp(
      home: StatefulBuilder(builder: (context, rebuild) => Scaffold(
        body: unlocked ? const Text('Unlocked') : MadrasatiAppLockGate(
          verifyPin: (_) async => false,
          verifyBiometrics: () async {
            rebuild(() => unlocked = true);
            return true;
          },
          authorizeRecovery: () async => false,
          saveRecoveredPin: (_) async => false,
          biometricEnabled: true,
        ),
      )),
    ));
    await tester.enterText(
      find.byKey(const ValueKey('app-lock-pin-input')), '123456');
    final biometric = find.byKey(const ValueKey('app-lock-biometric'));
    await tester.ensureVisible(biometric);
    await tester.tap(biometric);
    await tester.pumpAndSettle();
    expect(find.text('Unlocked'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

}
