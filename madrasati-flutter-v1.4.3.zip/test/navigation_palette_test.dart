import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/bottom_nav.dart';

void main() {
  testWidgets('bottom navigation keeps four ordered colored destinations',
      (tester) async {
    final taps = <int>[];
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        bottomNavigationBar: MadrasatiBottomNav(
          selectedIndex: 0,
          onSelect: taps.add,
          items: const [
            MadrasatiNavItem('اليوم', Icons.home_outlined, Color(0xff16805e)),
            MadrasatiNavItem('الجدول', Icons.calendar_month_outlined, Color(0xff3574b9)),
            MadrasatiNavItem('سجلّي', Icons.fact_check_outlined, Color(0xff805bb6)),
            MadrasatiNavItem('الإعدادات', Icons.tune, Color(0xffbd7942)),
          ],
        ),
      ),
    ));
    await tester.pumpAndSettle();
    final bar = find.byKey(const ValueKey('madrasati-colorful-bottom-nav'));
    expect(bar, findsOneWidget);
    expect(find.text('اليوم'), findsOneWidget);
    expect(find.text('الجدول'), findsOneWidget);
    expect(find.text('سجلّي'), findsOneWidget);
    expect(find.text('الإعدادات'), findsOneWidget);
    final widgets = tester.widgetList<NavigationDestination>(
        find.byType(NavigationDestination)).toList();
    expect(widgets.map((w) => w.label).toList(),
        ['اليوم', 'الجدول', 'سجلّي', 'الإعدادات']);
    await tester.tap(find.text('سجلّي'));
    expect(taps, [2]);
    expect(tester.takeException(), isNull);
  });
}
