import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/mosaic_home.dart';

void main() {
  testWidgets('approved modern HTML sections are native Flutter and navigable', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var search = 0;
    var hub = 0;
    var students = 0;
    final entries = [
      for (final title in ['جدولي', 'سجلّي', 'جرس المعلم', 'المناهج', 'مستمسكاتي'])
        MosaicEntry(title: title, description: 'وصف قسم $title',
          icon: Icons.school_outlined, color: const Color(0xff2962a3), onTap: () {}),
    ];
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: MosaicHome(
      school: 'مدرستي', entries: entries, day: const Text('حصص حقيقية'),
      accent: const Color(0xff087c68), compact: false, rounded: 22,
      showDescriptions: true, showDay: true, showShortcuts: true,
      showDecoration: true,
      quickAttendance: () {}, quickBell: () {}, quickSettings: () {},
      onSearch: () => search++, onCenter: () => hub++,
      onStudent: () => students++,
    ))));
    await tester.pumpAndSettle();
    expect(find.text('منصتك المدرسية في مكان واحد'), findsOneWidget);
    expect(find.text('تبحث عن شيء؟'), findsOneWidget);
    expect(find.text('تطبيقات مدرستي'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('modern-global-search')));
    expect(search, 1);
    // The section cards are below the initial 393 x 852 viewport. Just
    // finding the text (or trying a tap) is not enough: the card must be
    // scrolled into the hit-testable area of the real homepage ListView.
    final homeScroll = find.byType(ListView);
    final teacherCenter = find.byKey(const ValueKey('modern-teacher-center'));
    await tester.dragUntilVisible(
      teacherCenter, homeScroll, const Offset(0, -220),
      maxIteration: 20,
    );
    await tester.pumpAndSettle();
    expect(teacherCenter.hitTestable(), findsOneWidget);
    await tester.tap(teacherCenter);
    await tester.pump();
    expect(hub, 1);

    // There are two separate "ملف التلميذ" labels on the homepage.
    // Target the intended feature card rather than a .last text match.
    final studentProfile = find.byKey(const ValueKey('modern-spotlight-ملف التلميذ'));
    await tester.dragUntilVisible(
      studentProfile, homeScroll, const Offset(0, -220),
      maxIteration: 20,
    );
    await tester.pumpAndSettle();
    expect(studentProfile.hitTestable(), findsOneWidget);
    await tester.tap(studentProfile);
    await tester.pump();
    expect(students, 1);
    expect(tester.takeException(), isNull);
  });
}
