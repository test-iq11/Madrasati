import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:iraqi_school_library_dual/services/github_publisher.dart';

class _MemoryVault implements ManagerCredentialVault {
  final values = <String, String>{};
  bool readThrows = false;
  bool writeThrows = false;

  @override
  Future<String?> read(String key) async {
    if (readThrows) throw TypeError();
    return values[key];
  }

  @override
  Future<void> write(String key, String value) async {
    if (writeThrows) throw TypeError();
    values[key] = value;
  }

  @override
  Future<void> delete(String key) async { values.remove(key); }
}

void main() {
  const owner = 'school-owner';
  const repo = 'curriculum-data';
  const markerKey = 'madrasati_manager_verified_repository_v1';
  const tokenKey = 'github_manager_fine_grained_access_token';

  MockClient clientWithPushPermission() => MockClient((_) async => http.Response(
    jsonEncode({'full_name': '$owner/$repo', 'permissions': {'push': true}}),
    200,
  ));

  test('legacy TypeError does not grant admin or crash login', () async {
    final primary = _MemoryVault();
    final legacy = _MemoryVault()..readThrows = true;
    final publisher = GitHubPublisher(client: clientWithPushPermission(),
      owner: owner, repo: repo, primaryVault: primary, legacyVault: legacy);
    expect(await publisher.enrolledOnDevice, false);
    await publisher.activateWithToken('github_pat_authorized');
    expect(await publisher.enrolledOnDevice, true);
    expect(primary.values[tokenKey], 'github_pat_authorized');
    expect(primary.values[markerKey], '$owner/$repo');
  });

  test('incomplete or wrong-repository markers fail closed', () async {
    final primary = _MemoryVault()..values[tokenKey] = 'some_token';
    final legacy = _MemoryVault();
    final publisher = GitHubPublisher(client: clientWithPushPermission(),
      owner: owner, repo: repo, primaryVault: primary, legacyVault: legacy);
    expect(await publisher.enrolledOnDevice, false);
    primary.values[markerKey] = 'wrong/repository';
    expect(await publisher.enrolledOnDevice, false);
  });

  test('correct old vault remains readable after upgrade', () async {
    final primary = _MemoryVault();
    final legacy = _MemoryVault()..values.addAll({
      markerKey: '$owner/$repo', tokenKey: 'legacy_authorized',
    });
    final publisher = GitHubPublisher(client: clientWithPushPermission(),
      owner: owner, repo: repo, primaryVault: primary, legacyVault: legacy);
    expect(await publisher.enrolledOnDevice, true);
  });

  test('new vault write TypeError never activates administrator', () async {
    final primary = _MemoryVault()..writeThrows = true;
    final publisher = GitHubPublisher(client: clientWithPushPermission(),
      owner: owner, repo: repo, primaryVault: primary, legacyVault: _MemoryVault());
    await expectLater(publisher.activateWithToken('github_pat_authorized'),
      throwsA(isA<TypeError>()));
    expect(await publisher.enrolledOnDevice, false);
  });
}
