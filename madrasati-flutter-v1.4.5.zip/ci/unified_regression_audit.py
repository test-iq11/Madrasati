"""Prevent the old two-interface regression in the unified Flutter build.

Static checks only: these cannot replace flutter analyze, flutter test, Android
integration tests, or pixel-diff comparisons against the approved HTML.
"""
from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
rd=lambda p:(root/p).read_text(encoding='utf-8')
main=rd('lib/main.dart'); ui=rd('lib/unified_design.dart')
work=rd('lib/unified_workspaces.dart'); pub=rd('pubspec.yaml')
workflow=rd('.github/workflows/build-madrasati-android.yml')
lock=rd('pubspec.lock'); android=rd('android/app/build.gradle')
source=rd('ci/check_source.py')
ui_version=re.search(r'^version:\s*(\d+\.\d+\.\d+)', pub, re.M).group(1)
section_impl=ui[ui.index('class UnifiedSectionPage extends StatefulWidget'):]
page=main[main.index('Widget _page(BuildContext context, Section section) {'):main.index('Widget _nativePage(BuildContext context, Section section) =>')]
sections={'jadwali':'JadwaliWorkspace','sajli':'SajliWorkspace',
          'bell':'BellWorkspace','library':'LibraryWorkspace','scanner':'ScannerWorkspace'}
checks={
 'The exact unified HTML reference is packaged': (root/'design_reference/unified-approved-1.3.9.html').stat().st_size>100000,
 'Five section specifications match five workspaces': len(re.findall(r"UnifiedSectionSpec\('",ui))==5 and all(f"'{sid}'=>{klass}" in section_impl or f"'{sid}'=>widget.records" in section_impl for sid,klass in sections.items()),
 'All five departments enter new shell (no fallback)': 'return _unifiedDepartment(context, section);' in page and '_nativePage(context, section)' not in page.split('return _unifiedDepartment(context, section);')[0],
 'One section bottom bar only': '_navigation(context)' in section_impl and 'bottomNavigationBar:' not in section_impl,
 'Legacy UI callback not invoked by new section': 'widget.onOpenNative(' not in section_impl,
 'Original application UI widgets completely absent from root main': all(token not in main for token in ['TimetableApp(', 'TeacherBellApp(', 'MustamsakatiApp(', 'IraqiLibraryUserApp(']) and 'return SajliApp(' not in main,
 'Sajli selection opens new profile': "detail='profile'" in work and "'_profile'" not in work,
 'Sajli real records and atomic persistence': 'model!.setScore(' in work and 'model!.setAttendance(' in work and 'File(\'${file.path}.tmp\')' in work,
 'Sajli student cards are original data, not demo fixtures': "model?.people" in work and 'seedStudents' not in work,
 'Sajli parent report has four color groups': all(s in work for s in ['أولًا • معلومات التلميذ','ثانيًا • التحصيل الدراسي','ثالثًا • المواظبة والحضور','رابعًا • الملاحظات والتوصيات']),
 'Jadwali uses original database and validates swaps': 'widget.database.rows(' in work and '_database.swapLessons(' in main,
 'Bell uses Android notification service': 'bell_device.DeviceService.load()' in work and 'bell_device.DeviceService.sync(state!)' in work,
 'Library uses real catalog and PDF': 'LibraryRepository().cachedOrPackaged()' in work and 'PdfViewer.uri(' in work,
 'Scanner uses original perspective and filters': 'scan_perspective.rectifyImage(' in work and 'scan_filters.scanImageAsync(' in work,
 'Four front and four back slots': 'List<String?>.filled(8,null)' in work and "'الأمامي ${i~/2+1}'" in work and "'الخلفي ${i~/2+1}'" in work,
 'App-lock and biometric manager safeguards preserved': 'MadrasatiAppLockGate(' in main and 'ManagerPinStore' in main,
 'Secure storage matches all modules': '^11.2.0' in pub and '^11.2.0' in rd('modules/library/pubspec.yaml') and 'version: "11.2.0"' in lock,
 'Curriculum published data packaged': (root/'data/library.json').stat().st_size>200,
 'Version source of truth in workflow and pubspec': (
     (re.search(r"^version:\s*(\d+\.\d+\.\d+\+\d+)\s*$", pub, re.M) is not None)
     and re.search(r"^version:\s*(\d+\.\d+\.\d+\+\d+)\s*$", pub, re.M).group(1)
         in workflow
     and f"EXPECTED_PROJECT_VERSION: '{re.search(r'^version:\s*(\d+\.\d+\.\d+\+\d+)\s*$', pub, re.M).group(1)}'" in workflow
 ),
 'ZIP-only GitHub extraction retained': "ZIP files found:" in workflow and 'expected_version' in workflow and 'root-level ZIP' in workflow,
 'No debug signing masquerading as release': 'signingConfigs.debug' not in android and "BUILD_KIND='debug-test'" in workflow,
 'Uncompromised APK verification and tests': all(x in workflow for x in ('flutter analyze','flutter test',':app:testDebugUnitTest','apksigner','unzip -tq')),
 'Direct dependencies declared': all(re.search(r'^  '+k+r':',pub,re.M) for k in ('image_picker','path_provider','pdf','printing','pdfrx')),
 'No WebView wrapping HTML as the Flutter app': 'WebView' not in ui and 'WebView' not in work,
 'No automatic offline admin promotion': '_enrollManagerOnThisDevice()' in main,
 'Source check still covers old failure cases': 'flutter_secure_storage' in source and 'Overlay' in source,
 'Sajli bounded-scroll tests use Flutter WidgetTester API correctly': (
     'scrollUntilVisible(tile, 280,' in rd('test/unified_no_legacy_navigation_test.dart')
     and 'scrollUntilVisible(second, 280,' in rd('test/unified_no_legacy_navigation_test.dart')
     and 'scrollDelta:' not in rd('test/unified_no_legacy_navigation_test.dart')
 ),
 'App settings show the same version as the package': f"const _version = '{ui_version}';" in main,
 'Obsolete top-level Madrasati section reference removed': not (root/'design_reference/madrasati-home-sections-modern.html').exists(),
 'Unused library HTML preview removed from assets': not (root/'modules/library/assets/library_ui.html').exists() and 'library_ui.html' not in rd('modules/library/pubspec.yaml'),
 'Unused studio desk and Jadwali icon are not bundled': 'studio-desk.png' not in pub and 'assets/app_icon/' not in rd('modules/jadwali/pubspec.yaml') and (root/'modules/jadwali/assets/app_icon/jadwali-school-icon.png').is_file(),
 'Bell tone radios use RadioGroup instead of deprecated RadioListTile.groupValue': 'RadioGroup<String>' in work and 'value:tone,groupValue:' not in work,
 'Mounted async UI update uses a braced flow-control block': 'if(mounted){setState(' in work or 'if (mounted) {\n' in work,
 'Android APK build is split by ABI and all outputs are verified': workflow.count('--split-per-abi') == 2 and 'APK_FILES=(build/app/outputs/flutter-apk/app-*-${APK_VARIANT}.apk)' in workflow and 'Expected exactly 3 ABI APKs' in workflow,
}
for key,ok in checks.items():print(f"{'PASS' if ok else 'FAIL'} | {key}")
if not all(checks.values()):raise SystemExit(f'{sum(not v for v in checks.values())} unified source checks failed')
print(f'Passed {len(checks)} checks (static only; Flutter not executed).')
