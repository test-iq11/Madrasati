"""Check the package boundaries, Android channels, and expected build inputs."""
from pathlib import Path
import re
from zipfile import ZipFile
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]


def read(name):
    return (ROOT / name).read_text(encoding='utf-8')


pubspec = read('pubspec.yaml')
# Dependency regression: an unpublished secure-storage version once blocked all CI tests.
# Verify the root manifest, library module and already-pinned lockfile agree.
assert re.search(r'^  flutter_secure_storage: \^11\.2\.0\s*$', pubspec, re.M), \
    'Root pubspec.yaml must use published flutter_secure_storage ^11.2.0'
assert re.search(r'^  flutter_secure_storage: \^11\.2\.0\s*$',
                 read('modules/library/pubspec.yaml'), re.M), \
    'Library module must match the root secure storage constraint'
assert re.search(r'^  flutter_secure_storage:\n    dependency: "direct main"\n'
                 r'(?:.*\n){0,6}    version: "11\.2\.0"$',
                 read('pubspec.lock'), re.M), \
    'The root lockfile must pin flutter_secure_storage 11.2.0 as direct main'
# One version source: pubspec.yaml, with CI version and APK metadata checked against it.
project_version = re.search(r'^version:\s*(\d+\.\d+\.\d+\+\d+)\s*$', pubspec, re.M)
assert project_version, 'pubspec.yaml must provide a valid release version'
version = project_version.group(1)
workflow = read('.github/workflows/build-madrasati-android.yml')
assert re.search(r'^\s*EXPECTED_PROJECT_VERSION:\s*' + re.escape("'" + version + "'") + r'\s*$',
                 workflow, re.M), 'GitHub workflow EXPECTED_PROJECT_VERSION and pubspec differ'
extractor = read('ci/extract_project.py')
assert f"VERSION = '{version}'" in extractor, 'Standalone ZIP extractor version mismatch'
assert f"ARCHIVE = 'madrasati-flutter-v{version.split('+', 1)[0]}.zip'" in extractor, \
    'Standalone ZIP extractor archive name mismatch'
ns = {'a': 'http://schemas.android.com/apk/res/android'}
manifest = ElementTree.parse(ROOT / 'android/app/src/main/AndroidManifest.xml')
permissions = {row.get('{' + ns['a'] + '}name') for row in manifest.findall('uses-permission')}
assert {'android.permission.CAMERA', 'android.permission.USE_BIOMETRIC',
        'android.permission.VIBRATE', 'android.permission.SCHEDULE_EXACT_ALARM'} <= permissions
# Regression guard: a missing Bundle import previously broke :app:compileReleaseJavaWithJavac.
sajli_activity = read('android/app/src/main/java/com/sajli/school/SajliActivity.java')
assert 'FlutterFragmentActivity' in sajli_activity
assert re.search(r'^import\s+android\.os\.Bundle\s*;', sajli_activity, re.M), \
    'SajliActivity must import android.os.Bundle for PrintDocumentAdapter.onLayout'
assert re.search(r'LayoutResultCallback\s+\w+,\s*Bundle\s+\w+', sajli_activity), \
    'Check the native PDF PrintDocumentAdapter signature'
assert 'MainActivity : SajliActivity' in read('android/app/src/main/kotlin/com/school/teacherbell/MainActivity.kt')
assert 'com.school.teacherbell/device' in read('android/app/src/main/kotlin/com/school/teacherbell/MainActivity.kt')
assert '"sajli/files"' in read('android/app/src/main/java/com/sajli/school/SajliActivity.java')
with ZipFile(ROOT / 'android/gradle/wrapper/gradle-wrapper.jar') as wrapper:
    assert 'org/gradle/wrapper/GradleWrapperMain.class' in wrapper.namelist()
for module in ('jadwali', 'scanner', 'library'):
    assert 'file_picker: 13.3.2' in read(f'modules/{module}/pubspec.yaml')
    assert all('FilePicker.platform' not in f.read_text() for f in (ROOT / 'modules' / module / 'lib').rglob('*.dart'))
assert 'share_plus: 13.1.0' in read('modules/scanner/pubspec.yaml')
assert 'excel_plus:' in read('modules/library/pubspec.yaml')
assert '\n  excel:' not in read('modules/library/pubspec.yaml')
for asset in ('UI-Regular.ttf', 'UI-Bold.ttf', 'UI-Latin.ttf', 'Arabic-Regular.ttf', 'Report-Regular.ttf'):
    assert (ROOT / 'modules/jadwali/assets/fonts' / asset).stat().st_size > 1000
for path in (
    'modules/jadwali/test/unscheduled_reason_1312_test.dart',
    'modules/sajli/test/records_test.dart',
    'android/app/src/test/kotlin/com/school/teacherbell/BellVibrationTest.kt',
    'modules/library/assets/library_seed.json',
    'modules/scanner/assets/demo/sample_front.jpg',
):
    assert (ROOT / path).is_file(), path
for module in ('jadwali', 'bell', 'sajli', 'scanner', 'library'):
    assert f'path: modules/{module}' in pubspec
print('Project, module assets, native Android bridges, and dependency declarations checked.')

# Keep the Android toolchain aligned with the pinned Flutter release.
assert 'gradle-9.3.1-bin.zip' in read('android/gradle/wrapper/gradle-wrapper.properties')
assert 'id "com.android.application" version "9.1.1"' in read('android/settings.gradle')
assert 'android.builtInKotlin=false' in read('android/gradle.properties')
assert 'android.newDsl=false' in read('android/gradle.properties')
workflow = read('.github/workflows/build-madrasati-android.yml')
assert "FLUTTER_VERSION: '3.50.0'" in workflow
assert '--android-skip-build-dependency-validation' not in workflow
# CI must use the unit-test variant registered by AGP 9 (not a nonexistent release task).
assert ':app:testReleaseUnitTest' not in workflow, 'AGP 9 does not create this task by default'
assert ':app:testDebugUnitTest' in workflow
assert 'TEST-*.xml' in workflow and 'Android JUnit:' in workflow
for name in ('BellSchedulerTest.kt', 'BellVibrationTest.kt'):
    test_path = ROOT / 'android/app/src/test/kotlin/com/school/teacherbell' / name
    assert '@Test' in test_path.read_text(encoding='utf-8'), f'{name} has no tests'
# The workflow and source project must both avoid Maven Central as first resolver.
mirror = 'https://maven-central-eu.storage-download.googleapis.com/maven2/'
for gradle in ('android/settings.gradle', 'android/build.gradle'):
    gradle_source = read(gradle)
    assert gradle_source.index(mirror) < gradle_source.index('mavenCentral()'), gradle
    assert 'google()' in gradle_source and 'mavenCentral()' in gradle_source
# Gradle basic cache needs *.gradle* in repository root; this project is ZIP-only.
# Use the standard GitHub Actions cache keyed from the ZIP in the repo root.
assert 'uses: actions/cache@v4' in workflow
assert "hashFiles('*.zip')" in workflow
assert 'uses: gradle/actions/setup-gradle@v6' not in workflow
assert 'Configure Maven Central mirror in extracted source' in workflow
print('Google-hosted Maven mirror and ZIP-safe Gradle dependency cache checked.')
print('Pinned Android toolchain and Flutter compatibility flags checked.')

# UI feature and release metadata regression guards.
main = read('lib/main.dart')
assert 'return MosaicHome(' in main
assert 'Widget _bottomNav()' in main
assert 'MadrasatiAppLockGate(' in main
assert (ROOT / 'lib/app_lock_gate.dart').is_file()
assert (ROOT / 'lib/arabic_digit_formatter.dart').is_file()
assert 'child: Stack(children:' in main, 'App lock must cover all Navigator routes'
assert "purpose: 'app'" in main, 'Application PIN must be isolated from manager PIN'
assert 'MadrasatiPinStore' in main
assert 'فتح بالبصمة' in main
assert 'ألوان بطاقات التطبيقات' in main
assert (ROOT / 'test/mosaic_home_test.dart').is_file()
assert (ROOT / 'modules/sajli/test/student_name_navigation_test.dart').is_file()
assert "studentProfile(context, s);" in read('modules/sajli/lib/main.dart')
version_name, version_code = version.split('+', 1)
assert 'APK package metadata:' in workflow, 'APK metadata validation must print the observed package line'
assert "'iq.madrasati.school'" in workflow, 'APK application ID validation is missing'
assert f"'versionCode': (r\"\\bversionCode='([^']+)'\", '{version_code}')" in workflow, \
    'APK versionCode validation does not match pubspec.yaml release version'
assert f"'versionName': (r\"\\bversionName='([^']+)'\", '{version_name}')" in workflow, \
    'APK versionName validation does not match pubspec.yaml release version'
assert 'Both aapt and aapt2 failed' in workflow, 'APK metadata diagnostics must report both parser failures'
assert "expected_version = os.environ['EXPECTED_PROJECT_VERSION']" in workflow, \
    'ZIP-selection guard must use CI expected version'
# Prevent the modern-home navigation test from tapping cards that are
# rendered far below a phone-sized viewport (CI regression on 2026-11-19).
modern_test = read('test/modern_preview_test.dart')
modern_home = read('lib/mosaic_home.dart')
assert "ValueKey('modern-teacher-center')" in modern_home
assert "ValueKey('modern-spotlight-$title')" in modern_home
assert 'dragUntilVisible(' in modern_test
assert 'studentProfile.hitTestable()' in modern_test
assert 'teacherCenter.hitTestable()' in modern_test
assert "tester.ensureVisible(find.text('مركز المعلم الذكي'))" not in modern_test
print('Modern homepage tests scroll both feature cards into the hittable viewport.')
# Regression guards for 1.3.7 single-level department navigation and cards.
assert "drawer: _section == Section.today ? null : _sectionDrawer(context)" in main
assert "? () => _open(Section.today)" in main
assert "_shellScaffold.currentState?.openDrawer()" in main
assert "(_section == Section.today || _section == Section.settings)" in main
assert '_decoratedSection(' not in main, 'No duplicate department title hero'
assert 'child: _page(context, section)' in main
mosaic = read('lib/mosaic_home.dart')
assert 'final tileHeight = compact ? 155.0' in mosaic
assert 'final fifthHeight = compact ? 116.0 : 126.0' in mosaic
assert "ValueKey('student-selection-grid')" in read('modules/sajli/lib/main.dart')
assert 'SliverGridDelegateWithMaxCrossAxisExtent' in read('modules/sajli/lib/main.dart')
assert "ValueKey('school-statistics-colored-grid')" in read('lib/school_tools.dart')
assert "ValueKey('scanner-section-bottom-navigation')" in read('modules/scanner/lib/main.dart')
assert 'bottom: PreferredSize(' not in read('modules/scanner/lib/main.dart')
assert (ROOT / 'modules/sajli/test/student_picker_grid_test.dart').is_file()
assert (ROOT / 'test/school_statistics_grid_test.dart').is_file()
print('Single department bottom navigation, HTML-style tiles, student and statistic cards checked.')
# Sajli 1.3.8: keep real-statistic fine-line drawings, full pupil cards,
# and grouped guardian sections inside the Flutter app (not HTML only).
assert (ROOT / 'lib/school_stat_icon.dart').is_file()
assert 'SchoolStatLineIcon(' in read('lib/school_tools.dart')
assert 'student-selection-card-${id(current)}' in read('modules/sajli/lib/main.dart')
assert "attendanceLabels[status]" in read('modules/sajli/lib/main.dart')
assert 'sajli-parent-report-groups' in read('modules/sajli/lib/main.dart')
assert (ROOT / 'modules/sajli/test/parent_report_layout_test.dart').is_file()
assert 'test/parent_report_layout_test.dart' in workflow
assert 'reportBluePale' in read('modules/sajli/lib/report.dart')



print('Mosaic, Sajli name-tap, privacy lock and release versions checked.')

# Visual and behavioral regressions: approved RTL mosaic and student-grade entry.
assert 'tileHeight' in read('lib/mosaic_home.dart')
assert 'mosaic-${entry.title}' in read('lib/mosaic_home.dart')
assert 'ModernDayPanel(' in read('lib/main.dart')
assert 'DayCards(' in read('lib/modern_day_panel.dart')
assert 'showDialog<String>' in read('modules/sajli/lib/main.dart')
assert 'useRootNavigator: false' in read('modules/sajli/lib/main.dart')
assert 'student-sheet-save-grade' in read('modules/sajli/lib/student_sheet.dart')
assert (ROOT / 'test/day_cards_test.dart').is_file()
assert (ROOT / 'modules/sajli/test/student_name_navigation_test.dart').is_file()
print('Approved visual layout and real grade-entry flow checked.')

# Previous Sajli regression: the student grade sheet must preserve the original
# profile title and delete/undo path in addition to its new direct grade editor.
sheet = read('modules/sajli/lib/student_sheet.dart')
assert "import 'package:material_ui/material_ui.dart';" in sheet, \
    'Student sheet must use Sajli material_ui Material ancestors'
assert "import 'package:flutter/material.dart';" not in sheet, \
    'A mismatched Flutter Material import causes No Material widget found'
assert "key: const ValueKey('student-sheet-scrollable')" in sheet
assert "const Divider(height: 1)" in sheet, \
    'Student delete actions must be outside the scrolling form'
assert "Text('ملف التلميذ'" in sheet
assert "Text('حذف التلميذ'" in sheet
assert "ValueKey('student-sheet-save-grade')" in sheet
assert "ValueKey('student-sheet-close')" in sheet
assert "ValueKey('student-sheet-delete')" in sheet
assert 'showDialog<String>' in read('modules/sajli/lib/main.dart')
assert 'useRootNavigator: false' in read('modules/sajli/lib/main.dart')
assert 'sajli-profile-regression.log' in workflow
print('Sajli grade-editor, nested navigator, delete and restore regressions guarded.')

# Nested Material regression: Sajli dialogs must not inherit the unified
# Flutter root Navigator (it uses a different Material implementation).
sajli = read('modules/sajli/lib/main.dart')
assert 'useRootNavigator: true' not in sajli, 'Sajli dialog leaks to outer Navigator'
assert sajli.count('useRootNavigator: false') >= 10, 'Nested Sajli dialogs were not all routed locally'
assert 'flutter.MaterialApp(' in read('modules/sajli/test/student_name_navigation_test.dart'), \
    'Regression test must reproduce the mixed-Material nested host'
assert 'MadrasatiBottomNav(' in main
assert 'madrasati-colorful-bottom-nav' in read('lib/bottom_nav.dart')
assert 'إنشاء رمز المدير المعتمد' in main and 'ManagerPinLocation.encrypted' in main
print('Nested dialogs, first-run admin PIN and colored navigation checked.')

# Manager recovery must never silently turn an unreadable Android Keystore
# into an unprotected first-time administrator account.
secure_store = read('lib/security_store.dart')
assert 'ManagerPinLocation.unavailable' in secure_store
assert 'ManagerPinLocation.damagedLocal' in secure_store
assert 'pbkdf2-v1:' in secure_store and 'Isolate.run' in secure_store
assert 'ManagerPinStore' in main and '_recoverManagerPin()' in main
assert 'MadrasatiPinStore.forManager()' in main
assert 'resetOnError: false' in secure_store
assert 'biometricOnly: false' in main and 'persistAcrossBackgrounding: true' in main
assert 'لم تُفتح صلاحيات المدير' in main
assert 'admin-pin-tests.log' in workflow and 'test/security_store_test.dart' in workflow
print('Admin KeyStore failure is fail-closed, recovery needs device authentication, and PIN regression tests run early.')

# Local manager setup requires device authentication. Curriculum access
# independently requires repository enrollment.
main = read('lib/main.dart')
assert 'enrolledOnDevice' in main and 'activateWithToken' in main
assert 'if (!enrolled)' in main and 'if (!await _enrollManagerOnThisDevice()) return;' in main
assert 'if (section == Section.manager)' in main
assert '_updateProtection(' not in main
publisher = read('modules/library/lib/services/github_publisher.dart')
assert 'class GitHubManagerVerifier' in publisher
assert "permission['push'] != true" in publisher
assert "await _primary.write(_enrollmentKey, _repoId);" in publisher
assert 'saveToken(String token) => activateWithToken(token)' in publisher
assert 'data/library.json' in read('modules/library/lib/services/library_repository.dart')
assert 'refreshPublic()' in read('modules/library/lib/user/user_library_app.dart')
print('GitHub-gated manager enrollment, offline library cache and regular user access verified.')

assert 'test/github_manager_verifier_test.dart' in workflow
assert 'library-manager-access.log' in workflow
assert "LIBRARY_OWNER: ${{ vars.LIBRARY_OWNER || github.repository_owner }}" in workflow
assert "LIBRARY_REPO: ${{ vars.LIBRARY_REPO || 'iraqi-curriculum-library-rebuild' }}" in workflow
assert 'const ManagerTokenDialog()' in main
local_login = main.split('Future<bool> _authenticate()', 1)[1].split('Future<String?> _askPin', 1)[0]
assert local_login.index('enrolledOnDevice') < local_login.index('_managerPinStore.locate()')
assert 'if (!await _enrollManagerOnThisDevice()) return false;' in local_login
assert "identity['login']" in publisher
assert 'madrasati_manager_verified_owner_v2' in publisher
assert 'String enteredToken' in read('modules/library/lib/admin/admin_library_app.dart')
print('Account-free users, owner-authorized GitHub enrollment and token-dialog lifecycle verified.')

# Admin TypeError regression: an encrypted token must be bound to its
# repository, existing Keystore data remains readable, and malformed local
# PIN preferences must never become an open manager session.
publisher = read('modules/library/lib/services/github_publisher.dart')
assert "storageNamespace: 'madrasati_owner_authorization_v2'" in publisher
assert 'await _validatedToken(_primary)' in publisher
assert 'await _validatedToken(_legacy)' in publisher
assert "Future<void> activateWithToken(String token)" in publisher
assert 'GitHubManagerVerifier(' in publisher
assert 'if (marker != _repoId || !_configured) return null;' in publisher
assert 'ManagerCredentialVault' in publisher
assert 'final stored = preferences.get(localKey)' in read('lib/security_store.dart')
assert 'final record = preferences.get(localKey)' in read('lib/security_store.dart')
assert 'test/github_manager_storage_test.dart' in workflow
assert (ROOT / 'modules/library/test/github_manager_storage_test.dart').is_file()
assert 'تعذّر إتمام الدخول أثناء $stage' in main
print('Admin TypeError protected by isolated encrypted enrollment, legacy fallback, tests and stage diagnostics.')


# Public library data must remain a usable standalone GitHub catalog. Never
# overwrite a remotely published catalog with this bundled initial version.
import json
remote_seed = json.loads(read('data/library.json'))
bundled_seed = json.loads(read('modules/library/assets/library_seed.json'))
assert remote_seed == bundled_seed, 'Local data/library.json must be valid catalog seed'
assert remote_seed.get('schemaVersion') == 2
assert len(remote_seed.get('stages', [])) >= 3
assert (ROOT / 'test/app_lock_gate_test.dart').is_file()
assert 'test/app_lock_gate_test.dart' in workflow
assert 'AppLockGate' in read('test/app_lock_gate_test.dart')
# Editing inside the root MaterialApp.builder must have its own Overlay.
# Without it EditableText throws debugCheckHasOverlay and can leave unfinished
# batch edits in the app-lock PIN and recovery widget tests.
lock_gate = read('lib/app_lock_gate.dart')
lock_tests = read('test/app_lock_gate_test.dart')
assert 'Overlay(initialEntries: [_lockEntry])' in lock_gate
assert 'OverlayEntry _lockEntry = OverlayEntry(builder: _lockSurface)' in lock_gate
assert '_lockEntry.markNeedsBuild()' in lock_gate
assert '_lockEntry.remove()' in lock_gate and '_lockEntry.dispose()' in lock_gate
assert 'Overlay.maybeOf(tester.element(pinInput))' in lock_tests
assert 'Overlay.maybeOf(tester.element(confirmInput))' in lock_tests
print('Packaged GitHub data/library.json and application lock regression checks passed.')

# Authentication dialogs must use a context below MaterialApp and Navigator.
assert 'navigatorKey: _navigator' in main
assert '_navigator.currentState!.overlay!.context' in main
assert not re.search(r'showDialog<[^>]+>\(\s*context: context,', main)
print('Manager setup, PIN and recovery dialogs use the root Navigator overlay.')

# Sajli is hosted by material_ui, including when tested as a standalone app.
sajli = read('modules/sajli/lib/main.dart')
card_size_controls = read('modules/sajli/lib/card_size_settings.dart')
assert "import 'package:material_ui/material_ui.dart';" in card_size_controls
assert 'package:flutter/material.dart' not in card_size_controls
for section in ['sajli', 'tile-sajli']:
    assert f"SajliCardSizeSettings('{section}')" in sajli
assert 'cardDimensions(section)' in card_size_controls

# Approved premium homepage HTML is implemented with real Flutter widgets;
# the five module entry points remain native, never a WebView mockup.
home = read('lib/mosaic_home.dart')
assert 'class MosaicHero' in home and 'modern-global-search' in home
assert 'استكشف مركز المعلم' in home and 'إنجاز المنهج' in home
assert 'مركز المعلم الذكي' in home and 'ملف التلميذ' in home
assert 'return MosaicHome(' in main and 'child: _page(context, section)' in main
assert 'approved-ui-tests.log' in workflow and 'test/modern_preview_test.dart' in workflow
assert 'class ModernDayPanel' in read('lib/modern_day_panel.dart')
assert 'class TeacherHubPage' in read('lib/teacher_hub.dart')
assert 'class CurriculumProgressPage' in read('lib/teacher_hub.dart')
assert 'test/modern_preview_test.dart' in [str(p.relative_to(ROOT)) for p in (ROOT / 'test').glob('*.dart')]
print('Premium Flutter homepage, section shells, real day editor and teacher workspace checked.')
