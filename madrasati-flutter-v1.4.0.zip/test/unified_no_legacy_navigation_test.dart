import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:madrasati/unified_design.dart';
import 'package:sajli/records.dart';

void main() {
  testWidgets('real Sajli student selection stays in one new Flutter workspace',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final original = File('modules/sajli/assets/demo.json').readAsStringSync();
    final records = Records.decode(original);
    final temp = await Directory.systemTemp.createTemp('madrasati-native-sajli-');
    addTearDown(() => temp.delete(recursive: true));
    final file = File('${temp.path}/records.json');
    await file.writeAsString(original);
    final student = records.people.first;
    var legacyLaunches = 0;

    await tester.pumpWidget(MaterialApp(home: Scaffold(body: UnifiedSectionPage(
      spec: unifiedSections[1], school: 'مدرستي', dayName: 'الأحد',
      lessons: const [], students: [UnifiedStudent(
        id: student['id'].toString(), name: student['name'].toString(),
        group: records.className(student['classId'].toString()),
        registerNumber: student['number']?.toString() ?? '',
        attendance: 'غير مسجّل',
      )], classCount: records.activeClasses.length,
      records: records, recordsFile: file,
      onOpenNative: () => legacyLaunches++,
      onOpenSection: (_) {}, onStudent: (_) {},
      onAttendance: () {}, onStatistics: () {},
      onTransferToBell: () {}, onOpenBooks: () {},
      onChangeDay: () {},
    ))));
    await tester.pump();
    expect(find.byType(UnifiedHero), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('unified-tab-sajli-students')));
    await tester.pump();
    final tile = find.byKey(ValueKey('unified-student-${student['id']}'));
    await tester.ensureVisible(tile);
    await tester.pump();
    await tester.tap(tile);
    await tester.pump();
    expect(find.text('البيانات الأساسية'), findsOneWidget);
    expect(find.byType(UnifiedHero), findsOneWidget,
      reason: 'The student profile must NOT add a second old/new hero.');
    expect(legacyLaunches, 0);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Sajli parent report uses one cohesive new design',
      (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(393, 852);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final source = File('modules/sajli/assets/demo.json').readAsStringSync();
    final records = Records.decode(source);
    final temp = await Directory.systemTemp.createTemp('madrasati-parent-');
    addTearDown(() => temp.delete(recursive: true));
    final file = File('${temp.path}/records.json');
    await file.writeAsString(source);
    var oldLaunches = 0;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: UnifiedSectionPage(
      spec: unifiedSections[1], school: 'مدرستي', dayName: 'الأحد',
      lessons: const [], students: const [], classCount: 0,
      records: records, recordsFile: file,
      initialTab: 'reports', onOpenNative: () => oldLaunches++,
      onOpenSection: (_) {}, onStudent: (_) {},
      onAttendance: () {}, onStatistics: () {},
      onTransferToBell: () {}, onOpenBooks: () {}, onChangeDay: () {},
    ))));
    await tester.pump();
    expect(find.text('تقرير ولي الأمر'), findsOneWidget);
    // The section headings are present inside the new scrollable workspace.
    final second = find.text('ثانيًا • التحصيل الدراسي');
    await tester.ensureVisible(second);
    await tester.pump();
    expect(second, findsOneWidget);
    expect(oldLaunches, 0);
    expect(tester.takeException(), isNull);
  });
}
