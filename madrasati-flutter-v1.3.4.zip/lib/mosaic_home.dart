import 'package:madrasati_cards/card_size.dart';
import 'dart:math' as math;

import 'package:flutter/material.dart';

class MosaicEntry {
  const MosaicEntry({
    required this.title,
    required this.description,
    required this.icon,
    required this.color,
    required this.onTap,
    this.section,
  });
  final String? section;
  final String title;
  final String description;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
}

/// Studio launcher with two mobile columns and a three-column wide layout.
class MosaicHome extends StatelessWidget {
  const MosaicHome({
    required this.school,
    this.banner,
    this.center,
    required this.entries,
    required this.day,
    required this.accent,
    required this.compact,
    required this.rounded,
    required this.showDescriptions,
    required this.showDay,
    required this.showShortcuts,
    required this.showDecoration,
    required this.quickAttendance,
    required this.quickBell,
    required this.quickSettings,
    super.key,
  });

  final Widget? banner, center;
  final String school;
  final List<MosaicEntry> entries;
  final Widget day;
  final Color accent;
  final bool compact;
  final double rounded;
  final bool showDescriptions;
  final bool showDay;
  final bool showShortcuts;
  final bool showDecoration;
  final VoidCallback quickAttendance;
  final VoidCallback quickBell;
  final VoidCallback quickSettings;

  @override
  Widget build(BuildContext context) {
    final ink = Theme.of(context).colorScheme.onSurface;
    return LayoutBuilder(builder: (context, limits) {
      final outerPadding = limits.maxWidth >= 700 ? 20.0 : 14.0;
      final gridWidth = math.min(820.0, limits.maxWidth - outerPadding * 2);
      final gap = 10.0;
      final wide = limits.maxWidth >= 760;
      final tileHeight = compact ? 110.0 : 130.0;
      final fifthHeight = compact ? 76.0 : 86.0;
      if (entries.length < 5) {
        return const Center(child: Text('الأقسام غير مكتملة'));
      }
      return ListView(
        key: const PageStorageKey('mosaic-home'),
        padding: EdgeInsets.fromLTRB(outerPadding, 12, outerPadding, 30),
        children: [
          Center(
            child: SizedBox(
              width: gridWidth,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  banner ?? _banner(),
                  const SizedBox(height: 21),
                  Row(children: [
                    Icon(Icons.grid_view_rounded, color: accent, size: 22),
                    const SizedBox(width: 7),
                    Expanded(child: Text('تطبيقات مدرستي',
                      style: TextStyle(fontSize: 20, color: ink,
                          fontWeight: FontWeight.w900))),
                  ]),
                  const SizedBox(height: 13),
                  for (final row in (wide ? [[0, 1, 2], [3, 4]] : [[0, 1], [2, 3], [4]])) ...[
                    Row(children: [
                      for (final i in row) ...[
                        if (i != row.first) SizedBox(width: gap),
                        Expanded(child: _tile(context, entries[i],
                          i == 4 || (wide && i == 3) ? fifthHeight : tileHeight,
                          horizontal: i == 4 || (wide && i == 3))),
                      ],
                    ]),
                    if (row.last != 4) SizedBox(height: gap),
                  ],
                  if (showDay) ...[
                    const SizedBox(height: 22),
                    day,
                  ],
                  if (center != null) ...[const SizedBox(height: 16), center!],
                  if (showShortcuts) ...[
                    const SizedBox(height: 22),
                    Row(children: [
                      Icon(Icons.bolt_rounded, color: accent, size: 22),
                      const SizedBox(width: 7),
                      Text('اختصارات سريعة',
                          style: TextStyle(fontSize: 18,
                              color: ink, fontWeight: FontWeight.w900)),
                    ]),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: _shortcut(context, 'الجرس',
                          Icons.notifications_outlined,
                          const Color(0xffc9efd8), const Color(0xff116d50),
                          quickBell)),
                      const SizedBox(width: 8),
                      Expanded(child: _shortcut(context, 'تسجيل\nالحضور',
                          Icons.how_to_reg_outlined,
                          const Color(0xffd8ecfb), const Color(0xff17638c),
                          quickAttendance)),
                      const SizedBox(width: 8),
                      Expanded(child: _shortcut(context, 'تخصيص\nالواجهة',
                          Icons.tune_rounded,
                          const Color(0xffeae0f9), const Color(0xff6540a0),
                          quickSettings)),
                    ]),
                  ],
                ],
              ),
            ),
          ),
        ],
      );
    });
  }

  Widget _banner() => Container(
    constraints: BoxConstraints(minHeight: compact ? 112 : 146),
    decoration: BoxDecoration(
      color: accent,
      gradient: showDecoration
          ? LinearGradient(
              begin: AlignmentDirectional.topStart,
              end: AlignmentDirectional.bottomEnd,
              colors: [accent, Color.lerp(accent, Colors.black, .29)!],
            )
          : null,
      borderRadius: BorderRadius.circular(rounded + 12),
    ),
    clipBehavior: Clip.antiAlias,
    child: Stack(children: [
      if (showDecoration) ...[
        PositionedDirectional(
          bottom: -63, start: -22,
          child: Container(width: 230, height: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              color: Colors.white.withValues(alpha: .09),
            )),
        ),
        PositionedDirectional(
          top: -67, end: -40,
          child: Container(width: 160, height: 150,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withValues(alpha: .055),
            )),
        ),
      ],
      Padding(
        padding: EdgeInsets.all(compact ? 17 : 23),
        child: Row(children: [
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(school, maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: Colors.white,
                  fontSize: compact ? 27 : 34,
                  fontWeight: FontWeight.w900)),
              if (showDescriptions) ...[
                const SizedBox(height: 4),
                const Text('الجدول، الدرجات، الجرس، المناهج\nوالمستمسكات',
                  style: TextStyle(color: Colors.white,
                    height: 1.45, fontSize: 12)),
              ],
            ],
          )),
          if (showDecoration) ...[
            const SizedBox(width: 14),
            Container(
              width: 67, height: 67,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: .17),
                borderRadius: BorderRadius.circular(21),
              ),
              child: const Icon(Icons.school_outlined,
                color: Colors.white, size: 43),
            ),
          ],
        ]),
      ),
    ]),
  );

  Widget _tile(BuildContext context, MosaicEntry entry, double height,
      {bool horizontal = false}) {
    final scheme = Theme.of(context).colorScheme;
    final bg = Color.lerp(scheme.surface, entry.color, .13)!;
    const iconSize = 39.0;
    final icon = Container(
      width: iconSize, height: iconSize,
      decoration: BoxDecoration(
        color: entry.color,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Icon(entry.icon, color: Colors.white,
          size: 23),
    );
    final labels = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(entry.title, maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: scheme.onSurface,
              fontSize: 18,
              fontWeight: FontWeight.w900)),
        if (showDescriptions) ...[
          const SizedBox(height: 4),
          Text(entry.description, maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: scheme.onSurfaceVariant,
                fontSize: 11, height: 1.45)),
        ],
      ],
    );
    final tile = Material(
      color: bg,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(rounded),
        side: BorderSide(color: Color.lerp(scheme.outlineVariant, entry.color, .3)!)),
      child: InkWell(
        key: ValueKey('mosaic-${entry.title}'),
        onTap: entry.onTap,
        child: SizedBox(height: height,
          child: Padding(
            padding: EdgeInsets.all(horizontal ? 15 : 13),
            child: horizontal
                ? Row(children: [
                    icon, const SizedBox(width: 14),
                    Expanded(child: labels),
                    Icon(Icons.chevron_left_rounded,
                        color: scheme.onSurfaceVariant, size: 25),
                  ])
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [icon, Flexible(child: FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: labels))],
                  ),
          ),
        ),
      ),
    );
    return entry.section == null ? tile : SectionCard('tile-${entry.section}', child: tile);
  }

  Widget _shortcut(BuildContext context, String title, IconData icon,
      Color light, Color foreground, VoidCallback onTap) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: dark ? Color.lerp(light, Colors.black, .70) : light,
      borderRadius: BorderRadius.circular(rounded),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(rounded),
        child: SizedBox(
          height: compact ? 84 : 104,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 10),
            child: Column(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: dark ? light : foreground, size: 26),
                const SizedBox(height: 7),
                Text(title, maxLines: 2, textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 11, height: 1.35,
                    color: dark ? light : foreground,
                    fontWeight: FontWeight.w800)),
              ]),
          ),
        ),
      ),
    );
  }
}
