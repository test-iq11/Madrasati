import 'package:flutter/material.dart';

/// Standalone navigation widget: no database, channel or module dependencies.
/// The approved mosaic layout itself is intentionally unchanged.
class MadrasatiNavItem {
  const MadrasatiNavItem(this.label, this.icon, this.color);
  final String label;
  final IconData icon;
  final Color color;
}

class MadrasatiBottomNav extends StatelessWidget {
  const MadrasatiBottomNav({
    required this.items,
    required this.selectedIndex,
    required this.onSelect,
    super.key,
  });

  final List<MadrasatiNavItem> items;
  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final index = selectedIndex < 0
        ? 0
        : (selectedIndex >= items.length ? items.length - 1 : selectedIndex);
    final navColor = dark
        ? Color.lerp(items[index].color, Colors.white, .30)!
        : items[index].color;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: dark ? const Color(0xff1b292a) : const Color(0xfff0f7f5),
        border: Border(top: BorderSide(
          color: dark ? const Color(0xff36504a) : const Color(0xffdce9e4),
        )),
      ),
      child: NavigationBar(
        key: const ValueKey('madrasati-colorful-bottom-nav'),
        height: 74,
        elevation: 0,
        backgroundColor: Colors.transparent,
        indicatorColor: navColor.withValues(alpha: dark ? .25 : .17),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        selectedIndex: index,
        onDestinationSelected: onSelect,
        destinations: [
          for (var i = 0; i < items.length; i++)
            NavigationDestination(
              tooltip: items[i].label,
              icon: Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(
                  color: items[i].color.withValues(alpha: dark ? .16 : .09),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(items[i].icon,
                  color: dark
                      ? Color.lerp(items[i].color, Colors.white, .43)
                      : items[i].color,
                  size: 24,
                ),
              ),
              selectedIcon: Icon(items[i].icon,
                  color: navColor, size: 28),
              label: items[i].label,
            ),
        ],
      ),
    );
  }
}
