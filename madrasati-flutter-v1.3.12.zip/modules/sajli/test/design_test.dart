import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:sajli/card_size_settings.dart';
import 'package:sajli/main.dart';
import 'package:sajli/records.dart';

Records demoRecords() =>
    Records.decode(File('assets/demo.json').readAsStringSync());

void main() {
  testWidgets('card size controls open and resize in standalone Arabic Sajli', (tester) async {
    await tester.pumpWidget(MaterialApp(
      locale: const Locale('ar', 'IQ'),
      supportedLocales: const [Locale('ar', 'IQ')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: const Scaffold(body: SajliCardSizeSettings('test-sajli')),
    ));
    await tester.tap(find.text('حجم البطاقة داخل القسم'));
    await tester.pumpAndSettle();
    expect(find.byType(Slider), findsNWidgets(2));
    tester.widget<Slider>(find.byType(Slider).first).onChanged!(.8);
    await tester.pump();
    expect(find.text('العرض · 80٪'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('attendance reports remain available without grade data', (
    tester,
  ) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(1200, 900);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final records = demoRecords();
    final classId = records.activeClasses.first['id'].toString();
    for (final subject in records.subjects(classId)) {
      records.changeSubject(classId, subject, null);
    }
    for (final period in records.periods) {
      records.deletePeriod(period['key'].toString());
    }
    await tester.pumpWidget(
      SajliApp(records: records, file: File('unused.json')),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('التقارير').last);
    await tester.pumpAndSettle();

    final preview = find.widgetWithText(FilledButton, 'معاينة التقرير');
    expect(tester.widget<FilledButton>(preview).onPressed, isNull);
    await tester.tap(find.text('كشف الدرجات السنوي'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('كشف الحضور الشهري').last);
    await tester.pumpAndSettle();
    expect(tester.widget<FilledButton>(preview).onPressed, isNotNull);
  });

  testWidgets(
    'grade book follows the mobile preview and restores a deleted pupil',
    (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = const Size(390, 844);
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final folder = Directory.systemTemp.createTempSync('sajli-design-');
      addTearDown(() => folder.deleteSync(recursive: true));
      final records = demoRecords();
      final file = File('${folder.path}/sajli.json');
      final student = records.people.first;
      final name = student['name'].toString();
      final id = student['id'].toString();
      final subject = records.courses.first;
      final period = records.periods.first['key'].toString();
      final score = records.score(id, subject, period);
      records.setAttendance('2026-11-12', id, 'absent');

      await tester.pumpWidget(SajliApp(records: records, file: file));
      await tester.pumpAndSettle();
      expect(
        tester.getSize(find.byKey(const ValueKey('main-hero'))).height,
        greaterThan(165),
      );
      expect(find.text('سجل الدرجات'), findsOneWidget);

      final profile = find.byKey(ValueKey('profile-$id'));
      await tester.ensureVisible(profile);
      await tester.pumpAndSettle();
      expect(profile.hitTestable(), findsOneWidget);
      await tester.tap(profile);
      await tester.pumpAndSettle();
      expect(find.text('ملف التلميذ'), findsOneWidget);
      final deleteRect = tester.getRect(find.byKey(const ValueKey('student-sheet-delete')));
      expect(deleteRect.top, greaterThanOrEqualTo(0));
      expect(deleteRect.bottom, lessThanOrEqualTo(844));
      await tester.tap(find.text('حذف التلميذ'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('إلغاء'));
      await tester.pumpAndSettle();
      expect(records.people.any((s) => s['id'] == student['id']), isTrue);

      await tester.ensureVisible(profile);
      await tester.pumpAndSettle();
      expect(profile.hitTestable(), findsOneWidget);
      await tester.tap(profile);
      await tester.pumpAndSettle();
      await tester.tap(find.text('حذف التلميذ'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('تأكيد الحذف'));
      await tester.pumpAndSettle();
      expect(records.people.any((s) => s['id'] == student['id']), isFalse);
      expect(records.score(id, subject, period), isNull);
      expect(records.attendance('2026-11-12')[id], isNull);
      expect(find.text('حُذف ملف $name'), findsOneWidget);
      await tester.tap(find.text('تراجع'));
      await tester.pumpAndSettle();
      expect(records.score(id, subject, period), score);
      expect(records.attendance('2026-11-12')[id], 'absent');
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'saved height, text scaling, dark theme and display cards fit compact and wide screens',
    (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = const Size(320, 760);
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final records = demoRecords();
      records.data['appearance'] = {
        'hero': 'extra',
        'theme': 'dark',
        'font': 'largest',
        'density': 'compact',
      };
      await tester.pumpWidget(
        SajliApp(records: records, file: File('unused.json')),
      );
      await tester.pumpAndSettle();
      expect(
        tester.getSize(find.byKey(const ValueKey('main-hero'))).height,
        greaterThanOrEqualTo(224),
      );
      await tester.tap(find.text('الحضور').last);
      await tester.pumpAndSettle();
      expect(find.text('سجل الحضور'), findsOneWidget);
      await tester.tap(find.text('التقارير').last);
      await tester.pumpAndSettle();
      expect(find.text('نطاق العرض'), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('sajli-nav-3')));
      await tester.pumpAndSettle();
      final display = find.text('تفضيلات العرض');
      await tester.ensureVisible(display);
      await tester.pumpAndSettle();
      expect(display.hitTestable(), findsOneWidget);
      await tester.tap(display);
      await tester.pumpAndSettle();
      expect(find.text('ارتفاع البطاقة الرئيسية'), findsOneWidget);
      expect(find.text('مرتفعة جدًا'), findsOneWidget);
      expect(tester.takeException(), isNull);
      tester.view.physicalSize = const Size(1200, 900);
      await tester.tap(find.byKey(const ValueKey('sajli-nav-0')));
      await tester.pumpAndSettle();
      expect(find.text('بطاقة المتابعة الفردية'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
}
