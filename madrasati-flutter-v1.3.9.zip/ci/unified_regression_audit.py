"""Offline source audit for the approved unified native design.

This is NOT a substitute for Dart compilation, Flutter widget tests,
Android instrumented tests, actual APK signing, or screenshot comparisons.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
read = lambda p: (root / p).read_text(encoding='utf-8')
main = read('lib/main.dart')
ui = read('lib/unified_design.dart')
workflow = read('.github/workflows/build-madrasati-android.yml')
android = read('android/app/build.gradle')
source = read('ci/check_source.py')
sajli = read('modules/sajli/lib/main.dart')

checks = {
    'Baseline HTML retained byte-for-byte': (root / 'design_reference/unified-approved-1.3.9.html').stat().st_size > 100000,
    'All five department palettes and tabs': len(re.findall(r"UnifiedSectionSpec\('", ui)) == 5,
    'Native Flutter not embedded WebView HTML': 'WebView' not in ui and 'HtmlElementView' not in ui,
    'Native unified UI default enabled': "_prefs.getBool('${_prefix}unifiedDesign') ?? true" in main,
    'Old original tools kept available': '_nativePage(BuildContext context, Section section)' in main and 'onOpenNative: () => _launchNative(section)' in main,
    'Home 2x2 plus one wide card': "section.id == 'scanner' ? box.maxWidth : half" in ui,
    'One department-specific navigation': '_moduleNavigation(context)' in ui and 'bottomNavigationBar:' in main,
    'Student directly opens real Sajli profile': "_center.value = 'profile:$studentId'" in main and "request.startsWith('profile:')" in sajli,
    'School stats come from real attendance': 'records.attendance(currentDate)' in main and 'records.score(id, subject, key)' in main,
    'No new mock student fixtures in app source': 'seedStudents' not in ui and 'demo.json' not in ui,
    'Thin-line stat icon used': 'SchoolStatLineIcon(' in ui and 'lineWidth: 1.32' in ui,
    'Grouped parent report': all(x in ui for x in ('أولًا • معلومات التلميذ', 'ثانيًا • التحصيل الدراسي', 'ثالثًا • المواظبة والحضور', 'رابعًا • الملاحظات والتوصيات')),
    'Scanner has 4 front and 4 back layout': 'i < 8' in ui and 'i.isEven' in ui,
    'Reference card height controlled in settings': 'unifiedCardHeight' in main and 'this.height = 158' in ui,
    'True black unified night background': 'Color(0xff000000)' in ui and "final bg = dark ? const Color(0xff000000)" in main,
    'Admin and app gate preserved': 'MadrasatiAppLockGate(' in main and 'ManagerPinStore' in main,
    'Missing secure storage pinned version': '^11.2.0' in read('pubspec.yaml') and '^11.2.0' in read('modules/library/pubspec.yaml'),
    'Curriculum local JSON present': (root / 'data/library.json').stat().st_size > 100,
    'No release builds with debug signing': 'signingConfigs.debug' not in android and 'if (releaseStore)' in android,
    'No misleading unsigned release as installable release': "BUILD_KIND='debug-test'" in workflow and "BUILD_KIND='release'" in workflow,
    'New native tests in early CI': 'test/unified_design_test.dart' in workflow,
    'Same matching source version': "EXPECTED_PROJECT_VERSION: '1.3.9+24'" in workflow and 'version: 1.3.9+24' in read('pubspec.yaml'),
    'No automatic manager activation for user': '_authenticate()' in main and '_enrollManagerOnThisDevice()' in main,
    'Known grid regression guards retained': 'student-picker-grid' in read('modules/sajli/test/student_picker_grid_test.dart') or 'student-selection-grid' in sajli,
    'Existing regression suites stay enabled': all(s in workflow for s in ('test/app_lock_gate_test.dart','test/modern_preview_test.dart','test/parent_report_layout_test.dart', ':app:testDebugUnitTest')),
}
for title, passed in checks.items():
    print(f'{"PASS" if passed else "FAIL"} | {title}')
if not all(checks.values()):
    raise SystemExit(f'Failed {sum(not v for v in checks.values())} static checks')
print(f'Passed {len(checks)} offline regression checks (not a Flutter compile).')
