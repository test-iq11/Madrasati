import 'package:flutter/material.dart';
import 'package:madrasati_cards/unified_visuals.dart';
import 'interface_settings.dart';

class HtmlDashboardHero extends StatelessWidget {
  const HtmlDashboardHero({super.key, required this.onRepair, required this.onTimetable});
  final VoidCallback onRepair, onTimetable;
  @override
  Widget build(BuildContext context) {
    final ui = InterfaceSettings.instance;
    return UnifiedHero(key: const ValueKey('html-dashboard-hero'), title: 'جدولي الذكي',
      description: 'تخطيط الحصص وإصلاح التعارضات بأقل تغييرات ممكنة، ومعاينة كل خطوة قبل اعتمادها.',
      icon: Icons.calendar_month_outlined, first: ui.design.a, last: ui.design.b,
      chips: const [(Icons.swap_horiz, 'إصلاح ذكي'), (Icons.calendar_today_outlined, 'الجدول الدراسي')],
      actions: [FilledButton(onPressed: onRepair,
        style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: ui.design.accent),
        child: const Text('استكشف الإصلاح الذكي')),
        TextButton(onPressed: onTimetable, style: TextButton.styleFrom(foregroundColor: Colors.white),
          child: const Text('فتح الجدول الدراسي'))]);
  }
}
