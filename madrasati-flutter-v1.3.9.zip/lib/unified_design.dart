import 'package:flutter/material.dart';
import 'school_stat_icon.dart';

/// The approved unified HTML visual language, translated into native Flutter.
/// This layer is deliberately presentation-only: the original school databases,
/// timetable repair engine, document scanner, PDF reader, and permissions remain
/// owned by their existing modules. Never seed fake pupils or books here.
abstract final class UnifiedStyle {
  static const background = Color(0xfff5f7fb);
  static const foreground = Color(0xff172b3d);
  static const subdued = Color(0xff718298);
  static const border = Color(0xffe5ebf2);
  static const turquoise = Color(0xff087c77);
  static const emerald = Color(0xff3cb4a6);
  static const navy = Color(0xff264b73);
  static const darkBackground = Color(0xff000000);
  static const darkSurface = Color(0xff151d26);

  static Color bg(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? darkBackground : background;
  static Color surface(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? darkSurface : Colors.white;
  static Color ink(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xffeef5fa) : foreground;
  static Color muted(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xffa3b2c5) : subdued;
  static Color line(BuildContext context) => Theme.of(context).brightness == Brightness.dark
      ? const Color(0xff344354) : border;
}

class UnifiedSectionSpec {
  const UnifiedSectionSpec(this.id, this.title, this.subtitle, this.heroTitle,
      this.description, this.first, this.last, this.icon, this.tabs);
  final String id, title, subtitle, heroTitle, description;
  final Color first, last;
  final IconData icon;
  final List<UnifiedTab> tabs;
}

class UnifiedTab {
  const UnifiedTab(this.id, this.title, this.icon);
  final String id, title;
  final IconData icon;
}

const unifiedSections = <UnifiedSectionSpec>[
  UnifiedSectionSpec('jadwali', 'جدولي الذكي', 'الحصص والإصلاح والتقارير', 'جدولي الذكي',
    'جدول منظّم يحترم قيود الحصص ويمنحك مساحة لفهم التعارضات والإصلاح والتقارير.',
    Color(0xff176d77), Color(0xff4a9a92), Icons.calendar_month_outlined, [
      UnifiedTab('main', 'الرئيسية', Icons.home_outlined),
      UnifiedTab('schedule', 'الجدول', Icons.calendar_view_week_outlined),
      UnifiedTab('repair', 'الإصلاح', Icons.swap_horiz_rounded),
      UnifiedTab('reports', 'التقارير', Icons.summarize_outlined),
      UnifiedTab('tools', 'الإعداد', Icons.tune_rounded),
    ]),
  UnifiedSectionSpec('sajli', 'سجلي المدرسي', 'الملفات والدرجات والحضور', 'سجلي المدرسي',
    'مساحة متكاملة لكل تلميذ: ملف شخصي ودرجات وحضور وتقارير ولي الأمر.',
    Color(0xff665789), Color(0xff9788b1), Icons.people_outline_rounded, [
      UnifiedTab('main', 'الملخص', Icons.home_outlined),
      UnifiedTab('students', 'التلاميذ', Icons.people_outline),
      UnifiedTab('attendance', 'الحضور', Icons.done_all_rounded),
      UnifiedTab('reports', 'التقارير', Icons.insert_drive_file_outlined),
      UnifiedTab('tools', 'الأدوات', Icons.grid_view_rounded),
    ]),
  UnifiedSectionSpec('bell', 'جرس المعلم', 'الوقت والتنبيهات', 'جرس المعلم',
    'جدول زمني هادئ، تنبيهات قابلة للضبط، وربط مباشر بحصص جدولي.',
    Color(0xffb37563), Color(0xffd5a18a), Icons.notifications_none_rounded, [
      UnifiedTab('main', 'الرئيسية', Icons.notifications_none_rounded),
      UnifiedTab('periods', 'الحصص', Icons.schedule_outlined),
      UnifiedTab('week', 'الأسبوع', Icons.calendar_month_outlined),
      UnifiedTab('alerts', 'التنبيهات', Icons.volume_up_outlined),
      UnifiedTab('tools', 'الإعدادات', Icons.tune_rounded),
    ]),
  UnifiedSectionSpec('library', 'المناهج العراقية', 'كتب ومراجعات ومتابعة قراءة', 'مناهجك المدرسية',
    'مكتبة منظّمة حسب الصف والمادة، مع المفضلة ومتابعة القراءة.',
    Color(0xff326a9a), Color(0xff70a5bb), Icons.menu_book_outlined, [
      UnifiedTab('main', 'الرئيسية', Icons.home_outlined),
      UnifiedTab('books', 'الكتب', Icons.menu_book_outlined),
      UnifiedTab('saved', 'المحفوظات', Icons.file_download_outlined),
      UnifiedTab('reviews', 'المراجعات', Icons.star_border_rounded),
      UnifiedTab('tools', 'المزيد', Icons.grid_view_outlined),
    ]),
  UnifiedSectionSpec('scanner', 'مستمسكاتي', 'حفظ المستندات وطباعتها', 'مستمسكاتي',
    'بطاقتك في دقيقة، وثائقك محفوظة ومنظمة، من الهاتف إلى طباعة A4.',
    Color(0xff416b7e), Color(0xff77a6af), Icons.document_scanner_outlined, [
      UnifiedTab('main', 'الرئيسية', Icons.home_outlined),
      UnifiedTab('docs', 'مستنداتي', Icons.description_outlined),
      UnifiedTab('card', 'بطاقة بدقيقة', Icons.document_scanner_outlined),
      UnifiedTab('print', 'الطباعة', Icons.print_outlined),
      UnifiedTab('tools', 'الأدوات', Icons.grid_view_outlined),
    ]),
];

class UnifiedStudent {
  const UnifiedStudent({required this.id, required this.name,
      required this.group, required this.registerNumber, required this.attendance,
      this.gradeCount = 0});
  final String id, name, group, registerNumber, attendance;
  final int gradeCount;
}

class UnifiedLesson {
  const UnifiedLesson({required this.subject, required this.time,
      required this.teacher, required this.period});
  final String subject, time, teacher;
  final int period;
}

class UnifiedHero extends StatelessWidget {
  const UnifiedHero({super.key, required this.title, required this.description,
    required this.icon, required this.first, required this.last,
    required this.chips, this.kicker = 'مدرستي • نموذج المدرسة • مساحة تعليمية مترابطة'});
  final String title, description, kicker;
  final IconData icon;
  final Color first, last;
  final List<(IconData, String)> chips;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, size) {
    final small = size.maxWidth < 365;
    return Container(
      constraints: BoxConstraints(minHeight: small ? 225 : 237),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(29),
        gradient: LinearGradient(begin: Alignment.topRight,
            end: Alignment.bottomLeft, colors: [last, first]),
        boxShadow: [BoxShadow(color: first.withValues(alpha: .17), blurRadius: 28,
            offset: const Offset(0, 11))],
      ),
      child: Stack(children: [
        PositionedDirectional(top: -150, end: -80,
          child: Container(width: 300, height: 300, decoration: BoxDecoration(
            shape: BoxShape.circle, border: Border.all(color: Colors.white.withValues(alpha: .14)),
          ))),
        PositionedDirectional(bottom: -110, start: -130,
          child: Container(width: 225, height: 225, decoration: BoxDecoration(
            shape: BoxShape.circle, color: Colors.white.withValues(alpha: .07),
          ))),
        Padding(padding: EdgeInsets.fromLTRB(small ? 17 : 27, 23, small ? 17 : 27, 21),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                Expanded(child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18),
                    borderRadius: BorderRadius.circular(50),
                    border: Border.all(color: Colors.white.withValues(alpha: .27))),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.auto_awesome_outlined, color: Colors.white, size: 14),
                    const SizedBox(width: 7),
                    Expanded(child: Text(kicker, maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 10,
                        color: Colors.white, height: 1.5))),
                  ]))),
                const SizedBox(width: 11),
                const Icon(Icons.auto_awesome_rounded, size: 15, color: Color(0xffe6f9ff)),
              ]),
              const SizedBox(height: 18),
              Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min, children: [
                    Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w900, fontSize: small ? 23 : 28, height: 1.35)),
                    const SizedBox(height: 5),
                    Text(description, maxLines: 3, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xfff4f8fa),
                        fontSize: 11, height: 1.8)),
                  ])),
                const SizedBox(width: 11),
                Transform.rotate(angle: -.12,
                  child: Container(width: small ? 71 : 84, height: small ? 71 : 84,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .17),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white.withValues(alpha: .30))),
                    child: Icon(icon, color: Colors.white, size: small ? 47 : 55))),
              ]),
              const SizedBox(height: 18),
              Wrap(spacing: 7, runSpacing: 7, children: [
                for (final chip in chips)
                  Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .15),
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(color: Colors.white.withValues(alpha: .19))),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(chip.$1, color: Colors.white, size: 12),
                      const SizedBox(width: 5),
                      Text(chip.$2, style: const TextStyle(color: Colors.white,
                        fontSize: 10, fontWeight: FontWeight.w700)),
                    ])),
              ]),
            ])),
      ]),
    );
  });
}

class UnifiedHeading extends StatelessWidget {
  const UnifiedHeading(this.title, {this.subtitle, this.action, super.key});
  final String title;
  final String? subtitle;
  final Widget? action;
  @override Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 22, bottom: 12, right: 2, left: 2),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900,
          color: UnifiedStyle.ink(context))),
        if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 3),
          child: Text(subtitle!, style: TextStyle(fontSize: 10,
            color: UnifiedStyle.muted(context)))),
      ])),
      if (action != null) action!,
    ]),
  );
}

class UnifiedPanel extends StatelessWidget {
  const UnifiedPanel({super.key, required this.child, this.padding = const EdgeInsets.all(16)});
  final Widget child;
  final EdgeInsets padding;
  @override Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(color: UnifiedStyle.surface(context),
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: UnifiedStyle.line(context)),
      boxShadow: [BoxShadow(color: const Color(0xff253f55).withValues(alpha: .045),
        blurRadius: 23, offset: const Offset(0, 7))]),
    child: child,
  );
}

class UnifiedPillButton extends StatelessWidget {
  const UnifiedPillButton({super.key, required this.label, required this.onPressed,
    this.icon = Icons.arrow_back_rounded, this.color = UnifiedStyle.turquoise});
  final String label;
  final VoidCallback onPressed;
  final IconData icon;
  final Color color;
  @override Widget build(BuildContext context) => Material(
    color: color.withValues(alpha: Theme.of(context).brightness == Brightness.dark ? .26 : .10),
    borderRadius: BorderRadius.circular(11),
    child: InkWell(borderRadius: BorderRadius.circular(11), onTap: onPressed,
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: color, size: 15), const SizedBox(width: 5),
          Text(label, style: TextStyle(fontSize: 11, color: color,
            fontWeight: FontWeight.w900)),
        ]))),
  );
}

class UnifiedMetric extends StatelessWidget {
  const UnifiedMetric({super.key, required this.value, required this.label,
    required this.icon, required this.tint, required this.tone});
  final String value, label;
  final IconData icon;
  final Color tint, tone;
  @override Widget build(BuildContext context) => Container(
    constraints: const BoxConstraints(minHeight: 124),
    clipBehavior: Clip.antiAlias,
    decoration: BoxDecoration(color: UnifiedStyle.surface(context),
      borderRadius: BorderRadius.circular(19),
      border: Border.all(color: UnifiedStyle.line(context))),
    child: Stack(children: [
      PositionedDirectional(bottom: -48, start: -34,
        child: Container(width: 104, height: 104,
          decoration: BoxDecoration(shape: BoxShape.circle,
            color: tint.withValues(alpha: .50)))),
      Padding(padding: const EdgeInsets.all(13), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 38, height: 38,
          decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(12)),
          child: Center(child: SchoolStatLineIcon(
            label: label == 'إجمالي التلاميذ' || label == 'التلاميذ'
                ? 'عدد التلاميذ' : label == 'الصفوف والشعب' ? label
                : label == 'غير مسجل اليوم' || label == 'غير مسجّل'
                  ? 'غير مسجّل' : label,
            color: tone, size: 25, lineWidth: 1.32,
          ))),
        const SizedBox(height: 7),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900,
            color: UnifiedStyle.ink(context))),
        Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
          color: UnifiedStyle.muted(context))),
      ])),
    ]),
  );
}

class UnifiedFeatureCard extends StatelessWidget {
  const UnifiedFeatureCard({super.key, required this.title, required this.description,
    required this.icon, required this.first, required this.last,
    required this.onPressed, this.height = 158});
  final String title, description;
  final IconData icon;
  final Color first, last;
  final VoidCallback onPressed;
  final double height;
  @override Widget build(BuildContext context) => Material(
    color: Colors.transparent,
    child: InkWell(onTap: onPressed, borderRadius: BorderRadius.circular(23),
      child: Ink(height: height, decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(23),
        gradient: LinearGradient(begin: Alignment.topRight,
          end: Alignment.bottomLeft, colors: [first, last]),
        boxShadow: [BoxShadow(color: first.withValues(alpha: .12),
          blurRadius: 20, offset: const Offset(0, 8))]),
      child: Stack(children: [
        PositionedDirectional(top: -52, end: -48,
          child: Container(width: 160, height: 160,
            decoration: BoxDecoration(shape: BoxShape.circle,
              border: Border.all(color: Colors.white.withValues(alpha: .15))))),
        Padding(padding: const EdgeInsets.all(17), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Icon(icon, color: Colors.white, size: 26),
            const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 20),
          ]),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Colors.white, fontSize: 18,
                fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(description, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Color(0xffe9f2f4), fontSize: 10,
                height: 1.5)),
          ]),
        ])),
      ]))),
  );
}

class UnifiedQuick extends StatelessWidget {
  const UnifiedQuick({super.key, required this.title, required this.icon,
    required this.onTap, this.subtitle});
  final String title;
  final String? subtitle;
  final IconData icon;
  final VoidCallback onTap;
  @override Widget build(BuildContext context) => Material(
    color: UnifiedStyle.surface(context),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17),
      side: BorderSide(color: UnifiedStyle.line(context))),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(17),
      child: SizedBox(height: subtitle == null ? 95 : 102,
        child: Padding(padding: const EdgeInsets.all(9),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: UnifiedStyle.turquoise, size: 25),
            const SizedBox(height: 7),
            Text(title, textAlign: TextAlign.center, maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900,
                color: UnifiedStyle.ink(context))),
            if (subtitle != null) Text(subtitle!, maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: UnifiedStyle.muted(context), fontSize: 9)),
          ]))),
    ),
  );
}

class UnifiedRow extends StatelessWidget {
  const UnifiedRow({super.key, required this.icon, required this.title,
    this.subtitle, this.onTap, this.trailing, this.tone = UnifiedStyle.turquoise});
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final Color tone;
  @override Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(13),
    child: Padding(padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 3),
      child: Row(children: [
        Container(width: 43, height: 43,
          decoration: BoxDecoration(color: tone.withValues(alpha: .12),
            borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, size: 21, color: tone)),
        const SizedBox(width: 11),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: FontWeight.w800,
                color: UnifiedStyle.ink(context), fontSize: 12)),
            if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 3),
              child: Text(subtitle!, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: TextStyle(color: UnifiedStyle.muted(context), fontSize: 10))),
          ])),
        trailing ?? Icon(Icons.chevron_left_rounded,
          color: UnifiedStyle.muted(context), size: 19),
      ])),
  );
}

class UnifiedStudentTile extends StatelessWidget {
  const UnifiedStudentTile({super.key, required this.student, required this.index,
    required this.onTap, this.height = 171});
  final UnifiedStudent student;
  final int index;
  final VoidCallback onTap;
  final double height;
  static const shades = <(Color, Color)>[
    (Color(0xff3e77a9), Color(0xff5f9ac7)),
    (Color(0xff8062a4), Color(0xffa185bc)),
    (Color(0xff148f80), Color(0xff4aafa1)),
    (Color(0xffbb7d50), Color(0xffd59c71)),
    (Color(0xffa55f78), Color(0xffc17c98)),
    (Color(0xff4b859b), Color(0xff74a8b8)),
  ];
  @override Widget build(BuildContext context) {
    final palette = shades[index % shades.length];
    return Material(color: Colors.transparent, child: InkWell(onTap: onTap,
      borderRadius: BorderRadius.circular(22), child: Ink(height: height,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(begin: Alignment.topRight,
            end: Alignment.bottomLeft, colors: [palette.$1, palette.$2])),
        child: Stack(children: [
          PositionedDirectional(bottom: -46, start: -29,
            child: Container(width: 130, height: 130,
              decoration: BoxDecoration(shape: BoxShape.circle,
                color: Colors.white.withValues(alpha: .10)))),
          Padding(padding: const EdgeInsets.all(13),
            child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(width: 34, height: 34,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: .19),
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(color: Colors.white.withValues(alpha: .25))),
                    child: Text(student.name.isEmpty ? 'ت' : student.name[0],
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
                  const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 18),
                ]),
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(student.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14,
                    fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(student.group, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xfff0f6fb), fontSize: 10)),
                if (student.registerNumber.isNotEmpty)
                  Text('قيد ${student.registerNumber}', maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Color(0xffeff6f9), fontSize: 9)),
                const SizedBox(height: 9),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Flexible(child: Text(student.attendance, maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white, fontSize: 9,
                      fontWeight: FontWeight.w800))),
                  Text('${student.gradeCount} درجات',
                    style: const TextStyle(color: Colors.white, fontSize: 9)),
                ]),
              ]),
            ])),
        ]))),
    );
  }
}

class UnifiedHomePage extends StatelessWidget {
  const UnifiedHomePage({super.key, required this.school, required this.dayName,
    required this.lessons, required this.students, required this.classCount,
    required this.tasks, required this.progress, required this.onSection,
    required this.onDay, required this.onAttendance, required this.onStudent,
    required this.onStats, required this.onTeacherHub, required this.onLibrary,
    required this.onSearch, this.tab = 0, this.cardHeight = 158});
  final String school, dayName, tasks, progress;
  final List<UnifiedLesson> lessons;
  final List<UnifiedStudent> students;
  final int classCount;
  final int tab;
  final double cardHeight;
  final void Function(String) onSection;
  final VoidCallback onDay, onAttendance, onStudent,
      onStats, onTeacherHub, onLibrary, onSearch;

  @override Widget build(BuildContext context) {
    final unregistered = students.where((s) => s.attendance == 'غير مسجّل').length;
    return ColoredBox(color: UnifiedStyle.bg(context), child: ListView(
      key: const PageStorageKey('madrasati-unified-home-scroll'),
      padding: const EdgeInsets.fromLTRB(14, 1, 14, 105),
      children: [
        UnifiedHero(
          key: const ValueKey('unified-home-hero'),
          title: tab == 1 ? 'اليوم الدراسي' : tab == 2 ? 'مركز المهام' :
              tab == 3 ? 'نبض المدرسة' : 'مدرستك، بنظام واحد',
          description: tab == 0
              ? 'جدولك وحضور التلاميذ وتنبيهاتك وكتبك ومستمسكاتك؛ جميعها في تجربة عربية هادئة ومتناسقة.'
              : 'بيانات أقسام مدرستي الأصلية في عرض موحّد ومريح.',
          kicker: '$school • تجربة موحدة حقيقية',
          icon: tab == 0 ? Icons.school_outlined :
              tab == 1 ? Icons.calendar_today_outlined :
              tab == 2 ? Icons.task_alt_rounded : Icons.stacked_bar_chart_outlined,
          first: const Color(0xff066d71), last: const Color(0xff264b73),
          chips: [
            (Icons.calendar_today_outlined, dayName),
            (Icons.verified_user_outlined, 'بيانات مدرسية محلية'),
            (Icons.auto_awesome_outlined, 'أقسام مترابطة'),
          ]),
        if (tab == 0) ...[
          const UnifiedHeading('أقسام التطبيق', subtitle: 'انتقل إلى قسم وجوده في أنشطتك اليومية'),
          LayoutBuilder(builder: (context, box) {
            const gap = 12.0;
            final half = (box.maxWidth - gap) / 2;
            return Wrap(spacing: gap, runSpacing: gap, children: [
              for (final section in unifiedSections)
                SizedBox(width: section.id == 'scanner' ? box.maxWidth : half,
                  child: UnifiedFeatureCard(
                    key: ValueKey('unified-section-${section.id}'),
                    title: section.title, description: section.subtitle,
                    icon: section.icon, first: section.first, last: section.last,
                    height: section.id == 'scanner' ? 126 : cardHeight,
                    onPressed: () => onSection(section.id))),
            ]);
          }),
          const UnifiedHeading('اختصارات يومك', subtitle: 'خطوات سريعة من الأدوات الأكثر استخدامًا'),
          _quickGrid([
            ('ملف التلميذ', Icons.person_outline_rounded, onStudent),
            ('حضور اليوم', Icons.task_alt_rounded, onAttendance),
            ('حصص اليوم', Icons.calendar_month_outlined, onDay),
            ('بطاقة في دقيقة', Icons.document_scanner_outlined, () => onSection('scanner')),
            ('البحث الشامل', Icons.search_rounded, onSearch),
            ('مركز المعلم', Icons.school_outlined, onTeacherHub),
          ]),
          const UnifiedHeading('نبض المدرسة', subtitle: 'أرقام حقيقية من السجلات المحفوظة'),
          _metricGrid([
            ('${students.length}', 'عدد التلاميذ', Icons.people_outline,
                const Color(0xffe4f4ef), const Color(0xff348d86)),
            ('$unregistered', 'غير مسجل حضورهم', Icons.history_rounded,
                const Color(0xffe8f0fb), const Color(0xff7393b8)),
            ('${classCount}', 'الصفوف والشعب', Icons.school_outlined,
                const Color(0xffefe8f7), const Color(0xff85739d)),
            (tasks, 'مهام متبقية', Icons.task_alt_outlined,
                const Color(0xffe9f2f7), const Color(0xff739ab0)),
          ]),
          _todayLessons(context),
          const UnifiedHeading('كيف يعمل الترابط؟'),
          UnifiedPanel(child: Column(children: [
            UnifiedRow(icon: Icons.calendar_month_outlined, title: 'جدولي ← الجرس',
              subtitle: 'الحصة بعد حفظها في الجدول يمكن نقلها إلى برنامج الجرس.',
              onTap: () => onSection('jadwali')),
            Divider(height: 12, color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.people_outline_rounded, title: 'سجلي ← الإحصائيات',
              subtitle: 'تحديث الحضور في السجل ينعكس في المؤشرات والتقارير.', onTap: onStats),
            Divider(height: 12, color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.attach_file_outlined, title: 'مستمسكاتي ← ملف التلميذ',
              subtitle: 'احفظ صور المستمسكات وأرفقها من ملف التلميذ الأصلي.',
              onTap: () => onSection('scanner')),
            Divider(height: 12, color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.menu_book_outlined, title: 'المناهج ← الرئيسية',
              subtitle: 'افتح المكتبة وتابع تنزيل الكتب والدروس.', onTap: onLibrary),
          ])),
        ] else if (tab == 1) ...[
          _todayLessons(context),
          UnifiedHeading('إدارة يومك', subtitle: 'الحصص والحضور مرتبطة بالأقسام الأصلية',
            action: UnifiedPillButton(label: 'عرض الجدول',
                onPressed: () => onSection('jadwali'))),
          _quickGrid([
            ('الحضور', Icons.task_alt_rounded, onAttendance),
            ('الجرس', Icons.notifications_outlined, () => onSection('bell')),
            ('الكتب', Icons.menu_book_outlined, onLibrary),
            ('مركز المعلم', Icons.school_outlined, onTeacherHub),
          ]),
        ] else if (tab == 2) ...[
          UnifiedHeading('متابعة مهامك', subtitle: 'تعتمد على مركز المعلم المحفوظ فعليًا'),
          UnifiedPanel(child: Column(children: [
            UnifiedRow(icon: Icons.task_alt_outlined, title: '$tasks مهام متبقية',
              subtitle: 'فتح وإدارة المهام من مركز المعلم', onTap: onTeacherHub),
            Divider(color: UnifiedStyle.line(context)),
            UnifiedRow(icon: Icons.auto_stories_outlined, title: 'إنجاز المناهج: $progress',
              subtitle: 'راجع الدروس المنجزة من لوحة المتابعة', onTap: onTeacherHub),
          ])),
        ] else ...[
          const UnifiedHeading('المدرسة بالأرقام', subtitle: 'مؤشرات مستخرجة من سجلي وجدولي'),
          _metricGrid([
            ('${students.length}', 'التلاميذ', Icons.people_outline, const Color(0xffe5f5ed), const Color(0xff258f79)),
            ('$unregistered', 'غير مسجّل', Icons.history_rounded, const Color(0xffeef1fa), const Color(0xff7c8db4)),
            ('${lessons.length}', 'حصص اليوم', Icons.calendar_today_outlined, const Color(0xffe9f2f9), const Color(0xff5987b1)),
            (progress, 'إنجاز المنهج', Icons.donut_large_rounded, const Color(0xfff2ebf8), const Color(0xff846cac)),
          ]),
          const SizedBox(height: 13),
          UnifiedPillButton(label: 'إحصائيات المدرسة',
            icon: Icons.stacked_bar_chart_outlined, onPressed: onStats),
        ],
      ],
    ));
  }

  Widget _quickGrid(List<(String, IconData, VoidCallback)> items) =>
      LayoutBuilder(builder: (context, box) => Wrap(spacing: 11, runSpacing: 11,
        children: [for (final item in items)
          SizedBox(width: (box.maxWidth - 11) / 2,
            child: UnifiedQuick(title: item.$1, icon: item.$2, onTap: item.$3))]));

  Widget _metricGrid(List<(String, String, IconData, Color, Color)> items) =>
      LayoutBuilder(builder: (context, box) => Wrap(spacing: 12, runSpacing: 12,
        children: [for (final item in items)
          SizedBox(width: (box.maxWidth - 12) / 2,
            child: UnifiedMetric(value: item.$1, label: item.$2,
              icon: item.$3, tint: item.$4, tone: item.$5))]));

  Widget _todayLessons(BuildContext context) => Column(children: [
    UnifiedHeading('حصصك القادمة', subtitle: 'مرتبطة بجدولي للصف والتاريخ المحددين',
      action: UnifiedPillButton(label: 'الجدول الكامل',
          onPressed: () => onSection('jadwali'))),
    UnifiedPanel(child: lessons.isEmpty
      ? UnifiedRow(icon: Icons.info_outline, title: 'لا توجد حصص لهذا اليوم أو الصف',
          subtitle: 'يمكنك إعداد الجدول من قسم جدولي ثم العودة إلى هنا.',
          onTap: () => onSection('jadwali'))
      : Column(children: [
          for (final lesson in lessons.take(5)) ...[
            UnifiedRow(icon: Icons.event_note_outlined,
              title: 'الحصة ${lesson.period} • ${lesson.subject}',
              subtitle: '${lesson.time}${lesson.teacher.isNotEmpty ? ' • ${lesson.teacher}' : ''}',
              onTap: () => onSection('jadwali'),
              trailing: CircleAvatar(radius: 15,
                backgroundColor: const Color(0xffe6f5f1),
                child: Text('${lesson.period}', style: const TextStyle(
                  fontSize: 11, color: UnifiedStyle.turquoise,
                  fontWeight: FontWeight.w800))),
            ),
            if (lesson != lessons.take(5).last)
              Divider(height: 6, color: UnifiedStyle.line(context)),
          ],
        ])),
  ]);
}

class UnifiedSectionPage extends StatefulWidget {
  const UnifiedSectionPage({super.key, required this.spec, required this.school,
    required this.dayName, required this.lessons, required this.students,
    required this.classCount, required this.onOpenNative,
    required this.onOpenSection, required this.onStudent,
    required this.onAttendance, required this.onStatistics,
    required this.onTransferToBell, required this.onOpenBooks,
    required this.onChangeDay, this.onOpenReports, this.groupLabel = ''});
  final UnifiedSectionSpec spec;
  final String school, dayName, groupLabel;
  final List<UnifiedLesson> lessons;
  final List<UnifiedStudent> students;
  final int classCount;
  final VoidCallback onOpenNative, onAttendance, onStatistics,
      onTransferToBell, onOpenBooks, onChangeDay;
  final VoidCallback? onOpenReports;
  final void Function(String) onOpenSection;
  final void Function(String) onStudent;

  @override State<UnifiedSectionPage> createState() => _UnifiedSectionPageState();
}

class _UnifiedSectionPageState extends State<UnifiedSectionPage> {
  String tab = 'main';
  String search = '';
  String group = '';
  String selectedStudent = '';
  int shownStudents = 24;

  @override Widget build(BuildContext context) => ColoredBox(
    color: UnifiedStyle.bg(context),
    child: Column(children: [
      Expanded(child: ListView(
        key: PageStorageKey('unified-${widget.spec.id}-$tab'),
        padding: const EdgeInsets.fromLTRB(14, 1, 14, 14),
        children: [
          UnifiedHero(key: ValueKey('unified-${widget.spec.id}-hero'),
            title: widget.spec.heroTitle,
            description: widget.spec.description,
            kicker: '${widget.school} • ${widget.spec.subtitle}',
            icon: widget.spec.icon,
            first: widget.spec.first, last: widget.spec.last,
            chips: _chips()),
          ..._tabContent(context),
          const SizedBox(height: 13),
          UnifiedPanel(child: UnifiedRow(
            key: const ValueKey('unified-native-tool-launch'),
            icon: Icons.open_in_full_rounded,
            title: 'فتح جميع أدوات القسم الأصلية',
            subtitle: 'تعمل بالبيانات الحقيقية ومحرك القسم الأصلي دون فقدان الوظائف.',
            tone: widget.spec.first,
            onTap: widget.onOpenNative,
          )),
          const SizedBox(height: 22),
        ],
      )),
      _moduleNavigation(context),
    ]),
  );

  List<(IconData, String)> _chips() => switch (widget.spec.id) {
    'jadwali' => [
        (Icons.calendar_today_outlined, widget.dayName),
        (Icons.school_outlined, widget.groupLabel.isEmpty ? 'اختر الصف' : widget.groupLabel),
        (Icons.done_all_rounded, 'جدول أصلي'),
      ],
    'sajli' => [
        (Icons.people_outline, '${widget.students.length} تلميذ'),
        (Icons.calendar_today_outlined, widget.dayName),
        (Icons.verified_user_outlined, 'ملفات حقيقية'),
      ],
    'bell' => [
        (Icons.schedule_outlined, '${widget.lessons.length} حصص من جدولي'),
        (Icons.notifications_active_outlined, 'جرس أصلي'),
      ],
    'library' => [
        (Icons.menu_book_outlined, 'كتب المناهج'),
        (Icons.verified_user_outlined, 'مزامنة الأصل'),
      ],
    _ => [
        (Icons.document_scanner_outlined, '4 أماميات + 4 خلفيات'),
        (Icons.print_outlined, 'A4 فقط'),
        (Icons.shield_outlined, 'حفظ محلي'),
      ],
  };

  Widget _moduleNavigation(BuildContext context) => SafeArea(top: false, child:
    Container(margin: const EdgeInsets.fromLTRB(12, 6, 12, 8),
      padding: const EdgeInsets.fromLTRB(4, 5, 4, 5),
      decoration: BoxDecoration(color: UnifiedStyle.surface(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: UnifiedStyle.line(context)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .08),
          blurRadius: 17, offset: const Offset(0, 5))]),
      child: Row(children: [
        for (final choice in widget.spec.tabs)
          Expanded(child: InkWell(
            key: ValueKey('unified-tab-${widget.spec.id}-${choice.id}'),
            onTap: () { setState(() => tab = choice.id); },
            borderRadius: BorderRadius.circular(12),
            child: Container(
              height: 54,
              decoration: BoxDecoration(
                color: tab == choice.id
                    ? widget.spec.first.withValues(alpha: .12) : Colors.transparent,
                borderRadius: BorderRadius.circular(12)),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(choice.icon, size: 21,
                  color: tab == choice.id ? widget.spec.first : UnifiedStyle.muted(context)),
                const SizedBox(height: 5),
                Text(choice.title, maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 9, fontWeight: tab == choice.id
                      ? FontWeight.w900 : FontWeight.w700,
                    color: tab == choice.id ? widget.spec.first : UnifiedStyle.muted(context))),
              ]),
            ),
          )),
      ])));

  List<Widget> _tabContent(BuildContext context) => switch (widget.spec.id) {
    'jadwali' => _jadwali(context),
    'sajli' => _sajli(context),
    'bell' => _bell(context),
    'library' => _library(context),
    _ => _scanner(context),
  };

  List<Widget> _jadwali(BuildContext context) {
    if (tab == 'repair') return [
      const UnifiedHeading('الإصلاح الذكي', subtitle: 'أقل تغيير ممكن مع الحفاظ على قيود المعلمين'),
      _actionPanel([
        ('معالجة التعارضات', 'الإصلاح الذكي يبحث عن تبديل مباشر أو سلسلة حصص.',
          Icons.swap_horiz_rounded, widget.onOpenNative),
        ('فحص حصة محددة', 'شاهد أسباب تعذّر التبديل واقتراحات الإصلاح.',
          Icons.rule_rounded, widget.onOpenNative),
      ]),
      _notice('الخوارزمية الحقيقية تعمل في جدولي الأصلي؛ لا يتم إنشاء جدول تجريبي أو تعديل الحصص من هذه الواجهة.'),
    ];
    if (tab == 'reports') return [
      const UnifiedHeading('تقارير جدولي', subtitle: 'A4 عمودي أو أفقي فقط'),
      _actionPanel([
        ('جدول الصفوف', 'جميع الصفوف لكل يوم، وألوان مختلفة بين الأيام.',
          Icons.table_rows_outlined, widget.onOpenNative),
        ('نصاب المعلم', 'تقارير حصص المعلمين بألوان وفواصل واضحة.',
          Icons.bar_chart_rounded, widget.onOpenNative),
        ('تصدير Word / PDF / Excel', 'التصدير الحقيقي من محرك التقارير الأصلي.',
          Icons.print_outlined, widget.onOpenNative),
      ]),
    ];
    if (tab == 'tools') return [
      const UnifiedHeading('إعداد الجدول', subtitle: 'الصفوف والشعب، المعلمون، المواد والقيود'),
      _quickGrid([
        ('الشعب', Icons.school_outlined, widget.onOpenNative),
        ('المعلمون', Icons.people_alt_outlined, widget.onOpenNative),
        ('المواد', Icons.menu_book_outlined, widget.onOpenNative),
        ('القيود', Icons.tune_outlined, widget.onOpenNative),
      ]),
      const UnifiedHeading('قواعد محفوظة'),
      UnifiedPanel(child: Column(children: [
        UnifiedRow(icon: Icons.calendar_month_outlined,
          title: 'ست حصص افتراضيًا', subtitle: 'الصف السادس يوم الأحد سبع حصص؛ قابلة للتعديل في الجدول الأصلي.',
          onTap: widget.onOpenNative),
        Divider(color: UnifiedStyle.line(context)),
        UnifiedRow(icon: Icons.rule_rounded, title: 'قيود المعلمين والتعارضات',
          subtitle: 'لا يتم تجاوز القيود في واجهة العرض.', onTap: widget.onOpenNative),
      ])),
    ];
    return [
      UnifiedHeading('جدول اليوم', subtitle: 'الحصص الفعلية للصف المحدد',
        action: UnifiedPillButton(label: widget.dayName,
          icon: Icons.calendar_today_outlined, onPressed: widget.onChangeDay)),
      _lessonPanel(context, open: widget.onOpenNative),
      const UnifiedHeading('إجراءات سريعة', subtitle: 'كل أداة مرتبطة بمحرك جدولي الأصلي'),
      _quickGrid([
        ('إصلاح التعارضات', Icons.swap_horiz_rounded, () => setState(() => tab = 'repair')),
        ('تقارير A4', Icons.summarize_outlined, () => setState(() => tab = 'reports')),
        ('إعداد المدرسة', Icons.tune_rounded, () => setState(() => tab = 'tools')),
        ('الجرس المرتبط', Icons.notifications_none_rounded, () => widget.onOpenSection('bell')),
      ]),
      const UnifiedHeading('ربط الجدول بالجرس', subtitle: 'نقل مواد وأوقات الحصص من الجدول الحقيقي'),
      UnifiedPanel(child: Column(children: [
        const Text('لا تُعدّل هذه العملية خوارزمية الجدول؛ بل تنقل الحصص المحفوظة إلى برنامج جرس المعلم بعد تأكيدك.',
          style: TextStyle(fontSize: 11, height: 1.8)),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: widget.onTransferToBell,
          icon: const Icon(Icons.notifications_active_outlined),
          label: const Text('نقل حصص اليوم إلى الجرس'))),
      ])),
    ];
  }

  List<Widget> _sajli(BuildContext context) {
    if (tab == 'students') return [
      const UnifiedHeading('ملف التلميذ', subtitle: 'بطاقات مربعة ملونة بحسب الصف والشعبة'),
      _studentSearch(context),
      _studentGrid(context),
    ];
    if (tab == 'attendance') return [
      UnifiedHeading('الحضور والغياب', subtitle: 'تحضير مرتبط بسجلي وإحصائيات المدرسة',
        action: UnifiedPillButton(label: 'فتح التحضير', onPressed: widget.onAttendance)),
      _attendanceMetrics(context),
      const SizedBox(height: 15),
      _actionPanel([
        ('تحضير تلاميذ اليوم', 'الحضور والغياب والعذر والتأخر من السجل الأصلي.',
          Icons.fact_check_outlined, widget.onAttendance),
        ('إحصائيات المدرسة', 'رسومات بخط رفيع وأرقام من السجلات الفعلية.',
          Icons.stacked_bar_chart_outlined, widget.onStatistics),
      ]),
    ];
    if (tab == 'reports') return [
      const UnifiedHeading('تقرير ولي الأمر', subtitle: 'أربعة أقسام مريحة وواضحة'),
      _guardianReport(context),
      const UnifiedHeading('كشوف الدرجات', subtitle: 'الأشهر والفصول والسعي والامتحان النهائي'),
      UnifiedPanel(child: Column(children: [
        UnifiedRow(icon: Icons.table_view_outlined, title: 'تقرير صف ومادة واحدة',
          subtitle: 'يشمل جميع الحقول المطلوبة والتصدير إلى A4.', onTap: widget.onOpenNative),
        Divider(color: UnifiedStyle.line(context)),
        UnifiedRow(icon: Icons.file_present_outlined, title: 'Word / PDF / Excel',
          subtitle: 'الألوان والفواصل في التقارير الأصلية.', onTap: widget.onOpenReports ?? widget.onOpenNative),
      ])),
    ];
    if (tab == 'tools') return [
      const UnifiedHeading('إدارة سجلي', subtitle: 'بيانات حقيقية من سجلي الأصلي'),
      _quickGrid([
        ('الدرجات', Icons.school_outlined, widget.onOpenNative),
        ('التلاميذ', Icons.people_outline, () => setState(() => tab = 'students')),
        ('الحضور', Icons.task_alt_outlined, widget.onAttendance),
        ('التقارير', Icons.summarize_outlined, () => setState(() => tab = 'reports')),
      ]),
      const UnifiedHeading('إحصائيات المدرسة', subtitle: 'أيقونات مرسومة بخطوط أنحف'),
      _attendanceMetrics(context),
      const SizedBox(height: 13),
      UnifiedPillButton(label: 'كل الإحصائيات', onPressed: widget.onStatistics,
          icon: Icons.stacked_bar_chart_outlined),
    ];
    return [
      UnifiedHeading('ملف التلميذ', subtitle: 'بطاقات غنية بالمعلومات ومتناسقة مع الواجهة',
        action: UnifiedPillButton(label: 'جميع التلاميذ',
          onPressed: () => setState(() => tab = 'students'))),
      _metricGrid([
        ('${widget.students.length}', 'إجمالي التلاميذ', Icons.people_outline,
          const Color(0xffe7f3fb), const Color(0xff518aa6)),
        ('${_statusCount('غير مسجّل')}', 'غير مسجل اليوم', Icons.history_rounded,
          const Color(0xffeee9f7), const Color(0xff8976aa)),
      ]),
      const UnifiedHeading('الملفات الحديثة', subtitle: 'اختر تلميذًا لفتح ملفه الحقيقي'),
      _studentGrid(context, limit: 4),
      UnifiedHeading('إحصائيات المدرسة', subtitle: 'الرسومات الداخلية بخط رفيع',
        action: UnifiedPillButton(label: 'الإحصائيات', onPressed: widget.onStatistics,
          icon: Icons.stacked_bar_chart_outlined)),
      _attendanceMetrics(context),
      const UnifiedHeading('إجراءات مهمة'),
      _quickGrid([
        ('الحضور اليومي', Icons.task_alt_outlined, widget.onAttendance),
        ('ولي الأمر', Icons.file_present_outlined, () => setState(() => tab = 'reports')),
        ('درجات التلاميذ', Icons.workspace_premium_outlined, widget.onOpenNative),
        ('ملفات التلاميذ', Icons.people_outline, () => setState(() => tab = 'students')),
      ]),
    ];
  }

  List<Widget> _bell(BuildContext context) {
    if (tab == 'alerts') return [
      const UnifiedHeading('أنواع التنبيه', subtitle: 'تنبيه فقط، اهتزاز فقط، أو نغمة فقط'),
      _actionPanel([
        ('صوت النغمة', 'اختيار نغمة من الهاتف وتعديل مستوى الصوت.',
          Icons.music_note_outlined, widget.onOpenNative),
        ('اهتزاز الحصص', 'التحكم بعدد الاهتزازات واختبارها على الجهاز.',
          Icons.vibration_rounded, widget.onOpenNative),
        ('الإشعارات والتذكيرات', 'تنبيه مستقل لكل حصة ووقت محدد.',
          Icons.notifications_active_outlined, widget.onOpenNative),
      ]),
      _notice('اهتزاز الجرس وإشعارات الخلفية يعملان من Android الأصلي؛ واجهة العرض لا تستبدل جدولة النظام.'),
    ];
    if (tab == 'tools') return [
      const UnifiedHeading('إعدادات الجرس', subtitle: 'حفظ مستقل لكل حصة'),
      _quickGrid([
        ('النغمات', Icons.music_note_rounded, widget.onOpenNative),
        ('الهزاز', Icons.vibration_rounded, widget.onOpenNative),
        ('إعادة ضبط', Icons.restart_alt_rounded, widget.onOpenNative),
        ('تنبيه مسبق', Icons.alarm_outlined, widget.onOpenNative),
      ]),
    ];
    if (tab == 'week') return [
      const UnifiedHeading('البرنامج الأسبوعي', subtitle: 'التوقيت والمواد من الجدول المعتمد'),
      _lessonPanel(context, open: widget.onOpenNative),
      const SizedBox(height: 12),
      UnifiedPillButton(label: 'إدارة الأسبوع داخل الجرس', onPressed: widget.onOpenNative),
    ];
    return [
      UnifiedHeading('حصص اليوم', subtitle: 'اتصال بالجدول المدرسي الحقيقي',
        action: UnifiedPillButton(label: 'تغيير اليوم', onPressed: widget.onChangeDay,
          icon: Icons.calendar_today_outlined)),
      _lessonPanel(context, open: widget.onOpenNative),
      const UnifiedHeading('تحكم سريع'),
      _quickGrid([
        ('توقيت الحصص', Icons.schedule_outlined, widget.onOpenNative),
        ('تجربة النغمة', Icons.volume_up_outlined, () => setState(() => tab = 'alerts')),
        ('جدول الأسبوع', Icons.calendar_view_week_outlined, () => setState(() => tab = 'week')),
        ('نقل من جدولي', Icons.swap_horiz_outlined, widget.onTransferToBell),
      ]),
    ];
  }

  List<Widget> _library(BuildContext context) {
    if (tab == 'saved') return [
      const UnifiedHeading('المفضلة والتنزيلات', subtitle: 'البيانات الأصلية تبقى في مكتبة المناهج'),
      _actionPanel([
        ('الكتب المحفوظة', 'عرض المفضلة وفتح الكتاب من القارئ المدمج.',
          Icons.bookmark_border_rounded, widget.onOpenNative),
        ('تنزيل الكتب', 'نسبة تقدم التحميل وحفظها على الجهاز.',
          Icons.file_download_outlined, widget.onOpenNative),
        ('متابعة القراءة', 'استكمال الصفحات المحفوظة في القارئ الحقيقي.',
          Icons.auto_stories_outlined, widget.onOpenNative),
      ]),
    ];
    if (tab == 'reviews') return [
      const UnifiedHeading('المراجعات والتمارين', subtitle: 'المواد والأسئلة الأصلية'),
      _actionPanel([
        ('المراجعات', 'أسئلة المراحل الدراسية دون تغيير بنك الأسئلة.',
          Icons.quiz_outlined, widget.onOpenNative),
        ('التقدم الدراسي', 'راجع الدروس والمراجعات المحفوظة.',
          Icons.insights_outlined, widget.onOpenNative),
      ]),
    ];
    if (tab == 'tools') return [
      const UnifiedHeading('إعدادات المكتبة', subtitle: 'حافظنا على صلاحيات المدير وملفات المناهج'),
      _actionPanel([
        ('قارئ PDF المدمج', 'سرعة التصفح وأوضاع العرض الأصلية.',
          Icons.picture_as_pdf_outlined, widget.onOpenNative),
        ('تنسيق الصفوف', 'ألوان المراحل والأقسام والمفضلة.',
          Icons.color_lens_outlined, widget.onOpenNative),
        ('الربط بالمناهج', 'يمكن تحديث قائمة الكتب من الإدارة المعتمدة.',
          Icons.sync_rounded, widget.onOpenNative),
      ]),
    ];
    return [
      const UnifiedHeading('المراحل الدراسية', subtitle: 'استكشف كتب المرحلة والصف الحقيقيين'),
      _quickGrid([
        ('الابتدائية', Icons.school_outlined, widget.onOpenBooks),
        ('الكتب الدراسية', Icons.menu_book_outlined, widget.onOpenBooks),
        ('المفضلة', Icons.bookmark_border_rounded, () => setState(() => tab = 'saved')),
        ('المراجعات', Icons.quiz_outlined, () => setState(() => tab = 'reviews')),
      ]),
      const UnifiedHeading('الكتب المرتبطة بالحصص', subtitle: 'تصفّح الكتب المناسبة للصف المحدد'),
      UnifiedPanel(child: Column(children: [
        for (final subject in widget.lessons.map((l) => l.subject).toSet().take(4))
          UnifiedRow(icon: Icons.menu_book_outlined,
            title: subject, subtitle: 'من جدول الصف المحدد',
            tone: const Color(0xff528db2), onTap: widget.onOpenBooks),
        if (widget.lessons.isEmpty)
          UnifiedRow(icon: Icons.library_books_outlined,
            title: 'مكتبة المناهج', subtitle: 'افتح المكتبة لتصفح الكتب والمراجعات.',
            onTap: widget.onOpenBooks),
      ])),
      const UnifiedHeading('اختصارات المكتبة'),
      _quickGrid([
        ('قارئ الكتب', Icons.auto_stories_outlined, widget.onOpenNative),
        ('التنزيلات', Icons.download_outlined, () => setState(() => tab = 'saved')),
        ('المراجعات', Icons.check_circle_outline, () => setState(() => tab = 'reviews')),
        ('الكتاب الحالي', Icons.menu_book_outlined, widget.onOpenBooks),
      ]),
    ];
  }

  List<Widget> _scanner(BuildContext context) {
    if (tab == 'card') return [
      const UnifiedHeading('بطاقة في دقيقة', subtitle: 'أربع صور أمامية وأربع صور خلفية'),
      _slots(context),
      const SizedBox(height: 12),
      UnifiedPillButton(label: 'التقاط وترتيب البطاقات',
        icon: Icons.camera_alt_outlined, onPressed: widget.onOpenNative),
    ];
    if (tab == 'print') return [
      const UnifiedHeading('الطباعة والتصدير', subtitle: 'ورقة A4 بوضع أفقي أو عمودي'),
      _actionPanel([
        ('طباعة ملصق كامل الصفحة', 'تحكم في أبعاد البطاقة والحواف الدائرية.',
          Icons.print_outlined, widget.onOpenNative),
        ('قص المستند وتجميعه', 'يحافظ المحرر الأصلي على الصورة الأصلية.',
          Icons.document_scanner_outlined, widget.onOpenNative),
      ]),
    ];
    if (tab == 'docs') return [
      const UnifiedHeading('مستنداتي', subtitle: 'أرشيف الصور المحفوظة على الهاتف'),
      _actionPanel([
        ('أرشيف المستندات', 'استعرض الصور الملتقطة والقوالب المحفوظة.',
          Icons.folder_outlined, widget.onOpenNative),
        ('رفع صورة أو التقاطها', 'كاميرا الهاتف أو معرض الصور.',
          Icons.camera_alt_outlined, widget.onOpenNative),
      ]),
    ];
    if (tab == 'tools') return [
      const UnifiedHeading('أدوات المعالجة', subtitle: 'قص دقيق وتباين ودرجة وضوح وطباعة'),
      _quickGrid([
        ('القص بأربع زوايا', Icons.crop_rotate_outlined, widget.onOpenNative),
        ('تعديل الألوان', Icons.tune_outlined, widget.onOpenNative),
        ('إخفاء معلومات', Icons.shield_outlined, widget.onOpenNative),
        ('حفظ ومشاركة', Icons.ios_share_outlined, widget.onOpenNative),
      ]),
    ];
    return [
      const UnifiedHeading('ابدأ بمستند جديد', subtitle: 'الكاميرا أو المعرض، دون فقدان الصورة الأصلية'),
      _quickGrid([
        ('تصوير أو رفع', Icons.add_a_photo_outlined, widget.onOpenNative),
        ('بطاقة في دقيقة', Icons.document_scanner_outlined,
          () => setState(() => tab = 'card')),
      ]),
      const UnifiedHeading('إدارة مستنداتك', subtitle: 'أرشيف أصلي وليست صورًا تجريبية'),
      _actionPanel([
        ('آخر مستنداتك', 'عرض صور مستمسكاتي وحفظها بأمان.',
          Icons.folder_copy_outlined, widget.onOpenNative),
        ('التصدير والطباعة', 'ملصقات A4 أو نسخ PDF.',
          Icons.print_outlined, () => setState(() => tab = 'print')),
      ]),
    ];
  }

  Widget _lessonPanel(BuildContext context, {required VoidCallback open}) =>
    UnifiedPanel(child: widget.lessons.isEmpty
      ? UnifiedRow(icon: Icons.info_outline, title: 'لا توجد حصص لهذا اليوم',
          subtitle: 'أضف الحصص إلى الجدول الحقيقي من القسم الأصلي.', onTap: open)
      : Column(children: [
          for (final lesson in widget.lessons) ...[
            UnifiedRow(icon: widget.spec.id == 'bell'
                ? Icons.notifications_none_outlined : Icons.event_note_outlined,
              title: 'الحصة ${lesson.period} • ${lesson.subject}',
              subtitle: '${lesson.time}${lesson.teacher.isNotEmpty ? ' • ${lesson.teacher}' : ''}',
              tone: widget.spec.first, onTap: open,
              trailing: Text('تعديل', style: TextStyle(
                color: widget.spec.first, fontSize: 11, fontWeight: FontWeight.w900))),
            if (lesson != widget.lessons.last)
              Divider(height: 5, color: UnifiedStyle.line(context)),
          ],
        ]));

  Widget _studentSearch(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 13), child: TextField(
      key: const ValueKey('unified-student-search'),
      onChanged: (s) => setState(() { search = s.trim(); shownStudents = 24; }),
      decoration: InputDecoration(
        filled: true, fillColor: UnifiedStyle.surface(context),
        prefixIcon: const Icon(Icons.search_rounded),
        hintText: 'ابحث عن اسم التلميذ أو رقم القيد',
        hintStyle: TextStyle(fontSize: 12, color: UnifiedStyle.muted(context)),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: UnifiedStyle.line(context))),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: UnifiedStyle.line(context))),
      ),
    ));

  Widget _studentGrid(BuildContext context, {int? limit}) {
    final groups = widget.students.map((s) => s.group).toSet().toList();
    final filtered = widget.students.where((s) =>
      (group.isEmpty || s.group == group) &&
      (search.isEmpty || s.name.contains(search) || s.registerNumber.contains(search)))
      .toList();
    final visible = filtered.take(limit ?? shownStudents).toList();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (limit == null)
        Padding(padding: const EdgeInsets.only(bottom: 12), child: SizedBox(height: 40,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            ChoiceChip(label: const Text('جميع الصفوف'), selected: group.isEmpty,
              onSelected: (_) => setState(() => group = '')),
            for (final item in groups) ...[
              const SizedBox(width: 7),
              ChoiceChip(label: Text(item, maxLines: 1,
                overflow: TextOverflow.ellipsis),
                selected: group == item,
                onSelected: (_) => setState(() { group = item; shownStudents = 24; })),
            ],
          ]))),
      if (visible.isEmpty)
        UnifiedPanel(child: UnifiedRow(icon: Icons.people_outline,
          title: 'لا توجد ملفات مطابقة',
          subtitle: 'يمكن إضافة التلاميذ أو البحث عن اسم آخر من سجلي.',
          onTap: widget.onOpenNative))
      else LayoutBuilder(builder: (context, box) => Wrap(spacing: 12, runSpacing: 12,
        children: [
          for (var i = 0; i < visible.length; i++)
            SizedBox(width: (box.maxWidth - 12) / 2,
              child: UnifiedStudentTile(key: ValueKey('unified-student-${visible[i].id}'),
                student: visible[i], index: i,
                onTap: () => widget.onStudent(visible[i].id))),
        ])),
      if (limit == null && filtered.length > visible.length)
        Padding(padding: const EdgeInsets.only(top: 12),
          child: UnifiedPillButton(label: 'عرض المزيد (${filtered.length - visible.length})',
            icon: Icons.expand_more_rounded,
            onPressed: () => setState(() => shownStudents += 24))),
    ]);
  }

  int _statusCount(String status) => widget.students.where((s) => s.attendance == status).length;

  Widget _attendanceMetrics(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final unregistered = _statusCount('غير مسجّل');
      final metrics = <(String, String, IconData, Color, Color)>[
        ('${widget.students.length}', 'عدد التلاميذ', Icons.people_outline,
            const Color(0xffe8f5f4), const Color(0xff258f83)),
        ('${widget.classCount}', 'الصفوف والشعب', Icons.school_outlined,
            const Color(0xffedf1fb), const Color(0xff778ba9)),
        ('${_statusCount('حاضر')}', 'حاضر', Icons.check_circle_outline,
            const Color(0xffe8f8ef), const Color(0xff258d72)),
        ('${_statusCount('غائب')}', 'غائب', Icons.person_off_outlined,
            const Color(0xfffff0e9), const Color(0xffc98154)),
        ('${_statusCount('متأخر')}', 'متأخر', Icons.access_time_outlined,
            const Color(0xffeaf5fa), const Color(0xff418eac)),
        ('${_statusCount('بعذر')}', 'بعذر', Icons.verified_user_outlined,
            const Color(0xfff7ecf2), const Color(0xffa6678a)),
        ('$unregistered', 'غير مسجّل', Icons.history_outlined,
            const Color(0xffeeeefa), const Color(0xff8175ac)),
      ];
      return Wrap(spacing: 11, runSpacing: 11, children: [
        for (final m in metrics)
          SizedBox(width: (box.maxWidth - 11) / 2,
            child: UnifiedMetric(value: m.$1, label: m.$2,
              icon: m.$3, tint: m.$4, tone: m.$5)),
      ]);
    },
  );

  Widget _guardianReport(BuildContext context) {
    final chosen = widget.students.where((s) => s.id == selectedStudent).firstOrNull ??
        widget.students.firstOrNull;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      if (widget.students.isNotEmpty)
        UnifiedPanel(child: DropdownButtonFormField<String>(
          value: chosen?.id,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'التلميذ'),
          items: [for (final s in widget.students)
            DropdownMenuItem(value: s.id, child: Text(s.name,
              overflow: TextOverflow.ellipsis))],
          onChanged: (v) => setState(() => selectedStudent = v ?? ''),
        )),
      const SizedBox(height: 13),
      _guardianBlock('أولًا • معلومات التلميذ', Icons.person_outline,
        const Color(0xff4e79a2), const Color(0xffeaf3fc),
        chosen == null ? ['لا توجد بيانات تلميذ'] : [
          'الاسم: ${chosen.name}', 'الصف والشعبة: ${chosen.group}',
          if (chosen.registerNumber.isNotEmpty) 'رقم القيد: ${chosen.registerNumber}',
        ]),
      _guardianBlock('ثانيًا • التحصيل الدراسي', Icons.school_outlined,
        const Color(0xff238a7a), const Color(0xffe6f5f0), [
          'درجات مسجّلة: ${chosen?.gradeCount ?? 0}',
          'التفاصيل والأشهر والفصول في تقرير سجلي الأصلي',
        ]),
      _guardianBlock('ثالثًا • المواظبة والحضور', Icons.calendar_today_outlined,
        const Color(0xffb28446), const Color(0xfffff4e5), [
          'حالة اليوم: ${chosen?.attendance ?? '—'}',
          'الغياب والتأخر حسب سجل التحضير الفعلي',
        ]),
      _guardianBlock('رابعًا • الملاحظات والتوصيات', Icons.note_alt_outlined,
        const Color(0xff9366a9), const Color(0xfff5edfa), [
          'تُعرض الملاحظات المحفوظة من سجلي الحقيقي.',
          'لا تُنشئ الواجهة تعليقات أو نتائج غير موجودة.',
        ]),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, child: FilledButton.icon(
        onPressed: widget.onOpenReports ?? widget.onOpenNative,
        icon: const Icon(Icons.print_outlined),
        label: const Text('عرض وطباعة التقرير الكامل A4'))),
    ]);
  }

  Widget _guardianBlock(String label, IconData icon, Color tone, Color bg,
      List<String> fields) => Padding(padding: const EdgeInsets.only(bottom: 11),
    child: UnifiedPanel(padding: EdgeInsets.zero,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
          decoration: BoxDecoration(color: bg,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(21), topRight: Radius.circular(21))),
          child: Row(children: [Icon(icon, color: tone, size: 19),
            const SizedBox(width: 9),
            Expanded(child: Text(label, style: TextStyle(
              color: tone, fontSize: 13, fontWeight: FontWeight.w900))),
          ])),
        Padding(padding: const EdgeInsets.all(14), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [for (final field in fields)
            Padding(padding: const EdgeInsets.only(bottom: 6),
              child: Text(field, style: const TextStyle(fontSize: 11, height: 1.7)))])),
      ])));

  Widget _actionPanel(List<(String, String, IconData, VoidCallback)> actions) =>
    UnifiedPanel(child: Column(children: [
      for (var i = 0; i < actions.length; i++) ...[
        UnifiedRow(title: actions[i].$1, subtitle: actions[i].$2,
          icon: actions[i].$3, tone: widget.spec.first, onTap: actions[i].$4),
        if (i != actions.length - 1)
          Divider(height: 7, color: UnifiedStyle.border),
      ],
    ]));

  Widget _quickGrid(List<(String, IconData, VoidCallback)> actions) =>
    LayoutBuilder(builder: (context, box) => Wrap(spacing: 11, runSpacing: 11,
      children: [for (final action in actions)
        SizedBox(width: (box.maxWidth - 11) / 2,
          child: UnifiedQuick(title: action.$1, icon: action.$2,
              onTap: action.$3))]));

  Widget _metricGrid(List<(String, String, IconData, Color, Color)> metrics) =>
    LayoutBuilder(builder: (context, box) => Wrap(spacing: 12, runSpacing: 12,
      children: [for (final metric in metrics)
        SizedBox(width: (box.maxWidth - 12) / 2,
          child: UnifiedMetric(value: metric.$1, label: metric.$2,
              icon: metric.$3, tint: metric.$4, tone: metric.$5))]));

  Widget _notice(String text) => Padding(padding: const EdgeInsets.only(top: 13),
    child: Container(padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(color: const Color(0xffeaf3f6),
        borderRadius: BorderRadius.circular(13)),
      child: Row(children: [
        const Icon(Icons.info_outline, color: UnifiedStyle.turquoise, size: 19),
        const SizedBox(width: 8),
        Expanded(child: Text(text, style: const TextStyle(
          fontSize: 11, color: UnifiedStyle.foreground, height: 1.7))),
      ])));

  Widget _slots(BuildContext context) => LayoutBuilder(builder: (context, box) {
    return Wrap(spacing: 9, runSpacing: 9, children: [
      for (var i = 0; i < 8; i++)
        SizedBox(width: (box.maxWidth - 9) / 2,
          child: Material(color: UnifiedStyle.surface(context),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15),
              side: BorderSide(color: UnifiedStyle.line(context))),
            child: InkWell(onTap: widget.onOpenNative,
              borderRadius: BorderRadius.circular(15),
              child: SizedBox(height: 100, child: Column(
                mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.add_photo_alternate_outlined,
                    color: UnifiedStyle.muted(context), size: 26),
                  const SizedBox(height: 5),
                  Text(i.isEven ? 'الأمامي ${i ~/ 2 + 1}' : 'الخلفي ${i ~/ 2 + 1}',
                    style: TextStyle(color: UnifiedStyle.muted(context), fontSize: 12)),
                ]))),
          )),
    ]);
  });
}
