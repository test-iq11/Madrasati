"""Lightweight structural sanity check (NOT a Dart parser / flutter analyze)."""
from pathlib import Path

FILES = [Path(x) for x in ('lib/main.dart', 'lib/mosaic_home.dart', 'lib/bottom_nav.dart',
          'lib/modern_day_panel.dart', 'lib/teacher_hub.dart',
          'lib/school_tools.dart', 'lib/school_stat_icon.dart',
          'modules/sajli/lib/report.dart', 'modules/sajli/lib/report_data.dart',
          'modules/sajli/lib/office.dart', 'modules/sajli/lib/main.dart',
          'modules/scanner/lib/main.dart', 'test/modern_preview_test.dart',
          'test/school_statistics_grid_test.dart',
          'modules/sajli/test/student_picker_grid_test.dart',
          'modules/sajli/test/parent_report_layout_test.dart')]

for path in FILES:
    src = path.read_text(encoding='utf-8')
    stack = []
    state = 'code'
    q = ''
    depth = 0
    i = 0
    while i < len(src):
        c = src[i]
        n = src[i:i+2]
        if state == 'code':
            if n == '//': state = 'line'; i += 2; continue
            if n == '/*': state = 'comment'; depth = 1; i += 2; continue
            if c in "'\"":
                q = c * (3 if src[i:i+3] == c*3 else 1)
                state = 'string'; i += len(q); continue
            if c in '([{': stack.append((c,i))
            elif c in ')]}':
                if not stack:
                    raise ValueError(f'{path}: extra {c} at {i}')
                d,j = stack.pop()
                if (d,c) not in [('(',')'),('[',']'),('{','}')]:
                    raise ValueError(f'{path}: {d} at {j} mismatches {c} at {i}')
        elif state == 'line':
            if c == '\n': state = 'code'
        elif state == 'comment':
            if n == '/*': depth += 1; i += 2; continue
            if n == '*/':
                depth -= 1; i += 2
                if depth == 0: state = 'code'
                continue
        elif state == 'string':
            if c == '\\' and i + 1 < len(src): i += 2; continue
            if src[i:i+len(q)] == q:
                i += len(q); state = 'code'; continue
        i += 1
    if stack or state not in ('code', 'line'):
        raise ValueError(f'{path}: unmatched {stack[-3:]} state {state}')
    print(f'{path}: delimiters balanced (not compilation)')
